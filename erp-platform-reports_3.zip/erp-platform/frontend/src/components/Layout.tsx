import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCompany } from '../context/CompanyContext';

const NAV_GROUPS: { label: string; links: { to: string; label: string }[] }[] = [
  { label: 'Overview', links: [
    { to: '/', label: 'Dashboard' },
    { to: '/reports', label: 'Reports' },
  ] },
  { label: 'Selling', links: [
    { to: '/pos', label: 'Point of Sale' },
    { to: '/receivables', label: 'Sales & Receivables' },
  ] },
  { label: 'Buying', links: [{ to: '/payables', label: 'Purchasing & Payables' }] },
  { label: 'Operations', links: [
    { to: '/inventory', label: 'Inventory' },
    { to: '/fixed-assets', label: 'Fixed Assets' },
  ] },
  { label: 'Finance', links: [
    { to: '/accounting', label: 'General Ledger' },
    { to: '/banking', label: 'Banking' },
    { to: '/currency', label: 'Currency Mgmt' },
  ] },
  { label: 'Reports', links: [
    { to: '/reports/fs-profit-loss', label: 'Profit & Loss' },
    { to: '/reports/fs-balance-sheet', label: 'Balance Sheet' },
    { to: '/reports/fs-cash-flow', label: 'Cash Flow' },
    { to: '/reports/vat-return', label: 'VAT Return' },
  ] },
  { label: 'Admin', links: [{ to: '/settings', label: 'Settings' }] },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const { companies, company, setCompanyId } = useCompany();

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">Kruxus ERP</div>
        {NAV_GROUPS.map((g) => (
          <div key={g.label}>
            <div className="sidebar-group">{g.label}</div>
            {g.links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === '/' || l.to === '/reports'}
                className={({ isActive }) => 'sidebar-link' + (isActive ? ' active' : '')}
              >
                {l.label}
              </NavLink>
            ))}
          </div>
        ))}
      </aside>
      <div className="main-area">
        <div className="topbar">
          <select
            value={company?.id || ''}
            onChange={(e) => setCompanyId(Number(e.target.value))}
            style={{ minWidth: 260 }}
          >
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.baseCurrency})
              </option>
            ))}
          </select>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <span style={{ color: 'var(--text-dim)', fontSize: 13 }}>
              {user?.fullName} · {user?.role}
            </span>
            <button className="btn secondary" onClick={logout}>
              Log out
            </button>
          </div>
        </div>
        <div className="content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
