import React from 'react';

/**
 * Catches render / lazy-load errors so one broken page or card shows a
 * readable message (with a retry) instead of blanking the whole app.
 */
export default class ErrorBoundary extends React.Component<
  { children: React.ReactNode; label?: string; compact?: boolean },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error) {
    // eslint-disable-next-line no-console
    console.error(`[${this.props.label || 'page'}]`, error);
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    const msg = String(error?.message || error);
    const missingPkg = /Failed to fetch dynamically imported module|Failed to resolve import|Importing a module script failed|error loading dynamically imported module/i.test(msg);
    if (this.props.compact)
      return (
        <div className="card" style={{ color: 'var(--text-dim)', fontSize: 12 }}>
          {this.props.label || 'This section'} could not be displayed ({msg.slice(0, 120)}).
        </div>
      );
    return (
      <div className="card" style={{ maxWidth: 760, borderColor: 'var(--danger)' }}>
        <h3 style={{ marginTop: 0 }}>{this.props.label || 'This page'} could not be loaded</h3>
        {missingPkg ? (
          <p style={{ fontSize: 13, lineHeight: 1.6 }}>
            Some newly added packages (PDF / Excel export) are not installed yet. Close the two black <b>Backend</b> and <b>Frontend</b>{' '}
            windows and double-click <b>start_kruxus.bat</b> again - it installs them automatically. (Or run <code>npm install</code> in the{' '}
            <code>frontend</code> folder.)
          </p>
        ) : (
          <p style={{ fontSize: 13 }}>Technical detail: {msg}</p>
        )}
        <button className="btn" onClick={() => window.location.reload()}>
          Reload
        </button>
      </div>
    );
  }
}
