import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany } from '../context/CompanyContext';
import { useAuth } from '../context/AuthContext';

// ---------------------------------------------------------------------------
// Types (field names/shapes mirror the backend entities/DTOs exactly — see
// backend/src/modules/pos/*.entity.ts, pos.service.ts, pos.controller.ts)
// ---------------------------------------------------------------------------

type PosSessionStatus = 'OPEN' | 'CLOSED';

interface PosSession {
  id: number;
  companyId: number;
  branchId: number | null;
  cashierId: number;
  openedAt: string;
  closedAt: string | null;
  openingCashMinor: string;
  closingCashMinor: string | null;
  status: PosSessionStatus;
  notes: string | null;
  createdAt: string;
}

type ItemType = 'STOCK' | 'SERVICE' | 'NON_STOCK';

// PosService.lookupItem() result shape — note it does NOT include
// defaultTaxRateId, so it alone is not enough to preview tax client-side.
interface LookupItemResult {
  id: number;
  sku: string;
  name: string;
  itemType: ItemType;
  salesPriceMinor: number;
  currencyCode: string;
  quantityOnHand?: number;
}

// Subset of Item we fetch (lazily, per distinct item added to the cart) from
// GET /inventory/items/:id purely to resolve a client-side tax preview the
// same way InvoicesService/ItemsService.resolveGlAccounts does on the
// backend: item.defaultTaxRateId, falling back to its item class's default.
interface ItemDetailLite {
  itemClassId: number | null;
  defaultTaxRateId: number | null;
}

interface ItemClassLite {
  id: number;
  defaultTaxRateId: number | null;
}

interface TaxRate {
  id: number;
  companyId: number;
  code: string;
  name: string;
  rateBasisPoints: number;
  pricingMode: 'EXCLUSIVE' | 'INCLUSIVE';
  isVat: boolean;
  isActive: boolean;
}

interface Customer {
  id: number;
  code: string;
  name: string;
  isActive: boolean;
}

interface Account {
  id: number;
  code: string;
  name: string;
  accountType: string;
  isActive: boolean;
}

type TenderType = 'CASH' | 'CARD' | 'ON_ACCOUNT';

interface CartLine {
  itemId: number;
  sku: string;
  name: string;
  unitPriceMinor: number;
  currencyCode: string;
  itemType: ItemType;
  quantityOnHand?: number;
  quantity: number;
}

interface PosSaleLineResult {
  id: number;
  itemId: number;
  description: string;
  quantity: string;
  unitPriceMinor: string;
  taxRateId: number | null;
  lineTotalMinor: string;
}

interface PosSaleResult {
  id: number;
  saleNumber: string;
  sessionId: number;
  customerId: number;
  saleDate: string;
  subtotalMinor: string;
  taxMinor: string;
  totalMinor: string;
  tenderType: TenderType;
  tenderedMinor: string;
  changeMinor: string;
  invoiceId: number;
  status: string;
  lines: PosSaleLineResult[];
}

interface CheckoutResult {
  sale: PosSaleResult;
  invoiceNumber: string;
  changeMinor: number;
}

function roundUpToNearest(minor: number, stepMajor: number): number {
  const stepMinor = stepMajor * 100;
  if (minor <= 0) return stepMinor;
  return Math.ceil(minor / stepMinor) * stepMinor;
}

export default function PosPage() {
  const { company } = useCompany();
  const { user } = useAuth();

  // ---- POS session state ----
  const [session, setSession] = useState<PosSession | null>(null);
  const [sessionChecked, setSessionChecked] = useState(false);
  const [openingCashMajor, setOpeningCashMajor] = useState('');
  const [openBusy, setOpenBusy] = useState(false);
  const [openError, setOpenError] = useState('');
  const [showClosePanel, setShowClosePanel] = useState(false);
  const [closingCashMajor, setClosingCashMajor] = useState('');
  const [closeBusy, setCloseBusy] = useState(false);
  const [closeError, setCloseError] = useState('');

  // ---- Reference data ----
  const [taxRates, setTaxRates] = useState<TaxRate[]>([]);
  const [itemClasses, setItemClasses] = useState<ItemClassLite[]>([]);
  const [itemDetailCache, setItemDetailCache] = useState<Record<number, ItemDetailLite>>({});
  const itemDetailFetching = useRef<Set<number>>(new Set());
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);

  // ---- Search ----
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<LookupItemResult[]>([]);
  const [searching, setSearching] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<number | undefined>(undefined);

  // ---- Cart / checkout ----
  const [cart, setCart] = useState<CartLine[]>([]);
  const [customerId, setCustomerId] = useState<number | ''>('');
  const [tenderType, setTenderType] = useState<TenderType>('CASH');
  const [tenderedMajor, setTenderedMajor] = useState('');
  const [settlementAccountId, setSettlementAccountId] = useState<number | ''>('');
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');
  const [lastReceipt, setLastReceipt] = useState<CheckoutResult | null>(null);

  // -------------------------------------------------------------------
  // Load: open session, tax rates, item classes, customers, accounts
  // -------------------------------------------------------------------

  useEffect(() => {
    if (!company || !user) return;
    let cancelled = false;
    setSessionChecked(false);
    api
      .get('/pos/sessions', { params: { companyId: company.id } })
      .then((res) => {
        if (cancelled) return;
        const open = (res.data as PosSession[]).find(
          (s) => s.status === 'OPEN' && s.cashierId === user.id,
        );
        setSession(open || null);
      })
      .finally(() => {
        if (!cancelled) setSessionChecked(true);
      });
    return () => {
      cancelled = true;
    };
  }, [company?.id, user?.id]);

  useEffect(() => {
    if (!company) return;
    api
      .get('/tax-rates', { params: { companyId: company.id } })
      .then((res) => setTaxRates(res.data))
      .catch(() => {});
    api
      .get('/inventory/item-classes', { params: { companyId: company.id } })
      .then((res) => setItemClasses(res.data))
      .catch(() => {});
    api
      .get('/receivables/customers', { params: { companyId: company.id } })
      .then((res) => setCustomers((res.data as Customer[]).filter((c) => c.isActive)))
      .catch(() => {});
    api
      .get('/accounting/accounts', { params: { companyId: company.id } })
      .then((res) => setAccounts((res.data as Account[]).filter((a) => a.isActive)))
      .catch(() => {});
  }, [company?.id]);

  // -------------------------------------------------------------------
  // Search (debounced on type, immediate on Enter)
  // -------------------------------------------------------------------

  const runSearch = useCallback(
    async (q: string) => {
      if (!company || !q.trim()) {
        setResults([]);
        return;
      }
      setSearching(true);
      try {
        const res = await api.get('/pos/items/lookup', { params: { companyId: company.id, query: q.trim() } });
        setResults(res.data);
      } catch {
        setResults([]);
      } finally {
        setSearching(false);
      }
    },
    [company?.id],
  );

  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => runSearch(query), 250);
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [query, runSearch]);

  function onSearchKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
      runSearch(query);
    }
  }

  // -------------------------------------------------------------------
  // Item detail lazy-fetch, for the client-side tax preview only.
  // -------------------------------------------------------------------

  function ensureItemDetail(itemId: number) {
    if (itemDetailCache[itemId] || itemDetailFetching.current.has(itemId)) return;
    itemDetailFetching.current.add(itemId);
    api
      .get(`/inventory/items/${itemId}`)
      .then((res) => {
        setItemDetailCache((prev) => ({
          ...prev,
          [itemId]: {
            itemClassId: res.data.itemClassId ?? null,
            defaultTaxRateId: res.data.defaultTaxRateId ?? null,
          },
        }));
      })
      .catch(() => {})
      .finally(() => {
        itemDetailFetching.current.delete(itemId);
      });
  }

  // Returns the resolved tax rate id for an item: undefined = still loading,
  // null = resolved to "no tax". Mirrors ItemsService.resolveGlAccounts.
  function resolveTaxRateId(itemId: number): number | null | undefined {
    const detail = itemDetailCache[itemId];
    if (!detail) return undefined;
    if (detail.defaultTaxRateId != null) return detail.defaultTaxRateId;
    if (detail.itemClassId != null) {
      const cls = itemClasses.find((c) => c.id === detail.itemClassId);
      return cls?.defaultTaxRateId ?? null;
    }
    return null;
  }

  // -------------------------------------------------------------------
  // Cart mutations
  // -------------------------------------------------------------------

  function addToCart(item: LookupItemResult) {
    setCart((prev) => {
      const idx = prev.findIndex((l) => l.itemId === item.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], quantity: copy[idx].quantity + 1 };
        return copy;
      }
      return [
        ...prev,
        {
          itemId: item.id,
          sku: item.sku,
          name: item.name,
          unitPriceMinor: item.salesPriceMinor,
          currencyCode: item.currencyCode,
          itemType: item.itemType,
          quantityOnHand: item.quantityOnHand,
          quantity: 1,
        },
      ];
    });
    ensureItemDetail(item.id);
  }

  function setLineQuantity(itemId: number, quantity: number) {
    setCart((prev) => {
      if (quantity <= 0) return prev.filter((l) => l.itemId !== itemId);
      return prev.map((l) => (l.itemId === itemId ? { ...l, quantity } : l));
    });
  }

  function removeLine(itemId: number) {
    setCart((prev) => prev.filter((l) => l.itemId !== itemId));
  }

  // -------------------------------------------------------------------
  // Totals (client-side preview — see honest caveat in the UI below)
  // -------------------------------------------------------------------

  const taxRateMap = useMemo(() => {
    const m: Record<number, TaxRate> = {};
    for (const r of taxRates) m[r.id] = r;
    return m;
  }, [taxRates]);

  const lineTotals = useMemo(() => {
    return cart.map((l) => {
      const netMinor = Math.round(l.quantity * l.unitPriceMinor);
      const rateId = resolveTaxRateId(l.itemId);
      let taxMinor = 0;
      let resolving = false;
      if (rateId === undefined) {
        resolving = true;
      } else if (rateId !== null) {
        const rate = taxRateMap[rateId];
        if (rate) taxMinor = Math.round((netMinor * rate.rateBasisPoints) / 10000);
      }
      return { itemId: l.itemId, netMinor, taxMinor, resolving };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart, itemDetailCache, itemClasses, taxRateMap]);

  const subtotalMinor = lineTotals.reduce((sum, l) => sum + l.netMinor, 0);
  const taxMinor = lineTotals.reduce((sum, l) => sum + l.taxMinor, 0);
  const totalMinor = subtotalMinor + taxMinor;
  const taxStillResolving = lineTotals.some((l) => l.resolving);

  const tenderedMinor = tenderType === 'CASH' ? toMinor(Number(tenderedMajor) || 0) : totalMinor;
  const changeMinor = tenderType === 'CASH' ? tenderedMinor - totalMinor : 0;

  const quickCashOptions = useMemo(() => {
    const opts = new Set<number>();
    if (totalMinor > 0) {
      opts.add(totalMinor);
      opts.add(roundUpToNearest(totalMinor, 100));
      opts.add(roundUpToNearest(totalMinor, 500));
      opts.add(roundUpToNearest(totalMinor, 1000));
    }
    return Array.from(opts).sort((a, b) => a - b);
  }, [totalMinor]);

  useEffect(() => {
    // Prefill the tendered amount with the exact total the first time CASH
    // is selected for a sale, so the cashier usually only has to adjust it.
    if (tenderType === 'CASH' && tenderedMajor === '' && totalMinor > 0) {
      setTenderedMajor((totalMinor / 100).toFixed(2));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenderType]);

  const settlementAccountOptions = useMemo(() => {
    const assetAccounts = accounts.filter((a) => a.accountType === 'ASSET');
    return assetAccounts.length > 0 ? assetAccounts : accounts;
  }, [accounts]);

  // -------------------------------------------------------------------
  // Session open/close
  // -------------------------------------------------------------------

  async function openRegister() {
    if (!company || !user) return;
    setOpenError('');
    setOpenBusy(true);
    try {
      const res = await api.post('/pos/sessions/open', {
        companyId: company.id,
        cashierId: user.id,
        openingCashMinor: toMinor(Number(openingCashMajor) || 0),
      });
      setSession(res.data);
      setOpeningCashMajor('');
      window.setTimeout(() => searchInputRef.current?.focus(), 0);
    } catch (err: any) {
      setOpenError(err?.response?.data?.error?.message || err?.response?.data?.message || 'Could not open register');
    } finally {
      setOpenBusy(false);
    }
  }

  async function closeRegister() {
    if (!session) return;
    setCloseError('');
    setCloseBusy(true);
    try {
      await api.post(`/pos/sessions/${session.id}/close`, {
        closingCashMinor: toMinor(Number(closingCashMajor) || 0),
      });
      setSession(null);
      setShowClosePanel(false);
      setClosingCashMajor('');
      setCart([]);
    } catch (err: any) {
      setCloseError(err?.response?.data?.error?.message || err?.response?.data?.message || 'Could not close register');
    } finally {
      setCloseBusy(false);
    }
  }

  // -------------------------------------------------------------------
  // Checkout
  // -------------------------------------------------------------------

  function newSale() {
    setCart([]);
    setCustomerId('');
    setTenderType('CASH');
    setTenderedMajor('');
    setCheckoutError('');
    setLastReceipt(null);
    setQuery('');
    setResults([]);
    window.setTimeout(() => searchInputRef.current?.focus(), 0);
  }

  async function completeSale() {
    if (!company || !user || !session) return;
    setCheckoutError('');
    if (cart.length === 0) {
      setCheckoutError('Cart is empty');
      return;
    }
    if (tenderType === 'ON_ACCOUNT' && !customerId) {
      setCheckoutError('Select a customer for an on-account sale');
      return;
    }
    if ((tenderType === 'CASH' || tenderType === 'CARD') && !settlementAccountId) {
      setCheckoutError('Select a settlement account for CASH/CARD');
      return;
    }
    if (tenderType === 'CASH' && tenderedMinor < totalMinor) {
      setCheckoutError('Tendered amount is less than the sale total');
      return;
    }

    setCheckoutBusy(true);
    try {
      const res = await api.post('/pos/checkout', {
        companyId: company.id,
        sessionId: session.id,
        cashierId: user.id,
        customerId: customerId || undefined,
        lines: cart.map((l) => ({ itemId: l.itemId, quantity: l.quantity, unitPriceMinor: l.unitPriceMinor })),
        tenderType,
        tenderedMinor: tenderType === 'CASH' ? tenderedMinor : undefined,
        cashOrCardAccountId:
          tenderType === 'CASH' || tenderType === 'CARD' ? settlementAccountId : undefined,
      });
      setLastReceipt(res.data);
    } catch (err: any) {
      setCheckoutError(err?.response?.data?.error?.message || err?.response?.data?.message || 'Checkout failed');
    } finally {
      setCheckoutBusy(false);
    }
  }

  // -------------------------------------------------------------------
  // Render
  // -------------------------------------------------------------------

  if (!company) {
    return <div className="card">Loading company…</div>;
  }

  return (
    <div>
      <style>{`
        .pos-session-bar { display: flex; align-items: center; gap: 14px; font-size: 13px; color: var(--text-dim); }
        .pos-session-bar strong { color: var(--text); }
        .pos-layout { display: grid; grid-template-columns: 65% 1fr; gap: 16px; align-items: start; }
        @media (max-width: 900px) { .pos-layout { grid-template-columns: 1fr; } }
        .pos-search-input { width: 100%; font-size: 18px; padding: 14px 16px; }
        .pos-item-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin-top: 14px; max-height: 60vh; overflow-y: auto; }
        .pos-item-tile { text-align: left; background: var(--surface-2); border: 1px solid var(--border); border-radius: 10px; padding: 12px; cursor: pointer; color: var(--text); display: flex; flex-direction: column; gap: 6px; }
        .pos-item-tile:hover { border-color: var(--accent); }
        .pos-item-tile .sku { font-size: 11px; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.04em; }
        .pos-item-tile .name { font-size: 14px; font-weight: 600; line-height: 1.25; }
        .pos-item-tile .price { font-size: 15px; font-weight: 700; margin-top: auto; }
        .pos-cart-lines { display: flex; flex-direction: column; gap: 8px; max-height: 32vh; overflow-y: auto; margin: 12px 0; }
        .pos-cart-line { display: grid; grid-template-columns: 1fr auto; gap: 4px 10px; border-bottom: 1px solid var(--border); padding-bottom: 8px; }
        .pos-cart-line .name { font-size: 13px; font-weight: 600; }
        .pos-cart-line .meta { font-size: 12px; color: var(--text-dim); }
        .pos-qty-stepper { display: flex; align-items: center; gap: 6px; }
        .pos-qty-stepper button { width: 26px; height: 26px; border-radius: 6px; border: 1px solid var(--border); background: var(--surface-2); color: var(--text); cursor: pointer; font-weight: 700; line-height: 1; }
        .pos-qty-stepper input { width: 46px; text-align: center; padding: 4px; }
        .pos-line-remove { background: none; border: none; color: var(--danger); cursor: pointer; font-size: 16px; padding: 0 4px; }
        .pos-totals-row { display: flex; justify-content: space-between; font-size: 13px; color: var(--text-dim); padding: 2px 0; }
        .pos-totals-row.grand { font-size: 18px; font-weight: 700; color: var(--text); border-top: 1px solid var(--border); margin-top: 6px; padding-top: 8px; }
        .pos-tender-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 10px 0; }
        .pos-tender-btn { padding: 14px 8px; font-size: 14px; font-weight: 700; border-radius: 8px; border: 1px solid var(--border); background: var(--surface-2); color: var(--text); cursor: pointer; }
        .pos-tender-btn.active { background: var(--accent); border-color: var(--accent); color: white; }
        .pos-tender-btn:disabled { opacity: 0.4; cursor: not-allowed; }
        .pos-quick-cash { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
        .pos-quick-cash button { padding: 6px 10px; font-size: 12px; }
        .pos-complete-btn { width: 100%; padding: 16px; font-size: 16px; margin-top: 12px; }
        .pos-receipt-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; z-index: 50; }
        .pos-receipt-card { width: 380px; max-height: 85vh; overflow-y: auto; }
        .pos-receipt-card table { width: 100%; font-size: 13px; }
        .pos-receipt-card td { padding: 3px 0; }
      `}</style>

      <div className="page-header">
        <h1>Point of Sale</h1>
        {session && (
          <div className="pos-session-bar">
            <span className="pill green">Register open</span>
            <span>
              Opened <strong>{new Date(session.openedAt).toLocaleString()}</strong>
            </span>
            <span>
              Float <strong>{formatMoney(session.openingCashMinor, company.baseCurrency)}</strong>
            </span>
            <button className="btn secondary" onClick={() => setShowClosePanel((v) => !v)}>
              Close Register
            </button>
          </div>
        )}
      </div>

      {showClosePanel && session && (
        <div className="card" style={{ marginBottom: 16 }}>
          <h3 style={{ marginTop: 0 }}>Close Register</h3>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <input
              type="number"
              placeholder="Cash counted in drawer"
              value={closingCashMajor}
              onChange={(e) => setClosingCashMajor(e.target.value)}
              style={{ width: 200 }}
            />
            <button className="btn" disabled={closeBusy} onClick={closeRegister}>
              {closeBusy ? 'Closing…' : 'Confirm Close'}
            </button>
            <button className="btn secondary" onClick={() => setShowClosePanel(false)}>
              Cancel
            </button>
            {closeError && <span style={{ color: 'var(--danger)', fontSize: 13 }}>{closeError}</span>}
          </div>
        </div>
      )}

      {!sessionChecked && <div className="card">Checking for an open register…</div>}

      {sessionChecked && !session && (
        <div className="card" style={{ maxWidth: 420, margin: '40px auto' }}>
          <h2 style={{ marginTop: 0 }}>Open Register</h2>
          <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: -8 }}>
            Enter the opening cash float to start your POS session.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input
              type="number"
              placeholder="Opening cash float"
              value={openingCashMajor}
              onChange={(e) => setOpeningCashMajor(e.target.value)}
            />
            {openError && <div style={{ color: 'var(--danger)', fontSize: 13 }}>{openError}</div>}
            <button className="btn" disabled={openBusy} onClick={openRegister}>
              {openBusy ? 'Opening…' : 'Open Register'}
            </button>
          </div>
        </div>
      )}

      {sessionChecked && session && (
        <div className="pos-layout">
          {/* LEFT: search + results */}
          <div className="card">
            <input
              ref={searchInputRef}
              autoFocus
              className="pos-search-input"
              placeholder="Scan or search by SKU / name… (Enter to search)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={onSearchKeyDown}
            />
            {searching && <div style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: 8 }}>Searching…</div>}
            <div className="pos-item-grid">
              {results.map((item) => {
                const outOfStock = item.itemType === 'STOCK' && (item.quantityOnHand ?? 0) <= 0;
                return (
                  <button key={item.id} className="pos-item-tile" onClick={() => addToCart(item)}>
                    <span className="sku">{item.sku}</span>
                    <span className="name">{item.name}</span>
                    {item.itemType === 'STOCK' && (
                      <span className={`pill ${outOfStock ? 'red' : 'green'}`}>
                        {outOfStock ? 'Out of stock' : `${item.quantityOnHand} on hand`}
                      </span>
                    )}
                    <span className="price">{formatMoney(item.salesPriceMinor, item.currencyCode)}</span>
                  </button>
                );
              })}
              {!searching && results.length === 0 && query.trim() && (
                <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>No items matched "{query}".</div>
              )}
            </div>
          </div>

          {/* RIGHT: cart + checkout */}
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Cart</h3>
            {cart.length === 0 && <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>No items yet.</div>}
            <div className="pos-cart-lines">
              {cart.map((line) => {
                const exceedsStock =
                  line.itemType === 'STOCK' &&
                  line.quantityOnHand !== undefined &&
                  line.quantity > line.quantityOnHand;
                return (
                  <div key={line.itemId} className="pos-cart-line">
                    <div>
                      <div className="name">{line.name}</div>
                      <div className="meta">
                        {formatMoney(line.unitPriceMinor, line.currencyCode)} each
                        {exceedsStock && <span className="pill amber" style={{ marginLeft: 6 }}>Exceeds stock</span>}
                      </div>
                      <div className="pos-qty-stepper" style={{ marginTop: 4 }}>
                        <button onClick={() => setLineQuantity(line.itemId, line.quantity - 1)}>−</button>
                        <input
                          type="number"
                          value={line.quantity}
                          onChange={(e) => setLineQuantity(line.itemId, Math.max(0, Number(e.target.value) || 0))}
                        />
                        <button onClick={() => setLineQuantity(line.itemId, line.quantity + 1)}>+</button>
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div className="name">{formatMoney(line.unitPriceMinor * line.quantity, line.currencyCode)}</div>
                      <button className="pos-line-remove" onClick={() => removeLine(line.itemId)} title="Remove">
                        ×
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div>
              <div className="pos-totals-row">
                <span>Subtotal</span>
                <span>{formatMoney(subtotalMinor, company.baseCurrency)}</span>
              </div>
              <div className="pos-totals-row">
                <span>Tax{taxStillResolving ? ' (estimating…)' : ''}</span>
                <span>{formatMoney(taxMinor, company.baseCurrency)}</span>
              </div>
              <div className="pos-totals-row grand">
                <span>Total</span>
                <span>{formatMoney(totalMinor, company.baseCurrency)}</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 4 }}>
                Tax shown here is a client-side preview — the backend recomputes the authoritative tax and total at
                checkout.
              </div>
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Customer (optional — defaults to walk-in)</label>
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value ? Number(e.target.value) : '')}
                style={{ width: '100%', marginTop: 4 }}
              >
                <option value="">Walk-in customer</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Tender</label>
              <div className="pos-tender-grid">
                <button
                  className={`pos-tender-btn ${tenderType === 'CASH' ? 'active' : ''}`}
                  onClick={() => setTenderType('CASH')}
                >
                  CASH
                </button>
                <button
                  className={`pos-tender-btn ${tenderType === 'CARD' ? 'active' : ''}`}
                  onClick={() => setTenderType('CARD')}
                >
                  CARD
                </button>
                <button
                  className={`pos-tender-btn ${tenderType === 'ON_ACCOUNT' ? 'active' : ''}`}
                  disabled={!customerId}
                  title={!customerId ? 'Select a customer first — on-account sales cannot be walk-in' : undefined}
                  onClick={() => setTenderType('ON_ACCOUNT')}
                >
                  ON ACCOUNT
                </button>
              </div>
              {tenderType === 'ON_ACCOUNT' && !customerId && (
                <div style={{ fontSize: 12, color: 'var(--warn)' }}>Select a customer to use ON ACCOUNT.</div>
              )}

              {tenderType === 'CASH' && (
                <div style={{ marginTop: 6 }}>
                  <input
                    type="number"
                    placeholder="Tendered amount"
                    value={tenderedMajor}
                    onChange={(e) => setTenderedMajor(e.target.value)}
                    style={{ width: '100%' }}
                  />
                  <div className="pos-quick-cash">
                    {quickCashOptions.map((m) => (
                      <button
                        key={m}
                        className="btn secondary"
                        onClick={() => setTenderedMajor((m / 100).toFixed(2))}
                      >
                        {formatMoney(m, company.baseCurrency)}
                      </button>
                    ))}
                  </div>
                  <div style={{ marginTop: 8, fontSize: 14 }}>
                    Change due:{' '}
                    <strong style={{ color: changeMinor < 0 ? 'var(--danger)' : 'var(--accent-2)' }}>
                      {formatMoney(Math.max(changeMinor, 0), company.baseCurrency)}
                    </strong>
                  </div>
                </div>
              )}

              {(tenderType === 'CASH' || tenderType === 'CARD') && (
                <div style={{ marginTop: 10 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>Settlement account</label>
                  <select
                    value={settlementAccountId}
                    onChange={(e) => setSettlementAccountId(e.target.value ? Number(e.target.value) : '')}
                    style={{ width: '100%', marginTop: 4 }}
                  >
                    <option value="">Select account…</option>
                    {settlementAccountOptions.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.code} — {a.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {checkoutError && (
              <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{checkoutError}</div>
            )}

            <button
              className="btn pos-complete-btn"
              disabled={checkoutBusy || cart.length === 0}
              onClick={completeSale}
            >
              {checkoutBusy ? 'Processing…' : `Complete Sale — ${formatMoney(totalMinor, company.baseCurrency)}`}
            </button>
          </div>
        </div>
      )}

      {lastReceipt && (
        <div className="pos-receipt-overlay">
          <div className="card pos-receipt-card">
            <h2 style={{ marginTop: 0 }}>Sale Complete</h2>
            <div style={{ fontSize: 13, color: 'var(--text-dim)' }}>
              Sale {lastReceipt.sale.saleNumber} · Invoice {lastReceipt.invoiceNumber}
            </div>
            <table style={{ marginTop: 10 }}>
              <tbody>
                {lastReceipt.sale.lines.map((l) => (
                  <tr key={l.id}>
                    <td>
                      {l.description} × {Number(l.quantity)}
                    </td>
                    <td style={{ textAlign: 'right' }}>{formatMoney(l.lineTotalMinor, company.baseCurrency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="pos-totals-row">
              <span>Subtotal</span>
              <span>{formatMoney(lastReceipt.sale.subtotalMinor, company.baseCurrency)}</span>
            </div>
            <div className="pos-totals-row">
              <span>Tax</span>
              <span>{formatMoney(lastReceipt.sale.taxMinor, company.baseCurrency)}</span>
            </div>
            <div className="pos-totals-row grand">
              <span>Total</span>
              <span>{formatMoney(lastReceipt.sale.totalMinor, company.baseCurrency)}</span>
            </div>
            {lastReceipt.sale.tenderType === 'CASH' && (
              <>
                <div className="pos-totals-row">
                  <span>Tendered</span>
                  <span>{formatMoney(lastReceipt.sale.tenderedMinor, company.baseCurrency)}</span>
                </div>
                <div className="pos-totals-row">
                  <span>Change due</span>
                  <span>{formatMoney(lastReceipt.changeMinor, company.baseCurrency)}</span>
                </div>
              </>
            )}
            {lastReceipt.sale.invoiceId && (
              <a
                className="btn secondary"
                href={`/print/invoice/${lastReceipt.sale.invoiceId}`}
                target="_blank"
                rel="noreferrer"
                style={{ display: 'block', textAlign: 'center', textDecoration: 'none', marginTop: 10 }}
              >
                Print VAT tax invoice
              </a>
            )}
            <button className="btn pos-complete-btn" onClick={newSale}>
              New Sale
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
