import React, { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

interface CompanyRow {
  id: number;
  code: string;
  name: string;
  baseCurrency: string;
  addressLine: string | null;
  taxRegistrationNo: string | null;
  isActive: boolean;
}

interface BranchRow {
  id: number;
  companyId: number;
  code: string;
  name: string;
  isActive: boolean;
}

interface TaxRateRow {
  id: number;
  companyId: number;
  code: string;
  name: string;
  rateBasisPoints: number;
  pricingMode: 'EXCLUSIVE' | 'INCLUSIVE';
  isVat: boolean;
  outputTaxAccountId: number | null;
  inputTaxAccountId: number | null;
  isActive: boolean;
}

interface AccountRow {
  id: number;
  code: string;
  name: string;
}

type Tab = 'companies' | 'branches' | 'tax-rates';

export default function SettingsPage() {
  const [tab, setTab] = useState<Tab>('companies');

  return (
    <div>
      <div className="page-header">
        <h1>Settings</h1>
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <TabButton active={tab === 'companies'} onClick={() => setTab('companies')} label="Companies" />
        <TabButton active={tab === 'branches'} onClick={() => setTab('branches')} label="Branches" />
        <TabButton active={tab === 'tax-rates'} onClick={() => setTab('tax-rates')} label="Tax Rates" />
      </div>

      {tab === 'companies' ? <CompaniesTab /> : tab === 'branches' ? <BranchesTab /> : <TaxRatesTab />}
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button className={active ? 'btn' : 'btn secondary'} onClick={onClick} type="button">
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Companies
// ---------------------------------------------------------------------------

function CompaniesTab() {
  const { refresh } = useCompany();
  const [companies, setCompanies] = useState<CompanyRow[] | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [baseCurrency, setBaseCurrency] = useState('LKR');
  const [addressLine, setAddressLine] = useState('');
  const [taxRegistrationNo, setTaxRegistrationNo] = useState('');

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  function load() {
    setCompanies(null);
    api.get('/companies').then((res) => setCompanies(res.data));
  }

  useEffect(() => {
    load();
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    setBusy(true);
    try {
      await api.post('/companies', {
        code,
        name,
        baseCurrency,
        addressLine: addressLine || undefined,
        taxRegistrationNo: taxRegistrationNo || undefined,
      });
      setCode('');
      setName('');
      setBaseCurrency('LKR');
      setAddressLine('');
      setTaxRegistrationNo('');
      setShowForm(false);
      load();
      refresh();
      setSuccess(`Company "${name}" was created and is now selectable from the company switcher at the top of the app.`);
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create company');
    } finally {
      setBusy(false);
    }
  }

  const sorted = (companies || []).slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Companies</h2>
        <button
          className="btn"
          type="button"
          onClick={() => {
            setShowForm((s) => !s);
            setSuccess('');
          }}
        >
          {showForm ? 'Cancel' : '+ New Company'}
        </button>
      </div>

      {success && (
        <div className="card" style={{ marginBottom: 18, borderColor: 'var(--accent-2)' }}>
          <span className="pill green" style={{ marginRight: 8 }}>
            Created
          </span>
          {success}
        </div>
      )}

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Code</div>
              <input value={code} onChange={(e) => setCode(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Name</div>
              <input value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Base currency</div>
              <input
                placeholder="LKR"
                value={baseCurrency}
                onChange={(e) => setBaseCurrency(e.target.value.toUpperCase())}
                style={{ width: 80 }}
                required
              />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Address line</div>
              <input value={addressLine} onChange={(e) => setAddressLine(e.target.value)} style={{ width: 220 }} />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Tax registration no.</div>
              <input value={taxRegistrationNo} onChange={(e) => setTaxRegistrationNo(e.target.value)} />
            </div>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save'}
            </button>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
        </form>
      )}

      <div className="card">
        {companies === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No companies yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Base currency</th>
                <th>Tax registration no.</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((c) => (
                <tr key={c.id}>
                  <td>{c.code}</td>
                  <td>{c.name}</td>
                  <td>{c.baseCurrency}</td>
                  <td>{c.taxRegistrationNo || '—'}</td>
                  <td>
                    {c.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Branches
// ---------------------------------------------------------------------------

function BranchesTab() {
  const { company, companies } = useCompany();
  const [companyId, setCompanyId] = useState<number | null>(company?.id ?? null);
  const [branches, setBranches] = useState<BranchRow[] | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (companyId === null && company) {
      setCompanyId(company.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [company]);

  function load(id: number) {
    setBranches(null);
    api.get(`/companies/${id}/branches`).then((res) => setBranches(res.data));
  }

  useEffect(() => {
    if (companyId !== null) {
      load(companyId);
    }
  }, [companyId]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (companyId === null) return;
    setError('');
    setBusy(true);
    try {
      await api.post(`/companies/${companyId}/branches`, { code, name });
      setCode('');
      setName('');
      setShowForm(false);
      load(companyId);
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create branch');
    } finally {
      setBusy(false);
    }
  }

  const sorted = (branches || []).slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Branches</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)} disabled={companyId === null}>
          {showForm ? 'Cancel' : '+ New Branch'}
        </button>
      </div>

      <div className="card" style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Company</div>
        <select
          value={companyId ?? ''}
          onChange={(e) => setCompanyId(e.target.value ? Number(e.target.value) : null)}
        >
          <option value="">Select company…</option>
          {companies.map((c) => (
            <option key={c.id} value={c.id}>
              {c.code} — {c.name}
            </option>
          ))}
        </select>
      </div>

      {showForm && companyId !== null && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Code</div>
              <input value={code} onChange={(e) => setCode(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Name</div>
              <input value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save'}
            </button>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
        </form>
      )}

      <div className="card">
        {companyId === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Select a company to view its branches.</p>
        ) : branches === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No branches yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((b) => (
                <tr key={b.id}>
                  <td>{b.code}</td>
                  <td>{b.name}</td>
                  <td>
                    {b.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tax Rates (read-only)
// ---------------------------------------------------------------------------

function formatBasisPoints(bp: number): string {
  return (bp / 100).toFixed(2) + '%';
}

function TaxRatesTab() {
  const { company } = useCompany();
  const [rates, setRates] = useState<TaxRateRow[] | null>(null);
  const [accounts, setAccounts] = useState<AccountRow[]>([]);

  useEffect(() => {
    if (!company) return;
    setRates(null);
    api.get('/tax-rates', { params: { companyId: company.id } }).then((res) => setRates(res.data));
    api
      .get('/accounting/accounts', { params: { companyId: company.id } })
      .then((res) => setAccounts(res.data))
      .catch(() => setAccounts([]));
  }, [company]);

  function accountLabel(id: number | null): string {
    if (id === null || id === undefined) return '—';
    const a = accounts.find((x) => x.id === id);
    return a ? `${a.code} — ${a.name}` : String(id);
  }

  const sorted = (rates || []).slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Tax Rates</h2>
      </div>

      <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: -8, marginBottom: 18 }}>
        Tax rates (VAT, SSCL) are configured during system setup via the seed script. This view is read-only.
      </p>

      <div className="card">
        {!company ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : rates === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No tax rates configured for this company.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Rate</th>
                <th>VAT</th>
                <th>Output tax account</th>
                <th>Input tax account</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((r) => (
                <tr key={r.id}>
                  <td>{r.code}</td>
                  <td>{r.name}</td>
                  <td>{formatBasisPoints(r.rateBasisPoints)}</td>
                  <td>
                    {r.isVat ? <span className="pill green">Yes</span> : <span className="pill gray">No</span>}
                  </td>
                  <td>{accountLabel(r.outputTaxAccountId)}</td>
                  <td>{accountLabel(r.inputTaxAccountId)}</td>
                  <td>
                    {r.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
