import React, { useMemo, useState } from 'react';
import { Link, Route, Routes, useNavigate, useParams } from 'react-router-dom';
import ReportViewer from '../reports/ReportViewer';
import { CATALOG, findReport, loadCustomReports, REPORT_CSS } from '../reports/shared';
import type { ReportDef } from '../reports/engine';

const MODULE_ORDER = [
  'Financial Statements',
  'Tax (VAT)',
  'Sales',
  'Receivables',
  'Purchasing & Payables',
  'Inventory',
  'Fixed Assets & Banking',
  'My reports',
];

/**
 * Reports workspace (Acumatica-style): every report is a JSON definition
 * from reports/catalog.json (or a custom one saved in this browser), rendered
 * by one generic viewer with filters, grouping, charts and PDF/Excel/CSV/JSON export.
 */
export default function ReportsPage() {
  return (
    <>
      <style>{REPORT_CSS}</style>
      <Routes>
        <Route index element={<Catalog />} />
        <Route path=":id" element={<ReportRoute />} />
      </Routes>
    </>
  );
}

function ReportRoute() {
  const { id } = useParams();
  const def = useMemo(() => (id ? findReport(id) : undefined), [id]);
  if (!def) return <p style={{ color: 'var(--text-dim)' }}>Report not found. <Link to="/reports">Back to reports</Link></p>;
  return <ReportViewer key={def.id} def={def} />;
}

function Catalog() {
  const [q, setQ] = useState('');
  const navigate = useNavigate();
  const all: ReportDef[] = useMemo(() => [...CATALOG, ...loadCustomReports().map((r) => ({ ...r, module: r.module || 'My reports' }))], []);
  const filtered = all.filter((r) => !q || (r.title + ' ' + r.description + ' ' + r.module).toLowerCase().includes(q.toLowerCase()));
  const modules = Array.from(new Set([...MODULE_ORDER, ...filtered.map((r) => r.module)])).filter((m) => filtered.some((r) => r.module === m));
  const favs = all.filter((r) => r.favorite);

  const newCustom = () => {
    const tpl: ReportDef = {
      id: 'draft',
      title: 'My new report',
      module: 'My reports',
      description: 'Describe what this report shows.',
      kind: 'table',
      dataset: 'salesLines',
      period: 'range',
      defaultPreset: 'thisMonth',
      columns: [
        { field: 'category', label: 'Category' },
        { field: 'quantity', label: 'Units', format: 'number' },
        { field: 'net', label: 'Net sales', format: 'money' },
        { field: 'grossProfit', label: 'Gross profit', format: 'money' },
        { field: 'marginPct', label: 'Margin %', format: 'percent', ratio: { num: 'grossProfit', den: 'net', scale: 100 } },
      ],
      groupBy: ['category'],
      groupOptions: ['category', 'brand', 'customerName', 'month'],
      sort: [{ field: 'net', dir: 'desc' }],
      chart: { type: 'hbar', x: 'category', y: ['net'] },
      custom: true,
    };
    const list = loadCustomReports();
    const id = 'custom-new-' + Date.now().toString(36);
    localStorage.setItem('kruxus_custom_reports_v1', JSON.stringify([...list, { ...tpl, id }]));
    navigate(`/reports/${id}`);
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Reports</h1>
          <p style={{ color: 'var(--text-dim)', fontSize: 13, margin: '4px 0 0 0' }}>
            {all.length} reports across finance, tax, sales, purchasing and inventory · every report prints and exports to PDF, Excel, CSV and JSON
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search reports…" style={{ width: 260 }} autoFocus />
          <button className="btn" onClick={newCustom}>
            + New custom report
          </button>
        </div>
      </div>

      {!q && (
        <div style={{ marginBottom: 22 }}>
          <div className="sidebar-group" style={{ padding: '0 0 8px 0' }}>Favourites</div>
          <div className="rp-cat-grid">
            {favs.map((r) => (
              <ReportCard key={r.id} r={r} showModule />
            ))}
          </div>
        </div>
      )}

      {modules.map((m) => (
        <div key={m} style={{ marginBottom: 22 }}>
          <div className="sidebar-group" style={{ padding: '0 0 8px 0' }}>
            {m} <span style={{ textTransform: 'none' }}>({filtered.filter((r) => r.module === m).length})</span>
          </div>
          <div className="rp-cat-grid">
            {filtered
              .filter((r) => r.module === m)
              .map((r) => (
                <ReportCard key={r.id} r={r} />
              ))}
          </div>
        </div>
      ))}
      {filtered.length === 0 && <p style={{ color: 'var(--text-dim)' }}>No reports match “{q}”.</p>}
    </div>
  );
}

function ReportCard({ r, showModule }: { r: ReportDef; showModule?: boolean }) {
  const kindLabel = r.kind === 'statement' ? 'statement' : r.kind === 'vat-return' ? 'tax' : r.kind === 'customer-statement' ? 'statement' : r.chart ? 'table + chart' : 'table';
  return (
    <Link to={`/reports/${r.id}`} className="rp-card">
      <h4>
        {r.title}
        <span className="rp-badge">{kindLabel}</span>
        {r.custom && <span className="rp-badge">custom</span>}
      </h4>
      <p>{showModule ? `${r.module} · ` : ''}{r.description}</p>
    </Link>
  );
}
