import React, { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

interface Currency {
  id: number;
  code: string;
  name: string;
  symbol: string | null;
  decimalPlaces: number;
  isActive: boolean;
}

interface ExchangeRate {
  id: number;
  companyId: number;
  fromCurrency: string;
  toCurrency: string;
  rateDate: string;
  rate: string;
  source: string | null;
}

interface Account {
  id: number;
  companyId: number;
  code: string;
  name: string;
  accountType: string;
  normalBalance: string;
  isActive: boolean;
}

interface RevalueAdjustment {
  accountId: number;
  currencyCode: string;
  partyId: number | null;
  foreignBalanceMinor: number;
  oldBaseValueMinor: number;
  newBaseValueMinor: number;
  adjustmentMinor: number;
}

interface RevalueResult {
  companyId: number;
  asOfDate: string;
  adjustments: RevalueAdjustment[];
  journalEntryId: number | null;
}

type Tab = 'currencies' | 'rates' | 'revaluation';

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function CurrencyPage() {
  const { company } = useCompany();
  const [tab, setTab] = useState<Tab>('currencies');

  return (
    <div>
      <div className="page-header">
        <h1>Currency Management</h1>
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <TabButton active={tab === 'currencies'} onClick={() => setTab('currencies')} label="Currencies" />
        <TabButton active={tab === 'rates'} onClick={() => setTab('rates')} label="Exchange Rates" />
        <TabButton active={tab === 'revaluation'} onClick={() => setTab('revaluation')} label="Period-End Revaluation" />
      </div>

      {!company ? (
        <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
      ) : tab === 'currencies' ? (
        <CurrenciesTab />
      ) : tab === 'rates' ? (
        <ExchangeRatesTab companyId={company.id} baseCurrency={company.baseCurrency} />
      ) : (
        <RevaluationTab companyId={company.id} />
      )}
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button className={active ? 'btn' : 'btn secondary'} onClick={onClick} type="button">
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Currencies
// ---------------------------------------------------------------------------

function CurrenciesTab() {
  const [currencies, setCurrencies] = useState<Currency[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function load() {
    setCurrencies(null);
    api.get('/currencies').then((res) => setCurrencies(res.data));
  }

  useEffect(() => {
    load();
  }, []);

  async function onSeed() {
    setError('');
    setBusy(true);
    try {
      await api.post('/currencies/seed-defaults');
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to seed default currencies');
    } finally {
      setBusy(false);
    }
  }

  const sorted = (currencies || []).slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Currencies</h2>
        <button className="btn" type="button" onClick={onSeed} disabled={busy}>
          {busy ? 'Seeding…' : 'Seed default currencies'}
        </button>
      </div>
      <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: -10, marginBottom: 14 }}>
        Adds LKR, USD, GBP, EUR, INR, AUD if they don't already exist.
      </p>
      {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}

      <div className="card">
        {currencies === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No currencies yet. Seed the defaults to get started.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Symbol</th>
                <th>Decimal places</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((c) => (
                <tr key={c.id}>
                  <td>{c.code}</td>
                  <td>{c.name}</td>
                  <td>{c.symbol || ''}</td>
                  <td>{c.decimalPlaces}</td>
                  <td>
                    {c.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Exchange Rates
// ---------------------------------------------------------------------------

function ExchangeRatesTab({ companyId, baseCurrency }: { companyId: number; baseCurrency: string }) {
  const [currencies, setCurrencies] = useState<Currency[]>([]);

  useEffect(() => {
    api.get('/currencies').then((res) => setCurrencies(res.data));
  }, []);

  return (
    <div>
      <AddRateForm companyId={companyId} baseCurrency={baseCurrency} currencies={currencies} />
      <RateHistoryCard companyId={companyId} baseCurrency={baseCurrency} currencies={currencies} />
      <CheckRateCard companyId={companyId} baseCurrency={baseCurrency} currencies={currencies} />
    </div>
  );
}

function AddRateForm({
  companyId,
  baseCurrency,
  currencies,
}: {
  companyId: number;
  baseCurrency: string;
  currencies: Currency[];
}) {
  const [fromCurrency, setFromCurrency] = useState('');
  const [toCurrency, setToCurrency] = useState(baseCurrency);
  const [rateDate, setRateDate] = useState(todayStr());
  const [rate, setRate] = useState('');
  const [source, setSource] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    setToCurrency(baseCurrency);
  }, [baseCurrency]);

  useEffect(() => {
    if (!fromCurrency && currencies.length > 0) {
      const firstNonBase = currencies.find((c) => c.code !== baseCurrency);
      if (firstNonBase) setFromCurrency(firstNonBase.code);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currencies]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess('');
    setBusy(true);
    try {
      await api.post('/currencies/rates', {
        companyId,
        fromCurrency,
        toCurrency,
        rateDate,
        rate: Number(rate),
        source: source || undefined,
      });
      setSuccess('Rate saved.');
      setRate('');
      setSource('');
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to save rate');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card" style={{ marginBottom: 18 }}>
      <h2 style={{ margin: '0 0 12px 0', fontSize: 16 }}>Add Exchange Rate</h2>
      <form onSubmit={onSubmit}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>From currency</div>
            <select value={fromCurrency} onChange={(e) => setFromCurrency(e.target.value)} required>
              <option value="">Select…</option>
              {currencies.map((c) => (
                <option key={c.id} value={c.code}>
                  {c.code}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>To currency</div>
            <select value={toCurrency} onChange={(e) => setToCurrency(e.target.value)} required>
              <option value="">Select…</option>
              {currencies.map((c) => (
                <option key={c.id} value={c.code}>
                  {c.code}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Rate date</div>
            <input type="date" value={rateDate} onChange={(e) => setRateDate(e.target.value)} required />
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>
              1 {fromCurrency || '???'} = ___ {toCurrency || '???'}
            </div>
            <input
              type="number"
              step="0.000001"
              min="0"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              placeholder="e.g. 310.50"
              style={{ width: 140 }}
              required
            />
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Source (optional)</div>
            <input value={source} onChange={(e) => setSource(e.target.value)} placeholder="manual, CBSL, …" />
          </div>
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Save rate'}
          </button>
        </div>
      </form>
      {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
      {success && <div style={{ color: 'var(--accent-2)', fontSize: 13, marginTop: 10 }}>{success}</div>}
    </div>
  );
}

function RateHistoryCard({
  companyId,
  baseCurrency,
  currencies,
}: {
  companyId: number;
  baseCurrency: string;
  currencies: Currency[];
}) {
  const [fromCurrency, setFromCurrency] = useState('');
  const [toCurrency, setToCurrency] = useState(baseCurrency);
  const [history, setHistory] = useState<ExchangeRate[] | null>(null);

  useEffect(() => {
    setToCurrency(baseCurrency);
  }, [baseCurrency]);

  useEffect(() => {
    if (!fromCurrency && currencies.length > 0) {
      const firstNonBase = currencies.find((c) => c.code !== baseCurrency);
      if (firstNonBase) setFromCurrency(firstNonBase.code);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currencies]);

  useEffect(() => {
    if (!fromCurrency || !toCurrency) return;
    setHistory(null);
    api
      .get('/currencies/rates/history', { params: { companyId, fromCurrency, toCurrency } })
      .then((res) => setHistory(res.data));
  }, [companyId, fromCurrency, toCurrency]);

  return (
    <div className="card" style={{ marginBottom: 18 }}>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Rate History</h2>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <select value={fromCurrency} onChange={(e) => setFromCurrency(e.target.value)}>
            <option value="">From…</option>
            {currencies.map((c) => (
              <option key={c.id} value={c.code}>
                {c.code}
              </option>
            ))}
          </select>
          <span style={{ color: 'var(--text-dim)' }}>→</span>
          <select value={toCurrency} onChange={(e) => setToCurrency(e.target.value)}>
            <option value="">To…</option>
            {currencies.map((c) => (
              <option key={c.id} value={c.code}>
                {c.code}
              </option>
            ))}
          </select>
        </div>
      </div>

      {!fromCurrency || !toCurrency ? (
        <p style={{ color: 'var(--text-dim)' }}>Choose a currency pair to see its rate history.</p>
      ) : history === null ? (
        <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
      ) : history.length === 0 ? (
        <p style={{ color: 'var(--text-dim)' }}>
          No rates recorded yet for {fromCurrency} → {toCurrency}.
        </p>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Rate</th>
              <th>Trend</th>
              <th>Source</th>
            </tr>
          </thead>
          <tbody>
            {history.map((r, idx) => {
              const prev = history[idx + 1]; // next item is older since history is newest-first
              const curRate = Number(r.rate);
              const prevRate = prev ? Number(prev.rate) : null;
              let trend: React.ReactNode = '';
              if (prevRate !== null) {
                if (curRate > prevRate) trend = <span style={{ color: 'var(--accent-2)' }}>▲</span>;
                else if (curRate < prevRate) trend = <span style={{ color: 'var(--danger)' }}>▼</span>;
                else trend = <span style={{ color: 'var(--text-dim)' }}>—</span>;
              }
              return (
                <tr key={r.id}>
                  <td>{r.rateDate}</td>
                  <td>{curRate.toFixed(6)}</td>
                  <td>{trend}</td>
                  <td>{r.source || ''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

function CheckRateCard({
  companyId,
  baseCurrency,
  currencies,
}: {
  companyId: number;
  baseCurrency: string;
  currencies: Currency[];
}) {
  const [fromCurrency, setFromCurrency] = useState('');
  const [toCurrency, setToCurrency] = useState(baseCurrency);
  const [asOfDate, setAsOfDate] = useState(todayStr());
  const [result, setResult] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setToCurrency(baseCurrency);
  }, [baseCurrency]);

  async function onCheck(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setResult(null);
    setBusy(true);
    try {
      const res = await api.get('/currencies/rates', {
        params: { companyId, fromCurrency, toCurrency, asOfDate },
      });
      setResult(Number(res.data.rate));
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'No rate found for that pair/date');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card">
      <h2 style={{ margin: '0 0 12px 0', fontSize: 16 }}>Check a Rate</h2>
      <form onSubmit={onCheck}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>From currency</div>
            <select value={fromCurrency} onChange={(e) => setFromCurrency(e.target.value)} required>
              <option value="">Select…</option>
              {currencies.map((c) => (
                <option key={c.id} value={c.code}>
                  {c.code}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>To currency</div>
            <select value={toCurrency} onChange={(e) => setToCurrency(e.target.value)} required>
              <option value="">Select…</option>
              {currencies.map((c) => (
                <option key={c.id} value={c.code}>
                  {c.code}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>As of date</div>
            <input type="date" value={asOfDate} onChange={(e) => setAsOfDate(e.target.value)} required />
          </div>
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Checking…' : 'Check rate'}
          </button>
        </div>
      </form>
      {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
      {result !== null && (
        <div style={{ marginTop: 12, fontSize: 14 }}>
          1 {fromCurrency} = <strong>{result.toFixed(6)}</strong> {toCurrency} (as of {asOfDate})
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Period-End Revaluation
// ---------------------------------------------------------------------------

function RevaluationTab({ companyId }: { companyId: number }) {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [asOfDate, setAsOfDate] = useState(todayStr());
  const [unrealizedGainAccountId, setUnrealizedGainAccountId] = useState('');
  const [unrealizedLossAccountId, setUnrealizedLossAccountId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<RevalueResult | null>(null);

  useEffect(() => {
    api.get('/accounting/accounts', { params: { companyId } }).then((res) => setAccounts(res.data));
  }, [companyId]);

  function accountLabel(accountId: number): string {
    const a = accounts.find((x) => x.id === accountId);
    return a ? `${a.code} — ${a.name}` : String(accountId);
  }

  async function onRun(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setResult(null);
    setBusy(true);
    try {
      const res = await api.post('/currencies/revalue', {
        companyId,
        asOfDate,
        unrealizedGainAccountId: Number(unrealizedGainAccountId),
        unrealizedLossAccountId: Number(unrealizedLossAccountId),
      });
      setResult(res.data);
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to run revaluation');
    } finally {
      setBusy(false);
    }
  }

  const sortedAccounts = accounts.slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="card" style={{ marginBottom: 18 }}>
        <h2 style={{ margin: '0 0 6px 0', fontSize: 16 }}>Run Period-End Revaluation</h2>
        <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 0, marginBottom: 14 }}>
          Finds open foreign-currency balances and books unrealized exchange gain/loss if rates have moved since they
          were recorded.
        </p>
        <form onSubmit={onRun}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>As of date</div>
              <input type="date" value={asOfDate} onChange={(e) => setAsOfDate(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>
                Unrealized gain account
                <span style={{ marginLeft: 6, fontStyle: 'italic' }}>(usually Other Income)</span>
              </div>
              <select
                value={unrealizedGainAccountId}
                onChange={(e) => setUnrealizedGainAccountId(e.target.value)}
                required
              >
                <option value="">Select account…</option>
                {sortedAccounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.code} — {a.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>
                Unrealized loss account
                <span style={{ marginLeft: 6, fontStyle: 'italic' }}>(usually Other Expense)</span>
              </div>
              <select
                value={unrealizedLossAccountId}
                onChange={(e) => setUnrealizedLossAccountId(e.target.value)}
                required
              >
                <option value="">Select account…</option>
                {sortedAccounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.code} — {a.name}
                  </option>
                ))}
              </select>
            </div>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Running…' : 'Run Revaluation'}
            </button>
          </div>
        </form>
        {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
      </div>

      {result && (
        <div className="card">
          <h2 style={{ margin: '0 0 12px 0', fontSize: 16 }}>Result — as of {result.asOfDate}</h2>
          {result.adjustments.length === 0 ? (
            <span className="pill gray">No material FX adjustments found</span>
          ) : (
            <>
              <table className="data-table" style={{ marginBottom: 14 }}>
                <thead>
                  <tr>
                    <th>Account</th>
                    <th>Currency</th>
                    <th>Foreign balance (minor)</th>
                    <th>Old base value (minor)</th>
                    <th>New base value (minor)</th>
                    <th>Adjustment (minor)</th>
                  </tr>
                </thead>
                <tbody>
                  {result.adjustments.map((adj, idx) => (
                    <tr key={idx}>
                      <td>{accountLabel(adj.accountId)}</td>
                      <td>{adj.currencyCode}</td>
                      <td>{adj.foreignBalanceMinor}</td>
                      <td>{adj.oldBaseValueMinor}</td>
                      <td>{adj.newBaseValueMinor}</td>
                      <td style={{ color: adj.adjustmentMinor >= 0 ? 'var(--accent-2)' : 'var(--danger)', fontWeight: 600 }}>
                        {adj.adjustmentMinor >= 0 ? '+' : ''}
                        {adj.adjustmentMinor}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {result.journalEntryId !== null && (
                <div style={{ fontSize: 13 }}>
                  <span className="pill green">Posted</span>{' '}
                  Journal entry <strong>#{result.journalEntryId}</strong> created.{' '}
                  <span style={{ color: 'var(--text-dim)' }}>View it in General Ledger → Journal Entries.</span>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
