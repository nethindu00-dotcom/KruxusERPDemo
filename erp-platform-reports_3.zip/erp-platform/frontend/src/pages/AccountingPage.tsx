import React, { useEffect, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
type NormalBalance = 'DEBIT' | 'CREDIT';

interface Account {
  id: number;
  companyId: number;
  code: string;
  name: string;
  accountType: AccountType;
  normalBalance: NormalBalance;
  parentId: number | null;
  isActive: boolean;
  isControlAccount: boolean;
}

interface JournalLine {
  id: number;
  entryId: number;
  accountId: number;
  description: string | null;
  debitMinor: string;
  creditMinor: string;
  currencyCode: string;
  exchangeRate: string;
  baseDebitMinor: string;
  baseCreditMinor: string;
  partyType: string | null;
  partyId: number | null;
}

interface JournalEntry {
  id: number;
  companyId: number;
  entryNumber: string;
  entryDate: string;
  memo: string;
  sourceType: string;
  sourceId: string | null;
  status: 'POSTED' | 'REVERSED';
  reversesEntryId: number | null;
  postedBy: number | null;
  lines: JournalLine[];
  createdAt: string;
}

interface TrialBalanceRow {
  accountId: number;
  code: string;
  name: string;
  accountType: AccountType;
  normalBalance: NormalBalance;
  totalDebit: number;
  totalCredit: number;
  balance: number;
}

interface FiscalPeriod {
  id: number;
  companyId: number;
  periodCode: string;
  startDate: string;
  endDate: string;
  status: 'OPEN' | 'CLOSED';
}

type Tab = 'coa' | 'journal' | 'trial-balance' | 'periods';

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function AccountingPage() {
  const { company } = useCompany();
  const [tab, setTab] = useState<Tab>('coa');

  return (
    <div>
      <div className="page-header">
        <h1>Accounting</h1>
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <TabButton active={tab === 'coa'} onClick={() => setTab('coa')} label="Chart of Accounts" />
        <TabButton active={tab === 'journal'} onClick={() => setTab('journal')} label="Journal Entries" />
        <TabButton active={tab === 'trial-balance'} onClick={() => setTab('trial-balance')} label="Trial Balance" />
        <TabButton active={tab === 'periods'} onClick={() => setTab('periods')} label="Fiscal Periods" />
      </div>

      {!company ? (
        <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
      ) : tab === 'coa' ? (
        <ChartOfAccountsTab companyId={company.id} />
      ) : tab === 'journal' ? (
        <JournalEntriesTab companyId={company.id} currency={company.baseCurrency} />
      ) : tab === 'trial-balance' ? (
        <TrialBalanceTab companyId={company.id} currency={company.baseCurrency} />
      ) : (
        <FiscalPeriodsTab companyId={company.id} />
      )}
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button className={active ? 'btn' : 'btn secondary'} onClick={onClick} type="button">
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Chart of Accounts
// ---------------------------------------------------------------------------

function ChartOfAccountsTab({ companyId }: { companyId: number }) {
  const [accounts, setAccounts] = useState<Account[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [accountType, setAccountType] = useState<AccountType>('ASSET');
  const [normalBalance, setNormalBalance] = useState<NormalBalance>('DEBIT');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function load() {
    setAccounts(null);
    api.get('/accounting/accounts', { params: { companyId } }).then((res) => setAccounts(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await api.post('/accounting/accounts', { companyId, code, name, accountType, normalBalance });
      setCode('');
      setName('');
      setAccountType('ASSET');
      setNormalBalance('DEBIT');
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create account');
    } finally {
      setBusy(false);
    }
  }

  const sorted = (accounts || []).slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Accounts</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New account'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Code</div>
              <input value={code} onChange={(e) => setCode(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Name</div>
              <input value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Type</div>
              <select value={accountType} onChange={(e) => setAccountType(e.target.value as AccountType)}>
                <option value="ASSET">ASSET</option>
                <option value="LIABILITY">LIABILITY</option>
                <option value="EQUITY">EQUITY</option>
                <option value="INCOME">INCOME</option>
                <option value="EXPENSE">EXPENSE</option>
              </select>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Normal balance</div>
              <select value={normalBalance} onChange={(e) => setNormalBalance(e.target.value as NormalBalance)}>
                <option value="DEBIT">DEBIT</option>
                <option value="CREDIT">CREDIT</option>
              </select>
            </div>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save'}
            </button>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
        </form>
      )}

      <div className="card">
        {accounts === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No accounts yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Type</th>
                <th>Normal balance</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((a) => (
                <tr key={a.id}>
                  <td>{a.code}</td>
                  <td>{a.name}</td>
                  <td>{a.accountType}</td>
                  <td>{a.normalBalance}</td>
                  <td>
                    {a.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Journal Entries
// ---------------------------------------------------------------------------

interface NewLineRow {
  accountId: string;
  description: string;
  debit: string;
  credit: string;
}

function emptyLine(): NewLineRow {
  return { accountId: '', description: '', debit: '', credit: '' };
}

function JournalEntriesTab({ companyId, currency }: { companyId: number; currency: string }) {
  const [entries, setEntries] = useState<JournalEntry[] | null>(null);
  const [meta, setMeta] = useState<{ page: number; pageSize: number; total: number } | null>(null);
  const [page, setPage] = useState(1);
  const pageSize = 20;
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  const [accounts, setAccounts] = useState<Account[]>([]);

  const [showForm, setShowForm] = useState(false);
  const [entryDate, setEntryDate] = useState(todayStr());
  const [memo, setMemo] = useState('');
  const [rows, setRows] = useState<NewLineRow[]>([emptyLine(), emptyLine()]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [reversingId, setReversingId] = useState<number | null>(null);

  function load() {
    setEntries(null);
    api
      .get('/accounting/journal-entries', { params: { companyId, page, pageSize } })
      .then((res) => {
        setEntries(res.data.data);
        setMeta(res.data.meta);
      });
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId, page]);

  useEffect(() => {
    api.get('/accounting/accounts', { params: { companyId } }).then((res) => setAccounts(res.data));
  }, [companyId]);

  function accountLabel(accountId: number): string {
    const a = accounts.find((x) => x.id === accountId);
    return a ? `${a.code} — ${a.name}` : String(accountId);
  }

  function lineSum(entry: JournalEntry, field: 'debitMinor' | 'creditMinor'): number {
    return entry.lines.reduce((sum, l) => sum + Number(l[field] || 0), 0);
  }

  function toggleExpand(id: number) {
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  async function onReverse(id: number) {
    if (!window.confirm('Reverse this journal entry? This posts an offsetting entry.')) return;
    setReversingId(id);
    try {
      await api.post(`/accounting/journal-entries/${id}/reverse`);
      load();
    } catch (err: any) {
      window.alert(err?.response?.data?.error?.message || 'Failed to reverse entry');
    } finally {
      setReversingId(null);
    }
  }

  function updateRow(idx: number, patch: Partial<NewLineRow>) {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  }

  function addRow() {
    setRows((prev) => [...prev, emptyLine()]);
  }

  function removeRow(idx: number) {
    setRows((prev) => prev.filter((_, i) => i !== idx));
  }

  const debitTotal = rows.reduce((sum, r) => sum + (Number(r.debit) || 0), 0);
  const creditTotal = rows.reduce((sum, r) => sum + (Number(r.credit) || 0), 0);
  const filledRows = rows.filter((r) => r.accountId && (Number(r.debit) > 0 || Number(r.credit) > 0));
  const isBalanced = filledRows.length >= 2 && Math.abs(debitTotal - creditTotal) < 0.005 && debitTotal > 0;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!isBalanced) return;
    setBusy(true);
    try {
      await api.post('/accounting/journal-entries', {
        companyId,
        entryDate,
        memo,
        sourceType: 'manual',
        lines: filledRows.map((r) => ({
          accountId: Number(r.accountId),
          description: r.description || undefined,
          debitMinor: r.debit ? toMinor(Number(r.debit)) : 0,
          creditMinor: r.credit ? toMinor(Number(r.credit)) : 0,
        })),
      });
      setMemo('');
      setRows([emptyLine(), emptyLine()]);
      setEntryDate(todayStr());
      setShowForm(false);
      setPage(1);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to post entry');
    } finally {
      setBusy(false);
    }
  }

  const totalPages = meta ? Math.max(1, Math.ceil(meta.total / meta.pageSize)) : 1;

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Journal Entries</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New manual entry'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Entry date</div>
              <input type="date" value={entryDate} onChange={(e) => setEntryDate(e.target.value)} required />
            </div>
            <div style={{ flex: 1, minWidth: 200 }}>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Memo</div>
              <input value={memo} onChange={(e) => setMemo(e.target.value)} style={{ width: '100%' }} required />
            </div>
          </div>

          <table className="data-table" style={{ marginBottom: 10 }}>
            <thead>
              <tr>
                <th>Account</th>
                <th>Description</th>
                <th>Debit</th>
                <th>Credit</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, idx) => (
                <tr key={idx}>
                  <td>
                    <select value={r.accountId} onChange={(e) => updateRow(idx, { accountId: e.target.value })}>
                      <option value="">Select account…</option>
                      {accounts.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.code} — {a.name}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <input
                      value={r.description}
                      onChange={(e) => updateRow(idx, { description: e.target.value })}
                      style={{ width: '100%' }}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={r.debit}
                      onChange={(e) => updateRow(idx, { debit: e.target.value, credit: e.target.value ? '' : r.credit })}
                      style={{ width: 110 }}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={r.credit}
                      onChange={(e) => updateRow(idx, { credit: e.target.value, debit: e.target.value ? '' : r.debit })}
                      style={{ width: 110 }}
                    />
                  </td>
                  <td>
                    {rows.length > 2 && (
                      <button type="button" className="btn secondary" onClick={() => removeRow(idx)}>
                        Remove
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <button type="button" className="btn secondary" onClick={addRow}>
              + Add line
            </button>
            <div style={{ fontSize: 13 }}>
              Debit total: <strong>{debitTotal.toFixed(2)}</strong> &nbsp; Credit total:{' '}
              <strong>{creditTotal.toFixed(2)}</strong>{' '}
              {isBalanced ? (
                <span className="pill green" style={{ marginLeft: 8 }}>
                  Balanced
                </span>
              ) : (
                <span className="pill red" style={{ marginLeft: 8 }}>
                  Unbalanced
                </span>
              )}
            </div>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy || !isBalanced}>
            {busy ? 'Posting…' : 'Post entry'}
          </button>
        </form>
      )}

      <div className="card">
        {entries === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : entries.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No journal entries yet.</p>
        ) : (
          <>
            <table className="data-table">
              <thead>
                <tr>
                  <th></th>
                  <th>Entry #</th>
                  <th>Date</th>
                  <th>Memo</th>
                  <th>Source</th>
                  <th>Status</th>
                  <th>Debit total</th>
                  <th>Credit total</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {entries.map((entry) => (
                  <React.Fragment key={entry.id}>
                    <tr style={{ cursor: 'pointer' }} onClick={() => toggleExpand(entry.id)}>
                      <td>{expanded[entry.id] ? '▾' : '▸'}</td>
                      <td>{entry.entryNumber}</td>
                      <td>{entry.entryDate}</td>
                      <td>{entry.memo}</td>
                      <td>{entry.sourceType}</td>
                      <td>
                        {entry.status === 'POSTED' ? (
                          <span className="pill green">POSTED</span>
                        ) : (
                          <span className="pill gray">REVERSED</span>
                        )}
                      </td>
                      <td>{formatMoney(lineSum(entry, 'debitMinor'), currency)}</td>
                      <td>{formatMoney(lineSum(entry, 'creditMinor'), currency)}</td>
                      <td onClick={(e) => e.stopPropagation()}>
                        {entry.status === 'POSTED' && (
                          <button
                            className="btn secondary"
                            type="button"
                            disabled={reversingId === entry.id}
                            onClick={() => onReverse(entry.id)}
                          >
                            {reversingId === entry.id ? 'Reversing…' : 'Reverse'}
                          </button>
                        )}
                      </td>
                    </tr>
                    {expanded[entry.id] && (
                      <tr>
                        <td colSpan={9} style={{ background: 'var(--surface-2)' }}>
                          <table className="data-table">
                            <thead>
                              <tr>
                                <th>Account</th>
                                <th>Description</th>
                                <th>Debit</th>
                                <th>Credit</th>
                              </tr>
                            </thead>
                            <tbody>
                              {entry.lines.map((l) => (
                                <tr key={l.id}>
                                  <td>{accountLabel(l.accountId)}</td>
                                  <td>{l.description}</td>
                                  <td>{Number(l.debitMinor) > 0 ? formatMoney(l.debitMinor, currency) : ''}</td>
                                  <td>{Number(l.creditMinor) > 0 ? formatMoney(l.creditMinor, currency) : ''}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 12 }}>
              <button className="btn secondary" type="button" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </button>
              <span style={{ alignSelf: 'center', fontSize: 13, color: 'var(--text-dim)' }}>
                Page {page} of {totalPages}
              </span>
              <button
                className="btn secondary"
                type="button"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Trial Balance
// ---------------------------------------------------------------------------

function TrialBalanceTab({ companyId, currency }: { companyId: number; currency: string }) {
  const [asOfDate, setAsOfDate] = useState(todayStr());
  const [rows, setRows] = useState<TrialBalanceRow[] | null>(null);

  function load() {
    setRows(null);
    api.get('/accounting/trial-balance', { params: { companyId, asOfDate } }).then((res) => setRows(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId, asOfDate]);

  const totalDebit = (rows || []).reduce((sum, r) => sum + r.totalDebit, 0);
  const totalCredit = (rows || []).reduce((sum, r) => sum + r.totalCredit, 0);
  const diff = Math.abs(totalDebit - totalCredit);
  const matches = diff <= 1; // within a rounding cent (minor-unit integer)

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Trial Balance</h2>
        <div>
          <input type="date" value={asOfDate} onChange={(e) => setAsOfDate(e.target.value)} />
        </div>
      </div>

      <div className="kpi-grid" style={{ marginBottom: 18 }}>
        <div className="kpi-tile">
          <div className="label">Total Debits</div>
          <div className="value">{formatMoney(totalDebit, currency)}</div>
        </div>
        <div className="kpi-tile">
          <div className="label">Total Credits</div>
          <div className="value">{formatMoney(totalCredit, currency)}</div>
        </div>
        <div className="kpi-tile">
          <div className="label">Balanced</div>
          <div className="value">
            {matches ? <span className="pill green">Matches</span> : <span className="pill red">Mismatch</span>}
          </div>
        </div>
      </div>

      <div className="card">
        {rows === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : rows.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No activity as of this date.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Type</th>
                <th>Debit</th>
                <th>Credit</th>
                <th>Balance</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.accountId}>
                  <td>{r.code}</td>
                  <td>{r.name}</td>
                  <td>{r.accountType}</td>
                  <td>{formatMoney(r.totalDebit, currency)}</td>
                  <td>{formatMoney(r.totalCredit, currency)}</td>
                  <td>{formatMoney(r.balance, currency)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} style={{ fontWeight: 700 }}>
                  Totals
                </td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totalDebit, currency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totalCredit, currency)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Fiscal Periods
// ---------------------------------------------------------------------------

function FiscalPeriodsTab({ companyId }: { companyId: number }) {
  const [periods, setPeriods] = useState<FiscalPeriod[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [periodCode, setPeriodCode] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [closingId, setClosingId] = useState<number | null>(null);

  function load() {
    setPeriods(null);
    api.get('/accounting/periods', { params: { companyId } }).then((res) => setPeriods(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await api.post('/accounting/periods', { companyId, periodCode, startDate, endDate });
      setPeriodCode('');
      setStartDate('');
      setEndDate('');
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create period');
    } finally {
      setBusy(false);
    }
  }

  async function onClose(id: number) {
    if (!window.confirm('Close this fiscal period? No further postings will be allowed into it.')) return;
    setClosingId(id);
    try {
      await api.post(`/accounting/periods/${id}/close`);
      load();
    } catch (err: any) {
      window.alert(err?.response?.data?.error?.message || 'Failed to close period');
    } finally {
      setClosingId(null);
    }
  }

  const sorted = (periods || []).slice().sort((a, b) => a.periodCode.localeCompare(b.periodCode));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Fiscal Periods</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New period'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Period code</div>
              <input placeholder="2026-10" value={periodCode} onChange={(e) => setPeriodCode(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>Start date</div>
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>End date</div>
              <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
            </div>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save'}
            </button>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
        </form>
      )}

      <div className="card">
        {periods === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No fiscal periods yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Period</th>
                <th>Start date</th>
                <th>End date</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((p) => (
                <tr key={p.id}>
                  <td>{p.periodCode}</td>
                  <td>{p.startDate}</td>
                  <td>{p.endDate}</td>
                  <td>
                    {p.status === 'OPEN' ? (
                      <span className="pill green">OPEN</span>
                    ) : (
                      <span className="pill gray">CLOSED</span>
                    )}
                  </td>
                  <td>
                    {p.status === 'OPEN' && (
                      <button
                        className="btn secondary"
                        type="button"
                        disabled={closingId === p.id}
                        onClick={() => onClose(p.id)}
                      >
                        {closingId === p.id ? 'Closing…' : 'Close'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
