import React, { useEffect, useMemo, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany, Company } from '../context/CompanyContext';

// ---------------------------------------------------------------------------
// Types (mirrors backend entities — see inventory/item.entity.ts, item-class.entity.ts,
// stock-movement.entity.ts, accounting/account.entity.ts, tax/tax-rate.entity.ts)
// ---------------------------------------------------------------------------

type ItemType = 'STOCK' | 'SERVICE' | 'NON_STOCK';

interface ItemClass {
  id: number;
  companyId: number;
  code: string;
  name: string;
  inventoryAccountId: number | null;
  cogsAccountId: number | null;
  salesAccountId: number | null;
  adjustmentAccountId: number | null;
  expenseAccountId: number | null;
  defaultTaxRateId: number | null;
  isActive: boolean;
}

interface Item {
  id: number;
  companyId: number;
  sku: string;
  name: string;
  description: string | null;
  itemType: ItemType;
  itemClassId: number | null;
  unitOfMeasure: string;
  costingMethod: string;
  salesPriceMinor: string | number;
  currencyCode: string;
  reorderLevel: number | null;
  isActive: boolean;
  inventoryAccountId: number | null;
  cogsAccountId: number | null;
  salesAccountId: number | null;
  adjustmentAccountId: number | null;
  expenseAccountId: number | null;
  defaultTaxRateId: number | null;
}

interface Account {
  id: number;
  companyId: number;
  code: string;
  name: string;
  accountType: string;
  normalBalance: string;
  parentId: number | null;
  isActive: boolean;
  isControlAccount: boolean;
}

interface TaxRate {
  id: number;
  companyId: number;
  code: string;
  name: string;
  rateBasisPoints: number;
  pricingMode: 'EXCLUSIVE' | 'INCLUSIVE';
  isVat: boolean;
  outputTaxAccountId: number | null;
  inputTaxAccountId: number | null;
  isActive: boolean;
}

interface StockMovement {
  id: number;
  companyId: number;
  itemId: number;
  movementDate: string;
  movementType: 'RECEIPT' | 'ISSUE' | 'ADJUSTMENT_IN' | 'ADJUSTMENT_OUT' | 'TRANSFER';
  quantity: string;
  unitCostMinor: string;
  totalCostMinor: string;
  sourceType: string;
  sourceId: string | null;
  journalEntryId: number | null;
  createdAt: string;
}

interface CurrentStock {
  quantityOnHand: number;
  weightedAverageCostMinor: number;
  stockValueMinor: number;
}

interface StockValuationRow {
  itemId: number;
  sku: string;
  name: string;
  unitOfMeasure: string;
  quantityOnHand: number;
  weightedAverageCostMinor: number;
  stockValueMinor: number;
}

type Tab = 'items' | 'item-classes' | 'valuation';

// ---------------------------------------------------------------------------
// Small shared helpers
// ---------------------------------------------------------------------------

function accountLabel(a: Account): string {
  return `${a.code} — ${a.name}`;
}

function taxLabel(t: TaxRate): string {
  return `${t.code} — ${t.name} (${(t.rateBasisPoints / 100).toFixed(2)}%)`;
}

/** Caption describing what an item-class default resolves to, for the "inherit" hint next to an item's override field. */
function classDefaultCaption(
  cls: ItemClass | undefined,
  field: keyof Pick<
    ItemClass,
    'inventoryAccountId' | 'cogsAccountId' | 'salesAccountId' | 'adjustmentAccountId' | 'expenseAccountId'
  >,
  accounts: Account[],
): string {
  if (!cls) return 'no item class selected — leaving blank means no account at all';
  const val = cls[field];
  if (!val) return 'class has no default set either';
  const acc = accounts.find((a) => a.id === val);
  return acc ? `class default: ${accountLabel(acc)}` : `class default: account #${val}`;
}

function classDefaultTaxCaption(cls: ItemClass | undefined, taxRates: TaxRate[]): string {
  if (!cls) return 'no item class selected — leaving blank means no tax rate at all';
  if (!cls.defaultTaxRateId) return 'class has no default set either';
  const t = taxRates.find((x) => x.id === cls.defaultTaxRateId);
  return t ? `class default: ${taxLabel(t)}` : `class default: tax rate #${cls.defaultTaxRateId}`;
}

function movementPill(type: StockMovement['movementType']) {
  const positive = type === 'RECEIPT' || type === 'ADJUSTMENT_IN';
  const negative = type === 'ISSUE' || type === 'ADJUSTMENT_OUT';
  const cls = positive ? 'green' : negative ? 'red' : 'gray';
  return <span className={`pill ${cls}`}>{type}</span>;
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

// ---------------------------------------------------------------------------
// Item form (shared between creating a new item and editing an existing one)
// ---------------------------------------------------------------------------

interface ItemFormState {
  sku: string;
  name: string;
  description: string;
  itemType: ItemType;
  itemClassId: string;
  unitOfMeasure: string;
  salesPriceMajor: string;
  currencyCode: string;
  reorderLevel: string;
  isActive: boolean;
  inventoryAccountId: string;
  cogsAccountId: string;
  salesAccountId: string;
  adjustmentAccountId: string;
  expenseAccountId: string;
  defaultTaxRateId: string;
}

function blankItemForm(baseCurrency: string): ItemFormState {
  return {
    sku: '',
    name: '',
    description: '',
    itemType: 'STOCK',
    itemClassId: '',
    unitOfMeasure: 'EA',
    salesPriceMajor: '0',
    currencyCode: baseCurrency,
    reorderLevel: '',
    isActive: true,
    inventoryAccountId: '',
    cogsAccountId: '',
    salesAccountId: '',
    adjustmentAccountId: '',
    expenseAccountId: '',
    defaultTaxRateId: '',
  };
}

function itemToForm(item: Item): ItemFormState {
  return {
    sku: item.sku,
    name: item.name,
    description: item.description || '',
    itemType: item.itemType,
    itemClassId: item.itemClassId != null ? String(item.itemClassId) : '',
    unitOfMeasure: item.unitOfMeasure,
    salesPriceMajor: (Number(item.salesPriceMinor) / 100).toFixed(2),
    currencyCode: item.currencyCode,
    reorderLevel: item.reorderLevel != null ? String(item.reorderLevel) : '',
    isActive: item.isActive,
    inventoryAccountId: item.inventoryAccountId != null ? String(item.inventoryAccountId) : '',
    cogsAccountId: item.cogsAccountId != null ? String(item.cogsAccountId) : '',
    salesAccountId: item.salesAccountId != null ? String(item.salesAccountId) : '',
    adjustmentAccountId: item.adjustmentAccountId != null ? String(item.adjustmentAccountId) : '',
    expenseAccountId: item.expenseAccountId != null ? String(item.expenseAccountId) : '',
    defaultTaxRateId: item.defaultTaxRateId != null ? String(item.defaultTaxRateId) : '',
  };
}

function ItemForm({
  form,
  setForm,
  accounts,
  taxRates,
  itemClasses,
}: {
  form: ItemFormState;
  setForm: React.Dispatch<React.SetStateAction<ItemFormState>>;
  accounts: Account[];
  taxRates: TaxRate[];
  itemClasses: ItemClass[];
}) {
  const selectedClass = useMemo(
    () => itemClasses.find((c) => String(c.id) === form.itemClassId),
    [itemClasses, form.itemClassId],
  );

  function field<K extends keyof ItemFormState>(key: K, value: ItemFormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  const activeAccounts = accounts.filter((a) => a.isActive);
  const activeTaxRates = taxRates.filter((t) => t.isActive);

  const overrideFields: Array<{
    key: keyof Pick<
      ItemFormState,
      'inventoryAccountId' | 'cogsAccountId' | 'salesAccountId' | 'adjustmentAccountId' | 'expenseAccountId'
    >;
    label: string;
    classField: keyof Pick<
      ItemClass,
      'inventoryAccountId' | 'cogsAccountId' | 'salesAccountId' | 'adjustmentAccountId' | 'expenseAccountId'
    >;
  }> = [
    { key: 'inventoryAccountId', label: 'Inventory account', classField: 'inventoryAccountId' },
    { key: 'cogsAccountId', label: 'COGS account', classField: 'cogsAccountId' },
    { key: 'salesAccountId', label: 'Sales account', classField: 'salesAccountId' },
    { key: 'adjustmentAccountId', label: 'Adjustment account', classField: 'adjustmentAccountId' },
    { key: 'expenseAccountId', label: 'Expense account', classField: 'expenseAccountId' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 10 }}>
        <Labeled label="SKU">
          <input value={form.sku} onChange={(e) => field('sku', e.target.value)} />
        </Labeled>
        <Labeled label="Name">
          <input value={form.name} onChange={(e) => field('name', e.target.value)} />
        </Labeled>
      </div>

      <Labeled label="Description">
        <input value={form.description} onChange={(e) => field('description', e.target.value)} />
      </Labeled>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        <Labeled label="Item type">
          <select value={form.itemType} onChange={(e) => field('itemType', e.target.value as ItemType)}>
            <option value="STOCK">STOCK</option>
            <option value="SERVICE">SERVICE</option>
            <option value="NON_STOCK">NON_STOCK</option>
          </select>
        </Labeled>
        <Labeled label="Unit of measure">
          <input value={form.unitOfMeasure} onChange={(e) => field('unitOfMeasure', e.target.value)} />
        </Labeled>
        <Labeled label="Item class">
          <select value={form.itemClassId} onChange={(e) => field('itemClassId', e.target.value)}>
            <option value="">— none —</option>
            {itemClasses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.code} — {c.name}
              </option>
            ))}
          </select>
        </Labeled>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        <Labeled label={`Sales price (${form.currencyCode || 'major units'})`}>
          <input
            type="number"
            step="0.01"
            value={form.salesPriceMajor}
            onChange={(e) => field('salesPriceMajor', e.target.value)}
          />
        </Labeled>
        <Labeled label="Currency code">
          <input value={form.currencyCode} onChange={(e) => field('currencyCode', e.target.value)} />
        </Labeled>
        <Labeled label="Reorder level">
          <input
            type="number"
            value={form.reorderLevel}
            onChange={(e) => field('reorderLevel', e.target.value)}
          />
        </Labeled>
      </div>

      <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
        <input type="checkbox" checked={form.isActive} onChange={(e) => field('isActive', e.target.checked)} />
        Active
      </label>

      <div className="card" style={{ background: 'var(--surface-2)' }}>
        <div style={{ fontWeight: 600, marginBottom: 4 }}>GL account overrides</div>
        <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: 0 }}>
          Leave any of these blank to inherit the item class's default for that account. Only set an override here
          when this specific item needs to post somewhere different from its class.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
          {overrideFields.map((f) => (
            <Labeled key={f.key} label={f.label} caption={classDefaultCaption(selectedClass, f.classField, accounts)}>
              <select value={form[f.key]} onChange={(e) => field(f.key, e.target.value)}>
                <option value="">— inherit from item class —</option>
                {activeAccounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {accountLabel(a)}
                  </option>
                ))}
              </select>
            </Labeled>
          ))}
          <Labeled label="Default tax rate" caption={classDefaultTaxCaption(selectedClass, taxRates)}>
            <select value={form.defaultTaxRateId} onChange={(e) => field('defaultTaxRateId', e.target.value)}>
              <option value="">— inherit from item class —</option>
              {activeTaxRates.map((t) => (
                <option key={t.id} value={t.id}>
                  {taxLabel(t)}
                </option>
              ))}
            </select>
          </Labeled>
        </div>
      </div>
    </div>
  );
}

function Labeled({ label, caption, children }: { label: string; caption?: string; children: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>{label}</span>
      {children}
      {caption && <span style={{ fontSize: 11, color: 'var(--text-dim)', fontStyle: 'italic' }}>{caption}</span>}
    </div>
  );
}

function itemFormToPayload(form: ItemFormState, companyId: number): Partial<Item> {
  return {
    companyId,
    sku: form.sku,
    name: form.name,
    description: form.description || null,
    itemType: form.itemType,
    itemClassId: form.itemClassId ? Number(form.itemClassId) : null,
    unitOfMeasure: form.unitOfMeasure,
    salesPriceMinor: toMinor(Number(form.salesPriceMajor) || 0),
    currencyCode: form.currencyCode,
    reorderLevel: form.reorderLevel ? Number(form.reorderLevel) : null,
    isActive: form.isActive,
    inventoryAccountId: form.inventoryAccountId ? Number(form.inventoryAccountId) : null,
    cogsAccountId: form.cogsAccountId ? Number(form.cogsAccountId) : null,
    salesAccountId: form.salesAccountId ? Number(form.salesAccountId) : null,
    adjustmentAccountId: form.adjustmentAccountId ? Number(form.adjustmentAccountId) : null,
    expenseAccountId: form.expenseAccountId ? Number(form.expenseAccountId) : null,
    defaultTaxRateId: form.defaultTaxRateId ? Number(form.defaultTaxRateId) : null,
  };
}

// ---------------------------------------------------------------------------
// Stock adjustment mini-form
// ---------------------------------------------------------------------------

function AdjustmentForm({
  company,
  items,
  defaultItemId,
  onDone,
  onCancel,
}: {
  company: Company;
  items: Item[];
  defaultItemId?: number;
  onDone: () => void;
  onCancel: () => void;
}) {
  const [itemId, setItemId] = useState(defaultItemId ? String(defaultItemId) : '');
  const [quantity, setQuantity] = useState('1');
  const [direction, setDirection] = useState<'IN' | 'OUT'>('IN');
  const [unitCostMajor, setUnitCostMajor] = useState('');
  const [movementDate, setMovementDate] = useState(todayIso());
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const stockItems = items.filter((i) => i.itemType === 'STOCK');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!itemId) {
      setError('Select an item');
      return;
    }
    setBusy(true);
    try {
      await api.post('/inventory/adjustments', {
        itemId: Number(itemId),
        quantity: Number(quantity),
        direction,
        unitCostMinor: unitCostMajor ? toMinor(Number(unitCostMajor)) : undefined,
        movementDate,
        companyId: company.id,
        reason,
      });
      onDone();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || err?.response?.data?.message || 'Adjustment failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="card" style={{ background: 'var(--surface-2)', marginBottom: 16 }}>
      <div style={{ fontWeight: 600, marginBottom: 10 }}>Stock adjustment</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, alignItems: 'end' }}>
        <Labeled label="Item">
          <select value={itemId} onChange={(e) => setItemId(e.target.value)}>
            <option value="">— select —</option>
            {stockItems.map((i) => (
              <option key={i.id} value={i.id}>
                {i.sku} — {i.name}
              </option>
            ))}
          </select>
        </Labeled>
        <Labeled label="Direction">
          <select value={direction} onChange={(e) => setDirection(e.target.value as 'IN' | 'OUT')}>
            <option value="IN">IN (increase)</option>
            <option value="OUT">OUT (decrease)</option>
          </select>
        </Labeled>
        <Labeled label="Quantity">
          <input type="number" step="0.0001" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
        </Labeled>
        <Labeled
          label={`Unit cost${direction === 'OUT' ? ' (optional)' : ''}`}
          caption={direction === 'OUT' ? 'blank = use current weighted-average cost' : undefined}
        >
          <input
            type="number"
            step="0.01"
            value={unitCostMajor}
            onChange={(e) => setUnitCostMajor(e.target.value)}
            placeholder={direction === 'OUT' ? 'auto (WAC)' : ''}
          />
        </Labeled>
        <Labeled label="Date">
          <input type="date" value={movementDate} onChange={(e) => setMovementDate(e.target.value)} />
        </Labeled>
      </div>
      <div style={{ marginTop: 10 }}>
        <Labeled label="Reason">
          <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. stock count correction" />
        </Labeled>
      </div>
      {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 8 }}>{error}</div>}
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <button className="btn" type="submit" disabled={busy}>
          {busy ? 'Posting…' : 'Post adjustment'}
        </button>
        <button className="btn secondary" type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}

// ---------------------------------------------------------------------------
// Items tab
// ---------------------------------------------------------------------------

function ItemsTab({
  company,
  itemClasses,
  accounts,
  taxRates,
}: {
  company: Company;
  itemClasses: ItemClass[];
  accounts: Account[];
  taxRates: TaxRate[];
}) {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<ItemFormState>(blankItemForm(company.baseCurrency));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [stock, setStock] = useState<CurrentStock | null>(null);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [showAdjustment, setShowAdjustment] = useState(false);

  function loadItems() {
    setLoading(true);
    api
      .get('/inventory/items', { params: { companyId: company.id, search: search || undefined } })
      .then((res) => setItems(res.data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    const t = setTimeout(loadItems, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [company.id, search]);

  const selectedItem = items.find((i) => i.id === selectedId) || null;

  useEffect(() => {
    if (selectedItem && selectedItem.itemType === 'STOCK') {
      api.get(`/inventory/items/${selectedItem.id}/stock`).then((res) => setStock(res.data));
      api.get(`/inventory/items/${selectedItem.id}/movements`).then((res) => setMovements(res.data));
    } else {
      setStock(null);
      setMovements([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedItem?.id, selectedItem?.itemType]);

  function itemClassName(id: number | null): string {
    if (!id) return '—';
    const c = itemClasses.find((x) => x.id === id);
    return c ? c.name : `#${id}`;
  }

  function openForEdit(item: Item) {
    setCreating(false);
    setSelectedId(item.id);
    setForm(itemToForm(item));
    setError('');
  }

  function openForCreate() {
    setCreating(true);
    setSelectedId(null);
    setForm(blankItemForm(company.baseCurrency));
    setError('');
  }

  function closePanel() {
    setCreating(false);
    setSelectedId(null);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const payload = itemFormToPayload(form, company.id);
      if (creating) {
        await api.post('/inventory/items', payload);
      } else if (selectedId) {
        await api.patch(`/inventory/items/${selectedId}`, payload);
      }
      loadItems();
      closePanel();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || err?.response?.data?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }

  const panelOpen = creating || !!selectedItem;

  return (
    <div>
      <div className="page-header">
        <input
          placeholder="Search by SKU or name…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ width: 280 }}
        />
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn secondary" onClick={() => setShowAdjustment((v) => !v)} type="button">
            + Stock adjustment
          </button>
          <button className="btn" onClick={openForCreate} type="button">
            + New item
          </button>
        </div>
      </div>

      {showAdjustment && (
        <AdjustmentForm
          company={company}
          items={items}
          defaultItemId={selectedItem?.id}
          onDone={() => {
            setShowAdjustment(false);
            loadItems();
            if (selectedItem && selectedItem.itemType === 'STOCK') {
              api.get(`/inventory/items/${selectedItem.id}/stock`).then((res) => setStock(res.data));
              api.get(`/inventory/items/${selectedItem.id}/movements`).then((res) => setMovements(res.data));
            }
          }}
          onCancel={() => setShowAdjustment(false)}
        />
      )}

      <div className="card">
        {loading ? (
          <div style={{ color: 'var(--text-dim)' }}>Loading…</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>SKU</th>
                <th>Name</th>
                <th>Type</th>
                <th>UoM</th>
                <th>Sales price</th>
                <th>Item class</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr
                  key={item.id}
                  onClick={() => openForEdit(item)}
                  style={{ cursor: 'pointer', background: item.id === selectedId ? 'var(--surface-2)' : undefined }}
                >
                  <td>{item.sku}</td>
                  <td>{item.name}</td>
                  <td>{item.itemType}</td>
                  <td>{item.unitOfMeasure}</td>
                  <td>{formatMoney(item.salesPriceMinor, item.currencyCode)}</td>
                  <td>{itemClassName(item.itemClassId)}</td>
                  <td>
                    <span className={`pill ${item.isActive ? 'green' : 'gray'}`}>
                      {item.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ color: 'var(--text-dim)' }}>
                    No items found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {panelOpen && (
        <form onSubmit={submit} className="card" style={{ marginTop: 16 }}>
          <div className="page-header">
            <h2 style={{ fontSize: 16, margin: 0 }}>{creating ? 'New item' : `Edit item — ${selectedItem?.sku}`}</h2>
            <button className="btn secondary" type="button" onClick={closePanel}>
              Close
            </button>
          </div>

          <ItemForm form={form} setForm={setForm} accounts={accounts} taxRates={taxRates} itemClasses={itemClasses} />

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}

          <div style={{ marginTop: 14 }}>
            <button className="btn" type="submit" disabled={saving}>
              {saving ? 'Saving…' : creating ? 'Create item' : 'Save changes'}
            </button>
          </div>

          {!creating && selectedItem?.itemType === 'STOCK' && (
            <div style={{ marginTop: 20, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
              <h3 style={{ fontSize: 14, marginTop: 0 }}>Current stock</h3>
              {stock ? (
                <div className="kpi-grid" style={{ marginBottom: 16 }}>
                  <div className="kpi-tile">
                    <div className="label">Quantity on hand</div>
                    <div className="value">
                      {stock.quantityOnHand} {selectedItem.unitOfMeasure}
                    </div>
                  </div>
                  <div className="kpi-tile">
                    <div className="label">Weighted-avg cost</div>
                    <div className="value">{formatMoney(stock.weightedAverageCostMinor, company.baseCurrency)}</div>
                  </div>
                  <div className="kpi-tile">
                    <div className="label">Stock value</div>
                    <div className="value">{formatMoney(stock.stockValueMinor, company.baseCurrency)}</div>
                  </div>
                </div>
              ) : (
                <div style={{ color: 'var(--text-dim)' }}>Loading stock…</div>
              )}

              <h3 style={{ fontSize: 14 }}>Recent movements</h3>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Qty</th>
                    <th>Unit cost</th>
                    <th>Total cost</th>
                    <th>Source</th>
                  </tr>
                </thead>
                <tbody>
                  {movements.slice(0, 20).map((m) => (
                    <tr key={m.id}>
                      <td>{m.movementDate}</td>
                      <td>{movementPill(m.movementType)}</td>
                      <td>{m.quantity}</td>
                      <td>{formatMoney(m.unitCostMinor, company.baseCurrency)}</td>
                      <td>{formatMoney(m.totalCostMinor, company.baseCurrency)}</td>
                      <td>{m.sourceType}</td>
                    </tr>
                  ))}
                  {movements.length === 0 && (
                    <tr>
                      <td colSpan={6} style={{ color: 'var(--text-dim)' }}>
                        No movements yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </form>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Item classes tab
// ---------------------------------------------------------------------------

interface ItemClassFormState {
  code: string;
  name: string;
  isActive: boolean;
  inventoryAccountId: string;
  cogsAccountId: string;
  salesAccountId: string;
  adjustmentAccountId: string;
  expenseAccountId: string;
  defaultTaxRateId: string;
}

function blankClassForm(): ItemClassFormState {
  return {
    code: '',
    name: '',
    isActive: true,
    inventoryAccountId: '',
    cogsAccountId: '',
    salesAccountId: '',
    adjustmentAccountId: '',
    expenseAccountId: '',
    defaultTaxRateId: '',
  };
}

function classToForm(c: ItemClass): ItemClassFormState {
  return {
    code: c.code,
    name: c.name,
    isActive: c.isActive,
    inventoryAccountId: c.inventoryAccountId != null ? String(c.inventoryAccountId) : '',
    cogsAccountId: c.cogsAccountId != null ? String(c.cogsAccountId) : '',
    salesAccountId: c.salesAccountId != null ? String(c.salesAccountId) : '',
    adjustmentAccountId: c.adjustmentAccountId != null ? String(c.adjustmentAccountId) : '',
    expenseAccountId: c.expenseAccountId != null ? String(c.expenseAccountId) : '',
    defaultTaxRateId: c.defaultTaxRateId != null ? String(c.defaultTaxRateId) : '',
  };
}

function classFormToPayload(form: ItemClassFormState, companyId: number): Partial<ItemClass> {
  return {
    companyId,
    code: form.code,
    name: form.name,
    isActive: form.isActive,
    inventoryAccountId: form.inventoryAccountId ? Number(form.inventoryAccountId) : null,
    cogsAccountId: form.cogsAccountId ? Number(form.cogsAccountId) : null,
    salesAccountId: form.salesAccountId ? Number(form.salesAccountId) : null,
    adjustmentAccountId: form.adjustmentAccountId ? Number(form.adjustmentAccountId) : null,
    expenseAccountId: form.expenseAccountId ? Number(form.expenseAccountId) : null,
    defaultTaxRateId: form.defaultTaxRateId ? Number(form.defaultTaxRateId) : null,
  };
}

function ItemClassesTab({
  company,
  itemClasses,
  accounts,
  taxRates,
  onChanged,
}: {
  company: Company;
  itemClasses: ItemClass[];
  accounts: Account[];
  taxRates: TaxRate[];
  onChanged: () => void;
}) {
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<ItemClassFormState>(blankClassForm());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const selected = itemClasses.find((c) => c.id === selectedId) || null;
  const panelOpen = creating || !!selected;

  function openForEdit(c: ItemClass) {
    setCreating(false);
    setSelectedId(c.id);
    setForm(classToForm(c));
    setError('');
  }

  function openForCreate() {
    setCreating(true);
    setSelectedId(null);
    setForm(blankClassForm());
    setError('');
  }

  function closePanel() {
    setCreating(false);
    setSelectedId(null);
  }

  const activeAccounts = accounts.filter((a) => a.isActive);
  const activeTaxRates = taxRates.filter((t) => t.isActive);

  const glFields: Array<{
    key: keyof Pick<
      ItemClassFormState,
      'inventoryAccountId' | 'cogsAccountId' | 'salesAccountId' | 'adjustmentAccountId' | 'expenseAccountId'
    >;
    label: string;
  }> = [
    { key: 'inventoryAccountId', label: 'Inventory account' },
    { key: 'cogsAccountId', label: 'COGS account' },
    { key: 'salesAccountId', label: 'Sales account' },
    { key: 'adjustmentAccountId', label: 'Adjustment account' },
    { key: 'expenseAccountId', label: 'Expense account' },
  ];

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const payload = classFormToPayload(form, company.id);
      if (creating) {
        await api.post('/inventory/item-classes', payload);
      } else if (selectedId) {
        await api.patch(`/inventory/item-classes/${selectedId}`, payload);
      }
      onChanged();
      closePanel();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || err?.response?.data?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div />
        <button className="btn" type="button" onClick={openForCreate}>
          + New item class
        </button>
      </div>

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {itemClasses.map((c) => (
              <tr
                key={c.id}
                onClick={() => openForEdit(c)}
                style={{ cursor: 'pointer', background: c.id === selectedId ? 'var(--surface-2)' : undefined }}
              >
                <td>{c.code}</td>
                <td>{c.name}</td>
                <td>
                  <span className={`pill ${c.isActive ? 'green' : 'gray'}`}>{c.isActive ? 'Active' : 'Inactive'}</span>
                </td>
              </tr>
            ))}
            {itemClasses.length === 0 && (
              <tr>
                <td colSpan={3} style={{ color: 'var(--text-dim)' }}>
                  No item classes yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {panelOpen && (
        <form onSubmit={submit} className="card" style={{ marginTop: 16 }}>
          <div className="page-header">
            <h2 style={{ fontSize: 16, margin: 0 }}>{creating ? 'New item class' : `Edit item class — ${selected?.code}`}</h2>
            <button className="btn secondary" type="button" onClick={closePanel}>
              Close
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 10 }}>
              <Labeled label="Code">
                <input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value }))} />
              </Labeled>
              <Labeled label="Name">
                <input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
              </Labeled>
            </div>

            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
              <input
                type="checkbox"
                checked={form.isActive}
                onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))}
              />
              Active
            </label>

            <div className="card" style={{ background: 'var(--surface-2)' }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>GL defaults</div>
              <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: 0 }}>
                These are the accounts (and tax rate) that items in this class fall back to when they don't set their
                own override. Leaving one blank just means no default is set for it.
              </p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
                {glFields.map((f) => (
                  <Labeled key={f.key} label={f.label}>
                    <select
                      value={form[f.key]}
                      onChange={(e) => setForm((prev) => ({ ...prev, [f.key]: e.target.value }))}
                    >
                      <option value="">— none —</option>
                      {activeAccounts.map((a) => (
                        <option key={a.id} value={a.id}>
                          {accountLabel(a)}
                        </option>
                      ))}
                    </select>
                  </Labeled>
                ))}
                <Labeled label="Default tax rate">
                  <select
                    value={form.defaultTaxRateId}
                    onChange={(e) => setForm((f) => ({ ...f, defaultTaxRateId: e.target.value }))}
                  >
                    <option value="">— none —</option>
                    {activeTaxRates.map((t) => (
                      <option key={t.id} value={t.id}>
                        {taxLabel(t)}
                      </option>
                    ))}
                  </select>
                </Labeled>
              </div>
            </div>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}

          <div style={{ marginTop: 14 }}>
            <button className="btn" type="submit" disabled={saving}>
              {saving ? 'Saving…' : creating ? 'Create item class' : 'Save changes'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Stock valuation tab
// ---------------------------------------------------------------------------

function ValuationTab({ company }: { company: Company }) {
  const [rows, setRows] = useState<StockValuationRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .get('/inventory/stock-valuation', { params: { companyId: company.id } })
      .then((res) => setRows(res.data))
      .finally(() => setLoading(false));
  }, [company.id]);

  const total = rows.reduce((sum, r) => sum + Number(r.stockValueMinor || 0), 0);

  return (
    <div>
      <div className="kpi-grid" style={{ marginBottom: 16 }}>
        <div className="kpi-tile">
          <div className="label">Total stock value</div>
          <div className="value">{formatMoney(total, company.baseCurrency)}</div>
        </div>
        <div className="kpi-tile">
          <div className="label">Stock items</div>
          <div className="value">{rows.length}</div>
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ color: 'var(--text-dim)' }}>Loading…</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>SKU</th>
                <th>Name</th>
                <th>UoM</th>
                <th>Qty on hand</th>
                <th>Weighted-avg cost</th>
                <th>Stock value</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.itemId}>
                  <td>{r.sku}</td>
                  <td>{r.name}</td>
                  <td>{r.unitOfMeasure}</td>
                  <td>{r.quantityOnHand}</td>
                  <td>{formatMoney(r.weightedAverageCostMinor, company.baseCurrency)}</td>
                  <td>{formatMoney(r.stockValueMinor, company.baseCurrency)}</td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={6} style={{ color: 'var(--text-dim)' }}>
                    No stock items.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function InventoryPage() {
  const { company, loading: companyLoading } = useCompany();
  const [tab, setTab] = useState<Tab>('items');
  const [itemClasses, setItemClasses] = useState<ItemClass[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [taxRates, setTaxRates] = useState<TaxRate[]>([]);
  const [sharedLoading, setSharedLoading] = useState(true);

  function loadShared(companyId: number) {
    setSharedLoading(true);
    Promise.all([
      api.get('/inventory/item-classes', { params: { companyId } }),
      api.get('/accounting/accounts', { params: { companyId } }),
      api.get('/tax-rates', { params: { companyId } }),
    ])
      .then(([classesRes, accountsRes, taxRes]) => {
        setItemClasses(classesRes.data);
        setAccounts(accountsRes.data);
        setTaxRates(taxRes.data);
      })
      .finally(() => setSharedLoading(false));
  }

  useEffect(() => {
    if (company) loadShared(company.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [company?.id]);

  if (companyLoading || !company) {
    return (
      <div className="card">
        <div style={{ color: 'var(--text-dim)' }}>Loading…</div>
      </div>
    );
  }

  const tabs: Array<{ key: Tab; label: string }> = [
    { key: 'items', label: 'Items' },
    { key: 'item-classes', label: 'Item classes' },
    { key: 'valuation', label: 'Stock valuation' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1>Inventory</h1>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {tabs.map((t) => (
          <button
            key={t.key}
            type="button"
            className={tab === t.key ? 'btn' : 'btn secondary'}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {sharedLoading ? (
        <div className="card">
          <div style={{ color: 'var(--text-dim)' }}>Loading…</div>
        </div>
      ) : (
        <>
          {tab === 'items' && (
            <ItemsTab company={company} itemClasses={itemClasses} accounts={accounts} taxRates={taxRates} />
          )}
          {tab === 'item-classes' && (
            <ItemClassesTab
              company={company}
              itemClasses={itemClasses}
              accounts={accounts}
              taxRates={taxRates}
              onChanged={() => loadShared(company.id)}
            />
          )}
          {tab === 'valuation' && <ValuationTab company={company} />}
        </>
      )}
    </div>
  );
}
