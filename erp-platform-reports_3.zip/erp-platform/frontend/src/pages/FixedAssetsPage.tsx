import React, { useEffect, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

// ---------------------------------------------------------------------------
// Types (field names/shapes mirror the backend fixed-assets entities exactly)
// ---------------------------------------------------------------------------

type DepreciationMethod = 'STRAIGHT_LINE' | 'REDUCING_BALANCE';
type FixedAssetStatus = 'DRAFT' | 'CAPITALIZED' | 'DISPOSED' | 'TRANSFERRED';

interface Account {
  id: number;
  companyId: number;
  code: string;
  name: string;
  accountType: string;
  normalBalance: string;
  isActive: boolean;
}

interface AssetCategory {
  id: number;
  companyId: number;
  code: string;
  name: string;
  assetAccountId: number;
  accumulatedDepreciationAccountId: number;
  depreciationExpenseAccountId: number;
  defaultUsefulLifeMonths: number;
  defaultDepreciationMethod: DepreciationMethod;
  isActive: boolean;
}

// Shape returned by GET /fixed-assets/register (assetRegisterReport) — already
// carries the computed net book value and the category's name, which is
// exactly what the register table and its KPIs need.
interface RegisterRow {
  id: number;
  assetCode: string;
  name: string;
  categoryName?: string;
  acquisitionDate: string;
  status: FixedAssetStatus;
  costMinor: string;
  accumulatedDepreciationMinor: string;
  netBookValueMinor: string;
}

interface DepreciationLineRow {
  id: number;
  runId: number;
  fixedAssetId: number;
  depreciationAmountMinor: string;
  accumulatedAfterMinor: string;
}

interface DepreciationRunRow {
  id: number;
  companyId: number;
  periodCode: string;
  runDate: string;
  totalDepreciationMinor: string;
  journalEntryId: number | null;
  status: string;
  createdAt?: string;
  lines?: DepreciationLineRow[];
}

type Tab = 'register' | 'categories' | 'depreciation';

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function currentPeriodCode(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function toMajorStr(minor: string | number | null | undefined): string {
  return (Number(minor || 0) / 100).toFixed(2);
}

function minorFromMajorInput(major: string): number {
  return toMinor(Number(major || 0));
}

function Field({ label, children, grow }: { label: string; children: React.ReactNode; grow?: boolean }) {
  return (
    <div style={grow ? { flex: 1, minWidth: 180 } : undefined}>
      <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>{label}</div>
      {children}
    </div>
  );
}

function AccountSelect({
  accounts,
  value,
  onChange,
  required,
  placeholder = 'Select account…',
}: {
  accounts: Account[];
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} required={required}>
      <option value="">{placeholder}</option>
      {accounts.map((a) => (
        <option key={a.id} value={a.id}>
          {a.code} — {a.name}
        </option>
      ))}
    </select>
  );
}

function StatusPill({ status }: { status: FixedAssetStatus }) {
  const map: Record<FixedAssetStatus, { cls: string; label: string }> = {
    DRAFT: { cls: 'gray', label: 'Draft' },
    CAPITALIZED: { cls: 'green', label: 'Capitalized' },
    DISPOSED: { cls: 'red', label: 'Disposed' },
    TRANSFERRED: { cls: 'amber', label: 'Transferred' },
  };
  const m = map[status] || { cls: 'gray', label: status };
  return <span className={`pill ${m.cls}`}>{m.label}</span>;
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button className={active ? 'btn' : 'btn secondary'} onClick={onClick} type="button">
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------

export default function FixedAssetsPage() {
  const { company } = useCompany();
  const [tab, setTab] = useState<Tab>('register');
  const [categories, setCategories] = useState<AssetCategory[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);

  function reloadCategories() {
    if (!company) return;
    api.get('/fixed-assets/categories', { params: { companyId: company.id } }).then((res) => setCategories(res.data));
  }

  useEffect(() => {
    if (!company) return;
    reloadCategories();
    api.get('/accounting/accounts', { params: { companyId: company.id } }).then((res) => setAccounts(res.data));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [company?.id]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1>Fixed Assets 🎉</h1>
          <p style={{ color: 'var(--text-dim)', margin: '4px 0 0', fontSize: 13 }}>
            New: capitalize, depreciate and dispose of company assets, end to end.
          </p>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
        <TabButton active={tab === 'register'} onClick={() => setTab('register')} label="Asset Register" />
        <TabButton active={tab === 'categories'} onClick={() => setTab('categories')} label="Categories" />
        <TabButton active={tab === 'depreciation'} onClick={() => setTab('depreciation')} label="Depreciation Runs" />
      </div>

      {!company ? (
        <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
      ) : tab === 'register' ? (
        <AssetRegisterTab companyId={company.id} currency={company.baseCurrency} categories={categories} accounts={accounts} />
      ) : tab === 'categories' ? (
        <CategoriesTab companyId={company.id} categories={categories} accounts={accounts} reload={reloadCategories} />
      ) : (
        <DepreciationTab companyId={company.id} currency={company.baseCurrency} />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Asset Register
// ---------------------------------------------------------------------------

function emptyAssetForm() {
  return {
    assetCode: '',
    name: '',
    categoryId: '',
    acquisitionDate: todayStr(),
    costMajor: '',
    salvageValueMajor: '',
    usefulLifeMonths: '',
    depreciationMethod: 'STRAIGHT_LINE' as DepreciationMethod,
    depreciationRateBasisPoints: '',
    serialNumber: '',
    branchOrLocation: '',
    notes: '',
  };
}

function emptyDisposeForm() {
  return {
    disposalDate: todayStr(),
    proceedsMajor: '',
    proceedsAccountId: '',
    gainOnDisposalAccountId: '',
    lossOnDisposalAccountId: '',
  };
}

function AssetRegisterTab({
  companyId,
  currency,
  categories,
  accounts,
}: {
  companyId: number;
  currency: string;
  categories: AssetCategory[];
  accounts: Account[];
}) {
  const [rows, setRows] = useState<RegisterRow[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyAssetForm());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [capitalizingId, setCapitalizingId] = useState<number | null>(null);
  const [clearingAccountId, setClearingAccountId] = useState('');
  const [capBusy, setCapBusy] = useState(false);
  const [capError, setCapError] = useState('');

  const [disposingId, setDisposingId] = useState<number | null>(null);
  const [disposeForm, setDisposeForm] = useState(emptyDisposeForm());
  const [disposeBusy, setDisposeBusy] = useState(false);
  const [disposeError, setDisposeError] = useState('');

  function load() {
    setRows(null);
    api.get('/fixed-assets/register', { params: { companyId } }).then((res) => setRows(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  function onPickCategory(categoryIdStr: string) {
    const cat = categories.find((c) => String(c.id) === categoryIdStr);
    if (!cat) {
      setForm((f) => ({ ...f, categoryId: categoryIdStr }));
      return;
    }
    setForm((f) => ({
      ...f,
      categoryId: categoryIdStr,
      usefulLifeMonths: f.usefulLifeMonths || String(cat.defaultUsefulLifeMonths),
      depreciationMethod: f.depreciationMethod === 'STRAIGHT_LINE' ? cat.defaultDepreciationMethod : f.depreciationMethod,
    }));
  }

  function resetForm() {
    setForm(emptyAssetForm());
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!form.categoryId) {
      setError('Select an asset category');
      return;
    }
    setBusy(true);
    try {
      await api.post('/fixed-assets', {
        companyId,
        assetCode: form.assetCode,
        name: form.name,
        categoryId: Number(form.categoryId),
        acquisitionDate: form.acquisitionDate,
        costMinor: minorFromMajorInput(form.costMajor),
        salvageValueMinor: form.salvageValueMajor ? minorFromMajorInput(form.salvageValueMajor) : 0,
        usefulLifeMonths: Number(form.usefulLifeMonths) || 0,
        depreciationMethod: form.depreciationMethod,
        depreciationRateBasisPoints:
          form.depreciationMethod === 'REDUCING_BALANCE' && form.depreciationRateBasisPoints
            ? Number(form.depreciationRateBasisPoints)
            : undefined,
        serialNumber: form.serialNumber || undefined,
        branchOrLocation: form.branchOrLocation || undefined,
        notes: form.notes || undefined,
      });
      resetForm();
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create asset');
    } finally {
      setBusy(false);
    }
  }

  function openCapitalize(id: number) {
    setDisposingId(null);
    setCapitalizingId((prev) => (prev === id ? null : id));
    setClearingAccountId('');
    setCapError('');
  }

  async function onCapitalize(id: number) {
    setCapBusy(true);
    setCapError('');
    try {
      await api.post(`/fixed-assets/${id}/capitalize`, clearingAccountId ? { clearingAccountId: Number(clearingAccountId) } : {});
      setCapitalizingId(null);
      load();
    } catch (err: any) {
      setCapError(err?.response?.data?.error?.message || 'Failed to capitalize asset');
    } finally {
      setCapBusy(false);
    }
  }

  function openDispose(row: RegisterRow) {
    setCapitalizingId(null);
    setDisposingId((prev) => (prev === row.id ? null : row.id));
    setDisposeForm(emptyDisposeForm());
    setDisposeError('');
  }

  async function onDispose(row: RegisterRow) {
    if (!disposeForm.proceedsAccountId) {
      setDisposeError('Select a proceeds account');
      return;
    }
    setDisposeBusy(true);
    setDisposeError('');
    try {
      await api.post(`/fixed-assets/${row.id}/dispose`, {
        disposalDate: disposeForm.disposalDate,
        disposalProceedsMinor: disposeForm.proceedsMajor ? minorFromMajorInput(disposeForm.proceedsMajor) : 0,
        proceedsAccountId: Number(disposeForm.proceedsAccountId),
        gainOnDisposalAccountId: disposeForm.gainOnDisposalAccountId ? Number(disposeForm.gainOnDisposalAccountId) : undefined,
        lossOnDisposalAccountId: disposeForm.lossOnDisposalAccountId ? Number(disposeForm.lossOnDisposalAccountId) : undefined,
      });
      setDisposingId(null);
      load();
    } catch (err: any) {
      setDisposeError(err?.response?.data?.error?.message || 'Failed to dispose asset');
    } finally {
      setDisposeBusy(false);
    }
  }

  const totals = (rows || []).reduce(
    (acc, r) => {
      acc.cost += Number(r.costMinor || 0);
      acc.accum += Number(r.accumulatedDepreciationMinor || 0);
      acc.nbv += Number(r.netBookValueMinor || 0);
      return acc;
    },
    { cost: 0, accum: 0, nbv: 0 },
  );

  const COLS = 9;

  return (
    <div>
      <div className="kpi-grid" style={{ marginBottom: 18 }}>
        <div className="kpi-tile">
          <div className="label">Total Cost</div>
          <div className="value">{formatMoney(totals.cost, currency)}</div>
        </div>
        <div className="kpi-tile">
          <div className="label">Accumulated Depreciation</div>
          <div className="value">{formatMoney(totals.accum, currency)}</div>
        </div>
        <div className="kpi-tile">
          <div className="label">Net Book Value</div>
          <div className="value">{formatMoney(totals.nbv, currency)}</div>
        </div>
      </div>

      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Asset Register</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Asset'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label="Asset code">
              <input value={form.assetCode} onChange={(e) => setForm({ ...form, assetCode: e.target.value })} required />
            </Field>
            <Field label="Name" grow>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                style={{ width: '100%' }}
                required
              />
            </Field>
            <Field label="Category" grow>
              <select value={form.categoryId} onChange={(e) => onPickCategory(e.target.value)} required>
                <option value="">Select category…</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Acquisition date">
              <input
                type="date"
                value={form.acquisitionDate}
                onChange={(e) => setForm({ ...form, acquisitionDate: e.target.value })}
                required
              />
            </Field>
          </div>

          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label={`Cost (${currency})`}>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.costMajor}
                onChange={(e) => setForm({ ...form, costMajor: e.target.value })}
                style={{ width: 130 }}
                required
              />
            </Field>
            <Field label={`Salvage value (${currency})`}>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.salvageValueMajor}
                onChange={(e) => setForm({ ...form, salvageValueMajor: e.target.value })}
                style={{ width: 130 }}
              />
            </Field>
            <Field label="Useful life (months)">
              <input
                type="number"
                min="1"
                value={form.usefulLifeMonths}
                onChange={(e) => setForm({ ...form, usefulLifeMonths: e.target.value })}
                style={{ width: 120 }}
                required
              />
            </Field>
            <Field label="Depreciation method">
              <select
                value={form.depreciationMethod}
                onChange={(e) => setForm({ ...form, depreciationMethod: e.target.value as DepreciationMethod })}
              >
                <option value="STRAIGHT_LINE">Straight line</option>
                <option value="REDUCING_BALANCE">Reducing balance</option>
              </select>
            </Field>
            {form.depreciationMethod === 'REDUCING_BALANCE' && (
              <Field label="Rate (basis points, e.g. 2000 = 20%/yr)">
                <input
                  type="number"
                  min="0"
                  value={form.depreciationRateBasisPoints}
                  onChange={(e) => setForm({ ...form, depreciationRateBasisPoints: e.target.value })}
                  style={{ width: 160 }}
                  required
                />
              </Field>
            )}
          </div>

          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label="Serial number">
              <input value={form.serialNumber} onChange={(e) => setForm({ ...form, serialNumber: e.target.value })} />
            </Field>
            <Field label="Branch / location">
              <input
                value={form.branchOrLocation}
                onChange={(e) => setForm({ ...form, branchOrLocation: e.target.value })}
              />
            </Field>
            <Field label="Notes" grow>
              <input
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                style={{ width: '100%' }}
              />
            </Field>
          </div>

          <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: -2 }}>
            New assets are saved as <strong>Draft</strong>. Capitalize an asset once it's ready to start depreciating.
          </p>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Create asset'}
          </button>
        </form>
      )}

      <div className="card">
        {rows === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : rows.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No fixed assets yet — create the first one above.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Asset code</th>
                <th>Name</th>
                <th>Category</th>
                <th>Acquisition date</th>
                <th>Status</th>
                <th>Cost</th>
                <th>Accum. depreciation</th>
                <th>Net book value</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <React.Fragment key={r.id}>
                  <tr>
                    <td>{r.assetCode}</td>
                    <td>{r.name}</td>
                    <td>{r.categoryName || '—'}</td>
                    <td>{r.acquisitionDate}</td>
                    <td>
                      <StatusPill status={r.status} />
                    </td>
                    <td>{formatMoney(r.costMinor, currency)}</td>
                    <td>{formatMoney(r.accumulatedDepreciationMinor, currency)}</td>
                    <td>{formatMoney(r.netBookValueMinor, currency)}</td>
                    <td>
                      {r.status === 'DRAFT' && (
                        <button className="btn secondary" type="button" onClick={() => openCapitalize(r.id)}>
                          {capitalizingId === r.id ? 'Cancel' : 'Capitalize'}
                        </button>
                      )}
                      {r.status === 'CAPITALIZED' && (
                        <button className="btn secondary" type="button" onClick={() => openDispose(r)}>
                          {disposingId === r.id ? 'Cancel' : 'Dispose'}
                        </button>
                      )}
                    </td>
                  </tr>

                  {capitalizingId === r.id && (
                    <tr>
                      <td colSpan={COLS} style={{ background: 'var(--surface-2)' }}>
                        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end', padding: '6px 0' }}>
                          <Field label="Clearing account (optional)" grow>
                            <AccountSelect
                              accounts={accounts}
                              value={clearingAccountId}
                              onChange={setClearingAccountId}
                              placeholder="No clearing entry…"
                            />
                          </Field>
                          <button className="btn" type="button" disabled={capBusy} onClick={() => onCapitalize(r.id)}>
                            {capBusy ? 'Capitalizing…' : 'Confirm Capitalize'}
                          </button>
                        </div>
                        <p style={{ color: 'var(--text-dim)', fontSize: 12, margin: '4px 0 6px' }}>
                          Leave blank if this is an opening-balance migration with no funding-source entry needed.
                          Otherwise this account is credited for the asset's cost ({formatMoney(r.costMinor, currency)}).
                        </p>
                        {capError && <div style={{ color: 'var(--danger)', fontSize: 13 }}>{capError}</div>}
                      </td>
                    </tr>
                  )}

                  {disposingId === r.id && (
                    <DisposeRow
                      row={r}
                      currency={currency}
                      accounts={accounts}
                      form={disposeForm}
                      setForm={setDisposeForm}
                      busy={disposeBusy}
                      error={disposeError}
                      colSpan={COLS}
                      onSubmit={() => onDispose(r)}
                    />
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function DisposeRow({
  row,
  currency,
  accounts,
  form,
  setForm,
  busy,
  error,
  colSpan,
  onSubmit,
}: {
  row: RegisterRow;
  currency: string;
  accounts: Account[];
  form: ReturnType<typeof emptyDisposeForm>;
  setForm: React.Dispatch<React.SetStateAction<ReturnType<typeof emptyDisposeForm>>>;
  busy: boolean;
  error: string;
  colSpan: number;
  onSubmit: () => void;
}) {
  const proceedsMinor = form.proceedsMajor ? minorFromMajorInput(form.proceedsMajor) : 0;
  const netBookValueMinor = Number(row.netBookValueMinor || 0);
  const gainLossMinor = proceedsMinor - netBookValueMinor;
  const isGain = gainLossMinor > 0;
  const isLoss = gainLossMinor < 0;

  return (
    <tr>
      <td colSpan={colSpan} style={{ background: 'var(--surface-2)' }}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end', padding: '6px 0' }}>
          <Field label="Disposal date">
            <input
              type="date"
              value={form.disposalDate}
              onChange={(e) => setForm((f) => ({ ...f, disposalDate: e.target.value }))}
              required
            />
          </Field>
          <Field label={`Proceeds (${currency})`}>
            <input
              type="number"
              min="0"
              step="0.01"
              value={form.proceedsMajor}
              onChange={(e) => setForm((f) => ({ ...f, proceedsMajor: e.target.value }))}
              style={{ width: 130 }}
            />
          </Field>
          <Field label="Proceeds account" grow>
            <AccountSelect
              accounts={accounts}
              value={form.proceedsAccountId}
              onChange={(v) => setForm((f) => ({ ...f, proceedsAccountId: v }))}
              required
            />
          </Field>
          <Field label="Gain on disposal account" grow>
            <AccountSelect
              accounts={accounts}
              value={form.gainOnDisposalAccountId}
              onChange={(v) => setForm((f) => ({ ...f, gainOnDisposalAccountId: v }))}
              placeholder="Only needed on a gain…"
            />
          </Field>
          <Field label="Loss on disposal account" grow>
            <AccountSelect
              accounts={accounts}
              value={form.lossOnDisposalAccountId}
              onChange={(v) => setForm((f) => ({ ...f, lossOnDisposalAccountId: v }))}
              placeholder="Only needed on a loss…"
            />
          </Field>
          <button className="btn" type="button" disabled={busy} onClick={onSubmit}>
            {busy ? 'Disposing…' : 'Confirm Dispose'}
          </button>
        </div>

        <p style={{ fontSize: 13, margin: '4px 0 6px' }}>
          Net book value: <strong>{formatMoney(row.netBookValueMinor, currency)}</strong> &nbsp; Expected result:{' '}
          {isGain ? (
            <span className="pill green">Gain of {formatMoney(gainLossMinor, currency)} — set the gain account</span>
          ) : isLoss ? (
            <span className="pill red">Loss of {formatMoney(-gainLossMinor, currency)} — set the loss account</span>
          ) : (
            <span className="pill gray">No gain or loss</span>
          )}
        </p>

        {error && <div style={{ color: 'var(--danger)', fontSize: 13 }}>{error}</div>}
      </td>
    </tr>
  );
}

// ---------------------------------------------------------------------------
// Categories
// ---------------------------------------------------------------------------

function emptyCategoryForm() {
  return {
    code: '',
    name: '',
    assetAccountId: '',
    accumulatedDepreciationAccountId: '',
    depreciationExpenseAccountId: '',
    defaultUsefulLifeMonths: '60',
    defaultDepreciationMethod: 'STRAIGHT_LINE' as DepreciationMethod,
  };
}

function CategoriesTab({
  companyId,
  categories,
  accounts,
  reload,
}: {
  companyId: number;
  categories: AssetCategory[];
  accounts: Account[];
  reload: () => void;
}) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyCategoryForm());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await api.post('/fixed-assets/categories', {
        companyId,
        code: form.code,
        name: form.name,
        assetAccountId: Number(form.assetAccountId),
        accumulatedDepreciationAccountId: Number(form.accumulatedDepreciationAccountId),
        depreciationExpenseAccountId: Number(form.depreciationExpenseAccountId),
        defaultUsefulLifeMonths: Number(form.defaultUsefulLifeMonths) || 0,
        defaultDepreciationMethod: form.defaultDepreciationMethod,
      });
      setForm(emptyCategoryForm());
      setShowForm(false);
      reload();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create category');
    } finally {
      setBusy(false);
    }
  }

  const sorted = categories.slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Asset Categories</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Category'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label="Code">
              <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required />
            </Field>
            <Field label="Name" grow>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                style={{ width: '100%' }}
                required
              />
            </Field>
            <Field label="Default useful life (months)">
              <input
                type="number"
                min="1"
                value={form.defaultUsefulLifeMonths}
                onChange={(e) => setForm({ ...form, defaultUsefulLifeMonths: e.target.value })}
                style={{ width: 150 }}
                required
              />
            </Field>
            <Field label="Default depreciation method">
              <select
                value={form.defaultDepreciationMethod}
                onChange={(e) => setForm({ ...form, defaultDepreciationMethod: e.target.value as DepreciationMethod })}
              >
                <option value="STRAIGHT_LINE">Straight line</option>
                <option value="REDUCING_BALANCE">Reducing balance</option>
              </select>
            </Field>
          </div>

          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label="Asset (cost) account" grow>
              <AccountSelect
                accounts={accounts}
                value={form.assetAccountId}
                onChange={(v) => setForm({ ...form, assetAccountId: v })}
                required
              />
            </Field>
            <Field label="Accumulated depreciation account" grow>
              <AccountSelect
                accounts={accounts}
                value={form.accumulatedDepreciationAccountId}
                onChange={(v) => setForm({ ...form, accumulatedDepreciationAccountId: v })}
                required
              />
            </Field>
            <Field label="Depreciation expense account" grow>
              <AccountSelect
                accounts={accounts}
                value={form.depreciationExpenseAccountId}
                onChange={(v) => setForm({ ...form, depreciationExpenseAccountId: v })}
                required
              />
            </Field>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Create category'}
          </button>
        </form>
      )}

      <div className="card">
        {sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No asset categories yet — create the first one above.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Default useful life</th>
                <th>Default method</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((c) => (
                <tr key={c.id}>
                  <td>{c.code}</td>
                  <td>{c.name}</td>
                  <td>{c.defaultUsefulLifeMonths} months</td>
                  <td>{c.defaultDepreciationMethod === 'STRAIGHT_LINE' ? 'Straight line' : 'Reducing balance'}</td>
                  <td>
                    {c.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Depreciation Runs
// ---------------------------------------------------------------------------

function emptyRunForm() {
  return { periodCode: currentPeriodCode(), runDate: todayStr() };
}

function DepreciationTab({ companyId, currency }: { companyId: number; currency: string }) {
  const [runs, setRuns] = useState<DepreciationRunRow[] | null>(null);
  const [form, setForm] = useState(emptyRunForm());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [lastResult, setLastResult] = useState<DepreciationRunRow | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [linesByRun, setLinesByRun] = useState<Record<number, DepreciationLineRow[]>>({});
  const [assetNames, setAssetNames] = useState<Record<number, string>>({});

  function load() {
    setRuns(null);
    api.get('/fixed-assets/depreciation-runs', { params: { companyId } }).then((res) => setRuns(res.data));
  }

  useEffect(() => {
    load();
    api.get('/fixed-assets', { params: { companyId } }).then((res) => {
      const map: Record<number, string> = {};
      (res.data || []).forEach((a: any) => {
        map[a.id] = `${a.assetCode} — ${a.name}`;
      });
      setAssetNames(map);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  async function onRun(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    setLastResult(null);
    try {
      const res = await api.post('/fixed-assets/run-depreciation', {
        companyId,
        periodCode: form.periodCode,
        runDate: form.runDate,
      });
      const run: DepreciationRunRow = res.data;
      setLastResult(run);
      if (run?.id != null && run.lines) {
        setLinesByRun((prev) => ({ ...prev, [run.id]: run.lines as DepreciationLineRow[] }));
        setExpandedId(run.id);
      }
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to run depreciation');
    } finally {
      setBusy(false);
    }
  }

  function toggleExpand(id: number) {
    setExpandedId((prev) => (prev === id ? null : id));
  }

  const sortedRuns = runs || [];

  return (
    <div>
      <div className="card" style={{ marginBottom: 18 }}>
        <h2 style={{ marginTop: 0, fontSize: 16 }}>Run Depreciation</h2>
        <form onSubmit={onRun} style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <Field label="Period (YYYY-MM)">
            <input
              value={form.periodCode}
              onChange={(e) => setForm({ ...form, periodCode: e.target.value })}
              placeholder={currentPeriodCode()}
              style={{ width: 120 }}
              required
            />
          </Field>
          <Field label="Run date">
            <input type="date" value={form.runDate} onChange={(e) => setForm({ ...form, runDate: e.target.value })} required />
          </Field>
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Running…' : 'Run'}
          </button>
        </form>

        {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}

        {lastResult && (
          <div className="kpi-grid" style={{ marginTop: 16 }}>
            <div className="kpi-tile">
              <div className="label">Assets depreciated</div>
              <div className="value">{(lastResult.lines || []).length}</div>
            </div>
            <div className="kpi-tile">
              <div className="label">Total depreciation posted</div>
              <div className="value">{formatMoney(lastResult.totalDepreciationMinor, currency)}</div>
            </div>
          </div>
        )}
      </div>

      <div className="card">
        <h2 style={{ marginTop: 0, fontSize: 16 }}>Run History</h2>
        {runs === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : sortedRuns.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No depreciation runs yet — run the first one above.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th></th>
                <th>Period</th>
                <th>Run date</th>
                <th>Total depreciation</th>
              </tr>
            </thead>
            <tbody>
              {sortedRuns.map((run) => {
                const cachedLines = linesByRun[run.id];
                return (
                  <React.Fragment key={run.id}>
                    <tr style={{ cursor: 'pointer' }} onClick={() => toggleExpand(run.id)}>
                      <td>{expandedId === run.id ? '▾' : '▸'}</td>
                      <td>{run.periodCode}</td>
                      <td>{run.runDate}</td>
                      <td>{formatMoney(run.totalDepreciationMinor, currency)}</td>
                    </tr>
                    {expandedId === run.id && (
                      <tr>
                        <td colSpan={4} style={{ background: 'var(--surface-2)' }}>
                          {cachedLines ? (
                            cachedLines.length === 0 ? (
                              <p style={{ color: 'var(--text-dim)', margin: 8 }}>No assets were depreciated in this run.</p>
                            ) : (
                              <table className="data-table">
                                <thead>
                                  <tr>
                                    <th>Asset</th>
                                    <th>Depreciation amount</th>
                                    <th>Accumulated after</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {cachedLines.map((l) => (
                                    <tr key={l.id}>
                                      <td>{assetNames[l.fixedAssetId] || l.fixedAssetId}</td>
                                      <td>{formatMoney(l.depreciationAmountMinor, currency)}</td>
                                      <td>{formatMoney(l.accumulatedAfterMinor, currency)}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            )
                          ) : (
                            <p style={{ color: 'var(--text-dim)', margin: 8, fontSize: 12 }}>
                              Line-level detail is only available right after running this period — the history
                              listing doesn't return it. Re-run this period to see which assets it covered.
                            </p>
                          )}
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
