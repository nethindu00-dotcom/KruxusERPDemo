import React, { useEffect, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

// ---------------------------------------------------------------------------
// Types (field names/shapes mirror the backend entities exactly)
// ---------------------------------------------------------------------------

type SalesOrderStatus =
  | 'DRAFT'
  | 'CONFIRMED'
  | 'PARTIALLY_DELIVERED'
  | 'DELIVERED'
  | 'INVOICED'
  | 'CLOSED'
  | 'CANCELLED';

type InvoiceStatus = 'DRAFT' | 'POSTED' | 'PARTIALLY_PAID' | 'PAID' | 'VOID';

interface Customer {
  id: number;
  companyId: number;
  code: string;
  name: string;
  email: string | null;
  phone: string | null;
  address: string | null;
  defaultCurrencyCode: string;
  creditTermsDays: number;
  creditLimitMinor: string | null;
  arControlAccountId: number | null;
  isActive: boolean;
}

interface SalesOrderLine {
  id: number;
  soId: number;
  itemId: number;
  description: string | null;
  quantity: string;
  unitPriceMinor: string;
  taxRateId: number | null;
  quantityDelivered: string;
  quantityInvoiced: string;
}

interface SalesOrder {
  id: number;
  companyId: number;
  soNumber: string;
  customerId: number;
  orderDate: string;
  currencyCode: string;
  exchangeRate: string;
  status: SalesOrderStatus;
  notes: string | null;
  lines: SalesOrderLine[];
  createdAt: string;
}

interface DeliveryLine {
  id: number;
  dnId: number;
  soLineId: number | null;
  itemId: number;
  quantity: string;
}

interface Delivery {
  id: number;
  companyId: number;
  dnNumber: string;
  soId: number | null;
  customerId: number;
  deliveryDate: string;
  notes: string | null;
  lines: DeliveryLine[];
  createdAt: string;
}

interface InvoiceLine {
  id: number;
  invoiceId: number;
  itemId: number | null;
  description: string;
  quantity: string;
  unitPriceMinor: string;
  taxRateId: number | null;
  incomeAccountId: number | null;
  lineTotalMinor: string;
}

interface Invoice {
  id: number;
  companyId: number;
  invoiceNumber: string;
  customerId: number;
  invoiceDate: string;
  dueDate: string;
  currencyCode: string;
  exchangeRate: string;
  status: InvoiceStatus;
  subtotalMinor: string;
  taxMinor: string;
  totalMinor: string;
  amountReceivedMinor: string;
  journalEntryId: number | null;
  soId: number | null;
  dnId: number | null;
  lines: InvoiceLine[];
  createdAt: string;
}

interface ReceiptAllocation {
  id: number;
  receiptId: number;
  invoiceId: number;
  allocatedAmountMinor: string;
  realizedGainLossMinor: string | null;
}

interface Receipt {
  id: number;
  companyId: number;
  receiptNumber: string;
  customerId: number;
  receiptDate: string;
  bankAccountGlAccountId: number;
  currencyCode: string;
  exchangeRate: string;
  amountMinor: string;
  journalEntryId: number | null;
  status: string;
  allocations: ReceiptAllocation[];
  createdAt: string;
}

interface Item {
  id: number;
  companyId: number;
  sku: string;
  name: string;
  description: string | null;
  itemType: 'STOCK' | 'SERVICE' | 'NON_STOCK';
  itemClassId: number | null;
  unitOfMeasure: string;
  costingMethod: string;
  salesPriceMinor: string;
  currencyCode: string;
  reorderLevel: number | null;
  isActive: boolean;
  inventoryAccountId: number | null;
  cogsAccountId: number | null;
  salesAccountId: number | null;
  adjustmentAccountId: number | null;
  expenseAccountId: number | null;
  defaultTaxRateId: number | null;
}

interface ItemClass {
  id: number;
  companyId: number;
  code: string;
  name: string;
  inventoryAccountId: number | null;
  cogsAccountId: number | null;
  salesAccountId: number | null;
  adjustmentAccountId: number | null;
  expenseAccountId: number | null;
  defaultTaxRateId: number | null;
  isActive: boolean;
}

interface TaxRate {
  id: number;
  companyId: number;
  code: string;
  name: string;
  rateBasisPoints: number;
  pricingMode: 'EXCLUSIVE' | 'INCLUSIVE';
  isVat: boolean;
  outputTaxAccountId: number | null;
  inputTaxAccountId: number | null;
  isActive: boolean;
}

interface Account {
  id: number;
  companyId: number;
  code: string;
  name: string;
  accountType: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
  normalBalance: 'DEBIT' | 'CREDIT';
  parentId: number | null;
  isActive: boolean;
  isControlAccount: boolean;
}

interface AgingBucket {
  customerId: number;
  customerCode: string;
  customerName: string;
  current: number;
  d1_30: number;
  d31_60: number;
  d61_90: number;
  d90Plus: number;
  totalMinor: number;
}

type Tab = 'customers' | 'sales-orders' | 'deliveries' | 'invoices' | 'receipts' | 'aging';

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function addDaysStr(base: string, days: number): string {
  const d = new Date(base);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function toMajorStr(minor: string | number | null | undefined): string {
  return (Number(minor || 0) / 100).toFixed(2);
}

function minorFromMajorInput(major: string): number {
  return toMinor(Number(major || 0));
}

/** Mirrors ItemsService.resolveGlAccounts' fallback chain for the one field the frontend needs client-side. */
function resolveDefaultTaxRateId(item: Item, itemClasses: ItemClass[]): number | null {
  if (item.defaultTaxRateId != null) return item.defaultTaxRateId;
  const cls = itemClasses.find((c) => c.id === item.itemClassId);
  return cls?.defaultTaxRateId ?? null;
}

interface ReferenceData {
  customers: Customer[];
  items: Item[];
  itemClasses: ItemClass[];
  taxRates: TaxRate[];
  accounts: Account[];
  reloadCustomers: () => void;
  reloadItems: () => void;
}

function useReferenceData(companyId: number): ReferenceData {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [itemClasses, setItemClasses] = useState<ItemClass[]>([]);
  const [taxRates, setTaxRates] = useState<TaxRate[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);

  function reloadCustomers() {
    api.get('/receivables/customers', { params: { companyId } }).then((res) => setCustomers(res.data));
  }
  function reloadItems() {
    api.get('/inventory/items', { params: { companyId } }).then((res) => setItems(res.data));
  }

  useEffect(() => {
    reloadCustomers();
    reloadItems();
    api.get('/inventory/item-classes', { params: { companyId } }).then((res) => setItemClasses(res.data));
    api.get('/tax-rates', { params: { companyId } }).then((res) => setTaxRates(res.data));
    api.get('/accounting/accounts', { params: { companyId } }).then((res) => setAccounts(res.data));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  return { customers, items, itemClasses, taxRates, accounts, reloadCustomers, reloadItems };
}

function customerLabel(customers: Customer[], id: number | null | undefined): string {
  const c = customers.find((x) => x.id === id);
  return c ? `${c.code} — ${c.name}` : id != null ? String(id) : '—';
}

function itemLabel(items: Item[], id: number | null | undefined): string {
  const i = items.find((x) => x.id === id);
  return i ? `${i.sku} — ${i.name}` : id != null ? String(id) : '—';
}

function accountLabel(accounts: Account[], id: number | null | undefined): string {
  const a = accounts.find((x) => x.id === id);
  return a ? `${a.code} — ${a.name}` : id != null ? String(id) : '—';
}

function soLabel(orders: SalesOrder[], id: number | null | undefined): string {
  const so = orders.find((x) => x.id === id);
  return so ? so.soNumber : id != null ? String(id) : '—';
}

// ---------------------------------------------------------------------------
// Reusable pickers
// ---------------------------------------------------------------------------

function CustomerSelect({
  customers,
  value,
  onChange,
  required,
}: {
  customers: Customer[];
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} required={required}>
      <option value="">Select customer…</option>
      {customers.map((c) => (
        <option key={c.id} value={c.id}>
          {c.code} — {c.name}
        </option>
      ))}
    </select>
  );
}

function AccountSelect({
  accounts,
  value,
  onChange,
  required,
  placeholder = 'Select account…',
}: {
  accounts: Account[];
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} required={required}>
      <option value="">{placeholder}</option>
      {accounts.map((a) => (
        <option key={a.id} value={a.id}>
          {a.code} — {a.name}
        </option>
      ))}
    </select>
  );
}

function ItemSelect({
  items,
  value,
  onChange,
  required,
}: {
  items: Item[];
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} required={required}>
      <option value="">Select item…</option>
      {items.map((i) => (
        <option key={i.id} value={i.id}>
          {i.sku} — {i.name}
        </option>
      ))}
    </select>
  );
}

function TaxRateSelect({
  taxRates,
  value,
  onChange,
}: {
  taxRates: TaxRate[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">No tax</option>
      {taxRates.map((t) => (
        <option key={t.id} value={t.id}>
          {t.code} ({(t.rateBasisPoints / 100).toFixed(2)}%)
        </option>
      ))}
    </select>
  );
}

function SoStatusPill({ status }: { status: SalesOrderStatus }) {
  const map: Record<SalesOrderStatus, { cls: string; label: string }> = {
    DRAFT: { cls: 'gray', label: 'Draft' },
    CONFIRMED: { cls: 'amber', label: 'Confirmed' },
    PARTIALLY_DELIVERED: { cls: 'amber', label: 'Partially delivered' },
    DELIVERED: { cls: 'green', label: 'Delivered' },
    INVOICED: { cls: 'green', label: 'Invoiced' },
    CLOSED: { cls: 'gray', label: 'Closed' },
    CANCELLED: { cls: 'red', label: 'Cancelled' },
  };
  const m = map[status] || { cls: 'gray', label: status };
  return <span className={`pill ${m.cls}`}>{m.label}</span>;
}

function InvoiceStatusPill({ status }: { status: InvoiceStatus }) {
  const map: Record<InvoiceStatus, { cls: string; label: string }> = {
    DRAFT: { cls: 'gray', label: 'Draft — not posted' },
    POSTED: { cls: 'amber', label: 'Posted' },
    PARTIALLY_PAID: { cls: 'amber', label: 'Partially paid' },
    PAID: { cls: 'green', label: 'Paid' },
    VOID: { cls: 'red', label: 'Void' },
  };
  const m = map[status] || { cls: 'gray', label: status };
  return <span className={`pill ${m.cls}`}>{m.label}</span>;
}

function Field({ label, children, grow }: { label: string; children: React.ReactNode; grow?: boolean }) {
  return (
    <div style={grow ? { flex: 1, minWidth: 180 } : undefined}>
      <div style={{ fontSize: 11, color: 'var(--text-dim)', marginBottom: 4 }}>{label}</div>
      {children}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------

export default function ReceivablesPage() {
  const { company } = useCompany();
  const [tab, setTab] = useState<Tab>('customers');
  const refData = useReferenceData(company?.id || 0);

  return (
    <div>
      <div className="page-header">
        <h1>Receivables</h1>
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
        <TabButton active={tab === 'customers'} onClick={() => setTab('customers')} label="Customers" />
        <TabButton active={tab === 'sales-orders'} onClick={() => setTab('sales-orders')} label="Sales Orders" />
        <TabButton active={tab === 'deliveries'} onClick={() => setTab('deliveries')} label="Deliveries" />
        <TabButton active={tab === 'invoices'} onClick={() => setTab('invoices')} label="Invoices" />
        <TabButton active={tab === 'receipts'} onClick={() => setTab('receipts')} label="Receipts" />
        <TabButton active={tab === 'aging'} onClick={() => setTab('aging')} label="Aging" />
      </div>

      {!company ? (
        <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
      ) : tab === 'customers' ? (
        <CustomersTab companyId={company.id} refData={refData} />
      ) : tab === 'sales-orders' ? (
        <SalesOrdersTab companyId={company.id} refData={refData} />
      ) : tab === 'deliveries' ? (
        <DeliveriesTab companyId={company.id} refData={refData} />
      ) : tab === 'invoices' ? (
        <InvoicesTab companyId={company.id} refData={refData} />
      ) : tab === 'receipts' ? (
        <ReceiptsTab companyId={company.id} refData={refData} />
      ) : (
        <AgingTab companyId={company.id} currency={company.baseCurrency} />
      )}
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button className={active ? 'btn' : 'btn secondary'} onClick={onClick} type="button">
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Customers
// ---------------------------------------------------------------------------

function emptyCustomerForm() {
  return {
    code: '',
    name: '',
    email: '',
    phone: '',
    address: '',
    defaultCurrencyCode: 'LKR',
    creditTermsDays: '30',
    creditLimitMajor: '',
    arControlAccountId: '',
  };
}

function CustomersTab({ companyId, refData }: { companyId: number; refData: ReferenceData }) {
  const { customers, accounts, reloadCustomers } = refData;
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyCustomerForm());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function openCreate() {
    setEditingId(null);
    setForm(emptyCustomerForm());
    setShowForm(true);
    setError('');
  }

  function openEdit(c: Customer) {
    setEditingId(c.id);
    setForm({
      code: c.code,
      name: c.name,
      email: c.email || '',
      phone: c.phone || '',
      address: c.address || '',
      defaultCurrencyCode: c.defaultCurrencyCode,
      creditTermsDays: String(c.creditTermsDays),
      creditLimitMajor: c.creditLimitMinor ? toMajorStr(c.creditLimitMinor) : '',
      arControlAccountId: c.arControlAccountId ? String(c.arControlAccountId) : '',
    });
    setShowForm(true);
    setError('');
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const body = {
        companyId,
        code: form.code,
        name: form.name,
        email: form.email || undefined,
        phone: form.phone || undefined,
        address: form.address || undefined,
        defaultCurrencyCode: form.defaultCurrencyCode || 'LKR',
        creditTermsDays: Number(form.creditTermsDays) || 0,
        creditLimitMinor: form.creditLimitMajor ? minorFromMajorInput(form.creditLimitMajor) : null,
        arControlAccountId: form.arControlAccountId ? Number(form.arControlAccountId) : null,
      };
      if (editingId) {
        await api.patch(`/receivables/customers/${editingId}`, body);
      } else {
        await api.post('/receivables/customers', body);
      }
      setShowForm(false);
      setEditingId(null);
      setForm(emptyCustomerForm());
      reloadCustomers();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to save customer');
    } finally {
      setBusy(false);
    }
  }

  const sorted = customers.slice().sort((a, b) => a.code.localeCompare(b.code));

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Customers</h2>
        <button className="btn" type="button" onClick={() => (showForm ? setShowForm(false) : openCreate())}>
          {showForm ? 'Cancel' : '+ New customer'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label="Code">
              <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required />
            </Field>
            <Field label="Name" grow>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                style={{ width: '100%' }}
                required
              />
            </Field>
            <Field label="Email">
              <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
            <Field label="Phone">
              <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
            <Field label="Address" grow>
              <input
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                style={{ width: '100%' }}
              />
            </Field>
            <Field label="Default currency">
              <input
                value={form.defaultCurrencyCode}
                onChange={(e) => setForm({ ...form, defaultCurrencyCode: e.target.value.toUpperCase() })}
                style={{ width: 80 }}
              />
            </Field>
            <Field label="Credit terms (days)">
              <input
                type="number"
                min="0"
                value={form.creditTermsDays}
                onChange={(e) => setForm({ ...form, creditTermsDays: e.target.value })}
                style={{ width: 110 }}
              />
            </Field>
            <Field label="Credit limit">
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.creditLimitMajor}
                onChange={(e) => setForm({ ...form, creditLimitMajor: e.target.value })}
                style={{ width: 130 }}
              />
            </Field>
            <Field label="AR control account" grow>
              <AccountSelect
                accounts={accounts}
                value={form.arControlAccountId}
                onChange={(v) => setForm({ ...form, arControlAccountId: v })}
              />
            </Field>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : editingId ? 'Save changes' : 'Create customer'}
          </button>
        </form>
      )}

      <div className="card">
        {sorted.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No customers yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Currency</th>
                <th>Credit terms</th>
                <th>Credit limit</th>
                <th>Active</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((c) => (
                <tr key={c.id}>
                  <td>{c.code}</td>
                  <td>{c.name}</td>
                  <td>{c.defaultCurrencyCode}</td>
                  <td>{c.creditTermsDays} days</td>
                  <td>{c.creditLimitMinor ? formatMoney(c.creditLimitMinor, c.defaultCurrencyCode) : '—'}</td>
                  <td>
                    {c.isActive ? <span className="pill green">Active</span> : <span className="pill gray">Inactive</span>}
                  </td>
                  <td>
                    <button className="btn secondary" type="button" onClick={() => openEdit(c)}>
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Sales Orders
// ---------------------------------------------------------------------------

interface SoLineRow {
  itemId: string;
  description: string;
  quantity: string;
  unitPriceMajor: string;
  taxRateId: string;
}

function emptySoLine(): SoLineRow {
  return { itemId: '', description: '', quantity: '1', unitPriceMajor: '', taxRateId: '' };
}

function SalesOrdersTab({ companyId, refData }: { companyId: number; refData: ReferenceData }) {
  const { customers, items, itemClasses, taxRates } = refData;
  const [orders, setOrders] = useState<SalesOrder[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [customerId, setCustomerId] = useState('');
  const [orderDate, setOrderDate] = useState(todayStr());
  const [currencyCode, setCurrencyCode] = useState('LKR');
  const [exchangeRate, setExchangeRate] = useState('1');
  const [lines, setLines] = useState<SoLineRow[]>([emptySoLine()]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirmingId, setConfirmingId] = useState<number | null>(null);

  function load() {
    setOrders(null);
    api.get('/receivables/sales-orders', { params: { companyId } }).then((res) => setOrders(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  function updateLine(idx: number, patch: Partial<SoLineRow>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  function onPickItem(idx: number, itemIdStr: string) {
    const item = items.find((i) => String(i.id) === itemIdStr);
    if (!item) {
      updateLine(idx, { itemId: itemIdStr });
      return;
    }
    // Mirror the backend's fallback: resolve price/tax from the item the
    // moment it's picked, so the user sees them with no extra clicks. Both
    // remain overridable, and the backend re-resolves them independently on
    // create if left blank.
    const taxId = resolveDefaultTaxRateId(item, itemClasses);
    updateLine(idx, {
      itemId: itemIdStr,
      unitPriceMajor: toMajorStr(item.salesPriceMinor),
      taxRateId: taxId != null ? String(taxId) : '',
    });
  }

  function addLine() {
    setLines((prev) => [...prev, emptySoLine()]);
  }
  function removeLine(idx: number) {
    setLines((prev) => prev.filter((_, i) => i !== idx));
  }

  const filledLines = lines.filter((l) => l.itemId && Number(l.quantity) > 0);
  const subtotalMinor = filledLines.reduce(
    (sum, l) => sum + Math.round(Number(l.quantity) * minorFromMajorInput(l.unitPriceMajor)),
    0,
  );

  function resetForm() {
    setCustomerId('');
    setOrderDate(todayStr());
    setCurrencyCode('LKR');
    setExchangeRate('1');
    setLines([emptySoLine()]);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (filledLines.length === 0) {
      setError('Add at least one line');
      return;
    }
    setBusy(true);
    try {
      await api.post('/receivables/sales-orders', {
        companyId,
        customerId: Number(customerId),
        orderDate,
        currencyCode,
        exchangeRate: Number(exchangeRate) || 1,
        lines: filledLines.map((l) => ({
          itemId: Number(l.itemId),
          description: l.description || undefined,
          quantity: Number(l.quantity),
          unitPriceMinor: l.unitPriceMajor ? minorFromMajorInput(l.unitPriceMajor) : undefined,
          taxRateId: l.taxRateId ? Number(l.taxRateId) : undefined,
        })),
      });
      resetForm();
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create sales order');
    } finally {
      setBusy(false);
    }
  }

  async function onConfirm(id: number) {
    setConfirmingId(id);
    try {
      await api.post(`/receivables/sales-orders/${id}/confirm`);
      load();
    } catch (err: any) {
      window.alert(err?.response?.data?.error?.message || 'Failed to confirm sales order');
    } finally {
      setConfirmingId(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Sales Orders</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New SO'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
            <Field label="Customer" grow>
              <CustomerSelect customers={customers} value={customerId} onChange={setCustomerId} required />
            </Field>
            <Field label="Order date">
              <input type="date" value={orderDate} onChange={(e) => setOrderDate(e.target.value)} required />
            </Field>
            <Field label="Currency">
              <input
                value={currencyCode}
                onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())}
                style={{ width: 80 }}
              />
            </Field>
            <Field label="Exchange rate">
              <input
                type="number"
                min="0"
                step="0.000001"
                value={exchangeRate}
                onChange={(e) => setExchangeRate(e.target.value)}
                style={{ width: 110 }}
              />
            </Field>
          </div>

          <table className="data-table" style={{ marginBottom: 10 }}>
            <thead>
              <tr>
                <th>Item</th>
                <th>Description</th>
                <th>Qty</th>
                <th>Unit price</th>
                <th>Tax</th>
                <th>Line total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {lines.map((l, idx) => {
                const lineMinor = Math.round((Number(l.quantity) || 0) * minorFromMajorInput(l.unitPriceMajor));
                return (
                  <tr key={idx}>
                    <td>
                      <ItemSelect items={items} value={l.itemId} onChange={(v) => onPickItem(idx, v)} />
                    </td>
                    <td>
                      <input
                        value={l.description}
                        onChange={(e) => updateLine(idx, { description: e.target.value })}
                        style={{ width: 140 }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.0001"
                        value={l.quantity}
                        onChange={(e) => updateLine(idx, { quantity: e.target.value })}
                        style={{ width: 80 }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={l.unitPriceMajor}
                        onChange={(e) => updateLine(idx, { unitPriceMajor: e.target.value })}
                        style={{ width: 100 }}
                      />
                    </td>
                    <td>
                      <TaxRateSelect
                        taxRates={taxRates}
                        value={l.taxRateId}
                        onChange={(v) => updateLine(idx, { taxRateId: v })}
                      />
                    </td>
                    <td>{formatMoney(lineMinor, currencyCode)}</td>
                    <td>
                      {lines.length > 1 && (
                        <button type="button" className="btn secondary" onClick={() => removeLine(idx)}>
                          Remove
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <button type="button" className="btn secondary" onClick={addLine}>
              + Add line
            </button>
            <div style={{ fontSize: 14 }}>
              Subtotal: <strong>{formatMoney(subtotalMinor, currencyCode)}</strong>
            </div>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Create sales order'}
          </button>
        </form>
      )}

      <div className="card">
        {orders === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : orders.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No sales orders yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>SO #</th>
                <th>Customer</th>
                <th>Order date</th>
                <th>Currency</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {orders.map((so) => (
                <tr key={so.id}>
                  <td>{so.soNumber}</td>
                  <td>{customerLabel(customers, so.customerId)}</td>
                  <td>{so.orderDate}</td>
                  <td>{so.currencyCode}</td>
                  <td>
                    <SoStatusPill status={so.status} />
                  </td>
                  <td>
                    {so.status === 'DRAFT' && (
                      <button
                        className="btn secondary"
                        type="button"
                        disabled={confirmingId === so.id}
                        onClick={() => onConfirm(so.id)}
                      >
                        {confirmingId === so.id ? 'Confirming…' : 'Confirm'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Deliveries
// ---------------------------------------------------------------------------

interface DnLineDraft {
  soLineId: string;
  itemId: string;
  quantity: string;
  maxQuantity: number | null;
  include: boolean;
}

function DeliveriesTab({ companyId, refData }: { companyId: number; refData: ReferenceData }) {
  const { customers, items } = refData;
  const [deliveries, setDeliveries] = useState<Delivery[] | null>(null);
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [soId, setSoId] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [deliveryDate, setDeliveryDate] = useState(todayStr());
  const [soLineDrafts, setSoLineDrafts] = useState<DnLineDraft[]>([]);
  const [manualLines, setManualLines] = useState<{ itemId: string; quantity: string }[]>([
    { itemId: '', quantity: '1' },
  ]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function load() {
    setDeliveries(null);
    api.get('/receivables/deliveries', { params: { companyId } }).then((res) => setDeliveries(res.data));
  }

  function loadSalesOrders() {
    api.get('/receivables/sales-orders', { params: { companyId } }).then((res) => setSalesOrders(res.data));
  }

  useEffect(() => {
    load();
    loadSalesOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  // Sales orders that still have undelivered quantity on at least one line.
  const deliverableOrders = salesOrders.filter(
    (so) =>
      !['CANCELLED', 'CLOSED'].includes(so.status) &&
      so.lines.some((l) => Number(l.quantity) - Number(l.quantityDelivered) > 0.00001),
  );

  function onPickSo(id: string) {
    setSoId(id);
    if (!id) {
      setSoLineDrafts([]);
      return;
    }
    const so = salesOrders.find((s) => String(s.id) === id);
    if (!so) {
      setSoLineDrafts([]);
      return;
    }
    setCustomerId(String(so.customerId));
    const drafts = so.lines
      .filter((l) => Number(l.quantity) - Number(l.quantityDelivered) > 0.00001)
      .map((l) => {
        const remaining = Number(l.quantity) - Number(l.quantityDelivered);
        return {
          soLineId: String(l.id),
          itemId: String(l.itemId),
          quantity: String(remaining),
          maxQuantity: remaining,
          include: true,
        };
      });
    setSoLineDrafts(drafts);
  }

  function updateSoLineDraft(idx: number, patch: Partial<DnLineDraft>) {
    setSoLineDrafts((prev) => prev.map((d, i) => (i === idx ? { ...d, ...patch } : d)));
  }

  function updateManualLine(idx: number, patch: Partial<{ itemId: string; quantity: string }>) {
    setManualLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }
  function addManualLine() {
    setManualLines((prev) => [...prev, { itemId: '', quantity: '1' }]);
  }
  function removeManualLine(idx: number) {
    setManualLines((prev) => prev.filter((_, i) => i !== idx));
  }

  function resetForm() {
    setSoId('');
    setCustomerId('');
    setDeliveryDate(todayStr());
    setSoLineDrafts([]);
    setManualLines([{ itemId: '', quantity: '1' }]);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    let lines: { soLineId?: number; itemId: number; quantity: number }[] = [];
    if (soId) {
      lines = soLineDrafts
        .filter((d) => d.include && Number(d.quantity) > 0)
        .map((d) => ({ soLineId: Number(d.soLineId), itemId: Number(d.itemId), quantity: Number(d.quantity) }));
    } else {
      lines = manualLines
        .filter((l) => l.itemId && Number(l.quantity) > 0)
        .map((l) => ({ itemId: Number(l.itemId), quantity: Number(l.quantity) }));
    }

    if (lines.length === 0) {
      setError('Add at least one line to deliver');
      return;
    }
    if (!customerId) {
      setError('Select a customer');
      return;
    }

    setBusy(true);
    try {
      await api.post('/receivables/deliveries', {
        companyId,
        soId: soId ? Number(soId) : undefined,
        customerId: Number(customerId),
        deliveryDate,
        lines,
      });
      resetForm();
      setShowForm(false);
      load();
      loadSalesOrders();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create delivery');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Deliveries</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Delivery'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
            <Field label="Sales order (optional)" grow>
              <select value={soId} onChange={(e) => onPickSo(e.target.value)}>
                <option value="">— No sales order (manual) —</option>
                {deliverableOrders.map((so) => (
                  <option key={so.id} value={so.id}>
                    {so.soNumber} — {customerLabel(customers, so.customerId)}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Customer" grow>
              <CustomerSelect
                customers={customers}
                value={customerId}
                onChange={setCustomerId}
                required={!soId}
              />
            </Field>
            <Field label="Delivery date">
              <input type="date" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} required />
            </Field>
          </div>

          {soId ? (
            <table className="data-table" style={{ marginBottom: 10 }}>
              <thead>
                <tr>
                  <th></th>
                  <th>Item</th>
                  <th>Remaining qty</th>
                  <th>Deliver qty</th>
                </tr>
              </thead>
              <tbody>
                {soLineDrafts.map((d, idx) => (
                  <tr key={d.soLineId}>
                    <td>
                      <input
                        type="checkbox"
                        checked={d.include}
                        onChange={(e) => updateSoLineDraft(idx, { include: e.target.checked })}
                      />
                    </td>
                    <td>{itemLabel(items, Number(d.itemId))}</td>
                    <td>{d.maxQuantity}</td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.0001"
                        max={d.maxQuantity ?? undefined}
                        value={d.quantity}
                        disabled={!d.include}
                        onChange={(e) => {
                          const v = Math.min(Number(e.target.value) || 0, d.maxQuantity ?? Infinity);
                          updateSoLineDraft(idx, { quantity: String(v) });
                        }}
                        style={{ width: 100 }}
                      />
                    </td>
                  </tr>
                ))}
                {soLineDrafts.length === 0 && (
                  <tr>
                    <td colSpan={4} style={{ color: 'var(--text-dim)' }}>
                      This sales order has no undelivered lines.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          ) : (
            <table className="data-table" style={{ marginBottom: 10 }}>
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Qty</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {manualLines.map((l, idx) => (
                  <tr key={idx}>
                    <td>
                      <ItemSelect items={items} value={l.itemId} onChange={(v) => updateManualLine(idx, { itemId: v })} />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.0001"
                        value={l.quantity}
                        onChange={(e) => updateManualLine(idx, { quantity: e.target.value })}
                        style={{ width: 100 }}
                      />
                    </td>
                    <td>
                      {manualLines.length > 1 && (
                        <button type="button" className="btn secondary" onClick={() => removeManualLine(idx)}>
                          Remove
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {!soId && (
            <div style={{ marginBottom: 12 }}>
              <button type="button" className="btn secondary" onClick={addManualLine}>
                + Add line
              </button>
            </div>
          )}

          <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: -4 }}>
            Saving this delivery issues stock and posts COGS automatically.
          </p>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Create delivery'}
          </button>
        </form>
      )}

      <div className="card">
        {deliveries === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : deliveries.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No deliveries yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>DN #</th>
                <th>Customer</th>
                <th>Delivery date</th>
                <th>Sales order</th>
              </tr>
            </thead>
            <tbody>
              {deliveries.map((dn) => (
                <tr key={dn.id}>
                  <td>{dn.dnNumber}</td>
                  <td>{customerLabel(customers, dn.customerId)}</td>
                  <td>{dn.deliveryDate}</td>
                  <td>{dn.soId ? soLabel(salesOrders, dn.soId) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Invoices
// ---------------------------------------------------------------------------

interface InvLineRow {
  mode: 'item' | 'custom';
  itemId: string;
  description: string;
  quantity: string;
  unitPriceMajor: string;
  taxRateId: string;
  incomeAccountId: string;
}

function emptyInvLine(): InvLineRow {
  return { mode: 'item', itemId: '', description: '', quantity: '1', unitPriceMajor: '', taxRateId: '', incomeAccountId: '' };
}

function InvoicesTab({ companyId, refData }: { companyId: number; refData: ReferenceData }) {
  const { customers, items, itemClasses, taxRates, accounts } = refData;
  const [invoices, setInvoices] = useState<Invoice[] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [customerId, setCustomerId] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(todayStr());
  const [dueDate, setDueDate] = useState(addDaysStr(todayStr(), 30));
  const [currencyCode, setCurrencyCode] = useState('LKR');
  const [exchangeRate, setExchangeRate] = useState('1');
  const [lines, setLines] = useState<InvLineRow[]>([emptyInvLine()]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [postingId, setPostingId] = useState<number | null>(null);

  function load() {
    setInvoices(null);
    api.get('/receivables/invoices', { params: { companyId } }).then((res) => setInvoices(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  function updateLine(idx: number, patch: Partial<InvLineRow>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  function onPickItem(idx: number, itemIdStr: string) {
    const item = items.find((i) => String(i.id) === itemIdStr);
    if (!item) {
      updateLine(idx, { itemId: itemIdStr });
      return;
    }
    const taxId = resolveDefaultTaxRateId(item, itemClasses);
    updateLine(idx, {
      itemId: itemIdStr,
      description: item.name,
      unitPriceMajor: toMajorStr(item.salesPriceMinor),
      taxRateId: taxId != null ? String(taxId) : '',
    });
  }

  function setMode(idx: number, mode: 'item' | 'custom') {
    updateLine(idx, { mode, itemId: '', incomeAccountId: '', taxRateId: '', unitPriceMajor: '', description: '' });
  }

  function addLine() {
    setLines((prev) => [...prev, emptyInvLine()]);
  }
  function removeLine(idx: number) {
    setLines((prev) => prev.filter((_, i) => i !== idx));
  }

  function lineAmounts(l: InvLineRow) {
    const qty = Number(l.quantity) || 0;
    const netMinor = Math.round(qty * minorFromMajorInput(l.unitPriceMajor));
    const rate = taxRates.find((t) => String(t.id) === l.taxRateId);
    const taxMinor = rate ? Math.round((netMinor * rate.rateBasisPoints) / 10000) : 0;
    return { netMinor, taxMinor };
  }

  const validLines = lines.filter((l) => (l.mode === 'item' ? !!l.itemId : !!l.description) && Number(l.quantity) > 0);
  const subtotalMinor = validLines.reduce((sum, l) => sum + lineAmounts(l).netMinor, 0);
  const taxMinorTotal = validLines.reduce((sum, l) => sum + lineAmounts(l).taxMinor, 0);
  const totalMinor = subtotalMinor + taxMinorTotal;

  function resetForm() {
    setCustomerId('');
    setInvoiceDate(todayStr());
    setDueDate(addDaysStr(todayStr(), 30));
    setCurrencyCode('LKR');
    setExchangeRate('1');
    setLines([emptyInvLine()]);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (validLines.length === 0) {
      setError('Add at least one line');
      return;
    }
    for (const l of validLines) {
      if (l.mode === 'custom' && !l.incomeAccountId) {
        setError('Non-item lines require an income account');
        return;
      }
    }
    setBusy(true);
    try {
      await api.post('/receivables/invoices', {
        companyId,
        customerId: Number(customerId),
        invoiceDate,
        dueDate,
        currencyCode,
        exchangeRate: Number(exchangeRate) || 1,
        lines: validLines.map((l) => ({
          itemId: l.mode === 'item' ? Number(l.itemId) : undefined,
          description: l.description,
          quantity: Number(l.quantity),
          unitPriceMinor: minorFromMajorInput(l.unitPriceMajor),
          taxRateId: l.taxRateId ? Number(l.taxRateId) : undefined,
          incomeAccountId: l.mode === 'custom' ? Number(l.incomeAccountId) : undefined,
        })),
      });
      resetForm();
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to create invoice');
    } finally {
      setBusy(false);
    }
  }

  async function onPost(id: number) {
    setPostingId(id);
    try {
      await api.post(`/receivables/invoices/${id}/post`);
      load();
    } catch (err: any) {
      window.alert(err?.response?.data?.error?.message || 'Failed to post invoice');
    } finally {
      setPostingId(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Invoices</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Invoice'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
            <Field label="Customer" grow>
              <CustomerSelect customers={customers} value={customerId} onChange={setCustomerId} required />
            </Field>
            <Field label="Invoice date">
              <input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} required />
            </Field>
            <Field label="Due date">
              <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} required />
            </Field>
            <Field label="Currency">
              <input
                value={currencyCode}
                onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())}
                style={{ width: 80 }}
              />
            </Field>
            <Field label="Exchange rate">
              <input
                type="number"
                min="0"
                step="0.000001"
                value={exchangeRate}
                onChange={(e) => setExchangeRate(e.target.value)}
                style={{ width: 110 }}
              />
            </Field>
          </div>

          <table className="data-table" style={{ marginBottom: 10 }}>
            <thead>
              <tr>
                <th>Type</th>
                <th>Item / Description</th>
                <th>Income account</th>
                <th>Qty</th>
                <th>Unit price</th>
                <th>Tax</th>
                <th>Line total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {lines.map((l, idx) => {
                const { netMinor, taxMinor } = lineAmounts(l);
                return (
                  <tr key={idx}>
                    <td>
                      <select value={l.mode} onChange={(e) => setMode(idx, e.target.value as 'item' | 'custom')}>
                        <option value="item">Item</option>
                        <option value="custom">Custom</option>
                      </select>
                    </td>
                    <td>
                      {l.mode === 'item' ? (
                        <ItemSelect items={items} value={l.itemId} onChange={(v) => onPickItem(idx, v)} />
                      ) : (
                        <input
                          value={l.description}
                          onChange={(e) => updateLine(idx, { description: e.target.value })}
                          placeholder="Description"
                          style={{ width: 160 }}
                          required
                        />
                      )}
                    </td>
                    <td>
                      {l.mode === 'custom' && (
                        <AccountSelect
                          accounts={accounts}
                          value={l.incomeAccountId}
                          onChange={(v) => updateLine(idx, { incomeAccountId: v })}
                          placeholder="Income account…"
                        />
                      )}
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.0001"
                        value={l.quantity}
                        onChange={(e) => updateLine(idx, { quantity: e.target.value })}
                        style={{ width: 80 }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={l.unitPriceMajor}
                        onChange={(e) => updateLine(idx, { unitPriceMajor: e.target.value })}
                        style={{ width: 100 }}
                      />
                    </td>
                    <td>
                      <TaxRateSelect
                        taxRates={taxRates}
                        value={l.taxRateId}
                        onChange={(v) => updateLine(idx, { taxRateId: v })}
                      />
                    </td>
                    <td>{formatMoney(netMinor + taxMinor, currencyCode)}</td>
                    <td>
                      {lines.length > 1 && (
                        <button type="button" className="btn secondary" onClick={() => removeLine(idx)}>
                          Remove
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <button type="button" className="btn secondary" onClick={addLine}>
              + Add line
            </button>
            <div style={{ fontSize: 13, textAlign: 'right' }}>
              <div>Subtotal: {formatMoney(subtotalMinor, currencyCode)}</div>
              <div>Tax: {formatMoney(taxMinorTotal, currencyCode)}</div>
              <div style={{ fontSize: 15 }}>
                <strong>Total: {formatMoney(totalMinor, currencyCode)}</strong>
              </div>
            </div>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Create invoice (draft)'}
          </button>
        </form>
      )}

      <div className="card">
        {invoices === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : invoices.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No invoices yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Customer</th>
                <th>Invoice date</th>
                <th>Due date</th>
                <th>Currency</th>
                <th>Status</th>
                <th>Total</th>
                <th>Received</th>
                <th>Outstanding</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => {
                const outstanding = Number(inv.totalMinor) - Number(inv.amountReceivedMinor);
                return (
                  <tr key={inv.id}>
                    <td>{inv.invoiceNumber}</td>
                    <td>{customerLabel(customers, inv.customerId)}</td>
                    <td>{inv.invoiceDate}</td>
                    <td>{inv.dueDate}</td>
                    <td>{inv.currencyCode}</td>
                    <td>
                      <InvoiceStatusPill status={inv.status} />
                    </td>
                    <td>{formatMoney(inv.totalMinor, inv.currencyCode)}</td>
                    <td>{formatMoney(inv.amountReceivedMinor, inv.currencyCode)}</td>
                    <td>{formatMoney(outstanding, inv.currencyCode)}</td>
                    <td>
                      {inv.status === 'DRAFT' && (
                        <button
                          className="btn"
                          type="button"
                          disabled={postingId === inv.id}
                          onClick={() => onPost(inv.id)}
                        >
                          {postingId === inv.id ? 'Posting…' : 'Post'}
                        </button>
                      )}
                      {inv.status !== 'DRAFT' && (
                        <a
                          className="btn secondary"
                          href={`/print/invoice/${inv.id}`}
                          target="_blank"
                          rel="noreferrer"
                          style={{ textDecoration: 'none', whiteSpace: 'nowrap' }}
                          title="Print / download the VAT tax invoice"
                        >
                          Tax invoice
                        </a>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Receipts
// ---------------------------------------------------------------------------

function ReceiptsTab({ companyId, refData }: { companyId: number; refData: ReferenceData }) {
  const { customers, accounts } = refData;
  const [receipts, setReceipts] = useState<Receipt[] | null>(null);
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [customerId, setCustomerId] = useState('');
  const [receiptDate, setReceiptDate] = useState(todayStr());
  const [bankAccountGlAccountId, setBankAccountGlAccountId] = useState('');
  const [currencyCode, setCurrencyCode] = useState('LKR');
  const [exchangeRate, setExchangeRate] = useState('1');
  const [allocations, setAllocations] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function load() {
    setReceipts(null);
    api.get('/receivables/receipts', { params: { companyId } }).then((res) => setReceipts(res.data));
  }

  function loadInvoices() {
    api.get('/receivables/invoices', { params: { companyId } }).then((res) => setAllInvoices(res.data));
  }

  useEffect(() => {
    load();
    loadInvoices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  const openInvoices = allInvoices.filter(
    (inv) =>
      inv.customerId === Number(customerId) &&
      ['POSTED', 'PARTIALLY_PAID'].includes(inv.status) &&
      Number(inv.totalMinor) - Number(inv.amountReceivedMinor) > 0,
  );

  function onPickCustomer(id: string) {
    setCustomerId(id);
    const prefilled: Record<number, string> = {};
    allInvoices
      .filter(
        (inv) =>
          inv.customerId === Number(id) &&
          ['POSTED', 'PARTIALLY_PAID'].includes(inv.status) &&
          Number(inv.totalMinor) - Number(inv.amountReceivedMinor) > 0,
      )
      .forEach((inv) => {
        const outstanding = Number(inv.totalMinor) - Number(inv.amountReceivedMinor);
        prefilled[inv.id] = toMajorStr(outstanding);
      });
    setAllocations(prefilled);
    if (allInvoices.length) {
      const first = allInvoices.find((inv) => inv.customerId === Number(id));
      if (first) setCurrencyCode(first.currencyCode);
    }
  }

  function updateAllocation(invoiceId: number, major: string, outstandingMinor: number) {
    const capped = Math.min(minorFromMajorInput(major), outstandingMinor);
    setAllocations((prev) => ({ ...prev, [invoiceId]: toMajorStr(Math.max(0, capped)) }));
  }

  const totalAllocatedMinor = openInvoices.reduce(
    (sum, inv) => sum + minorFromMajorInput(allocations[inv.id] || '0'),
    0,
  );

  function resetForm() {
    setCustomerId('');
    setReceiptDate(todayStr());
    setBankAccountGlAccountId('');
    setCurrencyCode('LKR');
    setExchangeRate('1');
    setAllocations({});
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const allocs = openInvoices
      .map((inv) => ({ invoiceId: inv.id, allocatedAmountMinor: minorFromMajorInput(allocations[inv.id] || '0') }))
      .filter((a) => a.allocatedAmountMinor > 0);
    if (allocs.length === 0) {
      setError('Allocate an amount to at least one invoice');
      return;
    }
    if (!bankAccountGlAccountId) {
      setError('Select a bank/cash account');
      return;
    }
    setBusy(true);
    try {
      await api.post('/receivables/receipts', {
        companyId,
        customerId: Number(customerId),
        receiptDate,
        bankAccountGlAccountId: Number(bankAccountGlAccountId),
        currencyCode,
        exchangeRate: Number(exchangeRate) || 1,
        allocations: allocs,
      });
      resetForm();
      setShowForm(false);
      load();
      loadInvoices();
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'Failed to record receipt');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>Receipts</h2>
        <button className="btn" type="button" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ New Receipt'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={onSubmit} className="card" style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
            <Field label="Customer" grow>
              <CustomerSelect customers={customers} value={customerId} onChange={onPickCustomer} required />
            </Field>
            <Field label="Receipt date">
              <input type="date" value={receiptDate} onChange={(e) => setReceiptDate(e.target.value)} required />
            </Field>
            <Field label="Bank / cash account" grow>
              <AccountSelect
                accounts={accounts}
                value={bankAccountGlAccountId}
                onChange={setBankAccountGlAccountId}
                placeholder="Select account…"
                required
              />
            </Field>
            <Field label="Currency">
              <input
                value={currencyCode}
                onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())}
                style={{ width: 80 }}
              />
            </Field>
            <Field label="Exchange rate">
              <input
                type="number"
                min="0"
                step="0.000001"
                value={exchangeRate}
                onChange={(e) => setExchangeRate(e.target.value)}
                style={{ width: 110 }}
              />
            </Field>
          </div>

          {customerId && (
            <table className="data-table" style={{ marginBottom: 10 }}>
              <thead>
                <tr>
                  <th>Invoice #</th>
                  <th>Due date</th>
                  <th>Status</th>
                  <th>Outstanding</th>
                  <th>Allocate</th>
                </tr>
              </thead>
              <tbody>
                {openInvoices.map((inv) => {
                  const outstandingMinor = Number(inv.totalMinor) - Number(inv.amountReceivedMinor);
                  return (
                    <tr key={inv.id}>
                      <td>{inv.invoiceNumber}</td>
                      <td>{inv.dueDate}</td>
                      <td>
                        <InvoiceStatusPill status={inv.status} />
                      </td>
                      <td>{formatMoney(outstandingMinor, inv.currencyCode)}</td>
                      <td>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          max={toMajorStr(outstandingMinor)}
                          value={allocations[inv.id] ?? ''}
                          onChange={(e) => updateAllocation(inv.id, e.target.value, outstandingMinor)}
                          style={{ width: 110 }}
                        />
                      </td>
                    </tr>
                  );
                })}
                {openInvoices.length === 0 && (
                  <tr>
                    <td colSpan={5} style={{ color: 'var(--text-dim)' }}>
                      This customer has no open invoices.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12, fontSize: 14 }}>
            Total allocated: <strong style={{ marginLeft: 6 }}>{formatMoney(totalAllocatedMinor, currencyCode)}</strong>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 10 }}>{error}</div>}
          <button className="btn" type="submit" disabled={busy}>
            {busy ? 'Saving…' : 'Record receipt'}
          </button>
        </form>
      )}

      <div className="card">
        {receipts === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : receipts.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No receipts yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Receipt #</th>
                <th>Customer</th>
                <th>Receipt date</th>
                <th>Currency</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              {receipts.map((r) => (
                <tr key={r.id}>
                  <td>{r.receiptNumber}</td>
                  <td>{customerLabel(customers, r.customerId)}</td>
                  <td>{r.receiptDate}</td>
                  <td>{r.currencyCode}</td>
                  <td>{formatMoney(r.amountMinor, r.currencyCode)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Aging
// ---------------------------------------------------------------------------

function AgingTab({ companyId, currency }: { companyId: number; currency: string }) {
  const [rows, setRows] = useState<AgingBucket[] | null>(null);

  function load() {
    setRows(null);
    api.get('/receivables/aging', { params: { companyId } }).then((res) => setRows(res.data));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  const visibleRows = (rows || []).filter((r) => r.totalMinor > 0);
  const totals = (rows || []).reduce(
    (acc, r) => ({
      current: acc.current + r.current,
      d1_30: acc.d1_30 + r.d1_30,
      d31_60: acc.d31_60 + r.d31_60,
      d61_90: acc.d61_90 + r.d61_90,
      d90Plus: acc.d90Plus + r.d90Plus,
      totalMinor: acc.totalMinor + r.totalMinor,
    }),
    { current: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90Plus: 0, totalMinor: 0 },
  );

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0, fontSize: 16 }}>AR Aging</h2>
      </div>

      <div className="card">
        {rows === null ? (
          <p style={{ color: 'var(--text-dim)' }}>Loading…</p>
        ) : visibleRows.length === 0 ? (
          <p style={{ color: 'var(--text-dim)' }}>No outstanding receivables.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Customer</th>
                <th>Current</th>
                <th>1–30 days</th>
                <th>31–60 days</th>
                <th>61–90 days</th>
                <th>90+ days</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {visibleRows.map((r) => (
                <tr key={r.customerId}>
                  <td>
                    {r.customerCode} — {r.customerName}
                  </td>
                  <td>{formatMoney(r.current, currency)}</td>
                  <td>{formatMoney(r.d1_30, currency)}</td>
                  <td>{formatMoney(r.d31_60, currency)}</td>
                  <td>{formatMoney(r.d61_90, currency)}</td>
                  <td>{formatMoney(r.d90Plus, currency)}</td>
                  <td>
                    <strong>{formatMoney(r.totalMinor, currency)}</strong>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td style={{ fontWeight: 700 }}>Totals</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.current, currency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d1_30, currency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d31_60, currency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d61_90, currency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d90Plus, currency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.totalMinor, currency)}</td>
              </tr>
            </tfoot>
          </table>
        )}
      </div>
    </div>
  );
}
