import React, { useEffect, useMemo, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

// ---------------------------------------------------------------------------
// Types (field names mirror the backend entities/DTOs under
// backend/src/modules/payables, accounting, inventory and tax)
// ---------------------------------------------------------------------------

interface Supplier {
  id: number;
  code: string;
  name: string;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
  defaultCurrencyCode: string;
  paymentTermsDays: number;
  apControlAccountId: number;
  isActive: boolean;
}

interface Account {
  id: number;
  code: string;
  name: string;
  accountType: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
  normalBalance: string;
  isActive: boolean;
}

interface Item {
  id: number;
  sku: string;
  name: string;
  itemType: string;
}

interface TaxRate {
  id: number;
  code: string;
  name: string;
  rateBasisPoints: number;
  isActive: boolean;
}

interface PurchaseOrderLine {
  id: number;
  poId: number;
  itemId: number;
  description?: string | null;
  quantity: string;
  unitPriceMinor: string;
  taxRateId?: number | null;
  quantityReceived: string;
}

interface PurchaseOrder {
  id: number;
  poNumber: string;
  supplierId: number;
  orderDate: string;
  currencyCode: string;
  exchangeRate: string;
  status: 'DRAFT' | 'APPROVED' | 'PARTIALLY_RECEIVED' | 'RECEIVED' | 'CLOSED' | 'CANCELLED';
  notes?: string | null;
  lines: PurchaseOrderLine[];
}

interface GoodsReceiptLine {
  id: number;
  grnId: number;
  poLineId?: number | null;
  itemId: number;
  quantity: string;
  unitCostMinor: string;
}

interface GoodsReceipt {
  id: number;
  grnNumber: string;
  poId?: number | null;
  supplierId: number;
  receiptDate: string;
  notes?: string | null;
  lines: GoodsReceiptLine[];
}

interface BillLine {
  id: number;
  billId: number;
  itemId?: number | null;
  description: string;
  quantity: string;
  unitPriceMinor: string;
  taxRateId?: number | null;
  lineTotalMinor: string;
  expenseAccountId?: number | null;
}

interface Bill {
  id: number;
  billNumber: string;
  supplierId: number;
  billDate: string;
  dueDate: string;
  currencyCode: string;
  exchangeRate: string;
  status: 'DRAFT' | 'POSTED' | 'PARTIALLY_PAID' | 'PAID' | 'VOID';
  subtotalMinor: string;
  taxMinor: string;
  totalMinor: string;
  amountPaidMinor: string;
  lines: BillLine[];
}

interface PaymentAllocation {
  id: number;
  paymentId: number;
  billId: number;
  allocatedAmountMinor: string;
}

interface Payment {
  id: number;
  paymentNumber: string;
  supplierId: number;
  paymentDate: string;
  bankAccountGlAccountId: number;
  currencyCode: string;
  exchangeRate: string;
  amountMinor: string;
  allocations: PaymentAllocation[];
}

interface AgingBucket {
  supplierId: number;
  supplierName: string;
  current: number;
  d1to30: number;
  d31to60: number;
  d61to90: number;
  d90plus: number;
  totalOutstandingBaseMinor: number;
}

type TabKey = 'suppliers' | 'purchase-orders' | 'goods-receipts' | 'bills' | 'payments' | 'aging';

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: 'suppliers', label: 'Suppliers' },
  { key: 'purchase-orders', label: 'Purchase Orders' },
  { key: 'goods-receipts', label: 'Goods Receipts' },
  { key: 'bills', label: 'Bills' },
  { key: 'payments', label: 'Payments' },
  { key: 'aging', label: 'Aging' },
];

// ---------------------------------------------------------------------------
// Small shared helpers
// ---------------------------------------------------------------------------

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function errMessage(err: any, fallback: string): string {
  return err?.response?.data?.error?.message || err?.response?.data?.message || fallback;
}

/** Tax on a net (exclusive) amount, mirroring TaxService.computeTax server-side. */
function computeTaxMinor(netMinor: number, rate?: TaxRate | null): number {
  if (!rate) return 0;
  return Math.round((netMinor * rate.rateBasisPoints) / 10000);
}

function supplierLabel(s: Supplier): string {
  return `${s.code} — ${s.name}`;
}

function accountLabel(a: Account): string {
  return `${a.code} — ${a.name}`;
}

function itemLabel(i: Item): string {
  return `${i.sku} — ${i.name}`;
}

function taxRateLabel(t: TaxRate): string {
  return `${t.code} (${(t.rateBasisPoints / 100).toFixed(2)}%)`;
}

function Pill({ text, color }: { text: string; color: 'green' | 'red' | 'amber' | 'gray' }) {
  return <span className={`pill ${color}`}>{text}</span>;
}

function poStatusPill(status: PurchaseOrder['status']) {
  switch (status) {
    case 'DRAFT':
      return <Pill text="DRAFT" color="gray" />;
    case 'APPROVED':
      return <Pill text="APPROVED" color="amber" />;
    case 'PARTIALLY_RECEIVED':
      return <Pill text="PARTIALLY RECEIVED" color="amber" />;
    case 'RECEIVED':
      return <Pill text="RECEIVED" color="green" />;
    case 'CLOSED':
      return <Pill text="CLOSED" color="gray" />;
    case 'CANCELLED':
      return <Pill text="CANCELLED" color="red" />;
    default:
      return <Pill text={status} color="gray" />;
  }
}

function billStatusPill(status: Bill['status']) {
  switch (status) {
    case 'DRAFT':
      return <Pill text="Draft — not posted" color="gray" />;
    case 'POSTED':
      return <Pill text="POSTED" color="amber" />;
    case 'PARTIALLY_PAID':
      return <Pill text="PARTIALLY PAID" color="amber" />;
    case 'PAID':
      return <Pill text="PAID" color="green" />;
    case 'VOID':
      return <Pill text="VOID" color="red" />;
    default:
      return <Pill text={status} color="gray" />;
  }
}

// Reusable <select> pickers --------------------------------------------------

function SupplierSelect(props: {
  suppliers: Supplier[];
  value: number | '';
  onChange: (id: number | '') => void;
  disabled?: boolean;
}) {
  return (
    <select
      value={props.value}
      disabled={props.disabled}
      onChange={(e) => props.onChange(e.target.value ? Number(e.target.value) : '')}
    >
      <option value="">Select supplier…</option>
      {props.suppliers.map((s) => (
        <option key={s.id} value={s.id}>
          {supplierLabel(s)}
        </option>
      ))}
    </select>
  );
}

function AccountSelect(props: {
  accounts: Account[];
  value: number | '';
  onChange: (id: number | '') => void;
  filterTypes?: Account['accountType'][];
  placeholder?: string;
}) {
  const options = props.filterTypes
    ? props.accounts.filter((a) => props.filterTypes!.includes(a.accountType))
    : props.accounts;
  return (
    <select value={props.value} onChange={(e) => props.onChange(e.target.value ? Number(e.target.value) : '')}>
      <option value="">{props.placeholder || 'Select account…'}</option>
      {options.map((a) => (
        <option key={a.id} value={a.id}>
          {accountLabel(a)}
        </option>
      ))}
    </select>
  );
}

function ItemSelect(props: { items: Item[]; value: number | ''; onChange: (id: number | '') => void }) {
  return (
    <select value={props.value} onChange={(e) => props.onChange(e.target.value ? Number(e.target.value) : '')}>
      <option value="">Select item…</option>
      {props.items.map((i) => (
        <option key={i.id} value={i.id}>
          {itemLabel(i)}
        </option>
      ))}
    </select>
  );
}

function TaxRateSelect(props: { taxRates: TaxRate[]; value: number | ''; onChange: (id: number | '') => void }) {
  return (
    <select value={props.value} onChange={(e) => props.onChange(e.target.value ? Number(e.target.value) : '')}>
      <option value="">No tax</option>
      {props.taxRates.map((t) => (
        <option key={t.id} value={t.id}>
          {taxRateLabel(t)}
        </option>
      ))}
    </select>
  );
}

// ---------------------------------------------------------------------------
// Shared reference-data bundle passed down to every tab
// ---------------------------------------------------------------------------

interface RefData {
  suppliers: Supplier[];
  accounts: Account[];
  items: Item[];
  taxRates: TaxRate[];
}

// ---------------------------------------------------------------------------
// 1. Suppliers tab
// ---------------------------------------------------------------------------

interface SupplierFormState {
  code: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  defaultCurrencyCode: string;
  paymentTermsDays: string;
  apControlAccountId: number | '';
  isActive: boolean;
}

const emptySupplierForm: SupplierFormState = {
  code: '',
  name: '',
  email: '',
  phone: '',
  address: '',
  defaultCurrencyCode: 'LKR',
  paymentTermsDays: '30',
  apControlAccountId: '',
  isActive: true,
};

function SuppliersTab({ companyId, refData, onChanged }: { companyId: number; refData: RefData; onChanged: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [form, setForm] = useState<SupplierFormState>(emptySupplierForm);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  function startCreate() {
    setEditing(null);
    setForm(emptySupplierForm);
    setError('');
    setShowForm(true);
  }

  function startEdit(s: Supplier) {
    setEditing(s);
    setForm({
      code: s.code,
      name: s.name,
      email: s.email || '',
      phone: s.phone || '',
      address: s.address || '',
      defaultCurrencyCode: s.defaultCurrencyCode,
      paymentTermsDays: String(s.paymentTermsDays),
      apControlAccountId: s.apControlAccountId,
      isActive: s.isActive,
    });
    setError('');
    setShowForm(true);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.apControlAccountId) {
      setError('AP control account is required');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const body = {
        companyId,
        code: form.code,
        name: form.name,
        email: form.email || undefined,
        phone: form.phone || undefined,
        address: form.address || undefined,
        defaultCurrencyCode: form.defaultCurrencyCode,
        paymentTermsDays: Number(form.paymentTermsDays) || 0,
        apControlAccountId: Number(form.apControlAccountId),
        isActive: form.isActive,
      };
      if (editing) {
        await api.patch(`/payables/suppliers/${editing.id}`, body);
      } else {
        await api.post('/payables/suppliers', body);
      }
      setShowForm(false);
      onChanged();
    } catch (err: any) {
      setError(errMessage(err, 'Failed to save supplier'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Suppliers</h2>
        <button className="btn" onClick={startCreate}>
          + New Supplier
        </button>
      </div>

      {showForm && (
        <form className="card" onSubmit={submit} style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>{editing ? `Edit ${editing.code}` : 'New Supplier'}</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            <input placeholder="Code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required />
            <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <input placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <input placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <input placeholder="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <input
              placeholder="Default currency"
              value={form.defaultCurrencyCode}
              onChange={(e) => setForm({ ...form, defaultCurrencyCode: e.target.value.toUpperCase() })}
            />
            <input
              placeholder="Payment terms (days)"
              type="number"
              value={form.paymentTermsDays}
              onChange={(e) => setForm({ ...form, paymentTermsDays: e.target.value })}
            />
            <AccountSelect
              accounts={refData.accounts}
              value={form.apControlAccountId}
              onChange={(id) => setForm({ ...form, apControlAccountId: id })}
              placeholder="AP control account…"
            />
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
              <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} />
              Active
            </label>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save'}
            </button>
            <button className="btn secondary" type="button" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Currency</th>
              <th>Terms (days)</th>
              <th>Active</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {refData.suppliers.map((s) => (
              <tr key={s.id}>
                <td>{s.code}</td>
                <td>{s.name}</td>
                <td>{s.defaultCurrencyCode}</td>
                <td>{s.paymentTermsDays}</td>
                <td>{s.isActive ? <Pill text="Active" color="green" /> : <Pill text="Inactive" color="gray" />}</td>
                <td>
                  <button className="btn secondary" onClick={() => startEdit(s)}>
                    Edit
                  </button>
                </td>
              </tr>
            ))}
            {refData.suppliers.length === 0 && (
              <tr>
                <td colSpan={6} style={{ color: 'var(--text-dim)' }}>
                  No suppliers yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 2. Purchase Orders tab
// ---------------------------------------------------------------------------

interface PoLineDraft {
  itemId: number | '';
  description: string;
  quantity: string;
  unitPriceMajor: string;
  taxRateId: number | '';
}

function emptyPoLine(): PoLineDraft {
  return { itemId: '', description: '', quantity: '1', unitPriceMajor: '0', taxRateId: '' };
}

function PurchaseOrdersTab({ companyId, refData, baseCurrency }: { companyId: number; refData: RefData; baseCurrency: string }) {
  const [pos, setPos] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [supplierId, setSupplierId] = useState<number | ''>('');
  const [orderDate, setOrderDate] = useState(today());
  const [currencyCode, setCurrencyCode] = useState(baseCurrency || 'LKR');
  const [exchangeRate, setExchangeRate] = useState('1');
  const [lines, setLines] = useState<PoLineDraft[]>([emptyPoLine()]);

  const taxRateById = useMemo(() => new Map(refData.taxRates.map((t) => [t.id, t])), [refData.taxRates]);
  const supplierById = useMemo(() => new Map(refData.suppliers.map((s) => [s.id, s])), [refData.suppliers]);

  function load() {
    setLoading(true);
    api
      .get('/payables/purchase-orders', { params: { companyId } })
      .then((res) => setPos(res.data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  function poTotal(po: PurchaseOrder): number {
    return (po.lines || []).reduce((sum, l) => {
      const net = Number(l.quantity) * Number(l.unitPriceMinor);
      const tax = l.taxRateId ? computeTaxMinor(net, taxRateById.get(l.taxRateId)) : 0;
      return sum + net + tax;
    }, 0);
  }

  function startCreate() {
    setSupplierId('');
    setOrderDate(today());
    setCurrencyCode(baseCurrency || 'LKR');
    setExchangeRate('1');
    setLines([emptyPoLine()]);
    setError('');
    setShowForm(true);
  }

  function updateLine(idx: number, patch: Partial<PoLineDraft>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  function addLine() {
    setLines((prev) => [...prev, emptyPoLine()]);
  }

  function removeLine(idx: number) {
    setLines((prev) => prev.filter((_, i) => i !== idx));
  }

  function lineNetMinor(l: PoLineDraft): number {
    return Math.round(Number(l.quantity || 0) * toMinor(Number(l.unitPriceMajor || 0)));
  }

  function lineTaxMinor(l: PoLineDraft): number {
    return l.taxRateId ? computeTaxMinor(lineNetMinor(l), taxRateById.get(Number(l.taxRateId))) : 0;
  }

  const formTotal = lines.reduce((sum, l) => sum + lineNetMinor(l) + lineTaxMinor(l), 0);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supplierId) {
      setError('Select a supplier');
      return;
    }
    const validLines = lines.filter((l) => l.itemId && Number(l.quantity) > 0);
    if (validLines.length === 0) {
      setError('Add at least one line with an item and quantity');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await api.post('/payables/purchase-orders', {
        companyId,
        supplierId: Number(supplierId),
        orderDate,
        currencyCode,
        exchangeRate: Number(exchangeRate) || 1,
        lines: validLines.map((l) => ({
          itemId: Number(l.itemId),
          description: l.description || undefined,
          quantity: Number(l.quantity),
          unitPriceMinor: toMinor(Number(l.unitPriceMajor || 0)),
          taxRateId: l.taxRateId ? Number(l.taxRateId) : undefined,
        })),
      });
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(errMessage(err, 'Failed to create purchase order'));
    } finally {
      setBusy(false);
    }
  }

  async function approve(id: number) {
    try {
      await api.post(`/payables/purchase-orders/${id}/approve`);
      load();
    } catch (err: any) {
      window.alert(errMessage(err, 'Failed to approve purchase order'));
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Purchase Orders</h2>
        <button className="btn" onClick={startCreate}>
          + New PO
        </button>
      </div>

      {showForm && (
        <form className="card" onSubmit={submit} style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>New Purchase Order</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            <SupplierSelect suppliers={refData.suppliers} value={supplierId} onChange={setSupplierId} />
            <input type="date" value={orderDate} onChange={(e) => setOrderDate(e.target.value)} />
            <input placeholder="Currency" value={currencyCode} onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())} />
            <input
              placeholder="Exchange rate"
              type="number"
              step="0.000001"
              value={exchangeRate}
              onChange={(e) => setExchangeRate(e.target.value)}
            />
          </div>

          <table className="data-table" style={{ marginTop: 14 }}>
            <thead>
              <tr>
                <th style={{ width: '26%' }}>Item</th>
                <th>Description</th>
                <th style={{ width: 90 }}>Qty</th>
                <th style={{ width: 130 }}>Unit price</th>
                <th style={{ width: 170 }}>Tax</th>
                <th style={{ width: 130 }}>Line total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {lines.map((l, idx) => (
                <tr key={idx}>
                  <td>
                    <ItemSelect items={refData.items} value={l.itemId} onChange={(id) => updateLine(idx, { itemId: id })} />
                  </td>
                  <td>
                    <input value={l.description} onChange={(e) => updateLine(idx, { description: e.target.value })} />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.0001"
                      value={l.quantity}
                      onChange={(e) => updateLine(idx, { quantity: e.target.value })}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={l.unitPriceMajor}
                      onChange={(e) => updateLine(idx, { unitPriceMajor: e.target.value })}
                    />
                  </td>
                  <td>
                    <TaxRateSelect taxRates={refData.taxRates} value={l.taxRateId} onChange={(id) => updateLine(idx, { taxRateId: id })} />
                  </td>
                  <td>{formatMoney(lineNetMinor(l) + lineTaxMinor(l), currencyCode)}</td>
                  <td>
                    <button className="btn danger" type="button" onClick={() => removeLine(idx)} disabled={lines.length === 1}>
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn secondary" type="button" onClick={addLine} style={{ marginTop: 10 }}>
            + Add line
          </button>

          <div style={{ marginTop: 14, fontSize: 15, fontWeight: 700 }}>
            PO total: {formatMoney(formTotal, currencyCode)}
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Create PO'}
            </button>
            <button className="btn secondary" type="button" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>PO Number</th>
              <th>Supplier</th>
              <th>Order date</th>
              <th>Currency</th>
              <th>Status</th>
              <th>Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {pos.map((po) => (
              <tr key={po.id}>
                <td>{po.poNumber}</td>
                <td>{supplierById.get(po.supplierId)?.name || po.supplierId}</td>
                <td>{po.orderDate}</td>
                <td>{po.currencyCode}</td>
                <td>{poStatusPill(po.status)}</td>
                <td>{formatMoney(poTotal(po), po.currencyCode)}</td>
                <td>
                  {po.status === 'DRAFT' && (
                    <button className="btn secondary" onClick={() => approve(po.id)}>
                      Approve
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {!loading && pos.length === 0 && (
              <tr>
                <td colSpan={7} style={{ color: 'var(--text-dim)' }}>
                  No purchase orders yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 3. Goods Receipts tab
// ---------------------------------------------------------------------------

interface ManualGrnLine {
  itemId: number | '';
  quantity: string;
  unitCostMajor: string;
}

function emptyManualLine(): ManualGrnLine {
  return { itemId: '', quantity: '1', unitCostMajor: '0' };
}

function GoodsReceiptsTab({ companyId, refData }: { companyId: number; refData: RefData }) {
  const [grns, setGrns] = useState<GoodsReceipt[]>([]);
  const [pos, setPos] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [selectedPoId, setSelectedPoId] = useState<number | ''>('');
  const [manualSupplierId, setManualSupplierId] = useState<number | ''>('');
  const [receiptDate, setReceiptDate] = useState(today());
  const [grnClearingAccountId, setGrnClearingAccountId] = useState<number | ''>('');
  const [poLineDraft, setPoLineDraft] = useState<Record<number, { checked: boolean; qty: string }>>({});
  const [manualLines, setManualLines] = useState<ManualGrnLine[]>([emptyManualLine()]);

  const supplierById = useMemo(() => new Map(refData.suppliers.map((s) => [s.id, s])), [refData.suppliers]);
  const poById = useMemo(() => new Map(pos.map((p) => [p.id, p])), [pos]);
  const itemById = useMemo(() => new Map(refData.items.map((i) => [i.id, i])), [refData.items]);

  function load() {
    setLoading(true);
    Promise.all([
      api.get('/payables/goods-receipts', { params: { companyId } }),
      api.get('/payables/purchase-orders', { params: { companyId } }),
    ])
      .then(([grnRes, poRes]) => {
        setGrns(grnRes.data);
        setPos(poRes.data);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  const receivablePos = pos.filter((p) => p.status === 'APPROVED' || p.status === 'PARTIALLY_RECEIVED');
  const selectedPo = selectedPoId ? poById.get(Number(selectedPoId)) : undefined;
  const outstandingLines = selectedPo ? selectedPo.lines.filter((l) => Number(l.quantity) > Number(l.quantityReceived)) : [];

  useEffect(() => {
    if (!selectedPo) {
      setPoLineDraft({});
      return;
    }
    const draft: Record<number, { checked: boolean; qty: string }> = {};
    selectedPo.lines.forEach((l) => {
      const remaining = Number(l.quantity) - Number(l.quantityReceived);
      if (remaining > 0) draft[l.id] = { checked: false, qty: String(remaining) };
    });
    setPoLineDraft(draft);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPoId]);

  function startCreate() {
    setSelectedPoId('');
    setManualSupplierId('');
    setReceiptDate(today());
    setGrnClearingAccountId('');
    setManualLines([emptyManualLine()]);
    setError('');
    setShowForm(true);
  }

  function updateManualLine(idx: number, patch: Partial<ManualGrnLine>) {
    setManualLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!grnClearingAccountId) {
      setError('Select the clearing / AP account to credit for this receipt');
      return;
    }
    const finalSupplierId = selectedPo ? selectedPo.supplierId : Number(manualSupplierId);
    if (!finalSupplierId) {
      setError('Select a supplier');
      return;
    }

    const lines: Array<{ poLineId?: number; itemId: number; quantity: number; unitCostMinor?: number }> = [];
    outstandingLines.forEach((l) => {
      const d = poLineDraft[l.id];
      if (d && d.checked && Number(d.qty) > 0) {
        lines.push({ poLineId: l.id, itemId: l.itemId, quantity: Number(d.qty) });
      }
    });
    manualLines.forEach((m) => {
      if (m.itemId && Number(m.quantity) > 0) {
        lines.push({ itemId: Number(m.itemId), quantity: Number(m.quantity), unitCostMinor: toMinor(Number(m.unitCostMajor || 0)) });
      }
    });

    if (lines.length === 0) {
      setError('Add at least one line to receive');
      return;
    }

    setBusy(true);
    setError('');
    try {
      await api.post('/payables/goods-receipts', {
        companyId,
        poId: selectedPo ? selectedPo.id : undefined,
        supplierId: finalSupplierId,
        receiptDate,
        grnClearingAccountId: Number(grnClearingAccountId),
        lines,
      });
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(errMessage(err, 'Failed to create goods receipt'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Goods Receipts</h2>
        <button className="btn" onClick={startCreate}>
          + New GRN
        </button>
      </div>

      {showForm && (
        <form className="card" onSubmit={submit} style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>New Goods Receipt</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            <select value={selectedPoId} onChange={(e) => setSelectedPoId(e.target.value ? Number(e.target.value) : '')}>
              <option value="">No linked PO (manual receipt)</option>
              {receivablePos.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.poNumber} — {supplierById.get(p.supplierId)?.name || p.supplierId}
                </option>
              ))}
            </select>
            {!selectedPo && <SupplierSelect suppliers={refData.suppliers} value={manualSupplierId} onChange={setManualSupplierId} />}
            <input type="date" value={receiptDate} onChange={(e) => setReceiptDate(e.target.value)} />
            <AccountSelect
              accounts={refData.accounts}
              value={grnClearingAccountId}
              onChange={setGrnClearingAccountId}
              placeholder="Clearing / AP account to credit…"
            />
          </div>

          {selectedPo && (
            <>
              <h4 style={{ marginBottom: 6 }}>Outstanding PO lines</h4>
              <table className="data-table">
                <thead>
                  <tr>
                    <th style={{ width: 40 }}></th>
                    <th>Item</th>
                    <th>Ordered</th>
                    <th>Received</th>
                    <th>Remaining</th>
                    <th style={{ width: 120 }}>Receive qty</th>
                  </tr>
                </thead>
                <tbody>
                  {outstandingLines.map((l) => {
                    const d = poLineDraft[l.id] || { checked: false, qty: '0' };
                    const remaining = Number(l.quantity) - Number(l.quantityReceived);
                    return (
                      <tr key={l.id}>
                        <td>
                          <input
                            type="checkbox"
                            checked={d.checked}
                            onChange={(e) => setPoLineDraft({ ...poLineDraft, [l.id]: { ...d, checked: e.target.checked } })}
                          />
                        </td>
                        <td>{itemById.get(l.itemId)?.name || l.itemId}</td>
                        <td>{l.quantity}</td>
                        <td>{l.quantityReceived}</td>
                        <td>{remaining}</td>
                        <td>
                          <input
                            type="number"
                            step="0.0001"
                            value={d.qty}
                            onChange={(e) => setPoLineDraft({ ...poLineDraft, [l.id]: { ...d, qty: e.target.value } })}
                          />
                        </td>
                      </tr>
                    );
                  })}
                  {outstandingLines.length === 0 && (
                    <tr>
                      <td colSpan={6} style={{ color: 'var(--text-dim)' }}>
                        Nothing outstanding on this PO.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </>
          )}

          <h4 style={{ marginBottom: 6, marginTop: 16 }}>
            {selectedPo ? 'Additional manual lines (optional)' : 'Lines'}
          </h4>
          <table className="data-table">
            <thead>
              <tr>
                <th>Item</th>
                <th style={{ width: 100 }}>Qty</th>
                <th style={{ width: 150 }}>Unit cost</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {manualLines.map((m, idx) => (
                <tr key={idx}>
                  <td>
                    <ItemSelect items={refData.items} value={m.itemId} onChange={(id) => updateManualLine(idx, { itemId: id })} />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.0001"
                      value={m.quantity}
                      onChange={(e) => updateManualLine(idx, { quantity: e.target.value })}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={m.unitCostMajor}
                      onChange={(e) => updateManualLine(idx, { unitCostMajor: e.target.value })}
                    />
                  </td>
                  <td>
                    <button
                      className="btn danger"
                      type="button"
                      onClick={() => setManualLines((prev) => prev.filter((_, i) => i !== idx))}
                      disabled={manualLines.length === 1}
                    >
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn secondary" type="button" onClick={() => setManualLines((prev) => [...prev, emptyManualLine()])} style={{ marginTop: 10 }}>
            + Add manual line
          </button>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Create GRN'}
            </button>
            <button className="btn secondary" type="button" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>GRN Number</th>
              <th>Supplier</th>
              <th>Receipt date</th>
              <th>Linked PO</th>
            </tr>
          </thead>
          <tbody>
            {grns.map((g) => (
              <tr key={g.id}>
                <td>{g.grnNumber}</td>
                <td>{supplierById.get(g.supplierId)?.name || g.supplierId}</td>
                <td>{g.receiptDate}</td>
                <td>{g.poId ? poById.get(g.poId)?.poNumber || g.poId : '—'}</td>
              </tr>
            ))}
            {!loading && grns.length === 0 && (
              <tr>
                <td colSpan={4} style={{ color: 'var(--text-dim)' }}>
                  No goods receipts yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 4. Bills tab
// ---------------------------------------------------------------------------

interface BillLineDraft {
  mode: 'item' | 'expense';
  itemId: number | '';
  description: string;
  quantity: string;
  unitPriceMajor: string;
  taxRateId: number | '';
  expenseAccountId: number | '';
}

function emptyBillLine(): BillLineDraft {
  return { mode: 'item', itemId: '', description: '', quantity: '1', unitPriceMajor: '0', taxRateId: '', expenseAccountId: '' };
}

function BillsTab({ companyId, refData, baseCurrency }: { companyId: number; refData: RefData; baseCurrency: string }) {
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [supplierId, setSupplierId] = useState<number | ''>('');
  const [billDate, setBillDate] = useState(today());
  const [dueDate, setDueDate] = useState(today());
  const [currencyCode, setCurrencyCode] = useState(baseCurrency || 'LKR');
  const [exchangeRate, setExchangeRate] = useState('1');
  const [lines, setLines] = useState<BillLineDraft[]>([emptyBillLine()]);

  const supplierById = useMemo(() => new Map(refData.suppliers.map((s) => [s.id, s])), [refData.suppliers]);
  const itemById = useMemo(() => new Map(refData.items.map((i) => [i.id, i])), [refData.items]);
  const taxRateById = useMemo(() => new Map(refData.taxRates.map((t) => [t.id, t])), [refData.taxRates]);

  function load() {
    setLoading(true);
    api
      .get('/payables/bills', { params: { companyId } })
      .then((res) => setBills(res.data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  function startCreate() {
    setSupplierId('');
    setBillDate(today());
    setDueDate(today());
    setCurrencyCode(baseCurrency || 'LKR');
    setExchangeRate('1');
    setLines([emptyBillLine()]);
    setError('');
    setShowForm(true);
  }

  function updateLine(idx: number, patch: Partial<BillLineDraft>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  function lineNetMinor(l: BillLineDraft): number {
    return Math.round(Number(l.quantity || 0) * toMinor(Number(l.unitPriceMajor || 0)));
  }

  function lineTaxMinor(l: BillLineDraft): number {
    return l.taxRateId ? computeTaxMinor(lineNetMinor(l), taxRateById.get(Number(l.taxRateId))) : 0;
  }

  const subtotal = lines.reduce((sum, l) => sum + lineNetMinor(l), 0);
  const taxTotal = lines.reduce((sum, l) => sum + lineTaxMinor(l), 0);
  const grandTotal = subtotal + taxTotal;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supplierId) {
      setError('Select a supplier');
      return;
    }
    for (const l of lines) {
      if (!l.itemId && !l.expenseAccountId) {
        setError('Every line needs either an item or an expense account');
        return;
      }
      if (l.mode === 'item' && !l.description && !l.itemId) {
        setError('Every line needs a description');
        return;
      }
    }
    setBusy(true);
    setError('');
    try {
      await api.post('/payables/bills', {
        companyId,
        supplierId: Number(supplierId),
        billDate,
        dueDate,
        currencyCode,
        exchangeRate: Number(exchangeRate) || 1,
        lines: lines.map((l) => ({
          itemId: l.mode === 'item' && l.itemId ? Number(l.itemId) : undefined,
          description: l.description || (l.itemId ? itemById.get(Number(l.itemId))?.name : '') || 'Line item',
          quantity: Number(l.quantity) || 1,
          unitPriceMinor: toMinor(Number(l.unitPriceMajor || 0)),
          taxRateId: l.taxRateId ? Number(l.taxRateId) : undefined,
          expenseAccountId: l.mode === 'expense' && l.expenseAccountId ? Number(l.expenseAccountId) : undefined,
        })),
      });
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(errMessage(err, 'Failed to create bill'));
    } finally {
      setBusy(false);
    }
  }

  async function postBill(id: number) {
    try {
      await api.post(`/payables/bills/${id}/post`);
      load();
    } catch (err: any) {
      window.alert(errMessage(err, 'Failed to post bill'));
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Bills</h2>
        <button className="btn" onClick={startCreate}>
          + New Bill
        </button>
      </div>

      {showForm && (
        <form className="card" onSubmit={submit} style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>New Bill</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            <SupplierSelect suppliers={refData.suppliers} value={supplierId} onChange={setSupplierId} />
            <div>
              <label style={{ fontSize: 11, color: 'var(--text-dim)' }}>Bill date</label>
              <input type="date" value={billDate} onChange={(e) => setBillDate(e.target.value)} style={{ width: '100%' }} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: 'var(--text-dim)' }}>Due date</label>
              <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} style={{ width: '100%' }} />
            </div>
            <input placeholder="Currency" value={currencyCode} onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())} />
            <input
              placeholder="Exchange rate"
              type="number"
              step="0.000001"
              value={exchangeRate}
              onChange={(e) => setExchangeRate(e.target.value)}
            />
          </div>

          <table className="data-table" style={{ marginTop: 14 }}>
            <thead>
              <tr>
                <th style={{ width: 90 }}>Type</th>
                <th style={{ width: '22%' }}>Item / Account</th>
                <th>Description</th>
                <th style={{ width: 80 }}>Qty</th>
                <th style={{ width: 120 }}>Unit price</th>
                <th style={{ width: 160 }}>Tax</th>
                <th style={{ width: 120 }}>Total</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {lines.map((l, idx) => (
                <tr key={idx}>
                  <td>
                    <select
                      value={l.mode}
                      onChange={(e) => updateLine(idx, { mode: e.target.value as 'item' | 'expense', itemId: '', expenseAccountId: '' })}
                    >
                      <option value="item">Item</option>
                      <option value="expense">Expense</option>
                    </select>
                  </td>
                  <td>
                    {l.mode === 'item' ? (
                      <ItemSelect items={refData.items} value={l.itemId} onChange={(id) => updateLine(idx, { itemId: id })} />
                    ) : (
                      <AccountSelect
                        accounts={refData.accounts}
                        value={l.expenseAccountId}
                        onChange={(id) => updateLine(idx, { expenseAccountId: id })}
                        filterTypes={['EXPENSE']}
                        placeholder="Expense account…"
                      />
                    )}
                  </td>
                  <td>
                    <input
                      placeholder="Description"
                      value={l.description}
                      onChange={(e) => updateLine(idx, { description: e.target.value })}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.0001"
                      value={l.quantity}
                      onChange={(e) => updateLine(idx, { quantity: e.target.value })}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={l.unitPriceMajor}
                      onChange={(e) => updateLine(idx, { unitPriceMajor: e.target.value })}
                    />
                  </td>
                  <td>
                    <TaxRateSelect taxRates={refData.taxRates} value={l.taxRateId} onChange={(id) => updateLine(idx, { taxRateId: id })} />
                  </td>
                  <td>{formatMoney(lineNetMinor(l) + lineTaxMinor(l), currencyCode)}</td>
                  <td>
                    <button
                      className="btn danger"
                      type="button"
                      onClick={() => setLines((prev) => prev.filter((_, i) => i !== idx))}
                      disabled={lines.length === 1}
                    >
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn secondary" type="button" onClick={() => setLines((prev) => [...prev, emptyBillLine()])} style={{ marginTop: 10 }}>
            + Add line
          </button>

          <div style={{ marginTop: 14, fontSize: 13, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <div>Subtotal: {formatMoney(subtotal, currencyCode)}</div>
            <div>Tax: {formatMoney(taxTotal, currencyCode)}</div>
            <div style={{ fontSize: 15, fontWeight: 700 }}>Total: {formatMoney(grandTotal, currencyCode)}</div>
          </div>

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Create Bill (DRAFT)'}
            </button>
            <button className="btn secondary" type="button" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>Bill Number</th>
              <th>Supplier</th>
              <th>Bill date</th>
              <th>Due date</th>
              <th>Currency</th>
              <th>Status</th>
              <th>Total</th>
              <th>Paid</th>
              <th>Outstanding</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {bills.map((b) => (
              <tr key={b.id}>
                <td>{b.billNumber}</td>
                <td>{supplierById.get(b.supplierId)?.name || b.supplierId}</td>
                <td>{b.billDate}</td>
                <td>{b.dueDate}</td>
                <td>{b.currencyCode}</td>
                <td>{billStatusPill(b.status)}</td>
                <td>{formatMoney(b.totalMinor, b.currencyCode)}</td>
                <td>{formatMoney(b.amountPaidMinor, b.currencyCode)}</td>
                <td>{formatMoney(Number(b.totalMinor) - Number(b.amountPaidMinor), b.currencyCode)}</td>
                <td>
                  {b.status === 'DRAFT' && (
                    <button className="btn secondary" onClick={() => postBill(b.id)}>
                      Post
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {!loading && bills.length === 0 && (
              <tr>
                <td colSpan={10} style={{ color: 'var(--text-dim)' }}>
                  No bills yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 5. Payments tab
// ---------------------------------------------------------------------------

function PaymentsTab({ companyId, refData, baseCurrency }: { companyId: number; refData: RefData; baseCurrency: string }) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [supplierId, setSupplierId] = useState<number | ''>('');
  const [paymentDate, setPaymentDate] = useState(today());
  const [bankAccountGlAccountId, setBankAccountGlAccountId] = useState<number | ''>('');
  const [currencyCode, setCurrencyCode] = useState(baseCurrency || 'LKR');
  const [exchangeRate, setExchangeRate] = useState('1');
  const [amountMajor, setAmountMajor] = useState('0');
  const [allocDraft, setAllocDraft] = useState<Record<number, { checked: boolean; amountMajor: string }>>({});

  const supplierById = useMemo(() => new Map(refData.suppliers.map((s) => [s.id, s])), [refData.suppliers]);

  function load() {
    setLoading(true);
    Promise.all([
      api.get('/payables/payments', { params: { companyId } }),
      api.get('/payables/bills', { params: { companyId } }),
    ])
      .then(([payRes, billRes]) => {
        setPayments(payRes.data);
        setBills(billRes.data);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId]);

  const openBills = bills.filter(
    (b) => b.supplierId === Number(supplierId) && (b.status === 'POSTED' || b.status === 'PARTIALLY_PAID'),
  );

  useEffect(() => {
    const draft: Record<number, { checked: boolean; amountMajor: string }> = {};
    openBills.forEach((b) => {
      const outstanding = Number(b.totalMinor) - Number(b.amountPaidMinor);
      draft[b.id] = { checked: false, amountMajor: (outstanding / 100).toFixed(2) };
    });
    setAllocDraft(draft);
    setAmountMajor('0');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supplierId]);

  function startCreate() {
    setSupplierId('');
    setPaymentDate(today());
    setBankAccountGlAccountId('');
    setCurrencyCode(baseCurrency || 'LKR');
    setExchangeRate('1');
    setAmountMajor('0');
    setAllocDraft({});
    setError('');
    setShowForm(true);
  }

  const totalAllocatedMinor = openBills.reduce((sum, b) => {
    const d = allocDraft[b.id];
    return d && d.checked ? sum + toMinor(Number(d.amountMajor || 0)) : sum;
  }, 0);
  const amountMinor = toMinor(Number(amountMajor || 0));
  const checkedCount = openBills.filter((b) => allocDraft[b.id]?.checked).length;
  const amountsMatch = checkedCount > 0 && totalAllocatedMinor === amountMinor;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supplierId) {
      setError('Select a supplier');
      return;
    }
    if (!bankAccountGlAccountId) {
      setError('Select the bank/cash account to pay from');
      return;
    }
    if (!amountsMatch) {
      setError('Allocated amount must equal the payment amount');
      return;
    }
    const allocations = openBills
      .filter((b) => allocDraft[b.id]?.checked)
      .map((b) => ({ billId: b.id, allocatedAmountMinor: toMinor(Number(allocDraft[b.id].amountMajor || 0)) }));

    setBusy(true);
    setError('');
    try {
      await api.post('/payables/payments', {
        companyId,
        supplierId: Number(supplierId),
        paymentDate,
        bankAccountGlAccountId: Number(bankAccountGlAccountId),
        currencyCode,
        exchangeRate: Number(exchangeRate) || 1,
        amountMinor,
        allocations,
        companyBaseCurrency: baseCurrency,
      });
      setShowForm(false);
      load();
    } catch (err: any) {
      setError(errMessage(err, 'Failed to create payment'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Payments</h2>
        <button className="btn" onClick={startCreate}>
          + New Payment
        </button>
      </div>

      {showForm && (
        <form className="card" onSubmit={submit} style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>New Payment</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            <SupplierSelect suppliers={refData.suppliers} value={supplierId} onChange={setSupplierId} />
            <input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
            <AccountSelect
              accounts={refData.accounts}
              value={bankAccountGlAccountId}
              onChange={setBankAccountGlAccountId}
              filterTypes={['ASSET']}
              placeholder="Bank / cash account…"
            />
            <input placeholder="Currency" value={currencyCode} onChange={(e) => setCurrencyCode(e.target.value.toUpperCase())} />
            <input
              placeholder="Exchange rate"
              type="number"
              step="0.000001"
              value={exchangeRate}
              onChange={(e) => setExchangeRate(e.target.value)}
            />
            <div>
              <label style={{ fontSize: 11, color: 'var(--text-dim)' }}>Payment amount</label>
              <input type="number" step="0.01" value={amountMajor} onChange={(e) => setAmountMajor(e.target.value)} style={{ width: '100%' }} />
            </div>
          </div>

          {supplierId && (
            <>
              <h4 style={{ marginTop: 16, marginBottom: 6 }}>Open bills for {supplierById.get(Number(supplierId))?.name}</h4>
              <table className="data-table">
                <thead>
                  <tr>
                    <th style={{ width: 40 }}></th>
                    <th>Bill</th>
                    <th>Due date</th>
                    <th>Status</th>
                    <th>Outstanding</th>
                    <th style={{ width: 140 }}>Allocate</th>
                  </tr>
                </thead>
                <tbody>
                  {openBills.map((b) => {
                    const outstanding = Number(b.totalMinor) - Number(b.amountPaidMinor);
                    const d = allocDraft[b.id] || { checked: false, amountMajor: (outstanding / 100).toFixed(2) };
                    return (
                      <tr key={b.id}>
                        <td>
                          <input
                            type="checkbox"
                            checked={d.checked}
                            onChange={(e) => setAllocDraft({ ...allocDraft, [b.id]: { ...d, checked: e.target.checked } })}
                          />
                        </td>
                        <td>{b.billNumber}</td>
                        <td>{b.dueDate}</td>
                        <td>{billStatusPill(b.status)}</td>
                        <td>{formatMoney(outstanding, b.currencyCode)}</td>
                        <td>
                          <input
                            type="number"
                            step="0.01"
                            value={d.amountMajor}
                            onChange={(e) => {
                              const majorVal = Number(e.target.value || 0);
                              const clamped = Math.min(majorVal, outstanding / 100);
                              setAllocDraft({ ...allocDraft, [b.id]: { ...d, amountMajor: String(clamped) } });
                            }}
                          />
                        </td>
                      </tr>
                    );
                  })}
                  {openBills.length === 0 && (
                    <tr>
                      <td colSpan={6} style={{ color: 'var(--text-dim)' }}>
                        No open bills for this supplier.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>

              <div style={{ marginTop: 12, fontSize: 13, display: 'flex', alignItems: 'center', gap: 10 }}>
                <span>
                  Allocated: {formatMoney(totalAllocatedMinor, currencyCode)} / Payment amount: {formatMoney(amountMinor, currencyCode)}
                </span>
                {amountsMatch ? <Pill text="Balanced" color="green" /> : <Pill text="Does not match" color="amber" />}
              </div>
            </>
          )}

          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn" type="submit" disabled={busy || !amountsMatch}>
              {busy ? 'Saving…' : 'Create Payment'}
            </button>
            <button className="btn secondary" type="button" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>Payment Number</th>
              <th>Supplier</th>
              <th>Payment date</th>
              <th>Currency</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id}>
                <td>{p.paymentNumber}</td>
                <td>{supplierById.get(p.supplierId)?.name || p.supplierId}</td>
                <td>{p.paymentDate}</td>
                <td>{p.currencyCode}</td>
                <td>{formatMoney(p.amountMinor, p.currencyCode)}</td>
              </tr>
            ))}
            {!loading && payments.length === 0 && (
              <tr>
                <td colSpan={5} style={{ color: 'var(--text-dim)' }}>
                  No payments yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 6. Aging tab
// ---------------------------------------------------------------------------

function AgingTab({ companyId, baseCurrency }: { companyId: number; baseCurrency: string }) {
  const [rows, setRows] = useState<AgingBucket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .get('/payables/aging', { params: { companyId } })
      .then((res) => setRows(res.data))
      .finally(() => setLoading(false));
  }, [companyId]);

  const totals = rows.reduce(
    (acc, r) => ({
      current: acc.current + r.current,
      d1to30: acc.d1to30 + r.d1to30,
      d31to60: acc.d31to60 + r.d31to60,
      d61to90: acc.d61to90 + r.d61to90,
      d90plus: acc.d90plus + r.d90plus,
      total: acc.total + r.totalOutstandingBaseMinor,
    }),
    { current: 0, d1to30: 0, d31to60: 0, d61to90: 0, d90plus: 0, total: 0 },
  );

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>AP Aging</h2>
      </div>
      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>Supplier</th>
              <th>Current</th>
              <th>1–30 days</th>
              <th>31–60 days</th>
              <th>61–90 days</th>
              <th>90+ days</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.supplierId}>
                <td>{r.supplierName}</td>
                <td>{formatMoney(r.current, baseCurrency)}</td>
                <td>{formatMoney(r.d1to30, baseCurrency)}</td>
                <td>{formatMoney(r.d31to60, baseCurrency)}</td>
                <td>{formatMoney(r.d61to90, baseCurrency)}</td>
                <td>{formatMoney(r.d90plus, baseCurrency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(r.totalOutstandingBaseMinor, baseCurrency)}</td>
              </tr>
            ))}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={7} style={{ color: 'var(--text-dim)' }}>
                  Nothing outstanding.
                </td>
              </tr>
            )}
          </tbody>
          {rows.length > 0 && (
            <tfoot>
              <tr>
                <td style={{ fontWeight: 700 }}>Total</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.current, baseCurrency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d1to30, baseCurrency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d31to60, baseCurrency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d61to90, baseCurrency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.d90plus, baseCurrency)}</td>
                <td style={{ fontWeight: 700 }}>{formatMoney(totals.total, baseCurrency)}</td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page root
// ---------------------------------------------------------------------------

export default function PayablesPage() {
  const { company, loading: companyLoading } = useCompany();
  const [tab, setTab] = useState<TabKey>('suppliers');

  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [taxRates, setTaxRates] = useState<TaxRate[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);

  const companyId = company?.id;

  useEffect(() => {
    if (!companyId) return;
    api.get('/payables/suppliers', { params: { companyId } }).then((res) => setSuppliers(res.data));
    api.get('/accounting/accounts', { params: { companyId } }).then((res) => setAccounts(res.data));
    api.get('/inventory/items', { params: { companyId } }).then((res) => setItems(res.data));
    api.get('/tax-rates', { params: { companyId } }).then((res) => setTaxRates(res.data));
  }, [companyId, refreshKey]);

  if (companyLoading) {
    return <div className="card">Loading…</div>;
  }
  if (!company || !companyId) {
    return <div className="card">No company selected.</div>;
  }

  const refData: RefData = { suppliers, accounts, items, taxRates };

  return (
    <div>
      <div className="page-header">
        <h1>Payables</h1>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            className={tab === t.key ? 'btn' : 'btn secondary'}
            onClick={() => setTab(t.key)}
            type="button"
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'suppliers' && (
        <SuppliersTab companyId={companyId} refData={refData} onChanged={() => setRefreshKey((k) => k + 1)} />
      )}
      {tab === 'purchase-orders' && (
        <PurchaseOrdersTab companyId={companyId} refData={refData} baseCurrency={company.baseCurrency} />
      )}
      {tab === 'goods-receipts' && <GoodsReceiptsTab companyId={companyId} refData={refData} />}
      {tab === 'bills' && <BillsTab companyId={companyId} refData={refData} baseCurrency={company.baseCurrency} />}
      {tab === 'payments' && <PaymentsTab companyId={companyId} refData={refData} baseCurrency={company.baseCurrency} />}
      {tab === 'aging' && <AgingTab companyId={companyId} baseCurrency={company.baseCurrency} />}
    </div>
  );
}
