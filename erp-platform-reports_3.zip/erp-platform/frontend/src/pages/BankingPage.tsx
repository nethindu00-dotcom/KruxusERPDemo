import React, { useEffect, useMemo, useState } from 'react';
import { api, formatMoney, toMinor } from '../lib/api';
import { useCompany } from '../context/CompanyContext';

// ---------------------------------------------------------------------------
// Types (field names mirror backend/src/modules/banking and accounting entities)
// ---------------------------------------------------------------------------

interface Account {
  id: number;
  code: string;
  name: string;
  accountType: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
  normalBalance: string;
  isActive: boolean;
}

interface BankAccount {
  id: number;
  companyId: number;
  accountId: number;
  bankName: string;
  accountNumber: string;
  branchName?: string | null;
  currencyCode: string;
  openingBalanceMinor: string;
  openingBalanceDate?: string | null;
  isActive: boolean;
}

interface BankStatementLine {
  id: number;
  companyId: number;
  bankAccountId: number;
  statementDate: string;
  description: string;
  referenceNo?: string | null;
  debitMinor: string;
  creditMinor: string;
  runningBalanceMinor?: string | null;
  isMatched: boolean;
  matchedJournalEntryId?: number | null;
  matchedJournalLineId?: number | null;
  matchNote?: string | null;
  importBatchId?: string | null;
}

interface JournalLineRow {
  id: number;
  entryId: number;
  accountId: number;
  description?: string | null;
  debitMinor: string;
  creditMinor: string;
}

interface ReconciliationSummary {
  bankAccountId: number;
  asOfDate: string;
  bookBalanceMinor: string;
  statementBalanceMinor: string;
  differenceMinor: string;
  unmatchedStatementLines: BankStatementLine[];
  unreconciledJournalLines: JournalLineRow[];
}

type TabKey = 'accounts' | 'statement' | 'reconciliation';

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: 'accounts', label: 'Bank Accounts' },
  { key: 'statement', label: 'Statement Import & Matching' },
  { key: 'reconciliation', label: 'Reconciliation' },
];

// ---------------------------------------------------------------------------
// Small shared helpers
// ---------------------------------------------------------------------------

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function errMessage(err: any, fallback: string): string {
  return err?.response?.data?.error?.message || err?.response?.data?.message || fallback;
}

function accountLabel(a: Account): string {
  return `${a.code} — ${a.name}`;
}

function Pill({ text, color }: { text: string; color: 'green' | 'red' | 'amber' | 'gray' }) {
  return <span className={`pill ${color}`}>{text}</span>;
}

function AccountSelect(props: {
  accounts: Account[];
  value: number | '';
  onChange: (id: number | '') => void;
  placeholder?: string;
}) {
  return (
    <select value={props.value} onChange={(e) => props.onChange(e.target.value ? Number(e.target.value) : '')}>
      <option value="">{props.placeholder || 'Select account…'}</option>
      {props.accounts.map((a) => (
        <option key={a.id} value={a.id}>
          {accountLabel(a)}
        </option>
      ))}
    </select>
  );
}

// A valid-looking date in YYYY-MM-DD, or D/M/YYYY or M-D-YYYY etc. We only need
// "does the first cell look like a date" to skip a pasted header row.
function looksLikeDate(s: string): boolean {
  const t = s.trim();
  if (!t) return false;
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(t)) return true;
  if (/^\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}$/.test(t)) return true;
  return false;
}

// Normalize a loosely-formatted date string to YYYY-MM-DD (best effort).
function normalizeDate(s: string): string {
  const t = s.trim();
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(t)) {
    const [y, m, d] = t.split('-');
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
  }
  const m = t.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})$/);
  if (m) {
    let [, a, b, y] = m;
    if (y.length === 2) y = `20${y}`;
    // assume D/M/YYYY (common outside the US) — this is a best-effort import helper
    return `${y}-${b.padStart(2, '0')}-${a.padStart(2, '0')}`;
  }
  return t;
}

function parseAmount(s: string): number {
  const t = (s || '').replace(/[,\s]/g, '').trim();
  if (!t) return 0;
  const n = Number(t);
  return Number.isFinite(n) ? n : 0;
}

interface ParsedRow {
  statementDate: string;
  description: string;
  debitMajor: string;
  creditMajor: string;
}

function parsePastedLines(raw: string): ParsedRow[] {
  const rows: ParsedRow[] = [];
  const lines = raw.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const cells = trimmed.includes('\t') ? trimmed.split('\t') : trimmed.split(',');
    const trimmedCells = cells.map((c) => c.trim());
    if (trimmedCells.length < 2) continue;
    const [dateCell, descCell, debitCell, creditCell] = trimmedCells;
    if (!looksLikeDate(dateCell)) continue; // skip header row / junk
    rows.push({
      statementDate: normalizeDate(dateCell),
      description: descCell || '',
      debitMajor: debitCell || '',
      creditMajor: creditCell || '',
    });
  }
  return rows;
}

// ---------------------------------------------------------------------------
// Bank account selector shown atop the Statement & Reconciliation tabs
// ---------------------------------------------------------------------------

function BankAccountPicker(props: {
  bankAccounts: BankAccount[];
  selectedId: number | '';
  onChange: (id: number | '') => void;
}) {
  if (props.bankAccounts.length <= 1) return null;
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 11, color: 'var(--text-dim)', display: 'block', marginBottom: 4 }}>Bank account</label>
      <select value={props.selectedId} onChange={(e) => props.onChange(e.target.value ? Number(e.target.value) : '')}>
        <option value="">Select bank account…</option>
        {props.bankAccounts.map((b) => (
          <option key={b.id} value={b.id}>
            {b.bankName} — {b.accountNumber}
          </option>
        ))}
      </select>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 1. Bank Accounts tab
// ---------------------------------------------------------------------------

interface BankAccountFormState {
  bankName: string;
  accountNumber: string;
  branchName: string;
  accountId: number | '';
  currencyCode: string;
  openingBalanceMajor: string;
  openingBalanceDate: string;
}

function emptyBankAccountForm(baseCurrency: string): BankAccountFormState {
  return {
    bankName: '',
    accountNumber: '',
    branchName: '',
    accountId: '',
    currencyCode: baseCurrency || 'LKR',
    openingBalanceMajor: '0',
    openingBalanceDate: today(),
  };
}

function BankAccountsTab(props: {
  companyId: number;
  baseCurrency: string;
  bankAccounts: BankAccount[];
  accounts: Account[];
  onChanged: () => void;
  onSelect: (id: number) => void;
  selectedId: number | '';
}) {
  const { companyId, baseCurrency, bankAccounts, accounts } = props;
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<BankAccount | null>(null);
  const [form, setForm] = useState<BankAccountFormState>(emptyBankAccountForm(baseCurrency));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const accountById = useMemo(() => new Map(accounts.map((a) => [a.id, a])), [accounts]);

  function startCreate() {
    setEditing(null);
    setForm(emptyBankAccountForm(baseCurrency));
    setError('');
    setShowForm(true);
  }

  function startEdit(b: BankAccount) {
    setEditing(b);
    setForm({
      bankName: b.bankName,
      accountNumber: b.accountNumber,
      branchName: b.branchName || '',
      accountId: b.accountId,
      currencyCode: b.currencyCode,
      openingBalanceMajor: (Number(b.openingBalanceMinor) / 100).toFixed(2),
      openingBalanceDate: b.openingBalanceDate || today(),
    });
    setError('');
    setShowForm(true);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.accountId) {
      setError('Select the linked GL account');
      return;
    }
    if (!form.bankName || !form.accountNumber) {
      setError('Bank name and account number are required');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const body = {
        companyId,
        bankName: form.bankName,
        accountNumber: form.accountNumber,
        branchName: form.branchName || undefined,
        accountId: Number(form.accountId),
        currencyCode: form.currencyCode,
        openingBalanceMinor: toMinor(Number(form.openingBalanceMajor || 0)),
        openingBalanceDate: form.openingBalanceDate || undefined,
      };
      if (editing) {
        await api.patch(`/banking/accounts/${editing.id}`, body);
      } else {
        await api.post('/banking/accounts', body);
      }
      setShowForm(false);
      props.onChanged();
    } catch (err: any) {
      setError(errMessage(err, 'Failed to save bank account'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Bank Accounts</h2>
        <button className="btn" onClick={startCreate} type="button">
          + New Bank Account
        </button>
      </div>

      {showForm && (
        <form className="card" onSubmit={submit} style={{ marginBottom: 18 }}>
          <h3 style={{ marginTop: 0 }}>{editing ? `Edit ${editing.bankName}` : 'New Bank Account'}</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            <input
              placeholder="Bank name"
              value={form.bankName}
              onChange={(e) => setForm({ ...form, bankName: e.target.value })}
              required
            />
            <input
              placeholder="Account number"
              value={form.accountNumber}
              onChange={(e) => setForm({ ...form, accountNumber: e.target.value })}
              required
            />
            <input
              placeholder="Branch name"
              value={form.branchName}
              onChange={(e) => setForm({ ...form, branchName: e.target.value })}
            />
            <AccountSelect
              accounts={accounts}
              value={form.accountId}
              onChange={(id) => setForm({ ...form, accountId: id })}
              placeholder="Linked GL account…"
            />
            <input
              placeholder="Currency"
              value={form.currencyCode}
              onChange={(e) => setForm({ ...form, currencyCode: e.target.value.toUpperCase() })}
            />
            <div>
              <label style={{ fontSize: 11, color: 'var(--text-dim)' }}>Opening balance</label>
              <input
                type="number"
                step="0.01"
                value={form.openingBalanceMajor}
                onChange={(e) => setForm({ ...form, openingBalanceMajor: e.target.value })}
                style={{ width: '100%' }}
              />
            </div>
            <div>
              <label style={{ fontSize: 11, color: 'var(--text-dim)' }}>Opening balance date</label>
              <input
                type="date"
                value={form.openingBalanceDate}
                onChange={(e) => setForm({ ...form, openingBalanceDate: e.target.value })}
                style={{ width: '100%' }}
              />
            </div>
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <button className="btn" type="submit" disabled={busy}>
              {busy ? 'Saving…' : 'Save'}
            </button>
            <button className="btn secondary" type="button" onClick={() => setShowForm(false)}>
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="card">
        <table className="data-table">
          <thead>
            <tr>
              <th>Bank</th>
              <th>Account number</th>
              <th>GL account</th>
              <th>Currency</th>
              <th>Opening balance</th>
              <th>Active</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {bankAccounts.map((b) => {
              const glAccount = accountById.get(b.accountId);
              return (
                <tr
                  key={b.id}
                  onClick={() => props.onSelect(b.id)}
                  style={{ cursor: 'pointer', background: props.selectedId === b.id ? 'var(--surface-2)' : undefined }}
                >
                  <td>{b.bankName}</td>
                  <td>{b.accountNumber}</td>
                  <td>{glAccount ? accountLabel(glAccount) : b.accountId}</td>
                  <td>{b.currencyCode}</td>
                  <td>{formatMoney(b.openingBalanceMinor, b.currencyCode)}</td>
                  <td>{b.isActive ? <Pill text="Active" color="green" /> : <Pill text="Inactive" color="gray" />}</td>
                  <td>
                    <button
                      className="btn secondary"
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        startEdit(b);
                      }}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              );
            })}
            {bankAccounts.length === 0 && (
              <tr>
                <td colSpan={7} style={{ color: 'var(--text-dim)' }}>
                  No bank accounts yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: 10 }}>
        Click a row to select that bank account for the Statement Import and Reconciliation tabs.
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 2. Statement Import & Matching tab
// ---------------------------------------------------------------------------

function StatementTab(props: { companyId: number; bankAccount: BankAccount }) {
  const { companyId, bankAccount } = props;
  const [lines, setLines] = useState<BankStatementLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [unmatchedOnly, setUnmatchedOnly] = useState(false);

  const [pasteText, setPasteText] = useState('');
  const [preview, setPreview] = useState<ParsedRow[]>([]);
  const [importBusy, setImportBusy] = useState(false);
  const [importError, setImportError] = useState('');

  const [autoMatchBusy, setAutoMatchBusy] = useState(false);
  const [autoMatchResult, setAutoMatchResult] = useState<{ matchedCount: number; unmatchedCount: number; totalChecked: number } | null>(
    null,
  );

  const [manualMatchDraft, setManualMatchDraft] = useState<Record<number, { journalEntryId: string; journalLineId: string }>>({});
  const [rowBusy, setRowBusy] = useState<Record<number, boolean>>({});
  const [rowError, setRowError] = useState<Record<number, string>>({});

  function load() {
    setLoading(true);
    api
      .get(`/banking/accounts/${bankAccount.id}/statement-lines`, {
        params: { companyId, unmatchedOnly: unmatchedOnly ? 'true' : undefined },
      })
      .then((res) => setLines(res.data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    setAutoMatchResult(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bankAccount.id, companyId, unmatchedOnly]);

  function parse() {
    setPreview(parsePastedLines(pasteText));
    setImportError('');
  }

  async function doImport() {
    if (preview.length === 0) return;
    setImportBusy(true);
    setImportError('');
    try {
      await api.post(`/banking/accounts/${bankAccount.id}/statement-lines/import`, {
        companyId,
        lines: preview.map((r) => ({
          statementDate: r.statementDate,
          description: r.description,
          debitMinor: toMinor(parseAmount(r.debitMajor)),
          creditMinor: toMinor(parseAmount(r.creditMajor)),
        })),
      });
      setPasteText('');
      setPreview([]);
      load();
    } catch (err: any) {
      setImportError(errMessage(err, 'Failed to import statement lines'));
    } finally {
      setImportBusy(false);
    }
  }

  async function autoMatch() {
    setAutoMatchBusy(true);
    setAutoMatchResult(null);
    try {
      const res = await api.post(`/banking/accounts/${bankAccount.id}/auto-match`, {}, { params: { companyId } });
      setAutoMatchResult(res.data);
      load();
    } catch (err: any) {
      window.alert(errMessage(err, 'Auto-match failed'));
    } finally {
      setAutoMatchBusy(false);
    }
  }

  function updateManualDraft(lineId: number, patch: Partial<{ journalEntryId: string; journalLineId: string }>) {
    setManualMatchDraft((prev) => ({
      ...prev,
      [lineId]: { journalEntryId: '', journalLineId: '', ...prev[lineId], ...patch },
    }));
  }

  async function manualMatch(lineId: number) {
    const draft = manualMatchDraft[lineId];
    if (!draft || !draft.journalEntryId || !draft.journalLineId) {
      setRowError((prev) => ({ ...prev, [lineId]: 'Enter both a journal entry ID and a journal line ID' }));
      return;
    }
    setRowBusy((prev) => ({ ...prev, [lineId]: true }));
    setRowError((prev) => ({ ...prev, [lineId]: '' }));
    try {
      await api.post(`/banking/statement-lines/${lineId}/match`, {
        journalEntryId: Number(draft.journalEntryId),
        journalLineId: Number(draft.journalLineId),
      });
      load();
    } catch (err: any) {
      setRowError((prev) => ({ ...prev, [lineId]: errMessage(err, 'Failed to match line') }));
    } finally {
      setRowBusy((prev) => ({ ...prev, [lineId]: false }));
    }
  }

  async function unmatch(lineId: number) {
    setRowBusy((prev) => ({ ...prev, [lineId]: true }));
    try {
      await api.post(`/banking/statement-lines/${lineId}/unmatch`);
      load();
    } catch (err: any) {
      window.alert(errMessage(err, 'Failed to unmatch line'));
    } finally {
      setRowBusy((prev) => ({ ...prev, [lineId]: false }));
    }
  }

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Statement Import &amp; Matching</h2>
      </div>

      <div className="card" style={{ marginBottom: 18 }}>
        <h3 style={{ marginTop: 0 }}>Bulk-paste statement lines</h3>
        <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: -6 }}>
          Paste rows of <code>date,description,debit,credit</code> (comma or tab separated — one row per line). Amounts
          are in {bankAccount.currencyCode} major units (e.g. 1500.50). A header row is detected and skipped automatically.
        </p>
        <textarea
          value={pasteText}
          onChange={(e) => setPasteText(e.target.value)}
          placeholder={'2026-01-05,Cheque deposit,,25000.00\n2026-01-06,ATM withdrawal,5000.00,'}
          rows={6}
          style={{ width: '100%', fontFamily: 'monospace' }}
        />
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <button className="btn secondary" type="button" onClick={parse} disabled={!pasteText.trim()}>
            Parse
          </button>
          <button className="btn" type="button" onClick={doImport} disabled={preview.length === 0 || importBusy}>
            {importBusy ? 'Importing…' : `Import ${preview.length} line${preview.length === 1 ? '' : 's'}`}
          </button>
        </div>
        {importError && <div style={{ color: 'var(--danger)', fontSize: 13, marginTop: 10 }}>{importError}</div>}

        {preview.length > 0 && (
          <table className="data-table" style={{ marginTop: 14 }}>
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Debit</th>
                <th>Credit</th>
              </tr>
            </thead>
            <tbody>
              {preview.map((r, idx) => (
                <tr key={idx}>
                  <td>{r.statementDate}</td>
                  <td>{r.description}</td>
                  <td>{r.debitMajor ? formatMoney(toMinor(parseAmount(r.debitMajor)), bankAccount.currencyCode) : '—'}</td>
                  <td>{r.creditMajor ? formatMoney(toMinor(parseAmount(r.creditMajor)), bankAccount.currencyCode) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card" style={{ marginBottom: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
            <input type="checkbox" checked={unmatchedOnly} onChange={(e) => setUnmatchedOnly(e.target.checked)} />
            Show unmatched only
          </label>
          <button className="btn secondary" type="button" onClick={autoMatch} disabled={autoMatchBusy}>
            {autoMatchBusy ? 'Matching…' : 'Auto-match'}
          </button>
        </div>

        {autoMatchResult && (
          <div
            className="card"
            style={{ marginTop: 12, background: 'var(--surface-2)', padding: 12, fontSize: 13 }}
          >
            Auto-match complete — checked {autoMatchResult.totalChecked}, matched {autoMatchResult.matchedCount}, still
            unmatched {autoMatchResult.unmatchedCount}.
          </div>
        )}

        <p style={{ color: 'var(--text-dim)', fontSize: 12, marginTop: 12, marginBottom: 6 }}>
          For a manual match, find the journal entry on the General Ledger page's Journal Entries tab and enter its
          entry ID and the specific line ID here.
        </p>

        <table className="data-table" style={{ marginTop: 10 }}>
          <thead>
            <tr>
              <th>Date</th>
              <th>Description</th>
              <th>Reference</th>
              <th>Debit</th>
              <th>Credit</th>
              <th>Status</th>
              <th style={{ width: 260 }}>Match</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => {
              const draft = manualMatchDraft[l.id] || { journalEntryId: '', journalLineId: '' };
              return (
                <tr key={l.id}>
                  <td>{l.statementDate}</td>
                  <td>{l.description}</td>
                  <td>{l.referenceNo || '—'}</td>
                  <td>{Number(l.debitMinor) > 0 ? formatMoney(l.debitMinor, bankAccount.currencyCode) : '—'}</td>
                  <td>{Number(l.creditMinor) > 0 ? formatMoney(l.creditMinor, bankAccount.currencyCode) : '—'}</td>
                  <td>
                    {l.isMatched ? <Pill text="Matched" color="green" /> : <Pill text="Unmatched" color="gray" />}
                  </td>
                  <td>
                    {l.isMatched ? (
                      <button className="btn secondary" type="button" onClick={() => unmatch(l.id)} disabled={rowBusy[l.id]}>
                        {rowBusy[l.id] ? 'Working…' : 'Unmatch'}
                      </button>
                    ) : (
                      <div>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <input
                            type="number"
                            placeholder="Entry ID"
                            value={draft.journalEntryId}
                            onChange={(e) => updateManualDraft(l.id, { journalEntryId: e.target.value })}
                            style={{ width: 90 }}
                          />
                          <input
                            type="number"
                            placeholder="Line ID"
                            value={draft.journalLineId}
                            onChange={(e) => updateManualDraft(l.id, { journalLineId: e.target.value })}
                            style={{ width: 90 }}
                          />
                          <button
                            className="btn secondary"
                            type="button"
                            onClick={() => manualMatch(l.id)}
                            disabled={rowBusy[l.id]}
                          >
                            {rowBusy[l.id] ? '…' : 'Match'}
                          </button>
                        </div>
                        {rowError[l.id] && (
                          <div style={{ color: 'var(--danger)', fontSize: 11, marginTop: 4 }}>{rowError[l.id]}</div>
                        )}
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
            {!loading && lines.length === 0 && (
              <tr>
                <td colSpan={7} style={{ color: 'var(--text-dim)' }}>
                  No statement lines yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 3. Reconciliation tab
// ---------------------------------------------------------------------------

function ReconciliationTab(props: { companyId: number; bankAccount: BankAccount }) {
  const { companyId, bankAccount } = props;
  const [asOfDate, setAsOfDate] = useState(today());
  const [summary, setSummary] = useState<ReconciliationSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  function load() {
    setLoading(true);
    setError('');
    api
      .get(`/banking/accounts/${bankAccount.id}/reconciliation`, { params: { companyId, asOfDate } })
      .then((res) => setSummary(res.data))
      .catch((err) => setError(errMessage(err, 'Failed to load reconciliation summary')))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bankAccount.id, companyId, asOfDate]);

  const differenceMinor = summary ? Number(summary.differenceMinor) : 0;
  const isBalanced = Math.abs(differenceMinor) < 1; // within 1 minor unit

  return (
    <div>
      <div className="page-header">
        <h2 style={{ margin: 0 }}>Reconciliation</h2>
        <div>
          <label style={{ fontSize: 11, color: 'var(--text-dim)', marginRight: 6 }}>As of</label>
          <input type="date" value={asOfDate} onChange={(e) => setAsOfDate(e.target.value)} />
        </div>
      </div>

      {error && (
        <div className="card" style={{ color: 'var(--danger)', marginBottom: 18 }}>
          {error}
        </div>
      )}

      {loading && !summary && <div className="card">Loading…</div>}

      {summary && (
        <>
          <div className="kpi-grid" style={{ marginBottom: 18 }}>
            <div className="kpi-tile">
              <div className="label">Book balance</div>
              <div className="value">{formatMoney(summary.bookBalanceMinor, bankAccount.currencyCode)}</div>
            </div>
            <div className="kpi-tile">
              <div className="label">Statement balance</div>
              <div className="value">{formatMoney(summary.statementBalanceMinor, bankAccount.currencyCode)}</div>
            </div>
            <div className="kpi-tile">
              <div className="label">Difference</div>
              <div className="value">{formatMoney(summary.differenceMinor, bankAccount.currencyCode)}</div>
              <div style={{ marginTop: 6 }}>
                {isBalanced ? <Pill text="Balanced" color="green" /> : <Pill text="Out of balance" color="red" />}
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
            <div className="card">
              <h3 style={{ marginTop: 0 }}>Unmatched statement lines</h3>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.unmatchedStatementLines.map((l) => (
                    <tr key={l.id}>
                      <td>{l.statementDate}</td>
                      <td>{l.description}</td>
                      <td>
                        {Number(l.creditMinor) > 0
                          ? formatMoney(l.creditMinor, bankAccount.currencyCode)
                          : `-${formatMoney(l.debitMinor, bankAccount.currencyCode)}`}
                      </td>
                    </tr>
                  ))}
                  {summary.unmatchedStatementLines.length === 0 && (
                    <tr>
                      <td colSpan={3} style={{ color: 'var(--text-dim)' }}>
                        None — every statement line up to this date is matched.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="card">
              <h3 style={{ marginTop: 0 }}>Unreconciled journal lines</h3>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Entry</th>
                    <th>Description</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.unreconciledJournalLines.map((l) => (
                    <tr key={l.id}>
                      <td>#{l.entryId}</td>
                      <td>{l.description || '—'}</td>
                      <td>
                        {Number(l.debitMinor) > 0
                          ? formatMoney(l.debitMinor, bankAccount.currencyCode)
                          : `-${formatMoney(l.creditMinor, bankAccount.currencyCode)}`}
                      </td>
                    </tr>
                  ))}
                  {summary.unreconciledJournalLines.length === 0 && (
                    <tr>
                      <td colSpan={3} style={{ color: 'var(--text-dim)' }}>
                        None — every journal line posted to this account is reconciled.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page root
// ---------------------------------------------------------------------------

export default function BankingPage() {
  const { company, loading: companyLoading } = useCompany();
  const [tab, setTab] = useState<TabKey>('accounts');

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [selectedBankAccountId, setSelectedBankAccountId] = useState<number | ''>('');

  const companyId = company?.id;

  useEffect(() => {
    if (!companyId) return;
    api.get('/banking/accounts', { params: { companyId } }).then((res) => {
      setBankAccounts(res.data);
      setSelectedBankAccountId((prev) => {
        if (prev && res.data.some((b: BankAccount) => b.id === prev)) return prev;
        return res.data.length > 0 ? res.data[0].id : '';
      });
    });
    api.get('/accounting/accounts', { params: { companyId } }).then((res) => setAccounts(res.data));
  }, [companyId, refreshKey]);

  if (companyLoading) {
    return <div className="card">Loading…</div>;
  }
  if (!company || !companyId) {
    return <div className="card">No company selected.</div>;
  }

  const selectedBankAccount = bankAccounts.find((b) => b.id === selectedBankAccountId) || null;

  return (
    <div>
      <div className="page-header">
        <h1>Banking</h1>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 18, flexWrap: 'wrap' }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            className={tab === t.key ? 'btn' : 'btn secondary'}
            onClick={() => setTab(t.key)}
            type="button"
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'accounts' && (
        <BankAccountsTab
          companyId={companyId}
          baseCurrency={company.baseCurrency}
          bankAccounts={bankAccounts}
          accounts={accounts}
          onChanged={() => setRefreshKey((k) => k + 1)}
          onSelect={(id) => setSelectedBankAccountId(id)}
          selectedId={selectedBankAccountId}
        />
      )}

      {tab === 'statement' && (
        <div>
          <BankAccountPicker
            bankAccounts={bankAccounts}
            selectedId={selectedBankAccountId}
            onChange={setSelectedBankAccountId}
          />
          {selectedBankAccount ? (
            <StatementTab companyId={companyId} bankAccount={selectedBankAccount} />
          ) : (
            <div className="card">Select a bank account first (see the Bank Accounts tab).</div>
          )}
        </div>
      )}

      {tab === 'reconciliation' && (
        <div>
          <BankAccountPicker
            bankAccounts={bankAccounts}
            selectedId={selectedBankAccountId}
            onChange={setSelectedBankAccountId}
          />
          {selectedBankAccount ? (
            <ReconciliationTab companyId={companyId} bankAccount={selectedBankAccount} />
          ) : (
            <div className="card">Select a bank account first (see the Bank Accounts tab).</div>
          )}
        </div>
      )}
    </div>
  );
}
