import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api } from '../lib/api';
import { useCompany } from '../context/CompanyContext';
import { money, moneyShort, num, pct, SERIES, STATUS, todayIso } from '../lib/format';

/**
 * Executive dashboard tuned for a computer-hardware parts retailer: sales &
 * margin by category/brand/SKU, PC-build business, inventory health and
 * reorder alerts, working-capital ratios (DSO/DPO/DIO), AR/AP aging, VAT
 * position and cash. All figures come from GET /reports/dashboard.
 */

const tooltipStyle = { background: '#1d2639', border: '1px solid #2a3448', borderRadius: 8, fontSize: 12 };
const axis = { stroke: '#9aa5bd', fontSize: 11 } as const;
const grid = '#2a3448';
const toMajor = (v: number) => Number(v || 0) / 100;
const shortTick = (v: number) => moneyShort(v * 100);
const moneyTip = (v: number) => money(v * 100);

const CHANNEL_LABEL: Record<string, string> = { WALK_IN: 'Walk-in / counter', B2B: 'Corporate (B2B)', RESELLER: 'Resellers' };
const PAY_LABEL: Record<string, string> = { CASH: 'Cash', CARD: 'Card', CREDIT: 'Credit', BANK_TRANSFER: 'Bank transfer', CHEQUE: 'Cheque', ON_ACCOUNT: 'On account' };
const STOCK_STATUS_COLOR: Record<string, string> = {
  OK: STATUS.good,
  Reorder: STATUS.warning,
  'Out of stock': STATUS.critical,
  'Slow / dead': '#9085e9',
  Overstock: STATUS.neutral,
};

export default function DashboardPage() {
  const { company } = useCompany();
  const [asOf, setAsOf] = useState(todayIso());
  const [d, setD] = useState<any>(null);
  const [pos, setPos] = useState<any>(null);
  const [error, setError] = useState('');
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (!company?.id) return;
    let cancelled = false;
    setError('');
    setD(null);
    api
      .get('/reports/dashboard', { params: { companyId: company.id, asOf }, timeout: 60000 })
      .then((r) => {
        if (cancelled) return;
        if (!r.data || !r.data.kpis) setError('The server returned an unexpected response for the dashboard.');
        else setD(r.data);
      })
      .catch((e) => {
        if (cancelled) return;
        const status = e?.response?.status;
        if (status === 404)
          setError(
            'OLD_BACKEND',
          );
        else if (!e?.response) setError('NO_BACKEND');
        else setError(String(e?.response?.data?.message || e?.message || 'Could not load dashboard'));
      });
    api
      .get('/pos/daily-summary', { params: { companyId: company.id, date: asOf } })
      .then((r) => !cancelled && setPos(r.data))
      .catch(() => !cancelled && setPos(null));
    return () => {
      cancelled = true;
    };
  }, [company?.id, asOf, attempt]);

  if (!company) return <p style={{ color: 'var(--text-dim)' }}>Loading company…</p>;
  if (error)
    return (
      <div className="card" style={{ maxWidth: 760, borderColor: 'var(--danger)' }}>
        <h3 style={{ marginTop: 0 }}>The dashboard could not be loaded</h3>
        {error === 'OLD_BACKEND' ? (
          <p style={{ fontSize: 13, lineHeight: 1.6 }}>
            The backend that is running is an <b>older version</b> without the new reports API. Close the black <b>Kruxus ERP - Backend</b> and{' '}
            <b>Frontend</b> windows, then double-click <b>start_kruxus.bat</b> again.
          </p>
        ) : error === 'NO_BACKEND' ? (
          <p style={{ fontSize: 13, lineHeight: 1.6 }}>
            The backend is not reachable. Check that the <b>Kruxus ERP - Backend</b> window is open and shows "backend listening on :3001" (or
            run <b>start_kruxus.bat</b> again).
          </p>
        ) : (
          <p style={{ fontSize: 13 }}>{error}</p>
        )}
        <button className="btn" onClick={() => setAttempt((a) => a + 1)}>
          Try again
        </button>
      </div>
    );
  if (!d) return <p style={{ color: 'var(--text-dim)' }}>Loading dashboard…</p>;
  const k = d.kpis;
  const ccc = k.dso != null && k.dio != null && k.dpo != null ? k.dso + k.dio - k.dpo : null;

  const daily = d.daily.map((x: any) => ({ ...x, label: x.date.slice(5), sales: toMajor(x.sales), grossProfit: toMajor(x.grossProfit) }));
  const monthly = d.monthly
    .filter((m: any) => m.revenue || m.netProfit)
    .map((m: any) => ({ ...m, revenue: toMajor(m.revenue), grossProfit: toMajor(m.grossProfit), netProfit: toMajor(m.netProfit) }));
  const cat = d.byCategory.map((c: any) => ({ ...c, netM: toMajor(c.net), gpM: toMajor(c.grossProfit) }));
  const brands = d.byBrand.map((b: any) => ({ ...b, netM: toMajor(b.net) }));
  const channel = d.byChannel.map((c: any) => ({ name: CHANNEL_LABEL[c.name] || c.name, value: toMajor(c.net) }));
  const payment = d.byPayment.map((p: any) => ({ name: PAY_LABEL[p.name] || p.name, value: toMajor(p.value) })).sort((a: any, b: any) => b.value - a.value);
  const weekday = d.byWeekday.map((w: any) => ({ ...w, netM: toMajor(w.net) }));
  const stockCat = d.stockByCategory.map((s: any) => ({ ...s, valueM: toMajor(s.value) }));
  const arAging = d.arAging.map((a: any) => ({ ...a, v: toMajor(a.value) }));
  const apAging = d.apAging.map((a: any) => ({ ...a, v: toMajor(a.value) }));
  const expenses = d.expenses.slice(0, 8).map((e: any) => ({ ...e, v: toMajor(e.value) }));

  return (
    <div className="dash">
      <style>{DASH_CSS}</style>
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p style={{ color: 'var(--text-dim)', fontSize: 13, margin: '4px 0 0 0' }}>
            {company.name}
            {(company as any).tradingName ? ` · ${(company as any).tradingName}` : ''} · as at {d.asOf} · fiscal year from {d.periods.fyStart}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <label style={{ fontSize: 12, color: 'var(--text-dim)' }}>
            As at <input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value || todayIso())} />
          </label>
          <Link className="btn secondary" to="/reports" style={{ textDecoration: 'none' }}>
            All reports
          </Link>
        </div>
      </div>

      {/* ---------------- Headline KPIs */}
      <div className="dash-kpis">
        <Kpi
          label="Sales this month"
          value={money(k.salesMtd, { whole: true })}
          delta={k.salesGrowthPct}
          note={`vs ${money(k.salesLastMonthToDate, { whole: true })} same days last month`}
          to="/reports/sales-monthly-trend"
        />
        <Kpi label="Gross profit MTD" value={money(k.grossProfitMtd, { whole: true })} note={`${pct(k.grossMarginMtdPct)} margin · 30d ${pct(k.grossMargin30Pct)}`} to="/reports/sales-by-category" />
        <Kpi
          label="Net profit MTD"
          value={money(k.netProfitMtd, { whole: true })}
          tone={k.netProfitMtd >= 0 ? 'pos' : 'neg'}
          note={`YTD ${money(k.netProfitYtd, { whole: true })} on ${moneyShort(k.revenueYtd)} revenue`}
          to="/reports/fs-profit-loss"
        />
        <Kpi label="Cash & bank" value={money(k.cash, { whole: true })} note={k.cashRunwayMonths != null ? `${k.cashRunwayMonths} months of opex cover` : ''} to="/reports/fs-cash-flow" />
        <Kpi label="Receivables" value={money(k.receivables, { whole: true })} note={`DSO ${k.dso ?? '–'} days`} to="/reports/ar-aging-summary" />
        <Kpi label="Payables" value={money(k.payables, { whole: true })} note={`DPO ${k.dpo ?? '–'} days`} to="/reports/ap-aging-summary" />
        <Kpi label="Inventory value" value={money(k.inventoryValue, { whole: true })} note={`DIO ${k.dio ?? '–'} days · ${k.inventoryTurnsAnnualised ?? '–'}× turns/yr`} to="/reports/inv-valuation" />
        <Kpi
          label={k.vatPayable >= 0 ? 'VAT payable (net)' : 'VAT receivable (net)'}
          value={money(Math.abs(k.vatPayable), { whole: true })}
          note={`MTD output ${moneyShort(d.vat.mtd.outputVat)} · input ${moneyShort(d.vat.mtd.inputVat)}`}
          to="/reports/vat-return"
        />
      </div>

      <div className="dash-strip">
        <Mini label="Invoices (30d)" value={num(k.invoices30)} />
        <Mini label="Avg invoice (30d)" value={money(k.avgInvoice30, { whole: true })} />
        <Mini label="Units sold (30d)" value={num(k.units30)} />
        <Mini label="PC builds (90d)" value={`${k.pcBuilds90} · ${moneyShort(k.pcBuildRevenue90)}`} />
        <Mini label="Active B2B customers (90d)" value={num(k.activeCustomers90)} />
        <Mini label="SKUs / to reorder" value={`${k.skuCount} / ${k.skusToReorder}`} tone={k.skusToReorder ? 'warn' : undefined} />
        <Mini label="Current ratio" value={k.currentRatio ?? '–'} />
        <Mini label="Quick ratio" value={k.quickRatio ?? '–'} />
        <Mini label="Working capital" value={moneyShort(k.workingCapital)} />
        <Mini label="Cash conversion cycle" value={ccc != null ? `${ccc} days` : '–'} />
      </div>

      {/* ---------------- Sales trend */}
      <div className="dash-grid g-2-1">
        <Card title="Daily sales & gross profit - last 60 days" link="/reports/sales-detail">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={daily}>
              <CartesianGrid stroke={grid} vertical={false} />
              <XAxis dataKey="label" {...axis} interval={6} />
              <YAxis {...axis} tickFormatter={shortTick} width={60} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number, n: string) => [moneyTip(v), n]} labelFormatter={(l) => `Date ${l}`} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area type="monotone" dataKey="sales" name="Net sales" stroke={SERIES[0]} fill={SERIES[0]} fillOpacity={0.18} strokeWidth={2} />
              <Area type="monotone" dataKey="grossProfit" name="Gross profit" stroke={SERIES[2]} fill={SERIES[2]} fillOpacity={0.18} strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Monthly P&L" link="/reports/fs-profit-loss-monthly">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={monthly} barGap={2}>
              <CartesianGrid stroke={grid} vertical={false} />
              <XAxis dataKey="month" {...axis} />
              <YAxis {...axis} tickFormatter={shortTick} width={60} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number, n: string) => [moneyTip(v), n]} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="revenue" name="Revenue" fill={SERIES[0]} radius={[4, 4, 0, 0]} maxBarSize={26} />
              <Bar dataKey="grossProfit" name="Gross profit" fill={SERIES[2]} radius={[4, 4, 0, 0]} maxBarSize={26} />
              <Bar dataKey="netProfit" name="Net profit" fill={SERIES[3]} radius={[4, 4, 0, 0]} maxBarSize={26} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* ---------------- Category / brand */}
      <div className="dash-grid g-1-1">
        <Card title="Sales by product category - last 90 days" link="/reports/sales-by-category">
          <ResponsiveContainer width="100%" height={Math.max(240, cat.length * 26 + 30)}>
            <BarChart data={cat} layout="vertical" barGap={2}>
              <CartesianGrid stroke={grid} horizontal={false} />
              <XAxis type="number" {...axis} tickFormatter={shortTick} />
              <YAxis type="category" dataKey="name" {...axis} width={170} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number, n: string) => [moneyTip(v), n]} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="netM" name="Net sales" fill={SERIES[0]} radius={[0, 4, 4, 0]} maxBarSize={14} />
              <Bar dataKey="gpM" name="Gross profit" fill={SERIES[2]} radius={[0, 4, 4, 0]} maxBarSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Category margin league" link="/reports/sales-by-category">
          <table className="data-table dash-table">
            <thead>
              <tr>
                <th>Category</th>
                <th className="num">Units</th>
                <th className="num">Net sales</th>
                <th className="num">GP</th>
                <th className="num">Margin</th>
              </tr>
            </thead>
            <tbody>
              {d.byCategory.map((c: any) => (
                <tr key={c.name}>
                  <td>{c.name}</td>
                  <td className="num">{num(c.quantity)}</td>
                  <td className="num">{money(c.net, { whole: true })}</td>
                  <td className="num">{money(c.grossProfit, { whole: true })}</td>
                  <td className="num">
                    <MarginBar v={c.marginPct} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <div className="dash-grid g-1-1-1">
        <Card title="Top 10 SKUs - last 90 days" link="/reports/sales-by-item">
          <table className="data-table dash-table">
            <thead>
              <tr>
                <th>Item</th>
                <th className="num">Units</th>
                <th className="num">Sales</th>
                <th className="num">Margin</th>
              </tr>
            </thead>
            <tbody>
              {d.topSkus.map((s: any) => (
                <tr key={s.name}>
                  <td title={s.name} className="ellip">{s.name}</td>
                  <td className="num">{num(s.quantity)}</td>
                  <td className="num">{moneyShort(s.net)}</td>
                  <td className="num">{pct(s.marginPct)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
        <Card title="Revenue by brand - last 90 days" link="/reports/sales-by-brand">
          <ResponsiveContainer width="100%" height={Math.max(240, brands.length * 22 + 30)}>
            <BarChart data={brands} layout="vertical">
              <CartesianGrid stroke={grid} horizontal={false} />
              <XAxis type="number" {...axis} tickFormatter={shortTick} />
              <YAxis type="category" dataKey="name" {...axis} width={110} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [moneyTip(v), 'Net sales']} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
              <Bar dataKey="netM" fill={SERIES[0]} radius={[0, 4, 4, 0]} maxBarSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Top customers - last 90 days" link="/reports/sales-by-customer">
          <table className="data-table dash-table">
            <thead>
              <tr>
                <th>Customer</th>
                <th className="num">Sales</th>
                <th className="num">Margin</th>
              </tr>
            </thead>
            <tbody>
              {d.topCustomers.map((c: any) => (
                <tr key={c.name}>
                  <td className="ellip" title={c.name}>{c.name}</td>
                  <td className="num">{moneyShort(c.net)}</td>
                  <td className="num">{pct(c.marginPct)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      {/* ---------------- Channels */}
      <div className="dash-grid g-1-1-1-1">
        <Card title="Sales channel mix (90d)" link="/reports/sales-by-channel">
          <Donut data={channel} />
        </Card>
        <Card title="Payment mode mix (90d)" link="/reports/sales-by-channel">
          <Donut data={payment} />
        </Card>
        <Card title="Sales by weekday (90d)" link="/reports/sales-weekday">
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={weekday}>
              <CartesianGrid stroke={grid} vertical={false} />
              <XAxis dataKey="name" {...axis} />
              <YAxis {...axis} tickFormatter={shortTick} width={50} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [moneyTip(v), 'Net sales']} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
              <Bar dataKey="netM" fill={SERIES[0]} radius={[4, 4, 0, 0]} maxBarSize={26} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="Sales team (90d)" link="/reports/sales-by-salesperson">
          <table className="data-table dash-table">
            <thead>
              <tr>
                <th>Salesperson</th>
                <th className="num">Sales</th>
                <th className="num">Margin</th>
              </tr>
            </thead>
            <tbody>
              {d.bySalesPerson.map((s: any) => (
                <tr key={s.name}>
                  <td>{s.name}</td>
                  <td className="num">{moneyShort(s.net)}</td>
                  <td className="num">{pct(s.marginPct)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {pos && (
            <div style={{ marginTop: 10, fontSize: 12, color: 'var(--text-dim)' }}>
              POS today: <b style={{ color: 'var(--text)' }}>{pos.count ?? pos.salesCount ?? 0}</b> sales ·{' '}
              <b style={{ color: 'var(--text)' }}>{money(pos.totalMinor ?? pos.totalValueMinor ?? 0)}</b>
            </div>
          )}
        </Card>
      </div>

      {/* ---------------- Inventory health */}
      <div className="dash-section">Inventory health</div>
      <div className="dash-stock-status">
        {d.stockStatus.map((s: any) => (
          <Link key={s.name} to={s.name === 'Reorder' || s.name === 'Out of stock' ? '/reports/inv-reorder' : s.name === 'OK' ? '/reports/inv-valuation' : '/reports/inv-slow-moving'} className="dash-status">
            <span className="dot" style={{ background: STOCK_STATUS_COLOR[s.name] }} />
            <div>
              <div className="label">{s.name}</div>
              <div className="v">
                {s.count} SKUs · {moneyShort(s.value)}
              </div>
            </div>
          </Link>
        ))}
      </div>
      <div className="dash-grid g-1-1">
        <Card title="Reorder alerts" link="/reports/inv-reorder" linkLabel="Replenishment report →">
          {d.reorderList.length === 0 ? (
            <p className="dim">Nothing below reorder level. </p>
          ) : (
            <table className="data-table dash-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th className="num">On hand</th>
                  <th className="num">Reorder lvl</th>
                  <th className="num">Sold 30d</th>
                  <th className="num">Suggest</th>
                  <th>Supplier</th>
                </tr>
              </thead>
              <tbody>
                {d.reorderList.map((r: any) => (
                  <tr key={r.sku}>
                    <td className="ellip" title={r.itemName}>
                      <StatusDot status={r.status} /> {r.itemName}
                    </td>
                    <td className="num">{num(r.onHand)}</td>
                    <td className="num">{num(r.reorderLevel)}</td>
                    <td className="num">{num(r.soldLast30)}</td>
                    <td className="num">{num(r.suggestedOrderQty)}</td>
                    <td className="ellip" title={r.preferredSupplier}>{r.preferredSupplier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
        <Card title="Stock value by category" link="/reports/inv-valuation-category">
          <ResponsiveContainer width="100%" height={Math.max(240, stockCat.length * 24 + 30)}>
            <BarChart data={stockCat} layout="vertical">
              <CartesianGrid stroke={grid} horizontal={false} />
              <XAxis type="number" {...axis} tickFormatter={shortTick} />
              <YAxis type="category" dataKey="name" {...axis} width={170} />
              <Tooltip
                contentStyle={tooltipStyle}
                formatter={(v: number, _n: string, p: any) => [`${moneyTip(v)} · ${num(p.payload.units)} units · ${p.payload.skus} SKUs`, 'Stock value']}
                cursor={{ fill: 'rgba(255,255,255,.04)' }}
              />
              <Bar dataKey="valueM" fill={SERIES[6]} radius={[0, 4, 4, 0]} maxBarSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
      {d.slowMovers.length > 0 && (
        <Card title="Slow-moving & overstocked items (tied-up cash)" link="/reports/inv-slow-moving">
          <table className="data-table dash-table">
            <thead>
              <tr>
                <th>Item</th>
                <th>Category</th>
                <th className="num">On hand</th>
                <th className="num">Stock value</th>
                <th>Last sale</th>
                <th className="num">Days cover</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {d.slowMovers.map((r: any) => (
                <tr key={r.sku}>
                  <td>{r.itemName}</td>
                  <td>{r.category}</td>
                  <td className="num">{num(r.onHand)}</td>
                  <td className="num">{money(r.stockValue, { whole: true })}</td>
                  <td>{r.lastSaleDate || 'never'}</td>
                  <td className="num">{r.daysOfCover >= 999 ? '∞' : r.daysOfCover}</td>
                  <td>
                    <StatusDot status={r.status} /> {r.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {/* ---------------- Receivables / payables */}
      <div className="dash-section">Receivables, payables & cash</div>
      <div className="dash-grid g-1-1">
        <Card title={`Receivables aging · ${money(k.receivables, { whole: true })}`} link="/reports/ar-aging-summary">
          <AgingBars data={arAging} color={SERIES[0]} />
          <table className="data-table dash-table" style={{ marginTop: 8 }}>
            <thead>
              <tr>
                <th>Overdue invoice</th>
                <th>Customer</th>
                <th className="num">Days</th>
                <th className="num">Balance</th>
              </tr>
            </thead>
            <tbody>
              {d.overdueInvoices.map((i: any) => (
                <tr key={i.id}>
                  <td>
                    <a href={`/print/invoice/${i.id}`} target="_blank" rel="noreferrer" style={{ color: 'var(--accent)' }}>
                      {i.invoiceNumber}
                    </a>
                  </td>
                  <td className="ellip" title={i.customerName}>{i.customerName}</td>
                  <td className="num" style={{ color: i.daysOverdue > 60 ? 'var(--danger)' : i.daysOverdue > 30 ? 'var(--warn)' : undefined }}>
                    {i.daysOverdue}
                  </td>
                  <td className="num">{money(i.balance, { whole: true })}</td>
                </tr>
              ))}
              {d.overdueInvoices.length === 0 && (
                <tr>
                  <td colSpan={4} className="dim">No overdue invoices.</td>
                </tr>
              )}
            </tbody>
          </table>
        </Card>
        <Card title={`Payables aging · ${money(k.payables, { whole: true })}`} link="/reports/ap-aging-summary">
          <AgingBars data={apAging} color={SERIES[1]} />
          <table className="data-table dash-table" style={{ marginTop: 8 }}>
            <thead>
              <tr>
                <th>Due in next 14 days</th>
                <th>Supplier</th>
                <th>Due</th>
                <th className="num">Amount</th>
              </tr>
            </thead>
            <tbody>
              {d.upcomingPayments.map((b: any) => (
                <tr key={b.billNumber}>
                  <td>{b.billNumber}</td>
                  <td className="ellip" title={b.supplierName}>{b.supplierName}</td>
                  <td style={{ color: b.dueInDays < 0 ? 'var(--danger)' : undefined }}>
                    {b.dueInDays < 0 ? `${-b.dueInDays}d overdue` : b.dueInDays === 0 ? 'today' : `in ${b.dueInDays}d`}
                  </td>
                  <td className="num">{money(b.balance, { whole: true })}</td>
                </tr>
              ))}
              {d.upcomingPayments.length === 0 && (
                <tr>
                  <td colSpan={4} className="dim">Nothing due in the next 14 days.</td>
                </tr>
              )}
            </tbody>
          </table>
        </Card>
      </div>

      <div className="dash-grid g-1-1-1">
        <Card title="Operating expenses - last 90 days" link="/reports/fs-expense-analysis">
          <ResponsiveContainer width="100%" height={Math.max(220, expenses.length * 24 + 30)}>
            <BarChart data={expenses} layout="vertical">
              <CartesianGrid stroke={grid} horizontal={false} />
              <XAxis type="number" {...axis} tickFormatter={shortTick} />
              <YAxis type="category" dataKey="name" {...axis} width={150} />
              <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [moneyTip(v), 'Expense']} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
              <Bar dataKey="v" fill={SERIES[1]} radius={[0, 4, 4, 0]} maxBarSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="VAT position" link="/reports/vat-return">
          <table className="data-table dash-table">
            <thead>
              <tr>
                <th></th>
                <th className="num">This month</th>
                <th className="num">Last month</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Taxable supplies</td>
                <td className="num">{moneyShort(d.vat.mtd.taxableSupplies)}</td>
                <td className="num">{moneyShort(d.vat.lastMonth.taxableSupplies)}</td>
              </tr>
              <tr>
                <td>Output VAT</td>
                <td className="num">{money(d.vat.mtd.outputVat, { whole: true })}</td>
                <td className="num">{money(d.vat.lastMonth.outputVat, { whole: true })}</td>
              </tr>
              <tr>
                <td>Input VAT</td>
                <td className="num">{money(d.vat.mtd.inputVat, { whole: true })}</td>
                <td className="num">{money(d.vat.lastMonth.inputVat, { whole: true })}</td>
              </tr>
              <tr style={{ fontWeight: 700 }}>
                <td>Net payable / (refundable)</td>
                <td className="num">{money(d.vat.mtd.netVatPayable, { whole: true, brackets: true })}</td>
                <td className="num">{money(d.vat.lastMonth.netVatPayable, { whole: true, brackets: true })}</td>
              </tr>
              <tr>
                <td>Tax invoices issued</td>
                <td className="num">{d.vat.mtd.invoiceCount}</td>
                <td className="num">{d.vat.lastMonth.invoiceCount}</td>
              </tr>
            </tbody>
          </table>
          <p className="dim" style={{ fontSize: 11.5, marginBottom: 0 }}>
            VAT return for last month is due by the 20th. Open <Link to="/reports/vat-return" style={{ color: 'var(--accent)' }}>VAT return workings</Link> for
            the output / input schedules.
          </p>
        </Card>
        <Card title="Recent invoices" link="/reports/sales-invoice-register">
          <table className="data-table dash-table">
            <tbody>
              {d.recentInvoices.map((i: any) => (
                <tr key={i.id}>
                  <td>
                    <a href={`/print/invoice/${i.id}`} target="_blank" rel="noreferrer" style={{ color: 'var(--accent)' }} title="Print tax invoice">
                      {i.invoiceNumber}
                    </a>
                    <div className="dim" style={{ fontSize: 11 }}>{i.invoiceDate}</div>
                  </td>
                  <td className="ellip" title={i.customerName}>{i.customerName}</td>
                  <td className="num">{money(i.total, { whole: true })}</td>
                  <td>
                    <span className={'pill ' + (i.status === 'PAID' ? 'green' : i.status === 'PARTIALLY_PAID' ? 'amber' : 'gray')}>
                      {i.status.replace('_', ' ').toLowerCase()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- pieces
function Kpi({ label, value, note, delta, tone, to }: { label: string; value: string; note?: string; delta?: number | null; tone?: 'pos' | 'neg'; to?: string }) {
  const body = (
    <>
      <div className="label">{label}</div>
      <div className={'value' + (tone ? ` delta ${tone}` : '')}>{value}</div>
      <div className="note">
        {delta != null && (
          <span style={{ color: delta >= 0 ? 'var(--accent-2)' : 'var(--danger)', fontWeight: 700, marginRight: 6 }}>
            {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(1)}%
          </span>
        )}
        {note}
      </div>
    </>
  );
  return to ? (
    <Link to={to} className="kpi-tile dash-kpi">
      {body}
    </Link>
  ) : (
    <div className="kpi-tile dash-kpi">{body}</div>
  );
}

function Mini({ label, value, tone }: { label: string; value: React.ReactNode; tone?: 'warn' }) {
  return (
    <div className="dash-mini">
      <div className="label">{label}</div>
      <div className="v" style={tone === 'warn' ? { color: 'var(--warn)' } : undefined}>{value}</div>
    </div>
  );
}

function Card({ title, link, linkLabel, children }: { title: string; link?: string; linkLabel?: string; children: React.ReactNode }) {
  return (
    <div className="card dash-card">
      <div className="dash-card-head">
        <h3>{title}</h3>
        {link && (
          <Link to={link} className="dash-link">
            {linkLabel || 'Report →'}
          </Link>
        )}
      </div>
      {children}
    </div>
  );
}

function Donut({ data }: { data: { name: string; value: number }[] }) {
  const total = data.reduce((s, x) => s + x.value, 0);
  return (
    <div>
      <ResponsiveContainer width="100%" height={170}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" innerRadius={48} outerRadius={75} paddingAngle={2} stroke="#161d2e" strokeWidth={2}>
            {data.map((_, i) => (
              <Cell key={i} fill={SERIES[i % SERIES.length]} />
            ))}
          </Pie>
          <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => moneyTip(v)} />
        </PieChart>
      </ResponsiveContainer>
      <div className="dash-legend">
        {data.map((x, i) => (
          <div key={x.name}>
            <span className="sw" style={{ background: SERIES[i % SERIES.length] }} />
            {x.name}
            <span className="dim" style={{ marginLeft: 'auto' }}>{total ? ((x.value / total) * 100).toFixed(0) : 0}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AgingBars({ data, color }: { data: { bucket: string; v: number }[]; color: string }) {
  return (
    <ResponsiveContainer width="100%" height={170}>
      <BarChart data={data}>
        <CartesianGrid stroke={grid} vertical={false} />
        <XAxis dataKey="bucket" {...axis} />
        <YAxis {...axis} tickFormatter={shortTick} width={55} />
        <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => [moneyTip(v), 'Outstanding']} cursor={{ fill: 'rgba(255,255,255,.04)' }} />
        <Bar dataKey="v" fill={color} radius={[4, 4, 0, 0]} maxBarSize={40} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function MarginBar({ v }: { v: number }) {
  const w = Math.max(0, Math.min(100, (v / 30) * 100));
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span style={{ width: 50, height: 6, background: 'var(--surface-2)', borderRadius: 3, display: 'inline-block', overflow: 'hidden' }}>
        <span style={{ display: 'block', height: '100%', width: `${w}%`, background: SERIES[2], borderRadius: 3 }} />
      </span>
      {pct(v)}
    </span>
  );
}

function StatusDot({ status }: { status: string }) {
  return <span title={status} style={{ display: 'inline-block', width: 8, height: 8, borderRadius: 99, background: STOCK_STATUS_COLOR[status] || STATUS.neutral, marginRight: 4 }} />;
}

const DASH_CSS = `
.dash .dim { color: var(--text-dim); }
.dash-kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
.dash-kpi { text-decoration: none; color: inherit; display: block; transition: border-color .15s; }
.dash-kpi:hover { border-color: var(--accent); }
.dash-kpi .value { font-size: 22px; }
.dash-kpi .note { font-size: 11.5px; color: var(--text-dim); margin-top: 4px; min-height: 15px; }
.dash-strip { display: grid; grid-template-columns: repeat(5, 1fr); gap: 0; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; margin-bottom: 16px; }
.dash-mini { padding: 10px 14px; border-right: 1px solid var(--border); border-bottom: 1px solid var(--border); }
.dash-mini:nth-child(5n) { border-right: 0; }
.dash-mini:nth-last-child(-n+5) { border-bottom: 0; }
.dash-mini .label { font-size: 10.5px; color: var(--text-dim); text-transform: uppercase; letter-spacing: .04em; }
.dash-mini .v { font-size: 15px; font-weight: 700; margin-top: 3px; font-variant-numeric: tabular-nums; }
.dash-grid { display: grid; gap: 14px; margin-bottom: 14px; }
.dash-grid.g-2-1 { grid-template-columns: 2fr 1fr; }
.dash-grid.g-1-1 { grid-template-columns: 1fr 1fr; }
.dash-grid.g-1-1-1 { grid-template-columns: repeat(3, 1fr); }
.dash-grid.g-1-1-1-1 { grid-template-columns: repeat(4, 1fr); }
@media (max-width: 1300px) { .dash-grid.g-1-1-1-1 { grid-template-columns: 1fr 1fr; } .dash-grid.g-1-1-1 { grid-template-columns: 1fr 1fr; } }
@media (max-width: 1100px) { .dash-kpis { grid-template-columns: 1fr 1fr; } .dash-strip { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 1000px) { .dash-grid.g-2-1, .dash-grid.g-1-1, .dash-grid.g-1-1-1, .dash-grid.g-1-1-1-1 { grid-template-columns: 1fr; } }
.dash-card { min-width: 0; margin-bottom: 0; }
.dash-card + .dash-card { margin-top: 0; }
.dash > .dash-card { margin-bottom: 14px; }
.dash-card-head { display: flex; justify-content: space-between; align-items: baseline; gap: 10px; margin-bottom: 8px; }
.dash-card-head h3 { margin: 0; font-size: 14px; }
.dash-link { font-size: 12px; color: var(--accent); text-decoration: none; white-space: nowrap; }
.dash-table { font-size: 12px; }
.dash-table td, .dash-table th { padding: 5px 6px; }
.dash-table .num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.dash-table a { white-space: nowrap; }
.dash-table .ellip { max-width: 190px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dash-section { font-size: 12px; text-transform: uppercase; letter-spacing: .08em; color: var(--text-dim); margin: 22px 0 10px; font-weight: 700; }
.dash-stock-status { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 10px; margin-bottom: 14px; }
.dash-status { display: flex; gap: 10px; align-items: center; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 10px 14px; text-decoration: none; color: inherit; }
.dash-status:hover { border-color: var(--accent); }
.dash-status .dot { width: 10px; height: 10px; border-radius: 99px; flex-shrink: 0; }
.dash-status .label { font-size: 11px; color: var(--text-dim); text-transform: uppercase; }
.dash-status .v { font-weight: 700; font-size: 13.5px; }
.dash-legend { display: flex; flex-direction: column; gap: 4px; font-size: 12px; }
.dash-legend > div { display: flex; align-items: center; gap: 6px; }
.dash-legend .sw { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }
`;
