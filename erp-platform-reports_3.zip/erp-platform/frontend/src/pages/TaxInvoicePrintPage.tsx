import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../lib/api';
import { amountInWords, money, usDate } from '../lib/format';
import { downloadTaxInvoicePdf, InvoiceView } from '../lib/invoicePdf';

/**
 * Printable Sri Lanka VAT tax invoice (A4). Layout follows the standardised
 * tax-invoice particulars: "TAX INVOICE" title, supplier TIN / VAT number,
 * purchaser TIN, invoice date and date of supply (MM/DD/YYYY), place of
 * supply, mode of payment, per-line value excl. VAT / VAT rate / VAT amount,
 * totals and total consideration in words. Opened in its own tab from the
 * invoice list, POS receipt and invoice reports.
 */

const PAYMENT_MODES: Record<string, string> = {
  CASH: 'Cash',
  CARD: 'Credit / debit card',
  CHEQUE: 'Cheque',
  BANK_TRANSFER: 'Bank transfer',
  CREDIT: 'On credit',
  ON_ACCOUNT: 'On account (credit)',
  ONLINE: 'Online payment',
};

type DocType = 'TAX INVOICE' | 'SIMPLIFIED TAX INVOICE' | 'INVOICE';

export default function TaxInvoicePrintPage() {
  const { id } = useParams();
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState('');
  const [docType, setDocType] = useState<DocType>('TAX INVOICE');
  const [copyLabel, setCopyLabel] = useState('');
  const [whole, setWhole] = useState(false);
  const [showWarranty, setShowWarranty] = useState(true);
  const [placeOfSupply, setPlaceOfSupply] = useState('');
  const [paymentMode, setPaymentMode] = useState('');
  const [purchaserTin, setPurchaserTin] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api
      .get(`/reports/invoice-print/${id}`)
      .then((r) => {
        setData(r.data);
        const inv = r.data.invoice;
        setPlaceOfSupply(inv.placeOfSupply || r.data.company.addressLine || '');
        const pm = inv.paymentMode || (Number(inv.amountReceivedMinor) >= Number(inv.totalMinor) ? 'CASH' : 'CREDIT');
        setPaymentMode(PAYMENT_MODES[pm] || pm);
        setPurchaserTin(r.data.customer?.tin || '');
        document.title = `${inv.invoiceNumber} - Tax Invoice`;
      })
      .catch((e) => setError(e?.response?.data?.message || 'Could not load invoice'));
  }, [id]);

  const view: InvoiceView | null = useMemo(() => {
    if (!data) return null;
    const { invoice: inv, company: co, customer: cu, lines } = data;
    const r = (v: number) => (whole ? Math.round(v / 100) * 100 : v);
    const ls = lines.map((l: any) => {
      const net = r(l.netMinor);
      const vat = r(l.vatMinor + (l.otherTaxMinor || 0));
      return { ...l, unitPriceMinor: r(l.unitPriceMinor), netMinor: net, vatMinor: vat, grossMinor: net + vat };
    });
    const net = ls.reduce((s: number, l: any) => s + l.netMinor, 0);
    const vat = ls.reduce((s: number, l: any) => s + l.vatMinor, 0);
    const received = r(Number(inv.amountReceivedMinor || 0));
    return {
      docTitle: docType,
      copyLabel: copyLabel || undefined,
      invoiceNumber: inv.invoiceNumber,
      invoiceDate: inv.invoiceDate,
      supplyDate: inv.deliveryDate || inv.invoiceDate,
      dueDate: inv.dueDate,
      currency: inv.currencyCode || co.baseCurrency,
      supplier: {
        name: co.name,
        tradingName: co.tradingName,
        address: co.addressLine || '',
        tin: co.tin || (co.taxRegistrationNo || '').split('-')[0],
        vatNo: co.vatRegistrationNo || co.taxRegistrationNo || '',
        phone: co.phone,
        email: co.email,
      },
      purchaser: {
        name: cu?.name || '',
        address: cu?.address || '',
        tin: purchaserTin,
        vatNo: cu?.vatRegistrationNo || '',
        phone: cu?.phone || '',
      },
      placeOfSupply,
      paymentMode,
      salesPerson: inv.salesPerson,
      reference: [inv.soId ? `SO #${inv.soId}` : '', inv.dnId ? `DN #${inv.dnId}` : ''].filter(Boolean).join(' / ') || undefined,
      lines: ls,
      totals: { net, vat, gross: net + vat, received: Math.min(received, net + vat), balance: Math.max(0, net + vat - received) },
      whole,
      showWarranty,
      bankDetails: co.bankDetails,
      footer: co.invoiceFooter,
    };
  }, [data, docType, copyLabel, whole, showWarranty, placeOfSupply, paymentMode, purchaserTin]);

  if (error) return <div style={{ padding: 40, color: '#b00' }}>{error}</div>;
  if (!view) return <div style={{ padding: 40 }}>Loading invoice…</div>;
  const isDraft = data.invoice.status === 'DRAFT';
  const fm = (v: number) => money(v, { whole });

  return (
    <div className="invoice-print-root">
      <style>{PRINT_CSS}</style>
      <div className="inv-toolbar no-print">
        <strong style={{ marginRight: 8 }}>{view.invoiceNumber}</strong>
        <label>
          Document
          <select value={docType} onChange={(e) => setDocType(e.target.value as DocType)}>
            <option>TAX INVOICE</option>
            <option>SIMPLIFIED TAX INVOICE</option>
            <option>INVOICE</option>
          </select>
        </label>
        <label>
          Copy
          <select value={copyLabel} onChange={(e) => setCopyLabel(e.target.value)}>
            <option value="">Original</option>
            <option value="DUPLICATE">Duplicate</option>
            <option value="CUSTOMER COPY">Customer copy</option>
            <option value="OFFICE COPY">Office copy</option>
          </select>
        </label>
        <label>
          Place of supply
          <input value={placeOfSupply} onChange={(e) => setPlaceOfSupply(e.target.value)} style={{ width: 220 }} />
        </label>
        <label>
          Mode of payment
          <input value={paymentMode} onChange={(e) => setPaymentMode(e.target.value)} list="pay-modes" style={{ width: 140 }} />
          <datalist id="pay-modes">
            {Object.values(PAYMENT_MODES).map((p) => (
              <option key={p} value={p} />
            ))}
          </datalist>
        </label>
        <label>
          Purchaser TIN
          <input value={purchaserTin} onChange={(e) => setPurchaserTin(e.target.value)} style={{ width: 110 }} placeholder="9 digits" />
        </label>
        <label className="chk">
          <input type="checkbox" checked={whole} onChange={(e) => setWhole(e.target.checked)} /> Whole rupees
        </label>
        <label className="chk">
          <input type="checkbox" checked={showWarranty} onChange={(e) => setShowWarranty(e.target.checked)} /> Warranty
        </label>
        <span style={{ flex: 1 }} />
        <button onClick={() => window.print()}>Print</button>
        <button
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            try {
              await downloadTaxInvoicePdf(view);
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? 'Building…' : 'Download PDF'}
        </button>
      </div>
      {isDraft && <div className="no-print inv-warn">This invoice is still a DRAFT - post it before issuing it as a tax invoice.</div>}
      {docType === 'TAX INVOICE' && !purchaserTin && (
        <div className="no-print inv-note">
          The purchaser has no TIN on file. That is fine for non-registered buyers; enter the TIN above if the purchaser is VAT registered.
        </div>
      )}

      <div className="inv-page">
        {isDraft && <div className="inv-watermark">DRAFT</div>}
        <header className="inv-head">
          <div>
            <div className="inv-co">{view.supplier.name}</div>
            {view.supplier.tradingName && <div className="inv-sub">{view.supplier.tradingName}</div>}
            <div className="inv-sub">{view.supplier.address}</div>
            <div className="inv-sub">
              {[view.supplier.phone && `Tel: ${view.supplier.phone}`, view.supplier.email].filter(Boolean).join(' · ')}
            </div>
            <div className="inv-tin">
              Supplier TIN: <b>{view.supplier.tin || '-'}</b> &nbsp;·&nbsp; VAT Reg. No: <b>{view.supplier.vatNo || '-'}</b>
            </div>
          </div>
          <div className="inv-titlebox">
            <div className="inv-title">{view.docTitle}</div>
            {view.copyLabel && <div className="inv-copy">{view.copyLabel}</div>}
            <table className="inv-meta">
              <tbody>
                <tr><td>Invoice No</td><td>{view.invoiceNumber}</td></tr>
                <tr><td>Invoice Date</td><td>{usDate(view.invoiceDate)}</td></tr>
                <tr><td>Date of Supply</td><td>{usDate(view.supplyDate)}</td></tr>
                <tr><td>Due Date</td><td>{usDate(view.dueDate)}</td></tr>
              </tbody>
            </table>
          </div>
        </header>

        <section className="inv-parties">
          <div>
            <div className="inv-label">Purchaser</div>
            <div className="inv-pname">{view.purchaser.name}</div>
            {view.purchaser.address && <div>{view.purchaser.address}</div>}
            {view.purchaser.phone && <div>Tel: {view.purchaser.phone}</div>}
            <div>
              Purchaser TIN: <b>{view.purchaser.tin || 'N/A (not VAT registered)'}</b>
            </div>
            {view.purchaser.vatNo && <div>VAT Reg. No: {view.purchaser.vatNo}</div>}
          </div>
          <div>
            <div className="inv-label">Supply details</div>
            <table className="inv-kv">
              <tbody>
                <tr><td>Place of supply</td><td>{view.placeOfSupply}</td></tr>
                <tr><td>Mode of payment</td><td>{view.paymentMode}</td></tr>
                <tr><td>Currency</td><td>{view.currency}</td></tr>
                {view.salesPerson && <tr><td>Sales person</td><td>{view.salesPerson}</td></tr>}
                {view.reference && <tr><td>Reference</td><td>{view.reference}</td></tr>}
              </tbody>
            </table>
          </div>
        </section>

        <table className="inv-lines">
          <thead>
            <tr>
              <th style={{ width: 24 }}>#</th>
              <th style={{ width: 96 }}>Item code</th>
              <th>Description</th>
              <th className="r" style={{ width: 54 }}>Qty</th>
              <th className="r">Unit price<br />(excl. VAT)</th>
              <th className="r">Amount<br />(excl. VAT)</th>
              <th className="c" style={{ width: 40 }}>VAT rate</th>
              <th className="r">VAT amount</th>
              <th className="r">Amount<br />(incl. VAT)</th>
            </tr>
          </thead>
          <tbody>
            {view.lines.map((l) => (
              <tr key={l.lineNo}>
                <td className="c">{l.lineNo}</td>
                <td className="mono">{l.itemCode}</td>
                <td>
                  {l.description}
                  {view.showWarranty && l.warrantyMonths ? <div className="inv-wty">Warranty: {l.warrantyMonths} months</div> : null}
                </td>
                <td className="r">
                  {l.quantity} {l.unitOfMeasure}
                </td>
                <td className="r">{fm(l.unitPriceMinor)}</td>
                <td className="r">{fm(l.netMinor)}</td>
                <td className="c">{(l.vatRateBp / 100).toFixed(0)}%</td>
                <td className="r">{fm(l.vatMinor)}</td>
                <td className="r">{fm(l.grossMinor)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <section className="inv-bottom">
          <div className="inv-words">
            <div className="inv-label">Total consideration in words</div>
            <div>{amountInWords(view.totals.gross, view.currency)}</div>
            {data.receipts?.length > 0 && (
              <div style={{ marginTop: 10 }}>
                <div className="inv-label">Payments received</div>
                {data.receipts.map((rc: any) => (
                  <div key={rc.receiptNumber}>
                    {rc.receiptNumber} · {usDate(rc.receiptDate)} · {fm(rc.amountMinor)}
                  </div>
                ))}
              </div>
            )}
          </div>
          <table className="inv-totals">
            <tbody>
              <tr><td>Total value of supply (excl. VAT)</td><td>{fm(view.totals.net)}</td></tr>
              <tr><td>VAT @ 18%</td><td>{fm(view.totals.vat)}</td></tr>
              <tr className="grand"><td>Total consideration (incl. VAT) {view.currency}</td><td>{fm(view.totals.gross)}</td></tr>
              {view.totals.received > 0 && (
                <>
                  <tr><td>Less: amount received</td><td>{fm(view.totals.received)}</td></tr>
                  <tr className="grand"><td>Balance due</td><td>{fm(view.totals.balance)}</td></tr>
                </>
              )}
            </tbody>
          </table>
        </section>

        <footer className="inv-foot">
          {view.bankDetails && (
            <div>
              <b>Bank details:</b> {view.bankDetails}
            </div>
          )}
          {view.footer && <div style={{ marginTop: 4 }}>{view.footer}</div>}
          <div className="inv-sign">
            <div>Authorised signature (supplier)</div>
            <div>Received by - goods received in good order</div>
          </div>
          <div className="inv-gen">This is a computer-generated tax invoice.</div>
        </footer>
      </div>
    </div>
  );
}

const PRINT_CSS = `
.invoice-print-root { background: #e9ecf2; min-height: 100vh; color: #111; padding-bottom: 40px; font-family: 'Inter', -apple-system, 'Segoe UI', Arial, sans-serif; }
.inv-toolbar { position: sticky; top: 0; z-index: 5; display: flex; flex-wrap: wrap; gap: 12px; align-items: flex-end; padding: 10px 16px; background: #161d2e; color: #e8ecf4; font-size: 12px; }
.inv-toolbar label { display: flex; flex-direction: column; gap: 3px; color: #9aa5bd; }
.inv-toolbar label.chk { flex-direction: row; align-items: center; gap: 5px; padding-bottom: 7px; color: #e8ecf4; }
.inv-toolbar button { background: #4f7cff; color: #fff; border: 0; border-radius: 6px; padding: 8px 14px; font-weight: 600; cursor: pointer; }
.inv-toolbar button:disabled { opacity: .6; }
.inv-warn, .inv-note { max-width: 210mm; margin: 12px auto 0; padding: 8px 12px; border-radius: 6px; font-size: 12px; }
.inv-warn { background: #ffe4e6; color: #9f1239; }
.inv-note { background: #fef3c7; color: #78350f; }
.inv-page { position: relative; width: 210mm; min-height: 297mm; margin: 16px auto; background: #fff; padding: 14mm 12mm; box-shadow: 0 2px 16px rgba(0,0,0,.15); font-size: 11px; line-height: 1.4; overflow: hidden; }
.inv-watermark { position: absolute; top: 40%; left: 0; right: 0; text-align: center; font-size: 110px; color: rgba(220,38,38,.08); transform: rotate(-25deg); font-weight: 800; pointer-events: none; }
.inv-head { display: flex; justify-content: space-between; gap: 20px; border-bottom: 2px solid #111; padding-bottom: 10px; }
.inv-co { font-size: 20px; font-weight: 800; }
.inv-sub { color: #444; }
.inv-tin { margin-top: 4px; }
.inv-titlebox { min-width: 230px; }
.inv-title { border: 2px solid #111; text-align: center; font-size: 20px; font-weight: 800; letter-spacing: .06em; padding: 6px 10px; }
.inv-copy { text-align: center; color: #c81e1e; font-weight: 700; font-size: 10px; margin-top: 3px; letter-spacing: .1em; }
.inv-meta { width: 100%; margin-top: 6px; border-collapse: collapse; }
.inv-meta td { padding: 1px 0; }
.inv-meta td:last-child { text-align: right; font-weight: 700; }
.inv-parties { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; padding: 10px 0; border-bottom: 1px solid #bbb; }
.inv-label { font-size: 9px; text-transform: uppercase; letter-spacing: .08em; color: #555; font-weight: 700; margin-bottom: 2px; }
.inv-pname { font-weight: 700; font-size: 12.5px; }
.inv-kv { width: 100%; border-collapse: collapse; }
.inv-kv td { padding: 1px 0; vertical-align: top; }
.inv-kv td:last-child { text-align: right; font-weight: 600; }
.inv-lines { width: 100%; border-collapse: collapse; margin-top: 12px; }
.inv-lines th { background: #eef1f6; border: 1px solid #9aa3b5; padding: 5px 4px; font-size: 9.5px; text-align: left; }
.inv-lines td { border: 1px solid #c3c9d6; padding: 4px; vertical-align: top; }
.inv-lines .r { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.inv-lines .c { text-align: center; }
.inv-lines .mono { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 9.5px; }
.inv-wty { color: #666; font-size: 9.5px; }
.inv-bottom { display: grid; grid-template-columns: 1fr 300px; gap: 20px; margin-top: 10px; }
.inv-words { font-size: 11px; }
.inv-totals { border-collapse: collapse; width: 100%; }
.inv-totals td { padding: 3px 4px; }
.inv-totals td:last-child { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.inv-totals tr.grand td { font-weight: 800; border-top: 1px solid #111; border-bottom: 2px double #111; font-size: 12px; }
.inv-foot { margin-top: 18px; font-size: 10px; color: #333; }
.inv-sign { display: flex; justify-content: space-between; margin-top: 44px; }
.inv-sign div { border-top: 1px solid #333; padding-top: 3px; width: 42%; }
.inv-gen { text-align: center; color: #888; margin-top: 18px; font-size: 9px; }
@media print {
  @page { size: A4; margin: 0; }
  .no-print { display: none !important; }
  .invoice-print-root { background: #fff; padding: 0; }
  .inv-page { margin: 0; box-shadow: none; width: auto; min-height: auto; }
}
`;
