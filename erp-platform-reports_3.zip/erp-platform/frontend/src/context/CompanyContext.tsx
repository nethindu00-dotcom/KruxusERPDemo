import React, { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../lib/api';

export interface Company {
  id: number;
  code: string;
  name: string;
  baseCurrency: string;
  [key: string]: any;
}

interface CompanyContextValue {
  companies: Company[];
  company: Company | null;
  setCompanyId: (id: number) => void;
  loading: boolean;
  refresh: () => void;
}

const CompanyContext = createContext<CompanyContextValue>({} as any);

export function CompanyProvider({ children }: { children: React.ReactNode }) {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [companyId, setCompanyIdState] = useState<number | null>(() => {
    const raw = localStorage.getItem('kruxus_company_id');
    return raw ? Number(raw) : null;
  });
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    api
      .get('/companies')
      .then((res) => {
        setCompanies(res.data);
        if (!companyId && res.data.length > 0) {
          setCompanyIdState(res.data[0].id);
          localStorage.setItem('kruxus_company_id', String(res.data[0].id));
        }
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function setCompanyId(id: number) {
    setCompanyIdState(id);
    localStorage.setItem('kruxus_company_id', String(id));
    window.location.reload();
  }

  const company = companies.find((c) => c.id === companyId) || null;

  return (
    <CompanyContext.Provider value={{ companies, company, setCompanyId, loading, refresh: load }}>
      {children}
    </CompanyContext.Provider>
  );
}

export function useCompany() {
  return useContext(CompanyContext);
}
