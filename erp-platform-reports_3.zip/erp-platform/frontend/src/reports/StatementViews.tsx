import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api';
import { useCompany } from '../context/CompanyContext';
import { money, pct, slug, todayIso, usDate } from '../lib/format';
import { exportCsv, exportExcel, exportJson, exportPdf, ExportSheet } from '../lib/exporters';
import type { ReportDef } from './engine';
import { companyDetail, ExportBar, initialPeriod, PeriodPicker, PeriodState, periodLabel, PrintHeader } from './shared';

interface StatementLine {
  key: string;
  label: string;
  level: number;
  kind: 'heading' | 'account' | 'subtotal' | 'total' | 'percent';
  accountId?: number;
  code?: string;
  amounts: number[];
}

function useRunner() {
  const [busy, setBusy] = useState('');
  const run = async (k: string, fn: () => Promise<void>) => {
    setBusy(k);
    try {
      await fn();
    } finally {
      setBusy('');
    }
  };
  return { busy, run };
}

// =====================================================================
// Financial statements (P&L, balance sheet, cash flow, changes in equity)
// =====================================================================
export function StatementView({ def }: { def: ReportDef }) {
  const { company } = useCompany();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [period, setPeriod] = useState<PeriodState>(() => initialPeriod(def, params));
  const [compare, setCompare] = useState<string>(def.compare || '');
  const [compareAsOf, setCompareAsOf] = useState('');
  const [showCodes, setShowCodes] = useState(false);
  const [hideZero, setHideZero] = useState(true);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState('');
  const { busy, run } = useRunner();
  const isBs = def.statement === 'balance-sheet';

  useEffect(() => {
    if (!company?.id) return;
    setData(null);
    setError('');
    const q: any = { companyId: company.id };
    if (isBs) {
      q.asOf = period.to;
      if (compareAsOf) q.compareAsOf = compareAsOf;
    } else {
      q.from = period.from;
      q.to = period.to;
      if (compare) q.compare = compare;
    }
    api
      .get(`/reports/${def.statement}`, { params: q })
      .then((r) => setData(r.data))
      .catch((e) => setError(e?.response?.data?.message || 'Failed to load statement'));
  }, [company?.id, def.statement, period.from, period.to, compare, compareAsOf, isBs]);

  const lines: StatementLine[] = useMemo(
    () => (data?.lines || []).filter((l: StatementLine) => !(hideZero && l.kind === 'account' && l.amounts.every((a) => a === 0))),
    [data, hideZero],
  );
  const subtitle = isBs ? `As at ${period.to}${compareAsOf ? ` (comparative ${compareAsOf})` : ''}` : periodLabel(def, period);
  const showVariance = !isBs && (compare === 'prior-period' || compare === 'prior-year') && data?.columns?.length === 2;

  const amountText = (l: StatementLine, v: number) => (l.kind === 'percent' ? pct(v / 100) : l.kind === 'heading' ? '' : money(v, { brackets: true }));

  const toSheet = (): ExportSheet => {
    const cols = [
      { key: 'label', label: 'Particulars' },
      ...(showCodes ? [{ key: 'code', label: 'Code' }] : []),
      ...data.columns.map((c: any, i: number) => ({ key: 'c' + i, label: c.label, format: 'money' as const })),
      ...(showVariance ? [{ key: 'var', label: 'Variance', format: 'money' as const }, { key: 'varPct', label: 'Var %', format: 'percent' as const }] : []),
    ];
    const rows = lines.map((l) => {
      const o: any = { label: l.label, code: l.code || '', __l: l };
      l.amounts.forEach((a, i) => (o['c' + i] = l.kind === 'heading' ? null : l.kind === 'percent' ? null : a));
      if (l.kind === 'percent') o.label = `${l.label}: ${l.amounts.map((a) => pct(a / 100)).join(' / ')}`;
      if (showVariance && l.kind !== 'heading' && l.kind !== 'percent') {
        o.var = l.amounts[0] - l.amounts[1];
        o.varPct = l.amounts[1] ? Math.round(((l.amounts[0] - l.amounts[1]) / Math.abs(l.amounts[1])) * 10000) / 100 : null;
      }
      return o;
    });
    return {
      name: data.title.slice(0, 31),
      title: data.title,
      subtitle,
      columns: cols,
      rows,
      rowStyle: (r) => {
        const l: StatementLine = r.__l;
        if (l.kind === 'heading') return { bold: true, fill: l.level === 0 ? 'DCE4F7' : undefined };
        if (l.kind === 'subtotal') return { bold: true, topBorder: true };
        if (l.kind === 'total') return { bold: true, topBorder: true, doubleBottom: true, fill: 'EEF2FF' };
        if (l.kind === 'percent') return { italic: true };
        return { indent: 2 };
      },
    };
  };
  const meta = { companyName: company?.name || '', companyDetail: companyDetail(company) };
  const fname = `${slug(def.title)}-${period.to}`;

  const drill = (l: StatementLine) => {
    if (!l.accountId) return;
    const acc = `${l.code} ${l.label}`;
    const from = isBs ? '2000-01-01' : period.from;
    navigate(`/reports/fs-gl-detail?from=${from}&to=${period.to}&f_account=${encodeURIComponent(acc)}`);
  };

  return (
    <div>
      <div className="rp-bar no-print">
        <PeriodPicker mode={isBs ? 'asOf' : 'range'} value={period} onChange={setPeriod} />
        {def.statement === 'profit-loss' && (
          <label className="rp-field">
            Compare
            <select value={compare} onChange={(e) => setCompare(e.target.value)}>
              <option value="">No comparison</option>
              <option value="prior-period">Prior period</option>
              <option value="prior-year">Same period last year</option>
              <option value="monthly">Monthly columns</option>
            </select>
          </label>
        )}
        {isBs && (
          <label className="rp-field">
            Comparative date
            <input type="date" value={compareAsOf} onChange={(e) => setCompareAsOf(e.target.value)} />
          </label>
        )}
        <label className="rp-field" style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingBottom: 8 }}>
          <input type="checkbox" checked={showCodes} onChange={(e) => setShowCodes(e.target.checked)} /> Account codes
        </label>
        <label className="rp-field" style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingBottom: 8 }}>
          <input type="checkbox" checked={hideZero} onChange={(e) => setHideZero(e.target.checked)} /> Hide zero lines
        </label>
        {data && (
          <ExportBar
            busy={busy}
            onPdf={() => run('pdf', () => exportPdf([toSheet()], meta, fname))}
            onExcel={() => run('xlsx', () => exportExcel([toSheet()], meta, fname))}
            onCsv={() => exportCsv(toSheet(), fname)}
            onJson={() => exportJson(data, fname)}
          />
        )}
      </div>
      <PrintHeader company={company} title={data?.title || def.title} subtitle={subtitle} />
      {error && <p style={{ color: 'var(--danger)' }}>{error}</p>}
      {!data && !error && <p style={{ color: 'var(--text-dim)' }}>Building statement…</p>}
      {data && (
        <div className="card" style={{ overflowX: 'auto' }}>
          <div className="no-print" style={{ marginBottom: 8 }}>
            <div style={{ fontWeight: 700, fontSize: 15 }}>{data.title}</div>
            <div style={{ color: 'var(--text-dim)', fontSize: 12 }}>
              {company?.name} · {subtitle} · amounts in {company?.baseCurrency}
            </div>
          </div>
          <table className="rp-stmt">
            <thead>
              <tr>
                <th>Particulars</th>
                {showCodes && <th style={{ textAlign: 'left' }}>Code</th>}
                {data.columns.map((c: any) => (
                  <th key={c.label}>{c.label}</th>
                ))}
                {showVariance && (
                  <>
                    <th>Variance</th>
                    <th>Var %</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody>
              {lines.map((l) => (
                <tr
                  key={l.key}
                  className={`${l.kind} l${l.level}${l.accountId ? ' click' : ''}`}
                  onClick={() => drill(l)}
                  title={l.accountId ? 'Click to drill down to the general ledger' : undefined}
                >
                  <td>{l.label}</td>
                  {showCodes && <td>{l.code || ''}</td>}
                  {l.amounts.map((a, i) => (
                    <td key={i} className="num" style={a < 0 && l.kind !== 'heading' ? { color: 'var(--danger)' } : undefined}>
                      {amountText(l, a)}
                    </td>
                  ))}
                  {showVariance && (
                    <>
                      <td className="num">{l.kind === 'heading' || l.kind === 'percent' ? '' : money(l.amounts[0] - l.amounts[1], { brackets: true })}</td>
                      <td className="num">
                        {l.kind === 'heading' || l.kind === 'percent' || !l.amounts[1]
                          ? ''
                          : pct(((l.amounts[0] - l.amounts[1]) / Math.abs(l.amounts[1])) * 100)}
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          <StatementChecks data={data} statement={def.statement!} />
        </div>
      )}
    </div>
  );
}

function StatementChecks({ data, statement }: { data: any; statement: string }) {
  const c = data.checks || {};
  if (statement === 'balance-sheet' && c.balanced)
    return (
      <div className="rp-check">
        {c.balanced.every(Boolean) ? (
          <span className="pill green">Balanced: total assets = total equity and liabilities</span>
        ) : (
          <span className="pill red">Out of balance - check unposted entries</span>
        )}
      </div>
    );
  if (statement === 'cash-flow')
    return (
      <div className="rp-check">
        {c.reconciles ? (
          <span className="pill green">Reconciled: closing cash per statement = cash & bank per ledger ({money(c.closingPerLedger)})</span>
        ) : (
          <span className="pill red">
            Does not reconcile: ledger {money(c.closingPerLedger)} vs statement {money(c.closingPerStatement)}
          </span>
        )}
      </div>
    );
  return null;
}

// =====================================================================
// VAT return workings
// =====================================================================
export function VatReturnView({ def }: { def: ReportDef }) {
  const { company } = useCompany();
  const [params] = useSearchParams();
  const [period, setPeriod] = useState<PeriodState>(() => initialPeriod(def, params));
  const [data, setData] = useState<any>(null);
  const [tab, setTab] = useState<'output' | 'input'>('output');
  const { busy, run } = useRunner();

  useEffect(() => {
    if (!company?.id) return;
    setData(null);
    api.get('/reports/vat-return', { params: { companyId: company.id, from: period.from, to: period.to } }).then((r) => setData(r.data));
  }, [company?.id, period.from, period.to]);

  const s = data?.summary;
  const boxes: { label: string; value: number; strong?: boolean }[] = s
    ? [
        { label: 'Total value of supplies', value: s.totalSupplies },
        { label: 'Taxable supplies @ 18%', value: s.taxableSupplies },
        { label: 'Zero-rated / exempt supplies', value: s.zeroRatedOrExempt },
        { label: 'Output VAT', value: s.outputVat, strong: true },
        { label: 'Local purchases', value: s.localPurchases },
        { label: 'Import purchases', value: s.importPurchases },
        { label: 'Input VAT claimable', value: s.inputVat, strong: true },
        { label: s.netVatPayable >= 0 ? 'Net VAT payable to IRD' : 'Excess input VAT (carry forward / refund)', value: Math.abs(s.netVatPayable), strong: true },
      ]
    : [];
  const subtitle = `Taxable period ${period.from} to ${period.to}`;
  const outCols = [
    { key: 'invoiceDate', label: 'Date', format: 'date' as const },
    { key: 'invoiceNumber', label: 'Invoice No' },
    { key: 'customerName', label: 'Purchaser' },
    { key: 'customerTin', label: 'Purchaser TIN' },
    { key: 'taxableValue', label: 'Value of supply', format: 'money' as const },
    { key: 'zeroRatedOrExempt', label: 'Zero-rated / exempt', format: 'money' as const },
    { key: 'vat', label: 'VAT', format: 'money' as const },
    { key: 'total', label: 'Total', format: 'money' as const },
  ];
  const inCols = [
    { key: 'billDate', label: 'Date', format: 'date' as const },
    { key: 'supplierInvoiceNo', label: 'Supplier invoice No' },
    { key: 'billNumber', label: 'Our ref' },
    { key: 'supplierName', label: 'Supplier' },
    { key: 'supplierTin', label: 'Supplier TIN' },
    { key: 'importOrLocal', label: 'Local / import' },
    { key: 'value', label: 'Value', format: 'money' as const },
    { key: 'vat', label: 'Input VAT', format: 'money' as const },
  ];
  const sum = (rows: any[], k: string) => rows.reduce((a, r) => a + (r[k] || 0), 0);
  const sheets = (): ExportSheet[] => [
    {
      name: 'VAT return summary',
      title: 'VAT Return Workings',
      subtitle,
      columns: [
        { key: 'label', label: 'Item' },
        { key: 'value', label: `Amount (${company?.baseCurrency})`, format: 'money' },
      ],
      rows: boxes.map((b) => ({ label: b.label, value: b.value, strong: b.strong })),
      rowStyle: (r) => (r.strong ? { bold: true } : undefined),
    },
    {
      name: 'Output tax schedule',
      title: 'Output Tax Schedule',
      subtitle,
      columns: outCols,
      rows: data.outputSchedule,
      totals: { invoiceDate: 'Total', taxableValue: sum(data.outputSchedule, 'taxableValue'), zeroRatedOrExempt: sum(data.outputSchedule, 'zeroRatedOrExempt'), vat: sum(data.outputSchedule, 'vat'), total: sum(data.outputSchedule, 'total') },
    },
    {
      name: 'Input tax schedule',
      title: 'Input Tax Schedule',
      subtitle,
      columns: inCols,
      rows: data.inputSchedule,
      totals: { billDate: 'Total', value: sum(data.inputSchedule, 'value'), vat: sum(data.inputSchedule, 'vat') },
    },
  ];
  const meta = { companyName: company?.name || '', companyDetail: companyDetail(company) };
  const fname = `vat-return-${period.from}-${period.to}`;
  const rows = data ? (tab === 'output' ? data.outputSchedule : data.inputSchedule) : [];
  const cols = tab === 'output' ? outCols : inCols;

  return (
    <div>
      <div className="rp-bar no-print">
        <PeriodPicker mode="range" value={period} onChange={setPeriod} />
        {data && (
          <ExportBar
            busy={busy}
            onPdf={() => run('pdf', () => exportPdf(sheets(), meta, fname))}
            onExcel={() => run('xlsx', () => exportExcel(sheets(), meta, fname))}
            onCsv={() => exportCsv(sheets()[tab === 'output' ? 1 : 2], fname + '-' + tab)}
            onJson={() => exportJson(data, fname)}
          />
        )}
      </div>
      <PrintHeader company={company} title="VAT Return Workings" subtitle={subtitle} />
      {!data && <p style={{ color: 'var(--text-dim)' }}>Computing VAT…</p>}
      {data && (
        <>
          <div className="kpi-grid" style={{ marginBottom: 14 }}>
            {boxes.map((b) => (
              <div className="kpi-tile" key={b.label} style={b.strong ? { borderColor: 'var(--accent)' } : undefined}>
                <div className="label">{b.label}</div>
                <div className="value" style={{ fontSize: 20 }}>{money(b.value)}</div>
              </div>
            ))}
          </div>
          <div className="card" style={{ marginBottom: 14, fontSize: 12.5, color: 'var(--text-dim)' }}>
            Supplier: <b style={{ color: 'var(--text)' }}>{company?.name}</b> · TIN {(company as any)?.tin || '-'} · VAT No{' '}
            {(company as any)?.vatRegistrationNo || (company as any)?.taxRegistrationNo || '-'} · {s.invoiceCount} tax invoices issued ·{' '}
            {s.billCount} supplier invoices · VAT control accounts net balance at period end:{' '}
            <b style={{ color: 'var(--text)' }}>{money(s.vatControlBalanceAtEnd, { brackets: true })}</b>{' '}
            {s.vatControlBalanceAtEnd >= 0 ? '(payable)' : '(receivable)'}. Workings only - file the return on the IRD RAMIS portal.
          </div>
          <div className="rp-tabs no-print">
            <button className={'rp-tab' + (tab === 'output' ? ' active' : '')} onClick={() => setTab('output')}>
              Output tax schedule ({data.outputSchedule.length})
            </button>
            <button className={'rp-tab' + (tab === 'input' ? ' active' : '')} onClick={() => setTab('input')}>
              Input tax schedule ({data.inputSchedule.length})
            </button>
          </div>
          <div className="rp-table-wrap">
            <table className="rp-table">
              <thead>
                <tr>
                  {cols.map((c) => (
                    <th key={c.key} className={c.format === 'money' ? 'num' : ''}>
                      {c.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r: any, i: number) => (
                  <tr
                    key={i}
                    className={tab === 'output' ? 'link' : ''}
                    onClick={() => tab === 'output' && window.open(`/print/invoice/${r.invoiceId}`, '_blank')}
                  >
                    {cols.map((c) => (
                      <td key={c.key} className={c.format === 'money' ? 'num' : ''}>
                        {c.format === 'money' ? money(r[c.key]) : r[c.key]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  {cols.map((c, i) => (
                    <td key={c.key} className={c.format === 'money' ? 'num' : ''}>
                      {i === 0 ? 'Total' : c.format === 'money' ? money(sum(rows, c.key)) : ''}
                    </td>
                  ))}
                </tr>
              </tfoot>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

// =====================================================================
// Customer statement of account
// =====================================================================
export function CustomerStatementView({ def }: { def: ReportDef }) {
  const { company } = useCompany();
  const [params] = useSearchParams();
  const [period, setPeriod] = useState<PeriodState>(() => initialPeriod({ ...def, defaultPreset: 'last90' }, params));
  const [customers, setCustomers] = useState<any[]>([]);
  const [customer, setCustomer] = useState(params.get('customer') || '');
  const [invoices, setInvoices] = useState<any[] | null>(null);
  const [receipts, setReceipts] = useState<any[] | null>(null);
  const { busy, run } = useRunner();

  useEffect(() => {
    if (!company?.id) return;
    api.get('/reports/datasets/customers', { params: { companyId: company.id } }).then((r) => {
      const list = r.data.filter((c: any) => c.customerCode !== 'WALKIN').sort((a: any, b: any) => b.balance - a.balance);
      setCustomers(list);
      if (!customer && list[0]) setCustomer(list[0].customerCode);
    });
    api.get('/reports/datasets/salesInvoices', { params: { companyId: company.id, from: '2000-01-01', to: todayIso() } }).then((r) => setInvoices(r.data));
    api.get('/reports/datasets/receipts', { params: { companyId: company.id, from: '2000-01-01', to: todayIso() } }).then((r) => setReceipts(r.data));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [company?.id]);

  const cust = customers.find((c) => c.customerCode === customer);
  const model = useMemo(() => {
    if (!invoices || !receipts || !customer) return null;
    const tx = [
      ...invoices
        .filter((i) => i.customerCode === customer && i.status !== 'VOID')
        .map((i) => ({ date: i.invoiceDate, type: 'Invoice', ref: i.invoiceNumber, detail: `Due ${usDate(i.dueDate)}`, debit: i.total, credit: 0 })),
      ...receipts
        .filter((r) => r.customerCode === customer)
        .map((r) => ({ date: r.receiptDate, type: 'Receipt', ref: r.receiptNumber, detail: r.appliedTo ? `Applied to ${r.appliedTo}` : '', debit: 0, credit: r.amount })),
    ].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.type === 'Invoice' ? -1 : 1));
    const opening = tx.filter((t) => t.date < period.from).reduce((s, t) => s + t.debit - t.credit, 0);
    let bal = opening;
    const rows = tx
      .filter((t) => t.date >= period.from && t.date <= period.to)
      .map((t) => {
        bal += t.debit - t.credit;
        return { ...t, balance: bal };
      });
    const open = invoices.filter((i) => i.customerCode === customer && i.balance > 0 && i.status !== 'VOID');
    const aging = ['Current', '1-30', '31-60', '61-90', '90+'].map((b) => ({
      bucket: b,
      value: open.filter((i) => i.agingBucket === b).reduce((s, i) => s + i.balance, 0),
    }));
    return { opening, rows, closing: bal, aging };
  }, [invoices, receipts, customer, period.from, period.to]);

  const subtitle = `${cust?.customerName || ''} · ${period.from} to ${period.to}`;
  const sheet = (): ExportSheet => ({
    name: 'Statement',
    title: `Statement of Account - ${cust?.customerName}`,
    subtitle: `Period ${period.from} to ${period.to} · Customer TIN ${cust?.tin || 'N/A'} · Terms ${cust?.creditTermsDays} days`,
    summary: [
      { label: 'Opening balance', value: money(model!.opening) },
      { label: 'Closing balance', value: money(model!.closing) },
      ...model!.aging.map((a) => ({ label: `Aged ${a.bucket}`, value: money(a.value) })),
    ],
    columns: [
      { key: 'date', label: 'Date', format: 'date' },
      { key: 'type', label: 'Type' },
      { key: 'ref', label: 'Reference' },
      { key: 'detail', label: 'Details' },
      { key: 'debit', label: 'Debit', format: 'money' },
      { key: 'credit', label: 'Credit', format: 'money' },
      { key: 'balance', label: 'Balance', format: 'money' },
    ],
    rows: [{ date: period.from, type: 'Opening balance', balance: model!.opening }, ...model!.rows],
    totals: { date: 'Closing', debit: model!.rows.reduce((s, r) => s + r.debit, 0), credit: model!.rows.reduce((s, r) => s + r.credit, 0), balance: model!.closing },
  });
  const meta = { companyName: company?.name || '', companyDetail: companyDetail(company) };
  const fname = `statement-${slug(cust?.customerName || 'customer')}-${period.to}`;

  return (
    <div>
      <div className="rp-bar no-print">
        <label className="rp-field">
          Customer
          <select value={customer} onChange={(e) => setCustomer(e.target.value)} style={{ minWidth: 280 }}>
            {customers.map((c) => (
              <option key={c.customerCode} value={c.customerCode}>
                {c.customerName} - bal {money(c.balance)}
              </option>
            ))}
          </select>
        </label>
        <PeriodPicker mode="range" value={period} onChange={setPeriod} />
        {model && (
          <ExportBar
            busy={busy}
            onPdf={() => run('pdf', () => exportPdf([sheet()], meta, fname, { orientation: 'p' }))}
            onExcel={() => run('xlsx', () => exportExcel([sheet()], meta, fname))}
            onCsv={() => exportCsv(sheet(), fname)}
          />
        )}
      </div>
      <PrintHeader company={company} title="Statement of Account" subtitle={subtitle} />
      {!model && <p style={{ color: 'var(--text-dim)' }}>Loading…</p>}
      {model && cust && (
        <>
          <div className="card" style={{ marginBottom: 14, display: 'flex', gap: 30, flexWrap: 'wrap', fontSize: 13 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{cust.customerName}</div>
              <div style={{ color: 'var(--text-dim)' }}>
                {cust.customerCode} · TIN {cust.tin || 'N/A'} · {cust.phone} · terms {cust.creditTermsDays} days · limit {money(cust.creditLimit)}
              </div>
            </div>
            {model.aging.map((a) => (
              <div key={a.bucket}>
                <div style={{ color: 'var(--text-dim)', fontSize: 11, textTransform: 'uppercase' }}>{a.bucket}</div>
                <div style={{ fontWeight: 700 }}>{money(a.value)}</div>
              </div>
            ))}
            <div>
              <div style={{ color: 'var(--text-dim)', fontSize: 11, textTransform: 'uppercase' }}>Amount due</div>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{money(model.closing)}</div>
            </div>
          </div>
          <div className="rp-table-wrap">
            <table className="rp-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Reference</th>
                  <th>Details</th>
                  <th className="num">Debit</th>
                  <th className="num">Credit</th>
                  <th className="num">Balance</th>
                </tr>
              </thead>
              <tbody>
                <tr className="grp">
                  <td>{period.from}</td>
                  <td colSpan={5}>Opening balance</td>
                  <td className="num">{money(model.opening)}</td>
                </tr>
                {model.rows.map((r, i) => (
                  <tr key={i}>
                    <td>{r.date}</td>
                    <td>{r.type}</td>
                    <td>{r.ref}</td>
                    <td>{r.detail}</td>
                    <td className="num">{r.debit ? money(r.debit) : ''}</td>
                    <td className="num">{r.credit ? money(r.credit) : ''}</td>
                    <td className="num">{money(r.balance)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={4}>Closing balance at {period.to}</td>
                  <td className="num">{money(model.rows.reduce((s, r) => s + r.debit, 0))}</td>
                  <td className="num">{money(model.rows.reduce((s, r) => s + r.credit, 0))}</td>
                  <td className="num">{money(model.closing)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

