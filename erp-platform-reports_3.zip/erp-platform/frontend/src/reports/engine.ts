// JSON-driven report engine. A report is plain JSON (see catalog.json): which
// dataset to load, how to filter it, what to group by, which columns to show
// and how to aggregate them, optional chart. This module turns a definition +
// dataset rows into a rendered result model the viewer and exporters share.
import type { ColFormat } from '../lib/exporters';

export type Agg = 'sum' | 'avg' | 'count' | 'countDistinct' | 'min' | 'max' | 'first' | 'none';

export interface ColumnDef {
  field: string;
  label: string;
  format?: ColFormat;
  agg?: Agg;
  hidden?: boolean;
  /** Derived ratio, e.g. margin % = grossProfit / net * 100. Recomputed after aggregation. */
  ratio?: { num: string; den: string; scale?: number };
  /** Derived difference / sum of other fields. */
  expr?: { op: 'sub' | 'add'; fields: string[] };
}

export interface FilterDef {
  field: string;
  label: string;
}

export interface RowFilter {
  field: string;
  op: 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte' | 'in' | 'nin' | 'contains' | 'truthy';
  value?: any;
}

export interface ChartDef {
  type: 'bar' | 'hbar' | 'line' | 'area' | 'pie';
  x: string;
  y: string[];
  title?: string;
  limit?: number;
}

export interface ReportDef {
  id: string;
  title: string;
  module: string;
  description: string;
  kind: 'table' | 'statement' | 'vat-return' | 'customer-statement';
  statement?: 'profit-loss' | 'balance-sheet' | 'cash-flow' | 'changes-in-equity';
  dataset?: string;
  period?: 'range' | 'asOf' | 'none';
  defaultPreset?: string;
  compare?: string;
  rowFilter?: RowFilter[];
  filters?: FilterDef[];
  groupBy?: string[];
  groupOptions?: string[];
  showDetail?: boolean;
  columns?: ColumnDef[];
  sort?: { field: string; dir: 'asc' | 'desc' }[];
  limit?: number;
  chart?: ChartDef;
  rowLink?: string;
  /** Cross-tab: one extra column per value of `col`, summing `value` (e.g. aging buckets). */
  pivot?: { row: string; col: string; value: string; cols: string[] };
  favorite?: boolean;
  custom?: boolean;
}

export interface ResultGroup {
  key: string;
  summary: Record<string, any>;
  rows: Record<string, any>[];
}

export interface ReportResult {
  columns: ColumnDef[];
  grouped: boolean;
  groupFields: string[];
  groups: ResultGroup[];
  rows: Record<string, any>[]; // flat rows (ungrouped) or group summaries (grouped)
  totals: Record<string, any>;
  sourceCount: number;
}

const cmp = (a: any, b: any) => {
  if (a === b) return 0;
  if (a === null || a === undefined || a === '') return 1;
  if (b === null || b === undefined || b === '') return -1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b), undefined, { numeric: true });
};

function testFilter(row: Record<string, any>, f: RowFilter): boolean {
  const v = row[f.field];
  switch (f.op) {
    case 'eq':
      return v === f.value;
    case 'ne':
      return v !== f.value;
    case 'gt':
      return Number(v) > Number(f.value);
    case 'gte':
      return Number(v) >= Number(f.value);
    case 'lt':
      return Number(v) < Number(f.value);
    case 'lte':
      return Number(v) <= Number(f.value);
    case 'in':
      return Array.isArray(f.value) && f.value.includes(v);
    case 'nin':
      return Array.isArray(f.value) && !f.value.includes(v);
    case 'contains':
      return String(v ?? '').toLowerCase().includes(String(f.value ?? '').toLowerCase());
    case 'truthy':
      return !!v;
  }
}

function applyDerived(row: Record<string, any>, cols: ColumnDef[]) {
  for (const c of cols) {
    if (c.ratio) {
      const d = Number(row[c.ratio.den] || 0);
      row[c.field] = d ? Math.round((Number(row[c.ratio.num] || 0) / d) * (c.ratio.scale ?? 100) * 100) / 100 : null;
    } else if (c.expr) {
      const vals = c.expr.fields.map((f) => Number(row[f] || 0));
      row[c.field] = c.expr.op === 'add' ? vals.reduce((s, v) => s + v, 0) : vals.slice(1).reduce((s, v) => s - v, vals[0]);
    }
  }
  return row;
}

function aggregate(rows: Record<string, any>[], cols: ColumnDef[], groupFields: string[]): Record<string, any> {
  const out: Record<string, any> = {};
  for (const g of groupFields) out[g] = rows[0]?.[g];
  for (const c of cols) {
    if (groupFields.includes(c.field) || c.ratio || c.expr) continue;
    const agg = c.agg || (c.format === 'money' || c.format === 'number' ? 'sum' : 'none');
    const vals = rows.map((r) => r[c.field]);
    const nums = vals.map(Number).filter((v) => !isNaN(v));
    switch (agg) {
      case 'sum':
        out[c.field] = nums.reduce((s, v) => s + v, 0);
        break;
      case 'avg':
        out[c.field] = nums.length ? Math.round((nums.reduce((s, v) => s + v, 0) / nums.length) * 100) / 100 : null;
        break;
      case 'count':
        out[c.field] = rows.length;
        break;
      case 'countDistinct':
        out[c.field] = new Set(vals).size;
        break;
      case 'min':
        out[c.field] = [...vals].sort(cmp)[0];
        break;
      case 'max':
        out[c.field] = [...vals].sort(cmp).pop();
        break;
      case 'first':
        out[c.field] = vals[0];
        break;
      default:
        out[c.field] = rows.length === 1 ? vals[0] : undefined;
    }
  }
  return applyDerived(out, cols);
}

export interface RunState {
  filters: Record<string, string>;
  search: string;
  groupBy?: string[];
  showDetail?: boolean;
}

export function runReport(def: ReportDef, data: Record<string, any>[], state: RunState): ReportResult {
  let cols = (def.columns || []).filter((c) => !c.hidden);
  let rows = data.map((r) => applyDerived({ ...r }, def.columns || []));
  if (def.pivot) {
    const pv = def.pivot;
    const pcols: ColumnDef[] = pv.cols.map((v) => ({ field: 'pv_' + v, label: v, format: 'money', agg: 'sum' }));
    rows = rows.map((r) => {
      for (const v of pv.cols) r['pv_' + v] = r[pv.col] === v ? Number(r[pv.value] || 0) : 0;
      return r;
    });
    const at = cols.findIndex((c) => c.field === pv.value);
    cols = at >= 0 ? [...cols.slice(0, at), ...pcols, ...cols.slice(at)] : [...cols, ...pcols];
  }
  for (const f of def.rowFilter || []) rows = rows.filter((r) => testFilter(r, f));
  for (const [field, value] of Object.entries(state.filters)) {
    if (value !== '' && value !== undefined) rows = rows.filter((r) => String(r[field] ?? '') === value);
  }
  if (state.search) {
    const q = state.search.toLowerCase();
    rows = rows.filter((r) => cols.some((c) => String(r[c.field] ?? '').toLowerCase().includes(q)));
  }
  const sourceCount = rows.length;
  const groupFields = state.groupBy ?? def.groupBy ?? [];
  const sorter = (list: Record<string, any>[]) => {
    const sorts = def.sort || [];
    return list.sort((a, b) => {
      for (const s of sorts) {
        const c = cmp(a[s.field], b[s.field]);
        if (c) return s.dir === 'desc' ? -c : c;
      }
      return 0;
    });
  };
  const totals = aggregate(rows, cols, []);
  for (const g of groupFields) totals[g] = undefined;
  if (cols[0]) totals[cols[0].field] = cols[0].format && cols[0].format !== 'text' ? totals[cols[0].field] : 'Total';

  if (groupFields.length === 0) {
    let out = sorter(rows);
    if (def.limit) out = out.slice(0, def.limit);
    return { columns: cols, grouped: false, groupFields, groups: [], rows: out, totals, sourceCount };
  }
  const map = new Map<string, Record<string, any>[]>();
  for (const r of rows) {
    const k = groupFields.map((g) => String(r[g] ?? '–')).join(' › ');
    if (!map.has(k)) map.set(k, []);
    map.get(k)!.push(r);
  }
  let groups: ResultGroup[] = Array.from(map.entries()).map(([key, rs]) => ({
    key,
    summary: aggregate(rs, cols, groupFields),
    rows: sorter([...rs]),
  }));
  const sortedSummaries = sorter(groups.map((g) => g.summary));
  groups = sortedSummaries.map((s) => groups.find((g) => g.summary === s)!);
  if (def.limit) groups = groups.slice(0, def.limit);
  // In summary mode, show only group keys + aggregatable columns
  const summaryCols = [
    ...groupFields.map((g) => cols.find((c) => c.field === g) || { field: g, label: g }),
    ...cols.filter((c) => !groupFields.includes(c.field) && (c.ratio || c.expr || (c.agg && c.agg !== 'none') || c.format === 'money' || c.format === 'number')),
  ];
  const showDetail = state.showDetail ?? def.showDetail ?? false;
  return {
    columns: showDetail ? cols : summaryCols,
    grouped: true,
    groupFields,
    groups,
    rows: groups.map((g) => g.summary),
    totals,
    sourceCount,
  };
}

/** Distinct values for a filter dropdown. */
export function distinct(data: Record<string, any>[], field: string): string[] {
  return Array.from(new Set(data.map((r) => r[field]).filter((v) => v !== null && v !== undefined && v !== '')))
    .map(String)
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
}

export function fillTemplate(tpl: string, row: Record<string, any>): string {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => encodeURIComponent(row[k] ?? ''));
}
