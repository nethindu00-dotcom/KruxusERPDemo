import React from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import catalogJson from './catalog.json';
import type { ChartDef, ColumnDef, ReportDef } from './engine';
import { DATE_PRESETS, DatePreset, moneyShort, presetRange, SERIES, todayIso } from '../lib/format';
import { formatCell } from '../lib/exporters';

export const CATALOG: ReportDef[] = (catalogJson as any).reports;
const CUSTOM_KEY = 'kruxus_custom_reports_v1';

export function loadCustomReports(): ReportDef[] {
  try {
    return JSON.parse(localStorage.getItem(CUSTOM_KEY) || '[]');
  } catch {
    return [];
  }
}

export function saveCustomReports(list: ReportDef[]) {
  try {
    localStorage.setItem(CUSTOM_KEY, JSON.stringify(list));
  } catch {
    /* storage unavailable */
  }
}

export function findReport(id: string): ReportDef | undefined {
  return CATALOG.find((r) => r.id === id) || loadCustomReports().find((r) => r.id === id);
}

export function companyDetail(company: any): string {
  return [
    company?.addressLine,
    company?.tin ? `TIN ${company.tin}` : null,
    company?.vatRegistrationNo || company?.taxRegistrationNo ? `VAT ${company.vatRegistrationNo || company.taxRegistrationNo}` : null,
  ]
    .filter(Boolean)
    .join(' · ');
}

// ---------------------------------------------------------------- period picker
export interface PeriodState {
  preset: DatePreset | 'custom';
  from: string;
  to: string;
}

export function PeriodPicker({
  mode,
  value,
  onChange,
}: {
  mode: 'range' | 'asOf' | 'none';
  value: PeriodState;
  onChange: (v: PeriodState) => void;
}) {
  if (mode === 'none') return null;
  if (mode === 'asOf')
    return (
      <label className="rp-field">
        As at
        <input type="date" value={value.to} onChange={(e) => onChange({ ...value, preset: 'custom', to: e.target.value })} />
      </label>
    );
  return (
    <>
      <label className="rp-field">
        Period
        <select
          value={value.preset}
          onChange={(e) => {
            const p = e.target.value as DatePreset | 'custom';
            if (p === 'custom') onChange({ ...value, preset: p });
            else onChange({ preset: p, ...presetRange(p) });
          }}
        >
          {DATE_PRESETS.map((p) => (
            <option key={p.key} value={p.key}>
              {p.label}
            </option>
          ))}
          <option value="custom">Custom…</option>
        </select>
      </label>
      <label className="rp-field">
        From
        <input type="date" value={value.from} onChange={(e) => onChange({ ...value, preset: 'custom', from: e.target.value })} />
      </label>
      <label className="rp-field">
        To
        <input type="date" value={value.to} onChange={(e) => onChange({ ...value, preset: 'custom', to: e.target.value })} />
      </label>
    </>
  );
}

// ---------------------------------------------------------------- export bar
export function ExportBar({
  onPdf,
  onExcel,
  onCsv,
  onJson,
  busy,
}: {
  onPdf?: () => void;
  onExcel?: () => void;
  onCsv?: () => void;
  onJson?: () => void;
  busy?: string;
}) {
  return (
    <div className="rp-export no-print">
      <button className="btn secondary" onClick={() => window.print()} title="Print (or Save as PDF from the print dialog)">
        Print
      </button>
      {onPdf && (
        <button className="btn secondary" onClick={onPdf} disabled={!!busy}>
          {busy === 'pdf' ? 'PDF…' : 'PDF'}
        </button>
      )}
      {onExcel && (
        <button className="btn secondary" onClick={onExcel} disabled={!!busy}>
          {busy === 'xlsx' ? 'Excel…' : 'Excel'}
        </button>
      )}
      {onCsv && (
        <button className="btn secondary" onClick={onCsv}>
          CSV
        </button>
      )}
      {onJson && (
        <button className="btn secondary" onClick={onJson}>
          JSON
        </button>
      )}
    </div>
  );
}

export function PrintHeader({ company, title, subtitle }: { company: any; title: string; subtitle?: string }) {
  return (
    <div className="rp-print-header">
      <div className="rp-print-co">{company?.name}</div>
      <div className="rp-print-detail">{companyDetail(company)}</div>
      <div className="rp-print-title">{title}</div>
      {subtitle && <div className="rp-print-sub">{subtitle}</div>}
    </div>
  );
}

// ---------------------------------------------------------------- chart
const tooltipStyle = { background: '#1d2639', border: '1px solid #2a3448', borderRadius: 8, fontSize: 12 };

export function ReportChart({ chart, rows, columns }: { chart: ChartDef; rows: Record<string, any>[]; columns: ColumnDef[] }) {
  const colOf = (f: string) => columns.find((c) => c.field === f);
  const data = rows
    .filter((r) => r[chart.x] !== undefined)
    .slice(0, chart.limit || 30)
    .map((r) => {
      const o: Record<string, any> = { name: String(r[chart.x] ?? '–') };
      for (const y of chart.y) {
        const c = colOf(y);
        o[y] = c?.format === 'money' ? Number(r[y] || 0) / 100 : Number(r[y] || 0);
      }
      return o;
    });
  if (data.length === 0) return null;
  const label = (y: string) => colOf(y)?.label || y;
  const fmt = (v: number, y: string) =>
    colOf(y)?.format === 'money' ? moneyShort(v * 100) : colOf(y)?.format === 'percent' ? `${v}%` : v.toLocaleString();
  const height = chart.type === 'hbar' ? Math.max(220, data.length * 28 + 40) : 280;
  const multi = chart.y.length > 1;
  return (
    <div className="card rp-chart">
      {chart.title && <h3 style={{ margin: '0 0 8px 0', fontSize: 14 }}>{chart.title}</h3>}
      <ResponsiveContainer width="100%" height={height}>
        {chart.type === 'pie' ? (
          <PieChart>
            <Pie data={data} dataKey={chart.y[0]} nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={2} stroke="#161d2e" strokeWidth={2}>
              {data.map((_, i) => (
                <Cell key={i} fill={SERIES[i % SERIES.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => fmt(v, chart.y[0])} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
          </PieChart>
        ) : chart.type === 'line' ? (
          <LineChart data={data}>
            <CartesianGrid stroke="#2a3448" vertical={false} />
            <XAxis dataKey="name" stroke="#9aa5bd" fontSize={11} />
            <YAxis stroke="#9aa5bd" fontSize={11} tickFormatter={(v) => fmt(v, chart.y[0])} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: number, n: string) => [fmt(v, n), label(n)]} />
            {multi && <Legend formatter={(v) => label(v)} wrapperStyle={{ fontSize: 12 }} />}
            {chart.y.map((y, i) => (
              <Line key={y} dataKey={y} stroke={SERIES[i]} strokeWidth={2} dot={{ r: 4 }} />
            ))}
          </LineChart>
        ) : chart.type === 'area' ? (
          <AreaChart data={data}>
            <CartesianGrid stroke="#2a3448" vertical={false} />
            <XAxis dataKey="name" stroke="#9aa5bd" fontSize={11} />
            <YAxis stroke="#9aa5bd" fontSize={11} tickFormatter={(v) => fmt(v, chart.y[0])} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v: number, n: string) => [fmt(v, n), label(n)]} />
            {multi && <Legend formatter={(v) => label(v)} wrapperStyle={{ fontSize: 12 }} />}
            {chart.y.map((y, i) => (
              <Area key={y} dataKey={y} stroke={SERIES[i]} fill={SERIES[i]} fillOpacity={0.2} strokeWidth={2} />
            ))}
          </AreaChart>
        ) : (
          <BarChart data={data} layout={chart.type === 'hbar' ? 'vertical' : 'horizontal'} barGap={2}>
            <CartesianGrid stroke="#2a3448" horizontal={chart.type !== 'hbar'} vertical={chart.type === 'hbar'} />
            {chart.type === 'hbar' ? (
              <>
                <XAxis type="number" stroke="#9aa5bd" fontSize={11} tickFormatter={(v) => fmt(v, chart.y[0])} />
                <YAxis type="category" dataKey="name" stroke="#9aa5bd" fontSize={11} width={190} />
              </>
            ) : (
              <>
                <XAxis dataKey="name" stroke="#9aa5bd" fontSize={11} />
                <YAxis stroke="#9aa5bd" fontSize={11} tickFormatter={(v) => fmt(v, chart.y[0])} />
              </>
            )}
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: 'rgba(255,255,255,0.04)' }} formatter={(v: number, n: string) => [fmt(v, n), label(n)]} />
            {multi && <Legend formatter={(v) => label(v)} wrapperStyle={{ fontSize: 12 }} />}
            {chart.y.map((y, i) => (
              <Bar key={y} dataKey={y} fill={SERIES[i]} radius={chart.type === 'hbar' ? [0, 4, 4, 0] : [4, 4, 0, 0]} maxBarSize={36} />
            ))}
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}

export function cellText(row: Record<string, any>, c: ColumnDef) {
  return formatCell(row[c.field], c.format);
}

export const isNumCol = (c: ColumnDef) => ['money', 'number', 'number2', 'percent', 'int'].includes(c.format || '');

export const REPORT_CSS = `
.rp-bar { display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end; margin-bottom: 14px; }
.rp-field { display: flex; flex-direction: column; gap: 4px; font-size: 11px; color: var(--text-dim); text-transform: uppercase; letter-spacing: .04em; }
.rp-field input, .rp-field select { min-width: 130px; text-transform: none; letter-spacing: 0; }
.rp-field input[type=checkbox] { min-width: 0; }
.rp-export { display: flex; gap: 6px; margin-left: auto; }
.rp-tabs { display: flex; gap: 4px; margin-bottom: 12px; border-bottom: 1px solid var(--border); }
.rp-tab { background: none; border: 0; color: var(--text-dim); padding: 8px 14px; cursor: pointer; font-size: 13px; border-bottom: 2px solid transparent; }
.rp-tab.active { color: var(--text); border-bottom-color: var(--accent); }
.rp-table-wrap { overflow: auto; max-height: calc(100vh - 290px); border: 1px solid var(--border); border-radius: 10px; }
.rp-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 12.5px; }
.rp-table th { position: sticky; top: 0; background: var(--surface-2); color: var(--text-dim); text-align: left; font-weight: 600; padding: 8px 10px; border-bottom: 1px solid var(--border); font-size: 11px; text-transform: uppercase; letter-spacing: .04em; cursor: pointer; white-space: nowrap; z-index: 1; }
.rp-table td { padding: 6px 10px; border-bottom: 1px solid var(--border); white-space: nowrap; max-width: 380px; overflow: hidden; text-overflow: ellipsis; }
.rp-table td.num, .rp-table th.num { text-align: right; font-variant-numeric: tabular-nums; }
.rp-table tbody tr:hover td { background: var(--surface-2); }
.rp-table tr.grp td { background: rgba(79,124,255,.08); font-weight: 700; }
.rp-table tr.sub td { font-weight: 700; border-top: 1px solid var(--text-dim); }
.rp-table tfoot td { position: sticky; bottom: 0; background: var(--surface-2); font-weight: 800; border-top: 2px solid var(--text-dim); }
.rp-table tr.link { cursor: pointer; }
.rp-table .neg { color: var(--danger); }
.rp-stmt { width: 100%; border-collapse: collapse; font-size: 13px; }
.rp-stmt td, .rp-stmt th { padding: 6px 10px; }
.rp-stmt th { text-align: right; color: var(--text-dim); font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border); }
.rp-stmt th:first-child { text-align: left; }
.rp-stmt td.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.rp-stmt tr.heading td { font-weight: 700; padding-top: 14px; color: var(--accent); }
.rp-stmt tr.heading.l0 td { font-size: 14px; color: var(--text); text-transform: uppercase; letter-spacing: .04em; }
.rp-stmt tr.subtotal td { font-weight: 700; border-top: 1px solid var(--border); }
.rp-stmt tr.total td { font-weight: 800; border-top: 1px solid var(--text-dim); border-bottom: 3px double var(--text-dim); }
.rp-stmt tr.account td:first-child { padding-left: 34px; }
.rp-stmt tr.account.click:hover td { background: var(--surface-2); cursor: pointer; }
.rp-stmt tr.percent td { color: var(--text-dim); font-style: italic; }
.rp-chart { margin-bottom: 14px; }
.rp-print-header { display: none; }
.rp-check { font-size: 12px; margin-top: 10px; }
.rp-cat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 12px; }
.rp-card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 14px; cursor: pointer; text-decoration: none; display: block; }
.rp-card:hover { border-color: var(--accent); background: var(--surface-2); }
.rp-card h4 { margin: 0 0 6px 0; font-size: 14px; }
.rp-card p { margin: 0; font-size: 12px; color: var(--text-dim); line-height: 1.45; }
.rp-badge { display: inline-block; font-size: 10px; padding: 1px 7px; border-radius: 99px; background: var(--surface-2); color: var(--text-dim); margin-left: 6px; vertical-align: middle; font-weight: 600; }
.rp-json { width: 100%; min-height: 420px; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12px; line-height: 1.5; }
@media print {
  @page { margin: 12mm; }
  body { background: #fff !important; color: #000 !important; }
  .sidebar, .topbar, .no-print, .rp-bar, .rp-tabs { display: none !important; }
  .content { padding: 0 !important; overflow: visible !important; }
  .card, .kpi-tile { background: #fff !important; border-color: #ccc !important; color: #000 !important; }
  .rp-print-header { display: block; margin-bottom: 12px; color: #000; }
  .rp-print-co { font-size: 16px; font-weight: 800; }
  .rp-print-detail { font-size: 10px; color: #444; }
  .rp-print-title { font-size: 14px; font-weight: 700; margin-top: 6px; }
  .rp-print-sub { font-size: 11px; color: #333; }
  .rp-table-wrap { max-height: none !important; overflow: visible !important; border: 0; }
  .rp-table th, .rp-table tfoot td { position: static; background: #eef1f6 !important; color: #000 !important; }
  .rp-table td, .rp-stmt td { color: #000 !important; border-color: #ddd !important; }
  .rp-table tr.grp td { background: #f3f5fa !important; }
  .rp-stmt tr.heading td { color: #000 !important; }
  .rp-chart { break-inside: avoid; }
  .page-header { display: none; }
}
`;

export function initialPeriod(def: ReportDef, params?: URLSearchParams): PeriodState {
  const from = params?.get('from');
  const to = params?.get('to');
  if (from || to) return { preset: 'custom', from: from || presetRange('fy').from, to: to || todayIso() };
  const preset = (def.defaultPreset || 'fy') as DatePreset;
  return { preset, ...presetRange(preset) };
}

export function periodLabel(def: ReportDef, p: PeriodState) {
  if (def.period === 'none') return `As at ${todayIso()}`;
  if (def.period === 'asOf') return `As at ${p.to}`;
  return `For the period ${p.from} to ${p.to}`;
}

