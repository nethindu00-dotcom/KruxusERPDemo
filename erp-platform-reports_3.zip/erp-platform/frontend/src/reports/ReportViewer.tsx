import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api';
import { useCompany } from '../context/CompanyContext';
import { slug } from '../lib/format';
import { exportCsv, exportExcel, exportJson, exportPdf, ExportSheet } from '../lib/exporters';
import { distinct, fillTemplate, ReportDef, runReport } from './engine';
import {
  cellText,
  companyDetail,
  ExportBar,
  isNumCol,
  loadCustomReports,
  PeriodPicker,
  PeriodState,
  PrintHeader,
  ReportChart,
  saveCustomReports,
  initialPeriod,
  periodLabel,
} from './shared';
import { CustomerStatementView, StatementView, VatReturnView } from './StatementViews';

/** Top-level viewer: dispatches by report kind and owns the Definition (JSON) tab. */
export default function ReportViewer({ def: initialDef }: { def: ReportDef }) {
  const [def, setDef] = useState<ReportDef>(initialDef);
  const [tab, setTab] = useState<'report' | 'json'>('report');
  useEffect(() => setDef(initialDef), [initialDef]);
  const navigate = useNavigate();

  return (
    <div>
      <div className="page-header no-print">
        <div>
          <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
            <a href="/reports" onClick={(e) => { e.preventDefault(); navigate('/reports'); }} style={{ color: 'var(--accent)' }}>
              Reports
            </a>{' '}
            › {def.module}
          </div>
          <h1 style={{ marginTop: 4 }}>
            {def.title}
            {def.custom && <span className="rp-badge">custom</span>}
          </h1>
          <p style={{ color: 'var(--text-dim)', fontSize: 12.5, margin: '4px 0 0 0', maxWidth: 900 }}>{def.description}</p>
        </div>
      </div>
      <div className="rp-tabs no-print">
        <button className={'rp-tab' + (tab === 'report' ? ' active' : '')} onClick={() => setTab('report')}>
          Report
        </button>
        <button className={'rp-tab' + (tab === 'json' ? ' active' : '')} onClick={() => setTab('json')}>
          Definition (JSON)
        </button>
      </div>
      {tab === 'json' ? (
        <DefinitionEditor def={def} onApply={(d) => { setDef(d); setTab('report'); }} />
      ) : def.kind === 'statement' ? (
        <StatementView def={def} />
      ) : def.kind === 'vat-return' ? (
        <VatReturnView def={def} />
      ) : def.kind === 'customer-statement' ? (
        <CustomerStatementView def={def} />
      ) : (
        <TableReport def={def} />
      )}
    </div>
  );
}

// ---------------------------------------------------------------- table reports
function TableReport({ def }: { def: ReportDef }) {
  const { company } = useCompany();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [period, setPeriod] = useState<PeriodState>(() => initialPeriod(def, params));
  const [data, setData] = useState<any[] | null>(null);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState<Record<string, string>>(() => {
    const f: Record<string, string> = {};
    params.forEach((v, k) => {
      if (k.startsWith('f_')) f[k.slice(2)] = v;
    });
    return f;
  });
  const [search, setSearch] = useState('');
  const [groupBy, setGroupBy] = useState<string>((def.groupBy || []).join(','));
  const [showDetail, setShowDetail] = useState<boolean>(!!def.showDetail);
  const [sortOverride, setSortOverride] = useState<{ field: string; dir: 'asc' | 'desc' } | null>(null);
  const [busy, setBusy] = useState('');

  useEffect(() => {
    setGroupBy((def.groupBy || []).join(','));
    setShowDetail(!!def.showDetail);
    setSortOverride(null);
  }, [def]);

  useEffect(() => {
    if (!company?.id || !def.dataset) return;
    setData(null);
    setError('');
    const q: any = { companyId: company.id };
    if (def.period === 'range') {
      q.from = period.from;
      q.to = period.to;
    } else if (def.period === 'asOf') q.to = period.to;
    api
      .get(`/reports/datasets/${def.dataset}`, { params: q })
      .then((r) => setData(r.data))
      .catch((e) => setError(e?.response?.data?.message || 'Failed to load data'));
  }, [company?.id, def.dataset, def.period, period.from, period.to]);

  const groupFields = groupBy ? groupBy.split(',') : [];
  const effectiveDef: ReportDef = useMemo(
    () => (sortOverride ? { ...def, sort: [sortOverride, ...(def.sort || [])] } : def),
    [def, sortOverride],
  );
  const result = useMemo(
    () => (data ? runReport(effectiveDef, data, { filters, search, groupBy: groupFields, showDetail }) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data, effectiveDef, filters, search, groupBy, showDetail],
  );

  const groupChoices = Array.from(new Set([...(def.groupBy || []), ...(def.groupOptions || [])]));
  const labelOf = (f: string) => def.columns?.find((c) => c.field === f)?.label || f;
  const title = def.title;
  const subtitle = [periodLabel(def, period), ...Object.entries(filters).filter(([, v]) => v).map(([k, v]) => `${labelOf(k)}: ${v}`)].join(' · ');

  const toSheet = (): ExportSheet => {
    const r = result!;
    const cols = r.columns.map((c) => ({ key: c.field, label: c.label, format: c.format }));
    if (r.grouped && showDetail) {
      const rows: any[] = [];
      for (const g of r.groups) {
        rows.push({ [cols[0].key]: g.key, __kind: 'grp' });
        g.rows.forEach((x) => rows.push(x));
        rows.push({ ...g.summary, [cols[0].key]: `Total ${g.key}`, __kind: 'sub' });
      }
      return {
        name: title,
        title,
        subtitle,
        columns: cols,
        rows,
        totals: r.totals,
        rowStyle: (row) => (row.__kind === 'grp' ? { bold: true, fill: 'E8EEFF' } : row.__kind === 'sub' ? { bold: true, topBorder: true } : undefined),
      };
    }
    return { name: title, title, subtitle, columns: cols, rows: r.rows, totals: r.totals };
  };
  const meta = { companyName: company?.name || '', companyDetail: companyDetail(company) };
  const fname = `${slug(title)}-${period.to}`;
  const run = async (kind: string, fn: () => Promise<void>) => {
    setBusy(kind);
    try {
      await fn();
    } finally {
      setBusy('');
    }
  };

  const onRowClick = (row: any) => {
    if (!def.rowLink) return;
    const url = fillTemplate(def.rowLink, row);
    if (url.startsWith('/print/')) window.open(url, '_blank');
    else navigate(url);
  };

  const toggleSort = (field: string) =>
    setSortOverride((s) => (s?.field === field ? { field, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { field, dir: 'desc' }));

  return (
    <div>
      <div className="rp-bar no-print">
        <PeriodPicker mode={def.period || 'range'} value={period} onChange={setPeriod} />
        {(def.filters || []).map((f) => (
          <label key={f.field} className="rp-field">
            {f.label}
            <select value={filters[f.field] || ''} onChange={(e) => setFilters({ ...filters, [f.field]: e.target.value })}>
              <option value="">All</option>
              {(data ? distinct(data, f.field) : []).map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
          </label>
        ))}
        {groupChoices.length > 0 && (
          <label className="rp-field">
            Group by
            <select value={groupBy} onChange={(e) => setGroupBy(e.target.value)}>
              <option value="">(none - detail)</option>
              {(def.groupBy || []).length > 0 && <option value={(def.groupBy || []).join(',')}>{(def.groupBy || []).map(labelOf).join(' › ')}</option>}
              {groupChoices
                .filter((g) => (def.groupBy || []).join(',') !== g)
                .map((g) => (
                  <option key={g} value={g}>
                    {labelOf(g)}
                  </option>
                ))}
            </select>
          </label>
        )}
        {groupFields.length > 0 && (
          <label className="rp-field" style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingBottom: 8 }}>
            <input type="checkbox" checked={showDetail} onChange={(e) => setShowDetail(e.target.checked)} /> Show detail
          </label>
        )}
        <label className="rp-field">
          Search
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find in report…" />
        </label>
        {result && (
          <ExportBar
            busy={busy}
            onPdf={() => run('pdf', () => exportPdf([toSheet()], meta, fname))}
            onExcel={() => run('xlsx', () => exportExcel([toSheet()], meta, fname))}
            onCsv={() => exportCsv(toSheet(), fname)}
            onJson={() => exportJson({ report: def, period, filters, rows: result.rows, totals: result.totals }, fname)}
          />
        )}
      </div>
      <PrintHeader company={company} title={title} subtitle={subtitle} />
      {error && <p style={{ color: 'var(--danger)' }}>{error}</p>}
      {!data && !error && <p style={{ color: 'var(--text-dim)' }}>Running report…</p>}
      {result && (
        <>
          {def.chart && result.rows.length > 0 && <ReportChart chart={def.chart} rows={result.rows} columns={result.columns} />}
          <div style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 6 }} className="no-print">
            {result.sourceCount.toLocaleString()} records{result.grouped ? ` in ${result.groups.length} groups` : ''} · {subtitle}
            {def.rowLink && ' · click a row to open'}
          </div>
          <div className="rp-table-wrap">
            <table className="rp-table">
              <thead>
                <tr>
                  {result.columns.map((c) => (
                    <th key={c.field} className={isNumCol(c) ? 'num' : ''} onClick={() => toggleSort(c.field)}>
                      {c.label}
                      {sortOverride?.field === c.field ? (sortOverride.dir === 'asc' ? ' ▲' : ' ▼') : ''}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {result.grouped && showDetail
                  ? result.groups.map((g) => (
                      <React.Fragment key={g.key}>
                        <tr className="grp">
                          <td colSpan={result.columns.length}>
                            {g.key} <span style={{ color: 'var(--text-dim)', fontWeight: 400 }}>({g.rows.length})</span>
                          </td>
                        </tr>
                        {g.rows.map((row, i) => (
                          <DataRow key={i} row={row} result={result} onClick={def.rowLink ? () => onRowClick(row) : undefined} />
                        ))}
                        <tr className="sub">
                          {result.columns.map((c, i) => (
                            <td key={c.field} className={isNumCol(c) ? 'num' : ''}>
                              {i === 0 ? `Total ${g.key}` : isNumCol(c) ? cellText(g.summary, c) : ''}
                            </td>
                          ))}
                        </tr>
                      </React.Fragment>
                    ))
                  : result.rows.map((row, i) => (
                      <DataRow key={i} row={row} result={result} onClick={def.rowLink && !result.grouped ? () => onRowClick(row) : undefined} />
                    ))}
                {result.rows.length === 0 && (
                  <tr>
                    <td colSpan={result.columns.length} style={{ color: 'var(--text-dim)', padding: 20, textAlign: 'center' }}>
                      No records for this period / filter.
                    </td>
                  </tr>
                )}
              </tbody>
              {result.rows.length > 0 && (
                <tfoot>
                  <tr>
                    {result.columns.map((c, i) => (
                      <td key={c.field} className={isNumCol(c) ? 'num' : ''}>
                        {i === 0 ? 'Grand total' : isNumCol(c) && c.agg !== 'none' ? cellText(result.totals, c) : ''}
                      </td>
                    ))}
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function DataRow({ row, result, onClick }: { row: any; result: any; onClick?: () => void }) {
  return (
    <tr className={onClick ? 'link' : ''} onClick={onClick}>
      {result.columns.map((c: any) => {
        const v = row[c.field];
        return (
          <td key={c.field} className={(isNumCol(c) ? 'num' : '') + (typeof v === 'number' && v < 0 && c.format === 'money' ? ' neg' : '')} title={String(v ?? '')}>
            {cellText(row, c)}
          </td>
        );
      })}
    </tr>
  );
}

// ---------------------------------------------------------------- JSON definition editor
function DefinitionEditor({ def, onApply }: { def: ReportDef; onApply: (d: ReportDef) => void }) {
  const [text, setText] = useState(() => JSON.stringify(def, null, 2));
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();
  useEffect(() => setText(JSON.stringify(def, null, 2)), [def]);

  const parse = (): ReportDef | null => {
    try {
      const d = JSON.parse(text);
      if (!d.title || !d.kind) throw new Error('A report needs at least "title" and "kind".');
      if (d.kind === 'table' && (!d.dataset || !Array.isArray(d.columns))) throw new Error('Table reports need "dataset" and "columns".');
      setMsg('');
      return d;
    } catch (e: any) {
      setMsg('Invalid definition: ' + e.message);
      return null;
    }
  };

  return (
    <div className="card">
      <p style={{ marginTop: 0, fontSize: 13, color: 'var(--text-dim)' }}>
        Every report is plain JSON. Edit the definition to change columns, grouping, filters, sorting or the chart, then <b>Run</b> it.
        <b> Save as custom report</b> keeps your version in this browser under Reports › My reports. Datasets:{' '}
        <code>salesLines, salesInvoices, arOpen, purchaseLines, bills, apOpen, stockStatus, stockMovements, receipts, payments, journalLines, expenses, trialBalance, customers, suppliers, fixedAssets, depreciation, bankTransactions, vatOutput, vatInput, posSales</code>
        . Column formats: <code>money, number, number2, int, percent, date, text</code>; aggregates: <code>sum, avg, count, countDistinct, min, max, first, none</code>.
      </p>
      <textarea className="rp-json" value={text} onChange={(e) => setText(e.target.value)} spellCheck={false} />
      {msg && <p style={{ color: 'var(--danger)', fontSize: 12 }}>{msg}</p>}
      <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <button className="btn" onClick={() => { const d = parse(); if (d) onApply(d); }}>
          Run this definition
        </button>
        <button
          className="btn secondary"
          onClick={() => {
            const d = parse();
            if (!d) return;
            const list = loadCustomReports();
            const id = d.custom && list.some((x) => x.id === d.id) ? d.id : `custom-${slug(d.title)}-${Date.now().toString(36)}`;
            const saved = { ...d, id, custom: true, module: d.module || 'My reports' };
            saveCustomReports([...list.filter((x) => x.id !== id), saved]);
            setMsg('');
            navigate(`/reports/${id}`);
          }}
        >
          {def.custom ? 'Save changes' : 'Save as custom report'}
        </button>
        <button className="btn secondary" onClick={() => navigator.clipboard?.writeText(text)}>
          Copy JSON
        </button>
        <button className="btn secondary" onClick={() => exportJson(JSON.parse(text), slug(def.title) + '-definition')}>
          Download JSON
        </button>
        {def.custom && (
          <button
            className="btn danger"
            onClick={() => {
              saveCustomReports(loadCustomReports().filter((x) => x.id !== def.id));
              navigate('/reports');
            }}
          >
            Delete custom report
          </button>
        )}
      </div>
    </div>
  );
}
