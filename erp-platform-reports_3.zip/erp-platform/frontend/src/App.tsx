import React, { Suspense, lazy } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CompanyProvider } from './context/CompanyContext';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import AccountingPage from './pages/AccountingPage';
import InventoryPage from './pages/InventoryPage';
import PayablesPage from './pages/PayablesPage';
import ReceivablesPage from './pages/ReceivablesPage';
import BankingPage from './pages/BankingPage';
import FixedAssetsPage from './pages/FixedAssetsPage';
import CurrencyPage from './pages/CurrencyPage';
import PosPage from './pages/PosPage';
import SettingsPage from './pages/SettingsPage';
import ErrorBoundary from './components/ErrorBoundary';

// Report & invoice-print pages pull in the PDF / Excel libraries, so they are
// loaded on demand: the rest of the app keeps working even if those
// packages are missing, and the first page load stays small.
const ReportsPage = lazy(() => import('./pages/ReportsPage'));
const TaxInvoicePrintPage = lazy(() => import('./pages/TaxInvoicePrintPage'));

const loading = <p style={{ color: 'var(--text-dim)', padding: 24 }}>Loading…</p>;
const guard = (label: string, el: React.ReactNode) => (
  <ErrorBoundary label={label}>
    <Suspense fallback={loading}>{el}</Suspense>
  </ErrorBoundary>
);

function Protected({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const hasToken = !!localStorage.getItem('kruxus_token');
  if (!user && !hasToken) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/print/invoice/:id"
          element={
            <Protected>
              {guard('Tax invoice', <TaxInvoicePrintPage />)}
            </Protected>
          }
        />
        <Route
          path="/*"
          element={
            <Protected>
              <CompanyProvider>
                <Layout />
              </CompanyProvider>
            </Protected>
          }
        >
          <Route index element={guard('Dashboard', <DashboardPage />)} />
          <Route path="accounting/*" element={<AccountingPage />} />
          <Route path="inventory/*" element={<InventoryPage />} />
          <Route path="payables/*" element={<PayablesPage />} />
          <Route path="receivables/*" element={<ReceivablesPage />} />
          <Route path="banking/*" element={<BankingPage />} />
          <Route path="fixed-assets/*" element={<FixedAssetsPage />} />
          <Route path="currency/*" element={<CurrencyPage />} />
          <Route path="pos/*" element={<PosPage />} />
          <Route path="reports/*" element={guard('Reports', <ReportsPage />)} />
          <Route path="settings/*" element={<SettingsPage />} />
        </Route>
      </Routes>
    </AuthProvider>
  );
}
