import axios from 'axios';

export const api = axios.create({ baseURL: '/api/v1' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('kruxus_token');
  if (token) {
    config.headers.set('Authorization', `Bearer ${token}`);
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err?.response?.status === 401) {
      localStorage.removeItem('kruxus_token');
      localStorage.removeItem('kruxus_user');
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  },
);

// Money helpers: all amounts travel as integer minor units (cents) over the wire.
export function formatMoney(minor: number | string | undefined | null, currency = 'LKR'): string {
  const n = Number(minor || 0) / 100;
  return new Intl.NumberFormat('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) + ' ' + currency;
}

export function toMinor(major: number): number {
  return Math.round(major * 100);
}
