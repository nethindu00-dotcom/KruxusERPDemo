// Export helpers: Excel (exceljs), PDF (jsPDF + autotable), CSV and JSON.
// Heavy libraries are loaded on demand so they don't bloat the initial bundle.
import { money, num, pct } from './format';

export type ColFormat = 'money' | 'number' | 'number2' | 'percent' | 'date' | 'text' | 'int';

export interface ExportColumn {
  key: string;
  label: string;
  format?: ColFormat;
  width?: number; // characters (Excel)
  align?: 'left' | 'right' | 'center';
}

export interface ExportRowStyle {
  bold?: boolean;
  indent?: number;
  italic?: boolean;
  topBorder?: boolean;
  doubleBottom?: boolean;
  fill?: string; // hex without '#'
}

export interface ExportSheet {
  name: string; // Excel sheet name
  title: string;
  subtitle?: string;
  columns: ExportColumn[];
  rows: Record<string, any>[];
  totals?: Record<string, any> | null;
  rowStyle?: (row: Record<string, any>) => ExportRowStyle | undefined;
  /** Key/value block printed above the table (e.g. VAT return summary boxes). */
  summary?: { label: string; value: string }[];
}

export interface ExportMeta {
  companyName: string;
  companyDetail?: string;
  generatedBy?: string;
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function formatCell(v: any, f?: ColFormat): string {
  if (v === null || v === undefined || v === '') return '';
  switch (f) {
    case 'money':
      return money(v, { brackets: true });
    case 'number':
      return num(v, Number.isInteger(Number(v)) ? 0 : 2);
    case 'int':
      return num(v, 0);
    case 'number2':
      return num(v, 2);
    case 'percent':
      return pct(v, 2);
    default:
      return String(v);
  }
}

const isNumeric = (f?: ColFormat) => f === 'money' || f === 'number' || f === 'percent' || f === 'number2' || f === 'int';

// ---------------------------------------------------------------- Excel
export async function exportExcel(sheets: ExportSheet[], meta: ExportMeta, filename: string) {
  const ExcelJS = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook();
  wb.creator = meta.generatedBy || 'Kruxus ERP';
  wb.created = new Date();
  for (const s of sheets) {
    const ws = wb.addWorksheet(s.name.replace(/[\\/?*[\]:]/g, ' ').slice(0, 31), {
      views: [{ state: 'frozen', ySplit: 0 }],
      pageSetup: { orientation: s.columns.length > 7 ? 'landscape' : 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9 },
    });
    const ncol = s.columns.length;
    let r = 1;
    const head = (text: string, size: number, bold = true, color = '1F2937') => {
      ws.mergeCells(r, 1, r, Math.max(ncol, 1));
      const c = ws.getCell(r, 1);
      c.value = text;
      c.font = { bold, size, color: { argb: 'FF' + color } };
      r++;
    };
    head(meta.companyName, 14);
    if (meta.companyDetail) head(meta.companyDetail, 9, false, '6B7280');
    head(s.title, 12);
    if (s.subtitle) head(s.subtitle, 10, false, '4B5563');
    head(`Generated ${new Date().toLocaleString()}`, 8, false, '9CA3AF');
    r++;
    if (s.summary?.length) {
      for (const kv of s.summary) {
        ws.getCell(r, 1).value = kv.label;
        ws.getCell(r, 1).font = { bold: true };
        ws.getCell(r, Math.min(3, ncol)).value = kv.value;
        r++;
      }
      r++;
    }
    const headerRow = r;
    s.columns.forEach((col, i) => {
      const c = ws.getCell(r, i + 1);
      c.value = col.label;
      c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3A68' } };
      c.alignment = { horizontal: isNumeric(col.format) ? 'right' : 'left', vertical: 'middle', wrapText: true };
      c.border = { bottom: { style: 'thin' } };
    });
    ws.getRow(r).height = 20;
    r++;
    const writeRow = (row: Record<string, any>, style?: ExportRowStyle) => {
      s.columns.forEach((col, i) => {
        const c = ws.getCell(r, i + 1);
        let v = row[col.key];
        if (v === undefined || v === null || v === '') {
          c.value = null;
        } else if (col.format === 'money') {
          c.value = Number(v) / 100;
          c.numFmt = '#,##0.00;(#,##0.00);-';
        } else if (col.format === 'percent') {
          c.value = Number(v) / 100;
          c.numFmt = '0.00%';
        } else if (col.format === 'number' || col.format === 'int' || col.format === 'number2') {
          c.value = Number(v);
          c.numFmt = col.format === 'number2' ? '#,##0.00' : '#,##0.##';
        } else if (col.format === 'date' && /^\d{4}-\d{2}-\d{2}/.test(String(v))) {
          const [y, m, d] = String(v).slice(0, 10).split('-').map(Number);
          c.value = new Date(Date.UTC(y, m - 1, d));
          c.numFmt = 'yyyy-mm-dd';
        } else {
          c.value = String(v);
        }
        if (style) {
          c.font = { bold: !!style.bold, italic: !!style.italic };
          if (style.fill) c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF' + style.fill } };
          if (style.topBorder || style.doubleBottom)
            c.border = {
              ...(style.topBorder ? { top: { style: 'thin' } } : {}),
              ...(style.doubleBottom ? { bottom: { style: 'double' } } : {}),
            };
          if (i === 0 && style.indent) c.alignment = { indent: style.indent };
        }
      });
      r++;
    };
    for (const row of s.rows) writeRow(row, s.rowStyle?.(row));
    if (s.totals) writeRow(s.totals, { bold: true, topBorder: true, doubleBottom: true, fill: 'EEF2FF' });
    if (!s.rowStyle && s.rows.length) {
      ws.autoFilter = { from: { row: headerRow, column: 1 }, to: { row: headerRow + s.rows.length, column: ncol } };
    }
    ws.views = [{ state: 'frozen', ySplit: headerRow }];
    s.columns.forEach((col, i) => {
      const longest = Math.max(
        col.label.length,
        ...s.rows.slice(0, 300).map((row) => formatCell(row[col.key], col.format).length),
      );
      ws.getColumn(i + 1).width = col.width || Math.min(60, Math.max(10, longest + 2));
    });
  }
  const buf = await wb.xlsx.writeBuffer();
  download(new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), filename + '.xlsx');
}

// ---------------------------------------------------------------- PDF
export async function exportPdf(sheets: ExportSheet[], meta: ExportMeta, filename: string, opts: { orientation?: 'p' | 'l' } = {}) {
  const { jsPDF } = await import('jspdf');
  const autoTable = (await import('jspdf-autotable')).default;
  const wide = sheets.some((s) => s.columns.length > 7);
  const doc = new jsPDF({ orientation: opts.orientation || (wide ? 'l' : 'p'), unit: 'pt', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  sheets.forEach((s, si) => {
    if (si > 0) doc.addPage();
    let y = 40;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text(meta.companyName, 40, y);
    y += 14;
    if (meta.companyDetail) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(110);
      doc.text(meta.companyDetail, 40, y);
      doc.setTextColor(0);
      y += 14;
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text(s.title, 40, y + 4);
    y += 18;
    if (s.subtitle) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(s.subtitle, 40, y);
      y += 12;
    }
    if (s.summary?.length) {
      autoTable(doc, {
        startY: y + 4,
        body: s.summary.map((kv) => [kv.label, kv.value]),
        theme: 'plain',
        styles: { fontSize: 8.5, cellPadding: 2 },
        columnStyles: { 0: { fontStyle: 'bold', cellWidth: 220 }, 1: { halign: 'right', cellWidth: 140 } },
        margin: { left: 40 },
        tableWidth: 360,
      });
      y = (doc as any).lastAutoTable.finalY + 8;
    }
    const styles: (ExportRowStyle | undefined)[] = s.rows.map((r) => s.rowStyle?.(r));
    const body = s.rows.map((row) => s.columns.map((c) => formatCell(row[c.key], c.format)));
    autoTable(doc, {
      startY: y + 4,
      head: [s.columns.map((c) => c.label)],
      body,
      foot: s.totals ? [s.columns.map((c) => formatCell(s.totals![c.key], c.format))] : undefined,
      theme: s.rowStyle ? 'plain' : 'striped',
      styles: { fontSize: s.columns.length > 10 ? 6.5 : 8, cellPadding: 3, overflow: 'linebreak' },
      headStyles: { fillColor: [31, 58, 104], textColor: 255, fontStyle: 'bold' },
      footStyles: { fillColor: [238, 242, 255], textColor: 20, fontStyle: 'bold' },
      columnStyles: Object.fromEntries(
        s.columns.map((c, i) => [i, { halign: isNumeric(c.format) ? 'right' : c.align || 'left' }]),
      ) as any,
      margin: { left: 40, right: 40, bottom: 40 },
      didParseCell: (data: any) => {
        if (data.section === 'head') {
          data.cell.styles.halign = isNumeric(s.columns[data.column.index]?.format) ? 'right' : 'left';
        }
        if (data.section !== 'body') return;
        const st = styles[data.row.index];
        if (!st) return;
        if (st.bold) data.cell.styles.fontStyle = 'bold';
        if (st.italic) data.cell.styles.fontStyle = 'italic';
        if (st.fill) data.cell.styles.fillColor = st.fill;
        if (data.column.index === 0 && st.indent) data.cell.styles.cellPadding = { left: 3 + st.indent * 10, top: 3, bottom: 3, right: 3 };
        if (st.topBorder) {
          data.cell.styles.lineWidth = { top: 0.6 };
          data.cell.styles.lineColor = 60;
        }
      },
    });
  });
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(130);
    const h = doc.internal.pageSize.getHeight();
    doc.text(`${meta.companyName} · generated ${new Date().toLocaleString()}`, 40, h - 20);
    doc.text(`Page ${i} of ${pages}`, pageW - 40, h - 20, { align: 'right' });
  }
  doc.save(filename + '.pdf');
}

// ---------------------------------------------------------------- CSV / JSON
export function exportCsv(sheet: ExportSheet, filename: string) {
  const esc = (v: any) => {
    const s = v === null || v === undefined ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const val = (v: any, f?: ColFormat) => (v === null || v === undefined ? '' : f === 'money' ? (Number(v) / 100).toFixed(2) : v);
  const lines = [sheet.columns.map((c) => esc(c.label)).join(',')];
  for (const r of sheet.rows) lines.push(sheet.columns.map((c) => esc(val(r[c.key], c.format))).join(','));
  if (sheet.totals) lines.push(sheet.columns.map((c) => esc(val(sheet.totals![c.key], c.format))).join(','));
  download(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }), filename + '.csv');
}

export function exportJson(data: any, filename: string) {
  download(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), filename + '.json');
}
