// Formatting helpers shared by reports, statements, dashboard and invoice print.
// All money travels as integer minor units (cents).

export const SERIES = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767'];
export const STATUS = { good: '#22c58b', warning: '#f5a623', critical: '#ff5c6c', neutral: '#9aa5bd' };

const nf2 = new Intl.NumberFormat('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf0 = new Intl.NumberFormat('en-LK', { maximumFractionDigits: 0 });

/** 12,345.67 (no currency code). Negative shown in brackets for statements when `brackets` is set. */
export function money(minor: number | null | undefined, opts: { brackets?: boolean; whole?: boolean } = {}): string {
  const v = Number(minor || 0) / 100;
  const f = opts.whole ? nf0 : nf2;
  if (opts.brackets && v < 0) return `(${f.format(Math.abs(v))})`;
  return f.format(v);
}

/** Compact money for tiles/axes: 1.2M, 845K. */
export function moneyShort(minor: number | null | undefined): string {
  const v = Number(minor || 0) / 100;
  const a = Math.abs(v);
  if (a >= 1e9) return (v / 1e9).toFixed(2) + 'B';
  if (a >= 1e6) return (v / 1e6).toFixed(a >= 1e7 ? 1 : 2) + 'M';
  if (a >= 1e3) return (v / 1e3).toFixed(0) + 'K';
  return v.toFixed(0);
}

export function num(v: number | null | undefined, dp = 0): string {
  return new Intl.NumberFormat('en-LK', { minimumFractionDigits: dp, maximumFractionDigits: dp }).format(Number(v || 0));
}

export function pct(v: number | null | undefined, dp = 1): string {
  if (v === null || v === undefined || isNaN(Number(v))) return '–';
  return `${Number(v).toFixed(dp)}%`;
}

/** ISO yyyy-mm-dd -> MM/DD/YYYY (the format the Sri Lanka tax invoice specification calls for). */
export function usDate(isoDate?: string | null): string {
  if (!isoDate) return '';
  const [y, m, d] = isoDate.slice(0, 10).split('-');
  return `${m}/${d}/${y}`;
}

/** ISO -> 03 Oct 2026 */
export function niceDate(isoDate?: string | null): string {
  if (!isoDate) return '';
  const d = new Date(isoDate.slice(0, 10) + 'T00:00:00Z');
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

export function todayIso(): string {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

export function addDays(isoDate: string, days: number): string {
  const d = new Date(isoDate + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** Sri Lankan fiscal year (1 April - 31 March) start for a date. */
export function fiscalYearStart(isoDate: string): string {
  const [y, m] = isoDate.split('-').map(Number);
  return `${m >= 4 ? y : y - 1}-04-01`;
}

export type DatePreset =
  | 'today' | 'thisMonth' | 'lastMonth' | 'thisQuarter' | 'lastQuarter' | 'fy' | 'lastFy' | 'last30' | 'last90' | 'all';

export const DATE_PRESETS: { key: DatePreset; label: string }[] = [
  { key: 'today', label: 'Today' },
  { key: 'thisMonth', label: 'This month' },
  { key: 'lastMonth', label: 'Last month' },
  { key: 'thisQuarter', label: 'This quarter' },
  { key: 'lastQuarter', label: 'Last quarter' },
  { key: 'last30', label: 'Last 30 days' },
  { key: 'last90', label: 'Last 90 days' },
  { key: 'fy', label: 'This fiscal year' },
  { key: 'lastFy', label: 'Last fiscal year' },
  { key: 'all', label: 'All time' },
];

export function presetRange(p: DatePreset, ref = todayIso()): { from: string; to: string } {
  const [y, m] = ref.split('-').map(Number);
  const iso = (yy: number, mm: number, dd: number) => new Date(Date.UTC(yy, mm - 1, dd)).toISOString().slice(0, 10);
  switch (p) {
    case 'today':
      return { from: ref, to: ref };
    case 'thisMonth':
      return { from: iso(y, m, 1), to: ref };
    case 'lastMonth':
      return { from: iso(y, m - 1, 1), to: iso(y, m, 0) };
    case 'thisQuarter': {
      const q = Math.floor((m - 1) / 3) * 3 + 1;
      return { from: iso(y, q, 1), to: ref };
    }
    case 'lastQuarter': {
      const q = Math.floor((m - 1) / 3) * 3 + 1;
      return { from: iso(y, q - 3, 1), to: iso(y, q, 0) };
    }
    case 'last30':
      return { from: addDays(ref, -29), to: ref };
    case 'last90':
      return { from: addDays(ref, -89), to: ref };
    case 'fy':
      return { from: fiscalYearStart(ref), to: ref };
    case 'lastFy': {
      const s = fiscalYearStart(ref);
      return { from: fiscalYearStart(addDays(s, -1)), to: addDays(s, -1) };
    }
    case 'all':
      return { from: '2000-01-01', to: ref };
  }
}

// ---------------------------------------------------------------- amount in words
const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve',
  'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

function below1000(n: number): string {
  const parts: string[] = [];
  if (n >= 100) {
    parts.push(ONES[Math.floor(n / 100)] + ' Hundred');
    n %= 100;
    if (n) parts.push('and');
  }
  if (n >= 20) {
    parts.push(TENS[Math.floor(n / 10)] + (n % 10 ? '-' + ONES[n % 10] : ''));
  } else if (n > 0) parts.push(ONES[n]);
  return parts.join(' ');
}

/** Integer to words using the international (million/billion) scale. */
export function integerToWords(n: number): string {
  n = Math.floor(Math.abs(n));
  if (n === 0) return 'Zero';
  const scales = [
    [1e12, 'Trillion'],
    [1e9, 'Billion'],
    [1e6, 'Million'],
    [1e3, 'Thousand'],
  ] as const;
  const out: string[] = [];
  for (const [v, name] of scales) {
    if (n >= v) {
      out.push(below1000(Math.floor(n / v)) + ' ' + name);
      n %= v;
    }
  }
  if (n > 0) out.push(below1000(n));
  return out.join(' ');
}

/** "Sri Lankan Rupees One Hundred and Twenty Thousand and Cents Fifty Only" */
export function amountInWords(minor: number, currency = 'LKR'): string {
  const neg = minor < 0;
  minor = Math.abs(Math.round(minor));
  const major = Math.floor(minor / 100);
  const cents = minor % 100;
  const curName = currency === 'LKR' ? 'Sri Lankan Rupees' : currency === 'USD' ? 'US Dollars' : currency;
  const centName = currency === 'LKR' ? 'Cents' : 'Cents';
  let s = `${curName} ${integerToWords(major)}`;
  if (cents) s += ` and ${centName} ${integerToWords(cents)}`;
  return (neg ? 'Minus ' : '') + s + ' Only';
}

export function slug(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}
