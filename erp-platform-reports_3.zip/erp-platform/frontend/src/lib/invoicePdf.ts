// Vector PDF of a Sri Lanka VAT tax invoice (jsPDF + autotable), matching the
// on-screen print layout in TaxInvoicePrintPage.
import { amountInWords, money, usDate } from './format';

export interface InvoiceLineView {
  lineNo: number;
  itemCode: string;
  description: string;
  brand?: string | null;
  warrantyMonths?: number | null;
  unitOfMeasure: string;
  quantity: number;
  unitPriceMinor: number;
  netMinor: number;
  vatRateBp: number;
  vatMinor: number;
  grossMinor: number;
}

export interface InvoiceView {
  docTitle: string;
  copyLabel?: string;
  invoiceNumber: string;
  invoiceDate: string;
  supplyDate: string;
  dueDate: string;
  currency: string;
  supplier: { name: string; tradingName?: string; address: string; tin: string; vatNo: string; phone?: string; email?: string };
  purchaser: { name: string; address: string; tin: string; vatNo: string; phone?: string };
  placeOfSupply: string;
  paymentMode: string;
  salesPerson?: string;
  reference?: string;
  lines: InvoiceLineView[];
  totals: { net: number; vat: number; gross: number; received: number; balance: number };
  whole: boolean;
  showWarranty: boolean;
  bankDetails?: string;
  footer?: string;
}

const m = (v: number, whole: boolean) => money(v, { whole });

export async function downloadTaxInvoicePdf(v: InvoiceView) {
  const { jsPDF } = await import('jspdf');
  const autoTable = (await import('jspdf-autotable')).default;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const L = 36;
  const R = W - 36;
  let y = 40;

  // Supplier block
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(v.supplier.name, L, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  y += 13;
  if (v.supplier.tradingName) {
    doc.text(v.supplier.tradingName, L, y);
    y += 11;
  }
  doc.text(v.supplier.address || '', L, y);
  y += 11;
  doc.text([v.supplier.phone && `Tel: ${v.supplier.phone}`, v.supplier.email].filter(Boolean).join('   ·   '), L, y);
  y += 11;
  doc.setFont('helvetica', 'bold');
  doc.text(`Supplier TIN: ${v.supplier.tin || '-'}     VAT Reg. No: ${v.supplier.vatNo || '-'}`, L, y);

  // Title box
  doc.setDrawColor(20);
  doc.setLineWidth(1.2);
  doc.rect(R - 200, 26, 200, 30);
  doc.setFontSize(16);
  doc.text(v.docTitle, R - 100, 46, { align: 'center' });
  if (v.copyLabel) {
    doc.setFontSize(8);
    doc.setTextColor(200, 30, 30);
    doc.text(v.copyLabel, R - 100, 66, { align: 'center' });
    doc.setTextColor(0);
  }
  doc.setFontSize(8.5);
  const meta: [string, string][] = [
    ['Invoice No', v.invoiceNumber],
    ['Invoice Date', usDate(v.invoiceDate)],
    ['Date of Supply', usDate(v.supplyDate)],
    ['Due Date', usDate(v.dueDate)],
  ];
  let my = 80;
  meta.forEach(([k, val]) => {
    doc.setFont('helvetica', 'normal');
    doc.text(k, R - 200, my);
    doc.setFont('helvetica', 'bold');
    doc.text(val, R, my, { align: 'right' });
    my += 12;
  });

  y = Math.max(y, my) + 12;
  doc.setLineWidth(0.5);
  doc.line(L, y, R, y);
  y += 14;

  // Purchaser + supply details
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('PURCHASER', L, y);
  doc.text('SUPPLY DETAILS', W / 2 + 10, y);
  y += 12;
  doc.setFontSize(9);
  doc.text(v.purchaser.name || '', L, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  const pLines = [
    ...(doc.splitTextToSize(v.purchaser.address || '', W / 2 - L - 10) as string[]),
    v.purchaser.phone ? `Tel: ${v.purchaser.phone}` : '',
    `Purchaser TIN: ${v.purchaser.tin || 'N/A (not VAT registered)'}`,
    v.purchaser.vatNo ? `VAT Reg. No: ${v.purchaser.vatNo}` : '',
  ].filter(Boolean);
  pLines.forEach((t, i) => doc.text(t, L, y + 11 + i * 11));
  const sLines: [string, string][] = [
    ['Place of supply', v.placeOfSupply],
    ['Mode of payment', v.paymentMode],
    ['Currency', v.currency],
    ['Sales person', v.salesPerson || '-'],
    ['Reference', v.reference || '-'],
  ];
  sLines.forEach(([k, val], i) => {
    doc.setFont('helvetica', 'normal');
    doc.text(k, W / 2 + 10, y + i * 11);
    doc.setFont('helvetica', 'bold');
    doc.text(String(val || '-').slice(0, 48), R, y + i * 11, { align: 'right' });
  });
  y += Math.max(pLines.length * 11 + 14, sLines.length * 11 + 6);

  const head = [['#', 'Item code', 'Description', 'Qty', 'Unit price\n(excl. VAT)', 'Amount\n(excl. VAT)', 'VAT\nrate', 'VAT\namount', 'Amount\n(incl. VAT)']];
  const body = v.lines.map((l) => [
    String(l.lineNo),
    l.itemCode,
    l.description + (v.showWarranty && l.warrantyMonths ? `\nWarranty: ${l.warrantyMonths} months` : ''),
    `${l.quantity} ${l.unitOfMeasure}`,
    m(l.unitPriceMinor, v.whole),
    m(l.netMinor, v.whole),
    `${(l.vatRateBp / 100).toFixed(0)}%`,
    m(l.vatMinor, v.whole),
    m(l.grossMinor, v.whole),
  ]);
  autoTable(doc, {
    startY: y,
    head,
    body,
    theme: 'grid',
    styles: { fontSize: 7.8, cellPadding: 3, lineColor: 160, lineWidth: 0.4, textColor: 20 },
    headStyles: { fillColor: [235, 238, 245], textColor: 20, fontStyle: 'bold', halign: 'center', valign: 'middle' },
    columnStyles: {
      0: { cellWidth: 18, halign: 'center' },
      1: { cellWidth: 70 },
      2: { cellWidth: 'auto' },
      3: { cellWidth: 38, halign: 'right' },
      4: { cellWidth: 62, halign: 'right' },
      5: { cellWidth: 66, halign: 'right' },
      6: { cellWidth: 30, halign: 'center' },
      7: { cellWidth: 56, halign: 'right' },
      8: { cellWidth: 66, halign: 'right' },
    },
    margin: { left: L, right: 36 },
  });
  y = (doc as any).lastAutoTable.finalY + 10;
  if (y > 680) {
    doc.addPage();
    y = 50;
  }

  // Totals
  const tot: [string, string, boolean][] = [
    ['Total value of supply (excl. VAT)', m(v.totals.net, v.whole), false],
    ['VAT @ 18%', m(v.totals.vat, v.whole), false],
    [`Total consideration (incl. VAT) ${v.currency}`, m(v.totals.gross, v.whole), true],
  ];
  if (v.totals.received) {
    tot.push(['Less: amount received', m(v.totals.received, v.whole), false]);
    tot.push(['Balance due', m(v.totals.balance, v.whole), true]);
  }
  tot.forEach(([k, val, bold], i) => {
    doc.setFont('helvetica', bold ? 'bold' : 'normal');
    doc.setFontSize(bold ? 9.5 : 8.8);
    doc.text(k, R - 120, y + i * 14, { align: 'right' });
    doc.text(val, R, y + i * 14, { align: 'right' });
  });
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('Total in words:', L, y);
  doc.setFont('helvetica', 'normal');
  const words = doc.splitTextToSize(amountInWords(v.whole ? Math.round(v.totals.gross / 100) * 100 : v.totals.gross, v.currency), 260) as string[];
  doc.text(words, L, y + 11);
  y += Math.max(tot.length * 14, words.length * 11 + 14) + 18;

  doc.setFontSize(7.8);
  if (v.bankDetails) {
    doc.setFont('helvetica', 'bold');
    doc.text('Bank details:', L, y);
    doc.setFont('helvetica', 'normal');
    doc.text(v.bankDetails, L + 58, y);
    y += 12;
  }
  if (v.footer) {
    const f = doc.splitTextToSize(v.footer, R - L) as string[];
    doc.text(f, L, y);
    y += f.length * 10 + 6;
  }
  y = Math.max(y + 30, 740);
  doc.setLineWidth(0.5);
  doc.line(L, y, L + 170, y);
  doc.line(R - 170, y, R, y);
  doc.setFontSize(7.8);
  doc.text('Authorised signature (supplier)', L, y + 11);
  doc.text('Received by - goods received in good order', R - 170, y + 11);
  doc.setTextColor(120);
  doc.setFontSize(7);
  doc.text('This is a computer-generated tax invoice.', W / 2, 818, { align: 'center' });
  doc.save(`${v.invoiceNumber}.pdf`);
}
