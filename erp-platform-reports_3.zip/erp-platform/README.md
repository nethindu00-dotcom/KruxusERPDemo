# Kruxus ERP — Setup & Demo Guide

A full ERP + POS demo build: **Inventory, Finance/GL, Banking, Fixed
Assets, Accounts Payable, Currency Management, Accounts Receivable, POS,
and a Dashboard** — all in one app, with no database to install. Every
screen is backed by real, verified demo data for two companies, loaded
straight into memory when the app starts.

## What's inside

**Backend** (NestJS, `backend/`): Auth, Companies/Branches (multi-company),
General Ledger (Chart of Accounts + journal entries with built-in
multi-currency support), Tax (VAT 18% + SSCL), Inventory (items, item
classes, weighted-average costing), Purchasing + Payables (suppliers, POs,
goods receipts, bills, payments, AP aging), Sales + Receivables (customers,
sales orders, deliveries, invoices, receipts, AR aging), Banking (bank
accounts, statement import, auto-reconciliation), Fixed Assets (asset
register, categories, depreciation runs, disposal), Currency Management
(multi-currency rates, realized/unrealized FX gain-loss, period-end
revaluation), POS (cashier sessions, item lookup/checkout that posts a real
invoice + stock issue + GL entry).

**No database**: there is no MySQL, no TypeORM, no connection string
anywhere in this build. On startup, the backend loads a bundled set of JSON
files (`backend/src/database/seed-data/`) straight into memory and serves
everything from there — the exact same REST API shapes as before, just
with zero install/setup. Anything you create or change while using the app
(a new invoice, a POS sale, etc.) lives only in that running process's
memory and resets the next time the backend restarts; the bundled demo
data itself never changes.

**Frontend** (React + Vite, `frontend/`): a full admin app with a
**Dashboard** (cash, AR/AP aging, stock value, fixed assets, sales trend,
POS today) plus one page per module above, including a touch-friendly POS
terminal screen.

**Demo data**: two companies, both with real, GL-balanced trading history,
seeded from the exact same verified figures as the earlier MySQL-backed
build:

- **Demo Retail (Pvt) Ltd** (trading as *Demo Computers & Parts*) — a
  computer-hardware parts retailer: 73 stock SKUs across 13 categories (CPUs,
  GPUs, motherboards, RAM, SSD/HDD, PSUs, cases, cooling, monitors,
  peripherals, networking, laptops, accessories), ~400 VAT invoices
  (walk-in counter sales, custom PC builds, corporate and reseller orders),
  weekly replenishment POs/GRNs/bills from local distributors, customer
  receipts, supplier payments, monthly operating expenses, VAT settlements
  and matched bank statement lines, Jul–Oct 2026. Every journal balances.
  Originally an IT reseller demo company. ~3 months of
  purchase-to-pay and order-to-cash cycles, multi-currency USD supplier
  bills, fixed assets with depreciation runs, bank reconciliation, and a few
  POS sales. Trial balance balanced.
- **Serendib Home Care Distributors (Pvt) Ltd** — built from the Excel file
  you originally attached (`Serendib_Management_Accounts_Sep2026.xlsx`).
  Its September 2026 trial balance, AR/AP ledgers, fixed asset register,
  inventory and bank reconciliation match the spreadsheet's closing numbers
  to the rupee.

## Running it on Windows (easiest way)

See **SETUP_WINDOWS.md** in this folder — install Node.js, then
double-click `start_kruxus.bat`, which installs dependencies on first run
and starts everything (no database setup, no seeding step).

## Running it manually (Mac/Linux, or Windows via a terminal)

Requires Node 18+. Nothing else.

```bash
# 1. Backend
cd backend
npm install
npm run start:dev         # http://localhost:3001/api/v1 - loads the bundled demo data automatically

# 2. Frontend (new terminal)
cd frontend
npm install
npm run dev                # http://localhost:5173
```

**Login**: `admin@kruxus.local` / `Kruxus@2026`

Switch between the two companies from the dropdown at the top of the app.

## What's deliberately out of scope

This build covers inventory, finance, banking, fixed assets, AP, currency
management, receivables, POS, and a dashboard — everything named in the
original brief — plus the tax/GL foundation underneath it. It does **not**
include: a CRM/opportunity pipeline, project accounting with billing rules,
an expense-report/corporate-card module, a generic approval-workflow
engine, scheduled automation/business events, a report designer or
generic-inquiry/BI layer, field-level security or MFA, or a formal
webhook/integration-connector layer, or persistent storage (see below).
Each of those is realistically weeks-to-months of additional work on its
own — happy to scope any one of them next if it matters for the demo.

## Known limitations

- **No persistence.** This build deliberately has no database — it's built
  for "install nothing, click through it now." Anything you add while using
  it is gone when the backend process restarts. If you need a real,
  persistent multi-user system later, that's a different (bigger) build.
- The POS and other best-effort multi-step flows (checkout, revaluation)
  run as a sequence of in-memory writes rather than one atomic transaction
  across module boundaries — a demo-grade tradeoff, not a correctness bug.


## Reports, financial statements & VAT invoices (new)

**Reports workspace** (`/reports`, sidebar → Reports): 53 Acumatica-style
reports grouped by module — Financial Statements, Tax (VAT), Sales,
Receivables, Purchasing & Payables, Inventory, Fixed Assets & Banking.

- **Financial statements** straight from the general ledger: Profit & Loss
  (with prior-period / prior-year comparison and variance, or monthly
  columns), Balance Sheet (with comparative date and balance check), Cash
  Flow (indirect method, reconciled to the cash ledger), Changes in Equity,
  six-column Trial Balance, GL detail, Journal register. Click any account
  line to drill down to its ledger entries.
- **VAT**: VAT return workings (taxable supplies, output VAT, local/import
  input VAT, net payable) with output and input tax schedules.
- **Sales / purchasing / inventory analytics**: by category, brand, SKU,
  customer, salesperson, channel, weekday; margin and discount analysis; PC
  build sales; AR/AP aging (summary cross-tab and detail), collections list,
  customer statement of account, credit-limit utilisation, cash
  requirements; inventory valuation, reorder/replenishment by supplier,
  slow-moving & dead stock, ABC analysis, turnover & days of cover, stock
  card, price list; fixed-asset register, depreciation schedule, bank
  transactions.
- **Every report** prints and exports to **PDF, Excel (.xlsx), CSV and JSON**.

**JSON-driven report engine**: every report is a plain JSON definition in
`frontend/src/reports/catalog.json` (dataset, columns + formats + aggregates,
group-by options, filters, sorting, pivot, chart, row links). The
*Definition (JSON)* tab on each report lets you edit it live, and *Save as
custom report* / *+ New custom report* keeps your own reports in the
browser. Datasets are served by `GET /api/v1/reports/datasets/:name`.

**VAT tax invoice print** (`/print/invoice/:id`, the *Tax invoice* button on
Sales & Receivables → Invoices, the POS receipt, the invoice register and the
dashboard): A4 Sri Lanka tax invoice — "TAX INVOICE" title, supplier TIN and
VAT number, purchaser TIN, invoice date and date of supply in MM/DD/YYYY,
place of supply, mode of payment, per-line value excl. VAT / VAT rate / VAT
amount, totals and total consideration in words. Options: simplified tax
invoice / invoice, duplicate / customer / office copy, whole-rupee rounding,
warranty lines. Print from the browser or **Download PDF** (vector PDF).
Check the final layout against the current IRD gazette before going live.

**Dashboard**: rebuilt for a hardware retailer — sales/GP/net profit MTD with
growth, cash runway, DSO/DPO/DIO and cash-conversion cycle, current & quick
ratios, daily sales & GP trend, monthly P&L, category margin league, top
SKUs/brands/customers, channel & payment mix, weekday pattern, sales team,
inventory health (OK / reorder / out of stock / slow / overstock), reorder
alerts, slow movers, AR/AP aging with overdue and due-soon lists, expenses,
VAT position and recent invoices. `GET /api/v1/reports/dashboard`.

**Report API** (`backend/src/modules/reports`): `profit-loss`,
`balance-sheet`, `cash-flow`, `changes-in-equity`, `vat-return`,
`invoice-print/:id`, `datasets/:name`, `dashboard`.

Also fixed: document numbers (invoices, receipts, JEs, POs, bills…) are now
issued as highest-existing + 1 instead of row-count + 1, which could re-issue
an existing number (e.g. a duplicate INV-1-14).
