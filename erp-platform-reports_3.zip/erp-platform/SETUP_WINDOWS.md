# Running Kruxus ERP on your own Windows PC

This build needs **no database and no installation besides Node.js** — all
the demo data (both companies) is bundled with the app and loaded into
memory when it starts. You only have to do the setup below once; after that,
running it again is one double-click.

## Step 1 — Install Node.js (about 2 minutes)

1. Go to **https://nodejs.org**
2. Click the button that downloads the **LTS** version.
3. Run the downloaded installer. Click **Next → Next → Install → Finish**,
   leaving every option at its default.

That's the only prerequisite — no MySQL, no database setup, no passwords.

## Step 2 — Unzip the project

1. You should have a file called **`erp-platform.zip`**.
2. Right-click it → **Extract All...** → **Extract**.
3. Open the extracted `erp-platform` folder.

## Step 3 — Run it

1. Double-click **`start_kruxus.bat`**.
2. A black window (Command Prompt) will open. The first time, it installs
   what it needs (you'll see a lot of text scroll by — that's normal, and
   only happens once). Then it starts the backend and frontend (two new
   black windows will open — leave them open, that's the app running).
3. Your browser will open automatically to the login page.

**Login**: `admin@kruxus.local` / `Kruxus@2026`

Use the dropdown at the top of the app to switch between **Demo Retail (Pvt)
Ltd** and **Serendib Home Care Distributors (Pvt) Ltd**.

## Next time

Just double-click `start_kruxus.bat` again — it skips straight to starting
the app (takes about 15 seconds).

## Updating to a newer version (read this if the dashboard won't load)

1. **Close** the two black windows (**Kruxus ERP - Backend** and
   **Kruxus ERP - Frontend**) from the old version.
2. Unzip the new version (into a fresh folder, or over the old one - both work).
3. Double-click **`start_kruxus.bat`**.

The launcher now (a) stops any older copy still running on ports 3001/5173,
and (b) re-runs `npm install` automatically whenever `package.json` has
changed - the first start after an update takes a few extra minutes while it
downloads the new PDF/Excel export packages.

If the dashboard ever shows *"The backend that is running is an older
version"*, an old Backend window is still open - close it and run
`start_kruxus.bat` again. Manual fallback: open a terminal in the
`frontend` folder and run `npm install`, then do the same in `backend`.

## Something worth knowing: data resets on restart

This build keeps all its data in memory, not in a database. That means:

- It starts instantly with zero setup, which is the whole point for a demo.
- Anything you add or change while clicking through (a new sale, a new
  invoice, closing a POS session, etc.) is only there for as long as the
  **Backend** window stays open.
- Close that window (or restart your PC) and it goes back to the original
  bundled demo data next time you run `start_kruxus.bat` — nothing you did
  is saved permanently.

If you ever need this to be a real, persistent system (multiple people using
it, data that has to survive restarts), that's a different, bigger build —
just ask.

## If something goes wrong

Take a screenshot of the black window where the error appeared and send it
to Claude in this chat — that's the fastest way to get it fixed.

Common issue:
- **"Node.js was not found"** → Step 1 wasn't completed, or you need to close
  and reopen the window after installing.
