import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { ItemsService } from '../inventory/items.service';
import { SalesOrder, SalesOrderStatus } from './sales-order.entity';
import { SalesOrderLine } from './sales-order-line.entity';

export interface CreateSalesOrderLineInput {
  itemId: number;
  description?: string;
  quantity: number;
  unitPriceMinor?: number;
  taxRateId?: number;
}

export interface CreateSalesOrderInput {
  companyId: number;
  customerId: number;
  orderDate: string;
  currencyCode?: string;
  exchangeRate?: number;
  notes?: string;
  lines: CreateSalesOrderLineInput[];
}

@Injectable()
export class SalesOrdersService {
  constructor(
    private store: DataStore,
    private itemsService: ItemsService,
  ) {}

  findAll(companyId: number) {
    return this.store
      .find<SalesOrder>('salesOrder', (so: any) => so.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((so: any) => ({
        ...so,
        lines: this.store.find<SalesOrderLine>('salesOrderLine', (l: any) => l.soId === so.id),
      }));
  }

  async findOne(id: number): Promise<SalesOrder> {
    const so = this.store.findById<SalesOrder>('salesOrder', id);
    if (!so) throw new NotFoundException('Sales order not found');
    return {
      ...so,
      lines: this.store.find<SalesOrderLine>('salesOrderLine', (l: any) => l.soId === (so as any).id),
    } as SalesOrder;
  }

  private nextSoNumber(companyId: number): string {
    return this.store.nextDocNumber('salesOrder', 'soNumber', companyId, `SO-${companyId}-`, 0);
  }

  /**
   * Creates a sales order. For each line, the sale price and default tax
   * rate are resolved through ItemsService.resolveGlAccounts so the caller
   * never has to do manual GL/tax bookkeeping when selecting an item — both
   * remain editable overrides on the line.
   */
  async create(input: CreateSalesOrderInput): Promise<SalesOrder> {
    if (!input.lines || input.lines.length === 0) {
      throw new BadRequestException('A sales order needs at least one line');
    }

    const lineSpecs: Record<string, any>[] = [];
    for (const l of input.lines) {
      const item = await this.itemsService.findItem(l.itemId);
      const gl = await this.itemsService.resolveGlAccounts(item);
      lineSpecs.push({
        itemId: l.itemId,
        description: l.description,
        quantity: String(l.quantity),
        unitPriceMinor: String(Math.round(l.unitPriceMinor ?? Number(item.salesPriceMinor))),
        taxRateId: l.taxRateId ?? gl.defaultTaxRateId ?? undefined,
        quantityDelivered: '0',
        quantityInvoiced: '0',
      });
    }

    const so: any = this.store.insert('salesOrder', {
      companyId: input.companyId,
      soNumber: this.nextSoNumber(input.companyId),
      customerId: input.customerId,
      orderDate: input.orderDate,
      currencyCode: input.currencyCode || 'LKR',
      exchangeRate: String(input.exchangeRate ?? 1),
      notes: input.notes,
      status: SalesOrderStatus.DRAFT,
    });

    const lines = lineSpecs.map((spec) => this.store.insert('salesOrderLine', { ...spec, soId: so.id }));
    so.lines = lines;
    return so;
  }

  async update(id: number, body: Partial<SalesOrder>) {
    await this.findOne(id);
    const { lines, ...header } = body as any;
    this.store.update('salesOrder', id, header);
    return this.findOne(id);
  }

  async confirm(id: number) {
    const so = await this.findOne(id);
    if (so.status !== SalesOrderStatus.DRAFT) {
      throw new BadRequestException(`Sales order ${so.soNumber} is not in DRAFT status`);
    }
    this.store.update('salesOrder', id, { status: SalesOrderStatus.CONFIRMED });
    return this.findOne(id);
  }
}
