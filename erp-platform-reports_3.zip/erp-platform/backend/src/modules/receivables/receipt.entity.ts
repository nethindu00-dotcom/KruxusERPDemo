import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ReceiptAllocation } from './receipt-allocation.entity';

@Entity('receipt')
@Index(['companyId', 'receiptNumber'], { unique: true })
export class Receipt {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  receiptNumber: string;

  @Column()
  customerId: number;

  @Column({ type: 'date' })
  receiptDate: string;

  // The cash/bank GL account the money was received INTO. Just an
  // accountId — no dependency on a Banking module.
  @Column()
  bankAccountGlAccountId: number;

  @Column({ default: 'LKR' })
  currencyCode: string;

  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  // Total amount received, in currencyCode.
  @Column({ type: 'bigint' })
  amountMinor: string;

  @Column({ type: 'bigint', nullable: true })
  journalEntryId: number;

  @Column({ default: 'POSTED' })
  status: string;

  @OneToMany(() => ReceiptAllocation, (a) => a.receipt, { cascade: true })
  allocations: ReceiptAllocation[];

  @CreateDateColumn()
  createdAt: Date;
}
