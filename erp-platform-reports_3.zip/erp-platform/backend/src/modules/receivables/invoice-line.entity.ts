import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Invoice } from './invoice.entity';

@Entity('invoice_line')
@Index(['invoiceId'])
export class InvoiceLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => Invoice, (i) => i.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'invoice_id' })
  invoice: Invoice;

  @Column({ name: 'invoice_id' })
  invoiceId: number;

  // Nullable to allow non-item/service lines.
  @Column({ nullable: true })
  itemId: number;

  @Column()
  description: string;

  @Column({ type: 'decimal', precision: 18, scale: 4, default: 1 })
  quantity: string;

  @Column({ type: 'bigint' })
  unitPriceMinor: string;

  // Auto-filled from ItemsService.resolveGlAccounts(item).defaultTaxRateId
  // when itemId is set and this is left null at create time.
  @Column({ nullable: true })
  taxRateId: number;

  // Required when itemId is null (service/non-item lines) so postInvoice
  // knows which income account to credit.
  @Column({ nullable: true })
  incomeAccountId: number;

  // Net of tax: quantity * unitPriceMinor, rounded.
  @Column({ type: 'bigint' })
  lineTotalMinor: string;
}
