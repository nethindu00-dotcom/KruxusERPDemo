import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { CreateDeliveryInput, DeliveriesService } from './deliveries.service';

@Controller('receivables/deliveries')
export class DeliveriesController {
  constructor(private svc: DeliveriesService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: CreateDeliveryInput) {
    return this.svc.create(body);
  }
}
