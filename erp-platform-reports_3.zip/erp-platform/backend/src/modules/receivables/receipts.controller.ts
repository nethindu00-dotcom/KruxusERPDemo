import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { CreateReceiptInput, ReceiptsService } from './receipts.service';

@Controller('receivables/receipts')
export class ReceiptsController {
  constructor(private svc: ReceiptsService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: CreateReceiptInput) {
    return this.svc.createReceipt(body);
  }
}
