import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('customer')
@Index(['companyId', 'code'], { unique: true })
export class Customer {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  code: string;

  @Column()
  name: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true })
  address: string;

  @Column({ default: 'LKR' })
  defaultCurrencyCode: string;

  @Column({ type: 'int', default: 30 })
  creditTermsDays: number;

  @Column({ type: 'bigint', nullable: true })
  creditLimitMinor: string;

  // The "Trade debtors control" GL account this customer's AR posts to.
  // Stored per-customer so it can be overridden, though it is usually the
  // same shared control account across all customers.
  @Column({ nullable: true })
  arControlAccountId: number;

  @Column({ default: true })
  isActive: boolean;
}
