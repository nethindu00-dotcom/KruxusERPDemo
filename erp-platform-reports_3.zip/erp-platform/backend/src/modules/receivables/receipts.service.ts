import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService, PostLineInput } from '../accounting/accounting.service';
import { Customer } from './customer.entity';
import { Invoice, InvoiceStatus } from './invoice.entity';
import { Receipt } from './receipt.entity';
import { ReceiptAllocation } from './receipt-allocation.entity';

export interface ReceiptAllocationInput {
  invoiceId: number;
  // In the invoice's own currency (invoice.currencyCode).
  allocatedAmountMinor: number;
}

export interface CreateReceiptInput {
  companyId: number;
  customerId: number;
  receiptDate: string;
  bankAccountGlAccountId: number;
  currencyCode?: string;
  exchangeRate?: number;
  allocations: ReceiptAllocationInput[];
  // Optional: where to book the aggregate realized FX gain/loss arising from
  // allocations whose invoice was booked at a different exchange rate than
  // this receipt. If omitted, any differential is absorbed onto the bank
  // line instead of being booked separately (see postReceiptEntry).
  realizedGainAccountId?: number;
  realizedLossAccountId?: number;
}

const OPEN_INVOICE_STATUSES = [InvoiceStatus.POSTED, InvoiceStatus.PARTIALLY_PAID];

/**
 * Converts a transaction-currency minor amount to base currency using the
 * exact integer formula AccountingService.post uses internally, so any plug
 * line we compute here lands on exactly the right amount and the entry
 * balances to the unit.
 */
function toBaseMinor(amountMinor: number, exchangeRate: number): bigint {
  const amount = BigInt(Math.round(amountMinor));
  const rateScaled = BigInt(Math.round(exchangeRate * 1_000_000));
  return (amount * rateScaled) / 1_000_000n;
}

@Injectable()
export class ReceiptsService {
  constructor(
    private store: DataStore,
    private accountingService: AccountingService,
  ) {}

  findAll(companyId: number) {
    return this.store
      .find<Receipt>('receipt', (r: any) => r.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((r: any) => ({
        ...r,
        allocations: this.store.find<ReceiptAllocation>('receiptAllocation', (a: any) => a.receiptId === r.id),
      }));
  }

  async findOne(id: number): Promise<Receipt> {
    const receipt = this.store.findById<Receipt>('receipt', id);
    if (!receipt) throw new NotFoundException('Receipt not found');
    return {
      ...receipt,
      allocations: this.store.find<ReceiptAllocation>(
        'receiptAllocation',
        (a: any) => a.receiptId === (receipt as any).id,
      ),
    } as Receipt;
  }

  private nextReceiptNumber(companyId: number): string {
    return this.store.nextDocNumber('receipt', 'receiptNumber', companyId, `RCT-${companyId}-`, 0);
  }

  /**
   * Records a cash receipt allocated across one or more open invoices, and
   * posts ONE combined GL entry: debit the bank account for the full amount
   * received, credit the customer's AR control account once per allocation
   * (each converted at its own invoice's booking rate, so the AR sub-ledger
   * relief matches what was originally recognized), and plug any realized
   * FX gain/loss (from the receipt's rate differing from an invoice's
   * booking rate) either to the supplied gain/loss accounts or, if none are
   * supplied, onto the bank line itself as a documented simplification.
   */
  async createReceipt(input: CreateReceiptInput): Promise<Receipt> {
    if (!input.allocations || input.allocations.length === 0) {
      throw new BadRequestException('A receipt needs at least one allocation');
    }

    const customer = this.store.findById<Customer>('customer', input.customerId);
    if (!customer) throw new NotFoundException('Customer not found');
    if (!customer.arControlAccountId) {
      throw new BadRequestException(`Customer ${customer.code} has no AR control account configured`);
    }

    const currencyCode = input.currencyCode || 'LKR';
    const receiptExchangeRate = input.exchangeRate ?? 1;
    const amountMinor = input.allocations.reduce((sum, a) => sum + a.allocatedAmountMinor, 0);

    const saved: any = this.store.insert('receipt', {
      companyId: input.companyId,
      receiptNumber: this.nextReceiptNumber(input.companyId),
      customerId: input.customerId,
      receiptDate: input.receiptDate,
      bankAccountGlAccountId: input.bankAccountGlAccountId,
      currencyCode,
      exchangeRate: String(receiptExchangeRate),
      amountMinor: String(amountMinor),
      status: 'POSTED',
    });

    const glLines: PostLineInput[] = [
      {
        accountId: input.bankAccountGlAccountId,
        debitMinor: amountMinor,
        description: `Receipt ${saved.receiptNumber}`,
        currencyCode,
        exchangeRate: receiptExchangeRate,
      },
    ];

    let baseCreditTotal = 0n;
    const allocationSpecs: Record<string, any>[] = [];

    for (const a of input.allocations) {
      const invoice = this.store.findById<Invoice>('invoice', a.invoiceId);
      if (!invoice) throw new NotFoundException(`Invoice ${a.invoiceId} not found`);
      if (!OPEN_INVOICE_STATUSES.includes(invoice.status)) {
        throw new BadRequestException(
          `Invoice ${invoice.invoiceNumber} is not open for receipt (status ${invoice.status})`,
        );
      }

      const newAmountReceivedMinor = Number(invoice.amountReceivedMinor) + a.allocatedAmountMinor;
      const outstandingMinor = Number(invoice.totalMinor) - newAmountReceivedMinor;
      const newStatus = outstandingMinor <= 0 ? InvoiceStatus.PAID : InvoiceStatus.PARTIALLY_PAID;
      this.store.update('invoice', invoice.id, {
        amountReceivedMinor: String(newAmountReceivedMinor),
        status: newStatus,
      });

      const invoiceExchangeRate = Number(invoice.exchangeRate);
      // Sign convention: positive = gain (the receipt's exchange rate
      // values the collected amount higher in base currency than the rate
      // the invoice was originally booked at); negative = loss.
      const gainLossMinor =
        invoiceExchangeRate !== receiptExchangeRate
          ? Math.round(a.allocatedAmountMinor * (receiptExchangeRate - invoiceExchangeRate))
          : null;

      allocationSpecs.push({
        receiptId: saved.id,
        invoiceId: a.invoiceId,
        allocatedAmountMinor: String(a.allocatedAmountMinor),
        realizedGainLossMinor: gainLossMinor != null ? String(gainLossMinor) : null,
      });

      glLines.push({
        accountId: customer.arControlAccountId,
        creditMinor: a.allocatedAmountMinor,
        description: `Receipt ${saved.receiptNumber} applied to ${invoice.invoiceNumber}`,
        currencyCode: invoice.currencyCode,
        exchangeRate: invoiceExchangeRate,
        partyType: 'customer',
        partyId: customer.id,
      });
      baseCreditTotal += toBaseMinor(a.allocatedAmountMinor, invoiceExchangeRate);
    }

    for (const spec of allocationSpecs) {
      this.store.insert('receiptAllocation', spec);
    }

    // The bank line (at the receipt's own rate) and the AR credit lines
    // (each at its invoice's booking rate) will only balance in base
    // currency by coincidence; the difference IS the aggregate realized
    // FX gain/loss (plus any integer-rounding noise). Plug it explicitly.
    const baseDebitTotal = toBaseMinor(amountMinor, receiptExchangeRate);
    const diff = baseDebitTotal - baseCreditTotal; // >0: need more credit; <0: need more debit

    if (diff > 0n) {
      if (input.realizedGainAccountId) {
        glLines.push({
          accountId: input.realizedGainAccountId,
          creditMinor: Number(diff),
          description: `Realized FX gain on ${saved.receiptNumber}`,
          currencyCode,
          exchangeRate: 1,
        });
      } else {
        // No gain account configured — absorb the differential onto the
        // bank line itself rather than booking it separately.
        glLines.push({
          accountId: input.bankAccountGlAccountId,
          creditMinor: Number(diff),
          description: `FX gain/rounding on ${saved.receiptNumber} absorbed to cash account (no realized gain account configured)`,
          currencyCode,
          exchangeRate: 1,
        });
      }
    } else if (diff < 0n) {
      if (input.realizedLossAccountId) {
        glLines.push({
          accountId: input.realizedLossAccountId,
          debitMinor: Number(-diff),
          description: `Realized FX loss on ${saved.receiptNumber}`,
          currencyCode,
          exchangeRate: 1,
        });
      } else {
        glLines.push({
          accountId: input.bankAccountGlAccountId,
          debitMinor: Number(-diff),
          description: `FX loss/rounding on ${saved.receiptNumber} absorbed to cash account (no realized loss account configured)`,
          currencyCode,
          exchangeRate: 1,
        });
      }
    }

    const journalEntry = await this.accountingService.post({
      companyId: input.companyId,
      entryDate: input.receiptDate,
      memo: `Receipt ${saved.receiptNumber}`,
      sourceType: 'receipt',
      sourceId: String(saved.id),
      lines: glLines,
    });

    this.store.update('receipt', saved.id, { journalEntryId: journalEntry.id });

    return this.findOne(saved.id);
  }
}
