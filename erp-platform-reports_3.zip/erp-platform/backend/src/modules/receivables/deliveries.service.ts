import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { ItemsService } from '../inventory/items.service';
import { Delivery } from './delivery.entity';
import { DeliveryLine } from './delivery-line.entity';
import { SalesOrder, SalesOrderStatus } from './sales-order.entity';
import { SalesOrderLine } from './sales-order-line.entity';

export interface CreateDeliveryLineInput {
  soLineId?: number;
  itemId: number;
  quantity: number;
}

export interface CreateDeliveryInput {
  companyId: number;
  soId?: number;
  customerId: number;
  deliveryDate: string;
  notes?: string;
  lines: CreateDeliveryLineInput[];
}

@Injectable()
export class DeliveriesService {
  constructor(
    private store: DataStore,
    private itemsService: ItemsService,
  ) {}

  findAll(companyId: number) {
    return this.store
      .find<Delivery>('delivery', (d: any) => d.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((d: any) => ({
        ...d,
        lines: this.store.find<DeliveryLine>('deliveryLine', (l: any) => l.dnId === d.id),
      }));
  }

  async findOne(id: number): Promise<Delivery> {
    const dn = this.store.findById<Delivery>('delivery', id);
    if (!dn) throw new NotFoundException('Delivery not found');
    return {
      ...dn,
      lines: this.store.find<DeliveryLine>('deliveryLine', (l: any) => l.dnId === (dn as any).id),
    } as Delivery;
  }

  private nextDnNumber(companyId: number): string {
    return this.store.nextDocNumber('delivery', 'dnNumber', companyId, `DN-${companyId}-`, 0);
  }

  /**
   * Creates a delivery. For each line, issues stock at current weighted-
   * average cost via ItemsService.postIssue (which posts its own COGS/
   * inventory GL entry), then rolls the quantity up onto the matching sales
   * order line and recomputes the sales order's delivery status.
   */
  async create(input: CreateDeliveryInput): Promise<Delivery> {
    if (!input.lines || input.lines.length === 0) {
      throw new BadRequestException('A delivery needs at least one line');
    }

    const saved: any = this.store.insert('delivery', {
      companyId: input.companyId,
      dnNumber: this.nextDnNumber(input.companyId),
      soId: input.soId,
      customerId: input.customerId,
      deliveryDate: input.deliveryDate,
      notes: input.notes,
    });

    const touchedSoLineIds = new Set<number>();

    for (const l of input.lines) {
      const item = await this.itemsService.findItem(l.itemId);
      const gl = await this.itemsService.resolveGlAccounts(item);
      if (!gl.cogsAccountId) {
        throw new BadRequestException(`Item ${item.sku} has no resolved COGS account for issue`);
      }

      await this.itemsService.postIssue({
        itemId: l.itemId,
        quantity: l.quantity,
        movementDate: input.deliveryDate,
        sourceType: 'delivery',
        sourceId: String(saved.id),
        companyId: input.companyId,
        offsetAccountId: gl.cogsAccountId,
      });

      this.store.insert('deliveryLine', {
        dnId: saved.id,
        soLineId: l.soLineId,
        itemId: l.itemId,
        quantity: String(l.quantity),
      });

      if (l.soLineId) {
        const soLine = this.store.findById<SalesOrderLine>('salesOrderLine', l.soLineId);
        if (soLine) {
          this.store.update('salesOrderLine', soLine.id, {
            quantityDelivered: String(Number(soLine.quantityDelivered) + l.quantity),
          });
          touchedSoLineIds.add(soLine.soId);
        }
      }
    }

    if (input.soId) touchedSoLineIds.add(input.soId);
    for (const soId of touchedSoLineIds) {
      await this.refreshSoDeliveryStatus(soId);
    }

    return this.findOne(saved.id);
  }

  private async refreshSoDeliveryStatus(soId: number) {
    const so = this.store.findById<SalesOrder>('salesOrder', soId);
    const lines = this.store.find<SalesOrderLine>('salesOrderLine', (l: any) => l.soId === soId);
    if (!so || lines.length === 0) return;
    // Don't downgrade a sales order that has moved past delivery already
    // (invoiced/closed/cancelled) back to a delivery-progress status.
    if (
      [SalesOrderStatus.INVOICED, SalesOrderStatus.CLOSED, SalesOrderStatus.CANCELLED].includes(
        (so as any).status,
      )
    ) {
      return;
    }
    const allDelivered = lines.every((l: any) => Number(l.quantityDelivered) >= Number(l.quantity));
    const anyDelivered = lines.some((l: any) => Number(l.quantityDelivered) > 0);
    const newStatus = allDelivered
      ? SalesOrderStatus.DELIVERED
      : anyDelivered
        ? SalesOrderStatus.PARTIALLY_DELIVERED
        : (so as any).status;
    this.store.update('salesOrder', soId, { status: newStatus });
  }
}
