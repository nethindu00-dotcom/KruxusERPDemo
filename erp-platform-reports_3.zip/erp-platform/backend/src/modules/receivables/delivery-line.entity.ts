import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Delivery } from './delivery.entity';

@Entity('delivery_line')
@Index(['dnId'])
export class DeliveryLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => Delivery, (d) => d.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'dn_id' })
  delivery: Delivery;

  @Column({ name: 'dn_id' })
  dnId: number;

  @Column({ nullable: true })
  soLineId: number;

  @Column()
  itemId: number;

  @Column({ type: 'decimal', precision: 18, scale: 4 })
  quantity: string;
}
