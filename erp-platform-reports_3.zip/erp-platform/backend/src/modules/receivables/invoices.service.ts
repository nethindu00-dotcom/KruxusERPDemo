import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService, PostLineInput } from '../accounting/accounting.service';
import { ItemsService } from '../inventory/items.service';
import { TaxService } from '../tax/tax.service';
import { Customer } from './customer.entity';
import { Invoice, InvoiceStatus } from './invoice.entity';
import { InvoiceLine } from './invoice-line.entity';

export interface CreateInvoiceLineInput {
  itemId?: number;
  description: string;
  quantity?: number;
  unitPriceMinor: number;
  taxRateId?: number;
  // Required when itemId is not set (service/non-item lines).
  incomeAccountId?: number;
}

export interface CreateInvoiceInput {
  companyId: number;
  customerId: number;
  invoiceDate: string;
  dueDate: string;
  currencyCode?: string;
  exchangeRate?: number;
  soId?: number;
  dnId?: number;
  lines: CreateInvoiceLineInput[];
}

export interface AgingBucket {
  customerId: number;
  customerCode: string;
  customerName: string;
  current: number;
  d1_30: number;
  d31_60: number;
  d61_90: number;
  d90Plus: number;
  totalMinor: number;
}

const OPEN_INVOICE_STATUSES = [InvoiceStatus.POSTED, InvoiceStatus.PARTIALLY_PAID];

@Injectable()
export class InvoicesService {
  constructor(
    private store: DataStore,
    private itemsService: ItemsService,
    private taxService: TaxService,
    private accountingService: AccountingService,
  ) {}

  findAll(companyId: number) {
    return this.store
      .find<Invoice>('invoice', (i: any) => i.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((i: any) => ({
        ...i,
        lines: this.store.find<InvoiceLine>('invoiceLine', (l: any) => l.invoiceId === i.id),
      }));
  }

  async findOne(id: number): Promise<Invoice> {
    const invoice = this.store.findById<Invoice>('invoice', id);
    if (!invoice) throw new NotFoundException('Invoice not found');
    return {
      ...invoice,
      lines: this.store.find<InvoiceLine>('invoiceLine', (l: any) => l.invoiceId === (invoice as any).id),
    } as Invoice;
  }

  private nextInvoiceNumber(companyId: number): string {
    return this.store.nextDocNumber('invoice', 'invoiceNumber', companyId, `INV-${companyId}-`, 0);
  }

  /**
   * Creates a draft invoice. For an item line, the default tax rate is
   * auto-filled through ItemsService.resolveGlAccounts when not supplied —
   * the same "no manual work when selecting the inventory id" fallback used
   * on sales order lines — while still allowing an explicit override.
   */
  async create(input: CreateInvoiceInput): Promise<Invoice> {
    if (!input.lines || input.lines.length === 0) {
      throw new BadRequestException('An invoice needs at least one line');
    }

    const lineSpecs: Record<string, any>[] = [];
    let subtotalMinor = 0;
    let taxMinorTotal = 0;

    for (const l of input.lines) {
      const quantity = l.quantity ?? 1;
      let taxRateId = l.taxRateId;

      if (l.itemId) {
        const item = await this.itemsService.findItem(l.itemId);
        if (taxRateId == null) {
          const gl = await this.itemsService.resolveGlAccounts(item);
          taxRateId = gl.defaultTaxRateId ?? undefined;
        }
      } else if (!l.incomeAccountId) {
        throw new BadRequestException('A non-item invoice line requires an incomeAccountId');
      }

      const lineTotalMinor = Math.round(quantity * l.unitPriceMinor);
      subtotalMinor += lineTotalMinor;

      if (taxRateId) {
        const rate = await this.taxService.findOne(taxRateId);
        if (rate) taxMinorTotal += this.taxService.computeTax(lineTotalMinor, rate);
      }

      lineSpecs.push({
        itemId: l.itemId,
        description: l.description,
        quantity: String(quantity),
        unitPriceMinor: String(Math.round(l.unitPriceMinor)),
        taxRateId,
        incomeAccountId: l.incomeAccountId,
        lineTotalMinor: String(lineTotalMinor),
      });
    }

    const invoice: any = this.store.insert('invoice', {
      companyId: input.companyId,
      invoiceNumber: this.nextInvoiceNumber(input.companyId),
      customerId: input.customerId,
      invoiceDate: input.invoiceDate,
      dueDate: input.dueDate,
      currencyCode: input.currencyCode || 'LKR',
      exchangeRate: String(input.exchangeRate ?? 1),
      status: InvoiceStatus.DRAFT,
      subtotalMinor: String(subtotalMinor),
      taxMinor: String(taxMinorTotal),
      totalMinor: String(subtotalMinor + taxMinorTotal),
      amountReceivedMinor: '0',
      soId: input.soId,
      dnId: input.dnId,
    });

    const lines = lineSpecs.map((spec) => this.store.insert('invoiceLine', { ...spec, invoiceId: invoice.id }));
    invoice.lines = lines;
    return invoice;
  }

  /**
   * Posts the invoice to the GL via AccountingService.post (the only path
   * that may write journal_line rows). Per line: credit the resolved sales
   * account (item lines) or the line's incomeAccountId (non-item lines) for
   * the net amount; credit the tax rate's outputTaxAccountId for the tax, or
   * fold the tax into the main line if no output tax account is configured.
   * Debit the customer's AR control account for the gross total, tagged
   * with partyType/partyId so the AR sub-ledger can be reconstructed from
   * journal_line.
   */
  async postInvoice(id: number): Promise<Invoice> {
    const invoice = await this.findOne(id);
    if (invoice.status !== InvoiceStatus.DRAFT) {
      throw new BadRequestException(`Invoice ${invoice.invoiceNumber} is not in DRAFT status`);
    }

    const customer = this.store.findById<Customer>('customer', invoice.customerId);
    if (!customer) throw new NotFoundException('Customer not found');
    if (!customer.arControlAccountId) {
      throw new BadRequestException(`Customer ${customer.code} has no AR control account configured`);
    }

    const exchangeRate = Number(invoice.exchangeRate);
    const glLines: PostLineInput[] = [];

    for (const line of invoice.lines) {
      let creditAccountId: number | null | undefined;
      if (line.itemId) {
        const item = await this.itemsService.findItem(line.itemId);
        const gl = await this.itemsService.resolveGlAccounts(item);
        creditAccountId = gl.salesAccountId;
      } else {
        creditAccountId = line.incomeAccountId;
      }
      if (!creditAccountId) {
        throw new BadRequestException(`Invoice line ${line.id} has no resolvable sales/income account`);
      }

      let lineCreditMinor = Number(line.lineTotalMinor);

      if (line.taxRateId) {
        const rate = await this.taxService.findOne(line.taxRateId);
        if (rate) {
          const taxAmountMinor = this.taxService.computeTax(Number(line.lineTotalMinor), rate);
          if (rate.outputTaxAccountId) {
            glLines.push({
              accountId: rate.outputTaxAccountId,
              creditMinor: taxAmountMinor,
              description: `Tax on ${line.description}`,
              currencyCode: invoice.currencyCode,
              exchangeRate,
            });
          } else {
            // No output tax account configured for this rate — fold the tax
            // into the main sales/income line so the entry still balances.
            lineCreditMinor += taxAmountMinor;
          }
        }
      }

      glLines.push({
        accountId: creditAccountId,
        creditMinor: lineCreditMinor,
        description: line.description,
        currencyCode: invoice.currencyCode,
        exchangeRate,
      });
    }

    glLines.push({
      accountId: customer.arControlAccountId,
      debitMinor: Number(invoice.totalMinor),
      description: `Invoice ${invoice.invoiceNumber}`,
      currencyCode: invoice.currencyCode,
      exchangeRate,
      partyType: 'customer',
      partyId: customer.id,
    });

    const journalEntry = await this.accountingService.post({
      companyId: invoice.companyId,
      entryDate: invoice.invoiceDate,
      memo: `Invoice ${invoice.invoiceNumber}`,
      sourceType: 'invoice',
      sourceId: String(invoice.id),
      lines: glLines,
    });

    this.store.update('invoice', invoice.id, {
      status: InvoiceStatus.POSTED,
      journalEntryId: journalEntry.id,
    });
    return this.findOne(invoice.id);
  }

  /**
   * AR aging as of today: for every customer, the outstanding balance
   * (totalMinor - amountReceivedMinor) of each POSTED/PARTIALLY_PAID
   * invoice, converted to base currency via the invoice's own exchangeRate
   * and bucketed by days overdue against dueDate.
   */
  async getAgingReport(companyId: number): Promise<AgingBucket[]> {
    const customers = this.store.find<Customer>('customer', (c: any) => c.companyId === companyId);
    const invoices = this.store.find<Invoice>(
      'invoice',
      (i: any) => i.companyId === companyId && OPEN_INVOICE_STATUSES.includes(i.status),
    );

    const buckets = new Map<number, AgingBucket>();
    for (const c of customers) {
      // All ids are plain numbers in this build, but keep the Number(...)
      // normalization so a customerId lookup below always hits even if a
      // caller passes a numeric string.
      buckets.set(Number(c.id), {
        customerId: c.id,
        customerCode: c.code,
        customerName: c.name,
        current: 0,
        d1_30: 0,
        d31_60: 0,
        d61_90: 0,
        d90Plus: 0,
        totalMinor: 0,
      });
    }

    const today = new Date();
    for (const inv of invoices) {
      const bucket = buckets.get(Number(inv.customerId));
      if (!bucket) continue;

      const outstandingMinor = Number(inv.totalMinor) - Number(inv.amountReceivedMinor);
      if (outstandingMinor <= 0) continue;
      const baseOutstandingMinor = Math.round(outstandingMinor * Number(inv.exchangeRate));

      const dueDate = new Date(inv.dueDate);
      const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

      bucket.totalMinor += baseOutstandingMinor;
      if (daysOverdue <= 0) bucket.current += baseOutstandingMinor;
      else if (daysOverdue <= 30) bucket.d1_30 += baseOutstandingMinor;
      else if (daysOverdue <= 60) bucket.d31_60 += baseOutstandingMinor;
      else if (daysOverdue <= 90) bucket.d61_90 += baseOutstandingMinor;
      else bucket.d90Plus += baseOutstandingMinor;
    }

    return Array.from(buckets.values());
  }
}
