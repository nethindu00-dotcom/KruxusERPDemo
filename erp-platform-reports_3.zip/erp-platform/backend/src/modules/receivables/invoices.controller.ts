import { Controller, Get, Body, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { CreateInvoiceInput, InvoicesService } from './invoices.service';

@Controller('receivables')
export class InvoicesController {
  constructor(private svc: InvoicesService) {}

  @Get('invoices')
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get('invoices/:id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post('invoices')
  create(@Body() body: CreateInvoiceInput) {
    return this.svc.create(body);
  }

  @Post('invoices/:id/post')
  postInvoice(@Param('id', ParseIntPipe) id: number) {
    return this.svc.postInvoice(id);
  }

  @Get('aging')
  aging(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.getAgingReport(companyId);
  }
}
