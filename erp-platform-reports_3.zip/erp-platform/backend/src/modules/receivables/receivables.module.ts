import { Module } from '@nestjs/common';
import { AccountingModule } from '../accounting/accounting.module';
import { InventoryModule } from '../inventory/inventory.module';
import { TaxModule } from '../tax/tax.module';

import { CustomersService } from './customers.service';
import { SalesOrdersService } from './sales-orders.service';
import { DeliveriesService } from './deliveries.service';
import { InvoicesService } from './invoices.service';
import { ReceiptsService } from './receipts.service';

import { CustomersController } from './customers.controller';
import { SalesOrdersController } from './sales-orders.controller';
import { DeliveriesController } from './deliveries.controller';
import { InvoicesController } from './invoices.controller';
import { ReceiptsController } from './receipts.controller';

@Module({
  imports: [AccountingModule, InventoryModule, TaxModule],
  providers: [CustomersService, SalesOrdersService, DeliveriesService, InvoicesService, ReceiptsService],
  controllers: [
    CustomersController,
    SalesOrdersController,
    DeliveriesController,
    InvoicesController,
    ReceiptsController,
  ],
  exports: [CustomersService, SalesOrdersService, DeliveriesService, InvoicesService, ReceiptsService],
})
export class ReceivablesModule {}
