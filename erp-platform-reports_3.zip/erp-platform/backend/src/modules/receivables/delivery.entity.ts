import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { DeliveryLine } from './delivery-line.entity';

@Entity('delivery')
@Index(['companyId', 'dnNumber'], { unique: true })
export class Delivery {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  dnNumber: string;

  @Column({ nullable: true })
  soId: number;

  @Column()
  customerId: number;

  @Column({ type: 'date' })
  deliveryDate: string;

  @Column({ nullable: true })
  notes: string;

  @OneToMany(() => DeliveryLine, (l) => l.delivery, { cascade: true })
  lines: DeliveryLine[];

  @CreateDateColumn()
  createdAt: Date;
}
