import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { SalesOrder } from './sales-order.entity';

@Entity('sales_order_line')
@Index(['soId'])
export class SalesOrderLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => SalesOrder, (so) => so.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'so_id' })
  so: SalesOrder;

  @Column({ name: 'so_id' })
  soId: number;

  @Column()
  itemId: number;

  @Column({ nullable: true })
  description: string;

  @Column({ type: 'decimal', precision: 18, scale: 4 })
  quantity: string;

  // Defaulted from Item.salesPriceMinor when the line is created, but
  // editable thereafter.
  @Column({ type: 'bigint' })
  unitPriceMinor: string;

  // Auto-filled from ItemsService.resolveGlAccounts(item).defaultTaxRateId
  // when the line is created, but still editable.
  @Column({ nullable: true })
  taxRateId: number;

  @Column({ type: 'decimal', precision: 18, scale: 4, default: 0 })
  quantityDelivered: string;

  @Column({ type: 'decimal', precision: 18, scale: 4, default: 0 })
  quantityInvoiced: string;
}
