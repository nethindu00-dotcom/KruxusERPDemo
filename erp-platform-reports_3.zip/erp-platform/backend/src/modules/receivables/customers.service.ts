import { Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { Customer } from './customer.entity';

@Injectable()
export class CustomersService {
  constructor(private store: DataStore) {}

  findAll(companyId: number) {
    return this.store
      .find<Customer>('customer', (c: any) => c.companyId === companyId)
      .sort((a: any, b: any) => (a.code > b.code ? 1 : a.code < b.code ? -1 : 0));
  }

  async findOne(id: number): Promise<Customer> {
    const customer = this.store.findById<Customer>('customer', id);
    if (!customer) throw new NotFoundException('Customer not found');
    return customer;
  }

  create(body: Partial<Customer>) {
    return this.store.insert('customer', { ...body });
  }

  async update(id: number, body: Partial<Customer>) {
    await this.findOne(id);
    this.store.update('customer', id, body);
    return this.findOne(id);
  }
}
