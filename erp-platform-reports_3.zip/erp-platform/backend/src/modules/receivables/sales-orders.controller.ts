import { Body, Controller, Get, Param, ParseIntPipe, Patch, Post, Query } from '@nestjs/common';
import { CreateSalesOrderInput, SalesOrdersService } from './sales-orders.service';
import { SalesOrder } from './sales-order.entity';

@Controller('receivables/sales-orders')
export class SalesOrdersController {
  constructor(private svc: SalesOrdersService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: CreateSalesOrderInput) {
    return this.svc.create(body);
  }

  @Patch(':id')
  update(@Param('id', ParseIntPipe) id: number, @Body() body: Partial<SalesOrder>) {
    return this.svc.update(id, body);
  }

  @Post(':id/confirm')
  confirm(@Param('id', ParseIntPipe) id: number) {
    return this.svc.confirm(id);
  }
}
