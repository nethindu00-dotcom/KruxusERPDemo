import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { SalesOrderLine } from './sales-order-line.entity';

export enum SalesOrderStatus {
  DRAFT = 'DRAFT',
  CONFIRMED = 'CONFIRMED',
  PARTIALLY_DELIVERED = 'PARTIALLY_DELIVERED',
  DELIVERED = 'DELIVERED',
  INVOICED = 'INVOICED',
  CLOSED = 'CLOSED',
  CANCELLED = 'CANCELLED',
}

@Entity('sales_order')
@Index(['companyId', 'soNumber'], { unique: true })
export class SalesOrder {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  soNumber: string;

  @Column()
  customerId: number;

  @Column({ type: 'date' })
  orderDate: string;

  @Column({ default: 'LKR' })
  currencyCode: string;

  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  @Column({ type: 'enum', enum: SalesOrderStatus, default: SalesOrderStatus.DRAFT })
  status: SalesOrderStatus;

  @Column({ nullable: true })
  notes: string;

  @OneToMany(() => SalesOrderLine, (l) => l.so, { cascade: true })
  lines: SalesOrderLine[];

  @CreateDateColumn()
  createdAt: Date;
}
