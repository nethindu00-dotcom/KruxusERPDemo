import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { InvoiceLine } from './invoice-line.entity';

export enum InvoiceStatus {
  DRAFT = 'DRAFT',
  POSTED = 'POSTED',
  PARTIALLY_PAID = 'PARTIALLY_PAID',
  PAID = 'PAID',
  VOID = 'VOID',
}

@Entity('invoice')
@Index(['companyId', 'invoiceNumber'], { unique: true })
export class Invoice {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  invoiceNumber: string;

  @Column()
  customerId: number;

  @Column({ type: 'date' })
  invoiceDate: string;

  @Column({ type: 'date' })
  dueDate: string;

  @Column({ default: 'LKR' })
  currencyCode: string;

  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  @Column({ type: 'enum', enum: InvoiceStatus, default: InvoiceStatus.DRAFT })
  status: InvoiceStatus;

  @Column({ type: 'bigint', default: 0 })
  subtotalMinor: string;

  @Column({ type: 'bigint', default: 0 })
  taxMinor: string;

  @Column({ type: 'bigint', default: 0 })
  totalMinor: string;

  @Column({ type: 'bigint', default: 0 })
  amountReceivedMinor: string;

  @Column({ type: 'bigint', nullable: true })
  journalEntryId: number;

  @Column({ nullable: true })
  soId: number;

  @Column({ nullable: true })
  dnId: number;

  @OneToMany(() => InvoiceLine, (l) => l.invoice, { cascade: true })
  lines: InvoiceLine[];

  @CreateDateColumn()
  createdAt: Date;
}
