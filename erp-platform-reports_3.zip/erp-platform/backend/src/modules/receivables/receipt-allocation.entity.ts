import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Receipt } from './receipt.entity';

@Entity('receipt_allocation')
@Index(['receiptId'])
@Index(['invoiceId'])
export class ReceiptAllocation {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => Receipt, (r) => r.allocations, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'receipt_id' })
  receipt: Receipt;

  @Column({ name: 'receipt_id' })
  receiptId: number;

  @Column()
  invoiceId: number;

  // In the invoice's own currency (invoice.currencyCode).
  @Column({ type: 'bigint' })
  allocatedAmountMinor: string;

  // Base-currency realized FX gain/loss on this allocation. Sign convention:
  // positive = gain (the receipt's exchange rate values the collected amount
  // higher in base currency than the rate the invoice was originally booked
  // at); negative = loss. Null when the invoice's exchange rate equals the
  // receipt's (no FX movement to realize).
  @Column({ type: 'bigint', nullable: true })
  realizedGainLossMinor: string;
}
