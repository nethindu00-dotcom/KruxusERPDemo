import { Controller, Get, ParseIntPipe, Query } from '@nestjs/common';
import { TaxService } from './tax.service';

@Controller('tax-rates')
export class TaxController {
  constructor(private svc: TaxService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }
}
