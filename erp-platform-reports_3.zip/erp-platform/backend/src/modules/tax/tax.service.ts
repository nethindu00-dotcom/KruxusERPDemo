import { Injectable } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { TaxRate } from './tax-rate.entity';

@Injectable()
export class TaxService {
  constructor(private store: DataStore) {}

  findAll(companyId: number) {
    return this.store
      .find<any>('taxRate', (r) => r.companyId === companyId && r.isActive)
      .sort((a, b) => (a.code > b.code ? 1 : -1));
  }

  findOne(id: number) {
    return this.store.findById<any>('taxRate', id);
  }

  /** Computes tax on a net (tax-exclusive) line amount, in minor units. */
  computeTax(netMinor: number, rate: TaxRate): number {
    return Math.round((netMinor * rate.rateBasisPoints) / 10000);
  }
}
