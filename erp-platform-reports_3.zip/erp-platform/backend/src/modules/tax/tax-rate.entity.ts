import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('tax_rate')
@Index(['companyId', 'code'], { unique: true })
export class TaxRate {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  code: string; // e.g. VAT18, SSCL-TRD, SSCL-SERV, ZERO

  @Column()
  name: string;

  @Column({ type: 'int' })
  rateBasisPoints: number; // e.g. 1800 = 18%

  @Column({ default: 'EXCLUSIVE' })
  pricingMode: 'EXCLUSIVE' | 'INCLUSIVE';

  @Column({ default: false })
  isVat: boolean;

  @Column({ nullable: true })
  outputTaxAccountId: number; // sales side (collected)

  @Column({ nullable: true })
  inputTaxAccountId: number; // purchase side (paid, creditable) — null for non-creditable levies like SSCL

  @Column({ default: true })
  isActive: boolean;
}
