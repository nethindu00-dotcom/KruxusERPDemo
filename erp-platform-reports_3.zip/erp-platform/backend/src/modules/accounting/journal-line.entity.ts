import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { JournalEntry } from './journal-entry.entity';

@Entity('journal_line')
export class JournalLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => JournalEntry, (e) => e.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'entry_id' })
  entry: JournalEntry;

  @Column({ name: 'entry_id' })
  entryId: number;

  @Column({ name: 'account_id' })
  accountId: number;

  @Column({ nullable: true })
  description: string;

  // Transaction-currency amounts (minor units, e.g. cents)
  @Column({ type: 'bigint', default: 0 })
  debitMinor: string;

  @Column({ type: 'bigint', default: 0 })
  creditMinor: string;

  @Column({ default: 'LKR' })
  currencyCode: string;

  // Rate to convert this line's currency into the company's base currency
  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  // Base-currency amounts (minor units) — GL balance is always enforced on these
  @Column({ type: 'bigint', default: 0 })
  baseDebitMinor: string;

  @Column({ type: 'bigint', default: 0 })
  baseCreditMinor: string;

  @Column({ nullable: true })
  partyType: string; // customer | supplier | null

  @Column({ nullable: true })
  partyId: number;
}
