import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { AccountingService } from './accounting.service';
import { DataStore } from '../../database/data-store';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@Controller('accounting')
export class AccountingController {
  constructor(
    private svc: AccountingService,
    private store: DataStore,
  ) {}

  @Get('accounts')
  accounts(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAccounts(companyId);
  }

  @Post('accounts')
  createAccount(@Body() body: any) {
    return this.store.insert('account', { ...body });
  }

  @Get('journal-entries')
  entries(
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    return this.svc.listEntries(companyId, Number(page) || 1, Number(pageSize) || 50);
  }

  @Post('journal-entries')
  post(@Body() body: any, @CurrentUser() user: any) {
    return this.svc.post({ ...body, postedBy: user?.id });
  }

  @Post('journal-entries/:id/reverse')
  reverse(@Param('id', ParseIntPipe) id: number, @CurrentUser() user: any) {
    return this.svc.reverse(id, user?.id);
  }

  @Get('trial-balance')
  trialBalance(@Query('companyId', ParseIntPipe) companyId: number, @Query('asOfDate') asOfDate?: string) {
    return this.svc.trialBalance(companyId, asOfDate);
  }

  @Get('periods')
  periods(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.store
      .find<any>('fiscalPeriod', (p) => p.companyId === companyId)
      .sort((a, b) => (a.periodCode > b.periodCode ? 1 : -1));
  }

  @Post('periods')
  createPeriod(@Body() body: any) {
    return this.store.insert('fiscalPeriod', { ...body });
  }

  @Post('periods/:id/close')
  async closePeriod(@Param('id', ParseIntPipe) id: number) {
    return this.store.update('fiscalPeriod', id, { status: 'CLOSED' });
  }
}
