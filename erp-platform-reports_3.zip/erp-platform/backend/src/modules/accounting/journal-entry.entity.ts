import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { JournalLine } from './journal-line.entity';

@Entity('journal_entry')
@Index(['companyId', 'entryDate'])
export class JournalEntry {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column({ unique: true })
  entryNumber: string;

  @Column({ type: 'date' })
  entryDate: string;

  @Column()
  memo: string;

  @Column()
  sourceType: string; // manual | sales_invoice | bill | payment | receipt | pos_sale | depreciation | fx_revaluation ...

  @Column({ nullable: true })
  sourceId: string;

  @Column({ default: 'POSTED' })
  status: 'POSTED' | 'REVERSED';

  @Column({ nullable: true })
  reversesEntryId: number;

  @Column({ nullable: true })
  postedBy: number;

  @OneToMany(() => JournalLine, (l) => l.entry, { cascade: true })
  lines: JournalLine[];

  @CreateDateColumn()
  createdAt: Date;
}
