import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('fiscal_period')
@Index(['companyId', 'periodCode'], { unique: true })
export class FiscalPeriod {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  periodCode: string; // e.g. 2026-09

  @Column({ type: 'date' })
  startDate: string;

  @Column({ type: 'date' })
  endDate: string;

  @Column({ default: 'OPEN' })
  status: 'OPEN' | 'CLOSED';
}
