import { BadRequestException, Injectable } from '@nestjs/common';
import { DataStore } from '../../database/data-store';

export interface PostLineInput {
  accountId: number;
  description?: string;
  debitMinor?: number;
  creditMinor?: number;
  currencyCode?: string; // defaults to company base currency
  exchangeRate?: number; // to base currency; defaults to 1
  partyType?: string;
  partyId?: number;
}

export interface PostEntryInput {
  companyId: number;
  entryDate: string;
  memo: string;
  sourceType: string;
  sourceId?: string;
  postedBy?: number;
  lines: PostLineInput[];
}

/**
 * The single choke point for every ledger posting in the system. No other
 * code path may write journalLine rows directly. Enforces debit=credit on
 * BASE-currency amounts (never floats; integer minor units). Everything is
 * in-memory via DataStore - no database.
 */
@Injectable()
export class AccountingService {
  constructor(private store: DataStore) {}

  async findAccounts(companyId: number) {
    return this.store
      .find<any>('account', (a) => a.companyId === companyId)
      .sort((a, b) => (a.code > b.code ? 1 : -1));
  }

  private nextEntryNumber(companyId: number): string {
    return this.store.nextDocNumber('journalEntry', 'entryNumber', companyId, `JE-${companyId}-`, 6);
  }

  checkPeriodOpen(companyId: number, entryDate: string) {
    const period = this.store.findOne<any>(
      'fiscalPeriod',
      (p) => p.companyId === companyId && p.periodCode === entryDate.slice(0, 7),
    );
    if (period && period.status === 'CLOSED') {
      throw new BadRequestException(`Period ${period.periodCode} is closed for posting`);
    }
  }

  async post(input: PostEntryInput): Promise<any> {
    if (!input.lines || input.lines.length === 0) {
      throw new BadRequestException('A journal entry needs at least one line');
    }
    this.checkPeriodOpen(input.companyId, input.entryDate);

    let baseDebitTotal = 0n;
    let baseCreditTotal = 0n;

    const computedLines = input.lines.map((l) => {
      const debit = BigInt(Math.round(l.debitMinor || 0));
      const credit = BigInt(Math.round(l.creditMinor || 0));
      if (debit > 0n && credit > 0n) {
        throw new BadRequestException('A line cannot have both debit and credit');
      }
      const rate = l.exchangeRate ?? 1;
      const rateScaled = BigInt(Math.round(rate * 1_000_000));
      const baseDebit = (debit * rateScaled) / 1_000_000n;
      const baseCredit = (credit * rateScaled) / 1_000_000n;
      baseDebitTotal += baseDebit;
      baseCreditTotal += baseCredit;

      return {
        accountId: l.accountId,
        description: l.description || input.memo,
        debitMinor: debit.toString(),
        creditMinor: credit.toString(),
        currencyCode: l.currencyCode || 'LKR',
        exchangeRate: String(rate),
        baseDebitMinor: baseDebit.toString(),
        baseCreditMinor: baseCredit.toString(),
        partyType: l.partyType,
        partyId: l.partyId,
      };
    });

    if (baseDebitTotal !== baseCreditTotal) {
      throw new BadRequestException(
        `Unbalanced journal entry: base debits ${baseDebitTotal} != base credits ${baseCreditTotal}`,
      );
    }

    const entry: any = {
      companyId: input.companyId,
      entryNumber: this.nextEntryNumber(input.companyId),
      entryDate: input.entryDate,
      memo: input.memo,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      postedBy: input.postedBy,
      status: 'POSTED',
      reversesEntryId: null,
    };
    this.store.insert('journalEntry', entry);

    const lines = computedLines.map((l) => this.store.insert('journalLine', { ...l, entryId: entry.id }));
    entry.lines = lines;
    return entry;
  }

  async listEntries(companyId: number, page = 1, pageSize = 50) {
    const all = this.store
      .find<any>('journalEntry', (e) => e.companyId === companyId)
      .sort((a, b) => b.id - a.id);
    const total = all.length;
    const start = (page - 1) * pageSize;
    const data = all.slice(start, start + pageSize).map((e) => ({
      ...e,
      lines: this.store.find<any>('journalLine', (l) => l.entryId === e.id),
    }));
    return { data, meta: { page, pageSize, total } };
  }

  async trialBalance(companyId: number, asOfDate?: string) {
    const entries = this.store.find<any>(
      'journalEntry',
      (e) => e.companyId === companyId && e.status === 'POSTED' && (!asOfDate || e.entryDate <= asOfDate),
    );
    const entryIds = new Set(entries.map((e) => e.id));
    const lines = this.store.find<any>('journalLine', (l) => entryIds.has(l.entryId));
    const accounts = this.store.find<any>('account', (a) => a.companyId === companyId);

    const byAccount = new Map<number, { totalDebit: number; totalCredit: number }>();
    for (const l of lines) {
      const agg = byAccount.get(l.accountId) || { totalDebit: 0, totalCredit: 0 };
      agg.totalDebit += Number(l.baseDebitMinor || 0);
      agg.totalCredit += Number(l.baseCreditMinor || 0);
      byAccount.set(l.accountId, agg);
    }

    return accounts
      .filter((a) => byAccount.has(a.id))
      .sort((a, b) => (a.code > b.code ? 1 : -1))
      .map((a) => {
        const agg = byAccount.get(a.id)!;
        return {
          accountId: a.id,
          code: a.code,
          name: a.name,
          accountType: a.accountType,
          normalBalance: a.normalBalance,
          totalDebit: agg.totalDebit,
          totalCredit: agg.totalCredit,
          balance: a.normalBalance === 'DEBIT' ? agg.totalDebit - agg.totalCredit : agg.totalCredit - agg.totalDebit,
        };
      });
  }

  async reverse(entryId: number, postedBy?: number) {
    const original = this.store.findById<any>('journalEntry', entryId);
    if (!original) throw new BadRequestException('Entry not found');
    const originalLines = this.store.find<any>('journalLine', (l) => l.entryId === original.id);

    const reversed = await this.post({
      companyId: original.companyId,
      entryDate: new Date().toISOString().slice(0, 10),
      memo: `Reversal of ${original.entryNumber}: ${original.memo}`,
      sourceType: 'reversal',
      sourceId: String(original.id),
      postedBy,
      lines: originalLines.map((l) => ({
        accountId: l.accountId,
        description: l.description,
        debitMinor: Number(l.creditMinor),
        creditMinor: Number(l.debitMinor),
        currencyCode: l.currencyCode,
        exchangeRate: Number(l.exchangeRate),
        partyType: l.partyType,
        partyId: l.partyId,
      })),
    });

    this.store.update('journalEntry', original.id, { status: 'REVERSED', reversesEntryId: reversed.id });
    return reversed;
  }
}
