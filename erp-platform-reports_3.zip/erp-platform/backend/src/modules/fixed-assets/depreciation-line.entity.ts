import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { DepreciationRun } from './depreciation-run.entity';

@Entity('depreciation_line')
export class DepreciationLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => DepreciationRun, (r) => r.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'run_id' })
  run: DepreciationRun;

  @Column({ name: 'run_id' })
  runId: number;

  @Column({ name: 'fixed_asset_id' })
  fixedAssetId: number;

  @Column({ type: 'bigint' })
  depreciationAmountMinor: string;

  // The asset's accumulatedDepreciationMinor after this line
  @Column({ type: 'bigint' })
  accumulatedAfterMinor: string;
}
