import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { FixedAssetsService } from './fixed-assets.service';

@Controller('fixed-assets')
export class FixedAssetsController {
  constructor(private svc: FixedAssetsService) {}

  @Get('categories')
  categories(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAllCategories(companyId);
  }

  @Post('categories')
  createCategory(@Body() body: any) {
    return this.svc.createCategory(body);
  }

  @Get('depreciation-runs')
  depreciationRuns(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.listDepreciationRuns(companyId);
  }

  @Get('register')
  register(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.assetRegisterReport(companyId);
  }

  @Post('run-depreciation')
  runDepreciation(@Body() body: any) {
    return this.svc.runDepreciation(body);
  }

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: any) {
    return this.svc.create(body);
  }

  @Post(':id/capitalize')
  capitalize(@Param('id', ParseIntPipe) id: number, @Body() body: { clearingAccountId?: number }) {
    return this.svc.capitalize(id, body?.clearingAccountId);
  }

  @Post(':id/dispose')
  dispose(
    @Param('id', ParseIntPipe) id: number,
    @Body()
    body: {
      disposalDate: string;
      disposalProceedsMinor: number;
      proceedsAccountId: number;
      gainOnDisposalAccountId?: number;
      lossOnDisposalAccountId?: number;
    },
  ) {
    return this.svc.disposeAsset({ assetId: id, ...body });
  }
}
