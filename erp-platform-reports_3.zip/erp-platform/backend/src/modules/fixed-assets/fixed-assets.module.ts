import { Module } from '@nestjs/common';
import { AccountingModule } from '../accounting/accounting.module';
import { FixedAssetsService } from './fixed-assets.service';
import { FixedAssetsController } from './fixed-assets.controller';

@Module({
  imports: [AccountingModule],
  providers: [FixedAssetsService],
  controllers: [FixedAssetsController],
  exports: [FixedAssetsService],
})
export class FixedAssetsModule {}
