import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { DepreciationLine } from './depreciation-line.entity';

@Entity('depreciation_run')
export class DepreciationRun {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  // e.g. '2026-09'
  @Column()
  periodCode: string;

  @Column({ type: 'date' })
  runDate: string;

  @Column({ type: 'bigint' })
  totalDepreciationMinor: string;

  @Column({ type: 'bigint', nullable: true })
  journalEntryId: number;

  @Column({ default: 'POSTED' })
  status: 'POSTED';

  @OneToMany(() => DepreciationLine, (l) => l.run, { cascade: true })
  lines: DepreciationLine[];

  @CreateDateColumn()
  createdAt: Date;
}
