import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

export enum DepreciationMethod {
  STRAIGHT_LINE = 'STRAIGHT_LINE',
  REDUCING_BALANCE = 'REDUCING_BALANCE',
}

@Entity('asset_category')
@Index(['companyId', 'code'], { unique: true })
export class AssetCategory {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  code: string;

  @Column()
  name: string;

  // Cost / gross-value asset account, e.g. "Motor vehicles - cost"
  @Column({ name: 'asset_account_id' })
  assetAccountId: number;

  // Contra-asset, credit-normal account
  @Column({ name: 'accumulated_depreciation_account_id' })
  accumulatedDepreciationAccountId: number;

  // Expense account
  @Column({ name: 'depreciation_expense_account_id' })
  depreciationExpenseAccountId: number;

  @Column({ type: 'int' })
  defaultUsefulLifeMonths: number;

  @Column({ type: 'enum', enum: DepreciationMethod, default: DepreciationMethod.STRAIGHT_LINE })
  defaultDepreciationMethod: DepreciationMethod;

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
