import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { DepreciationMethod } from './asset-category.entity';

export enum FixedAssetStatus {
  DRAFT = 'DRAFT',
  CAPITALIZED = 'CAPITALIZED',
  DISPOSED = 'DISPOSED',
  TRANSFERRED = 'TRANSFERRED',
}

@Entity('fixed_asset')
@Index(['companyId', 'assetCode'], { unique: true })
export class FixedAsset {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column({ name: 'asset_code' })
  assetCode: string;

  @Column()
  name: string;

  @Column({ name: 'category_id' })
  categoryId: number;

  @Column({ type: 'date' })
  acquisitionDate: string;

  // Original capitalized cost in minor units, base currency
  @Column({ type: 'bigint' })
  costMinor: string;

  @Column({ type: 'bigint', default: 0 })
  salvageValueMinor: string;

  @Column({ type: 'int' })
  usefulLifeMonths: number;

  @Column({ type: 'enum', enum: DepreciationMethod })
  depreciationMethod: DepreciationMethod;

  // Only used for REDUCING_BALANCE, e.g. 2000 = 20%/yr
  @Column({ type: 'int', nullable: true })
  depreciationRateBasisPoints: number;

  @Column({ type: 'enum', enum: FixedAssetStatus, default: FixedAssetStatus.DRAFT })
  status: FixedAssetStatus;

  // Running total, updated as depreciation posts
  @Column({ type: 'bigint', default: 0 })
  accumulatedDepreciationMinor: string;

  // Last YYYY-MM depreciation run that included this asset
  @Column({ nullable: true })
  lastDepreciatedPeriod: string;

  @Column({ type: 'date', nullable: true })
  disposalDate: string;

  @Column({ type: 'bigint', nullable: true })
  disposalProceedsMinor: string;

  @Column({ nullable: true })
  branchOrLocation: string;

  @Column({ nullable: true })
  serialNumber: string;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
