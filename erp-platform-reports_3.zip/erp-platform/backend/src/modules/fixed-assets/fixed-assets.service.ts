import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService } from '../accounting/accounting.service';
import { AssetCategory } from './asset-category.entity';
import { FixedAsset, FixedAssetStatus } from './fixed-asset.entity';
import { DepreciationMethod } from './asset-category.entity';
import { DepreciationRun } from './depreciation-run.entity';
import { DepreciationLine } from './depreciation-line.entity';

export interface CapitalizeInput {
  assetId: number;
  clearingAccountId?: number;
}

export interface RunDepreciationInput {
  companyId: number;
  periodCode: string; // e.g. '2026-09'
  runDate: string;
}

export interface DisposeAssetInput {
  assetId: number;
  disposalDate: string;
  disposalProceedsMinor: number;
  proceedsAccountId: number;
  gainOnDisposalAccountId?: number;
  lossOnDisposalAccountId?: number;
}

function endOfMonth(periodCode: string): string {
  const [year, month] = periodCode.split('-').map((n) => Number(n));
  // day 0 of next month = last day of this month
  const last = new Date(Date.UTC(year, month, 0));
  return last.toISOString().slice(0, 10);
}

@Injectable()
export class FixedAssetsService {
  constructor(
    private store: DataStore,
    private accountingService: AccountingService,
  ) {}

  // ---------- Asset categories ----------

  findAllCategories(companyId: number) {
    return this.store
      .find<AssetCategory>('assetCategory', (c) => c.companyId === companyId)
      .sort((a, b) => (a.code > b.code ? 1 : a.code < b.code ? -1 : 0));
  }

  createCategory(data: Partial<AssetCategory>) {
    return this.store.insert('assetCategory', { ...data });
  }

  // ---------- Fixed assets CRUD ----------

  async findAll(companyId: number) {
    const assets = this.store
      .find<FixedAsset>('fixedAsset', (a) => a.companyId === companyId)
      .sort((a, b) => (a.assetCode > b.assetCode ? 1 : a.assetCode < b.assetCode ? -1 : 0));
    const categories = this.store.find<AssetCategory>('assetCategory', (c) => c.companyId === companyId);
    // category.id and asset.categoryId are both plain numbers in this
    // in-memory store, so a straight Number() key normalization is now
    // redundant but harmless - kept for parity with the previous lookup.
    const categoryById = new Map(categories.map((c) => [Number(c.id), c]));
    return assets.map((a) => this.withCategoryAndNbv(a, categoryById.get(Number(a.categoryId))));
  }

  async findOne(id: number) {
    const asset = this.store.findById<FixedAsset>('fixedAsset', id);
    if (!asset) throw new NotFoundException(`Fixed asset ${id} not found`);
    const category = this.store.findById<AssetCategory>('assetCategory', asset.categoryId);
    return this.withCategoryAndNbv(asset, category);
  }

  private withCategoryAndNbv(asset: FixedAsset, category?: AssetCategory) {
    const netBookValueMinor = (BigInt(asset.costMinor) - BigInt(asset.accumulatedDepreciationMinor)).toString();
    return {
      ...asset,
      categoryName: category?.name,
      netBookValueMinor,
    };
  }

  create(data: Partial<FixedAsset>) {
    return this.store.insert('fixedAsset', {
      ...data,
      status: FixedAssetStatus.DRAFT,
      accumulatedDepreciationMinor: '0',
    });
  }

  async update(id: number, data: Partial<FixedAsset>) {
    const asset = this.store.findById<FixedAsset>('fixedAsset', id);
    if (!asset) throw new NotFoundException(`Fixed asset ${id} not found`);
    return this.store.update('fixedAsset', id, data);
  }

  // ---------- Capitalization ----------

  async capitalize(assetId: number, clearingAccountId?: number) {
    const asset = this.store.findById<FixedAsset>('fixedAsset', assetId);
    if (!asset) throw new NotFoundException(`Fixed asset ${assetId} not found`);
    if (asset.status !== FixedAssetStatus.DRAFT) {
      throw new BadRequestException(`Asset ${asset.assetCode} is not in DRAFT status`);
    }

    if (clearingAccountId) {
      const category = this.store.findById<AssetCategory>('assetCategory', asset.categoryId);
      if (!category) throw new NotFoundException(`Asset category ${asset.categoryId} not found`);
      await this.accountingService.post({
        companyId: asset.companyId,
        entryDate: asset.acquisitionDate,
        memo: `Capitalization of asset ${asset.assetCode} - ${asset.name}`,
        sourceType: 'fixed_asset_capitalization',
        sourceId: String(asset.id),
        lines: [
          {
            accountId: category.assetAccountId,
            description: `Capitalize ${asset.assetCode}`,
            debitMinor: Number(asset.costMinor),
          },
          {
            accountId: clearingAccountId,
            description: `Capitalize ${asset.assetCode}`,
            creditMinor: Number(asset.costMinor),
          },
        ],
      });
    }

    return this.store.update('fixedAsset', assetId, { status: FixedAssetStatus.CAPITALIZED });
  }

  // ---------- Depreciation ----------

  async runDepreciation(input: RunDepreciationInput) {
    const { companyId, periodCode, runDate } = input;
    const periodEnd = endOfMonth(periodCode);

    const candidates = this.store.find<FixedAsset>(
      'fixedAsset',
      (a) => a.companyId === companyId && a.status === FixedAssetStatus.CAPITALIZED && a.acquisitionDate <= periodEnd,
    );

    const categories = this.store.find<AssetCategory>('assetCategory', (c) => c.companyId === companyId);
    // See findAll() above: kept as Number(...) for parity, though both sides
    // are already plain numbers in this in-memory store.
    const categoryById = new Map(categories.map((c) => [Number(c.id), c]));

    type Pending = { asset: FixedAsset; category: AssetCategory; monthlyDep: number };
    const pending: Pending[] = [];

    for (const asset of candidates) {
      if (asset.lastDepreciatedPeriod && asset.lastDepreciatedPeriod >= periodCode) continue;

      const cost = Number(asset.costMinor);
      const salvage = Number(asset.salvageValueMinor);
      const accumulated = Number(asset.accumulatedDepreciationMinor);
      const depreciableBase = cost - salvage;
      const remaining = depreciableBase - accumulated;
      if (remaining <= 0) continue;

      const category = categoryById.get(Number(asset.categoryId));
      if (!category) continue;

      let monthlyDep: number;
      if (asset.depreciationMethod === DepreciationMethod.STRAIGHT_LINE) {
        monthlyDep = Math.round(depreciableBase / asset.usefulLifeMonths);
      } else {
        const rateBp = asset.depreciationRateBasisPoints || 0;
        monthlyDep = Math.round(((cost - accumulated) * rateBp) / 10000 / 12);
      }
      monthlyDep = Math.min(monthlyDep, remaining);

      if (monthlyDep <= 0) continue;

      pending.push({ asset, category, monthlyDep });
    }

    if (pending.length === 0) {
      const emptyRun = this.store.insert('depreciationRun', {
        companyId,
        periodCode,
        runDate,
        totalDepreciationMinor: '0',
        journalEntryId: null,
        status: 'POSTED',
      });
      return { ...emptyRun, lines: [] };
    }

    const lines = pending.flatMap(({ asset, category, monthlyDep }) => [
      {
        accountId: category.depreciationExpenseAccountId,
        description: `Depreciation - ${asset.assetCode}`,
        debitMinor: monthlyDep,
      },
      {
        accountId: category.accumulatedDepreciationAccountId,
        description: `Depreciation - ${asset.assetCode}`,
        creditMinor: monthlyDep,
      },
    ]);

    const totalDepreciationMinor = pending.reduce((sum, p) => sum + p.monthlyDep, 0);

    const journalEntry = await this.accountingService.post({
      companyId,
      entryDate: runDate,
      memo: `Depreciation run ${periodCode}`,
      sourceType: 'depreciation',
      lines,
    });

    const savedRun = this.store.insert('depreciationRun', {
      companyId,
      periodCode,
      runDate,
      totalDepreciationMinor: String(totalDepreciationMinor),
      journalEntryId: journalEntry.id,
      status: 'POSTED',
    });

    const savedLines: DepreciationLine[] = [];
    for (const { asset, monthlyDep } of pending) {
      const newAccumulated = Number(asset.accumulatedDepreciationMinor) + monthlyDep;

      const depLine = this.store.insert('depreciationLine', {
        runId: savedRun.id,
        fixedAssetId: asset.id,
        depreciationAmountMinor: String(monthlyDep),
        accumulatedAfterMinor: String(newAccumulated),
      });
      savedLines.push(depLine);

      this.store.update('fixedAsset', asset.id, {
        accumulatedDepreciationMinor: String(newAccumulated),
        lastDepreciatedPeriod: periodCode,
      });
    }

    return { ...savedRun, lines: savedLines };
  }

  listDepreciationRuns(companyId: number) {
    return this.store
      .find<DepreciationRun>('depreciationRun', (r) => r.companyId === companyId)
      .sort((a, b) => b.id - a.id);
  }

  // ---------- Disposal ----------

  async disposeAsset(input: DisposeAssetInput) {
    const { assetId, disposalDate, disposalProceedsMinor, proceedsAccountId, gainOnDisposalAccountId, lossOnDisposalAccountId } =
      input;

    const asset = this.store.findById<FixedAsset>('fixedAsset', assetId);
    if (!asset) throw new NotFoundException(`Fixed asset ${assetId} not found`);
    if (asset.status !== FixedAssetStatus.CAPITALIZED) {
      throw new BadRequestException(`Asset ${asset.assetCode} is not CAPITALIZED and cannot be disposed`);
    }
    const category = this.store.findById<AssetCategory>('assetCategory', asset.categoryId);
    if (!category) throw new NotFoundException(`Asset category ${asset.categoryId} not found`);

    const cost = Number(asset.costMinor);
    const accumulated = Number(asset.accumulatedDepreciationMinor);
    const netBookValue = cost - accumulated;
    const gainLoss = disposalProceedsMinor - netBookValue;

    const lines: any[] = [];

    if (accumulated > 0) {
      lines.push({
        accountId: category.accumulatedDepreciationAccountId,
        description: `Write off accumulated depreciation - ${asset.assetCode}`,
        debitMinor: accumulated,
      });
    }
    if (disposalProceedsMinor > 0) {
      lines.push({
        accountId: proceedsAccountId,
        description: `Proceeds on disposal - ${asset.assetCode}`,
        debitMinor: disposalProceedsMinor,
      });
    }
    lines.push({
      accountId: category.assetAccountId,
      description: `Derecognize cost - ${asset.assetCode}`,
      creditMinor: cost,
    });

    if (gainLoss > 0) {
      if (!gainOnDisposalAccountId) {
        throw new BadRequestException(
          `Disposal of asset ${asset.assetCode} results in a gain of ${gainLoss}; please supply gainOnDisposalAccountId`,
        );
      }
      lines.push({
        accountId: gainOnDisposalAccountId,
        description: `Gain on disposal - ${asset.assetCode}`,
        creditMinor: gainLoss,
      });
    } else if (gainLoss < 0) {
      if (!lossOnDisposalAccountId) {
        throw new BadRequestException(
          `Disposal of asset ${asset.assetCode} results in a loss of ${-gainLoss}; please supply lossOnDisposalAccountId`,
        );
      }
      lines.push({
        accountId: lossOnDisposalAccountId,
        description: `Loss on disposal - ${asset.assetCode}`,
        debitMinor: -gainLoss,
      });
    }

    await this.accountingService.post({
      companyId: asset.companyId,
      entryDate: disposalDate,
      memo: `Disposal of asset ${asset.assetCode} - ${asset.name}`,
      sourceType: 'fixed_asset_disposal',
      sourceId: String(asset.id),
      lines,
    });

    return this.store.update('fixedAsset', assetId, {
      status: FixedAssetStatus.DISPOSED,
      disposalDate,
      disposalProceedsMinor: String(disposalProceedsMinor),
    });
  }

  // ---------- Reports ----------

  async assetRegisterReport(companyId: number) {
    const assets = this.store
      .find<FixedAsset>('fixedAsset', (a) => a.companyId === companyId)
      .sort((a, b) => (a.assetCode > b.assetCode ? 1 : a.assetCode < b.assetCode ? -1 : 0));
    const categories = this.store.find<AssetCategory>('assetCategory', (c) => c.companyId === companyId);
    const categoryById = new Map(categories.map((c) => [Number(c.id), c]));

    return assets.map((a) => {
      const category = categoryById.get(Number(a.categoryId));
      const netBookValueMinor = (BigInt(a.costMinor) - BigInt(a.accumulatedDepreciationMinor)).toString();
      return {
        id: a.id,
        assetCode: a.assetCode,
        name: a.name,
        categoryName: category?.name,
        acquisitionDate: a.acquisitionDate,
        status: a.status,
        costMinor: a.costMinor,
        accumulatedDepreciationMinor: a.accumulatedDepreciationMinor,
        netBookValueMinor,
      };
    });
  }
}
