import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';

/**
 * Read-only reporting layer. Everything here is computed on the fly from the
 * in-memory DataStore (no database): financial statements straight from the
 * general ledger, VAT returns from posted invoices/bills, and a set of flat,
 * enriched "datasets" that the frontend's JSON-driven report engine groups,
 * filters, charts and exports.
 *
 * All money values are integer minor units (cents), base currency.
 */

type Row = Record<string, any>;

export interface StatementLine {
  key: string;
  label: string;
  level: number; // 0 = section heading, 1 = group, 2 = account
  kind: 'heading' | 'account' | 'subtotal' | 'total' | 'percent';
  accountId?: number;
  code?: string;
  amounts: number[]; // one per column
}

export interface Statement {
  title: string;
  company: Row;
  columns: { label: string; from?: string; to?: string; asOf?: string }[];
  lines: StatementLine[];
  checks?: Row;
}

const DAY = 86_400_000;
const iso = (d: Date) => d.toISOString().slice(0, 10);
const n = (v: any) => Number(v || 0);

/** Sri Lankan fiscal year runs 1 April - 31 March. */
export function fiscalYearStart(date: string): string {
  const [y, m] = date.split('-').map(Number);
  return `${m >= 4 ? y : y - 1}-04-01`;
}

@Injectable()
export class ReportsService {
  constructor(private store: DataStore) {}

  // ===================================================================
  // Shared helpers
  // ===================================================================

  today(): string {
    return iso(new Date());
  }

  company(companyId: number) {
    const c = this.store.findById<any>('company', companyId);
    if (!c) throw new NotFoundException('Company not found');
    return c;
  }

  accounts(companyId: number) {
    return this.store.find<any>('account', (a) => a.companyId === companyId).sort((a, b) => (a.code > b.code ? 1 : -1));
  }

  /** Classifies an account into a statement section / group using code ranges and names. */
  classify(a: Row): { section: string; group: string; order: number } {
    const code = Number(a.code);
    const name = String(a.name || '');
    switch (a.accountType) {
      case 'ASSET':
        if (code >= 1500 && code < 2000) return { section: 'ASSET', group: 'Non-current assets', order: 2 };
        if (code < 1100) return { section: 'ASSET', group: 'Cash & cash equivalents', order: 1 };
        return { section: 'ASSET', group: 'Current assets', order: 1 };
      case 'LIABILITY':
        if (/loan|long[- ]term|lease/i.test(name)) return { section: 'LIABILITY', group: 'Non-current liabilities', order: 2 };
        return { section: 'LIABILITY', group: 'Current liabilities', order: 1 };
      case 'EQUITY':
        return { section: 'EQUITY', group: 'Equity', order: 1 };
      case 'INCOME':
        if (code >= 4000 && code < 4500) return { section: 'INCOME', group: 'Revenue', order: 1 };
        return { section: 'INCOME', group: 'Other income', order: 4 };
      default: // EXPENSE
        if (code >= 4000 && code < 4500) return { section: 'EXPENSE', group: 'Revenue', order: 1 }; // contra revenue (discounts)
        if (code >= 5000 && code < 5500) return { section: 'EXPENSE', group: 'Cost of sales', order: 2 };
        if (code >= 5500 && code < 6000) return { section: 'EXPENSE', group: 'Other expenses', order: 5 };
        if (code >= 7000 && code < 8000) return { section: 'EXPENSE', group: 'Finance costs', order: 6 };
        if (code >= 8000) return { section: 'EXPENSE', group: 'Income tax expense', order: 8 };
        if (/depreciation|amorti/i.test(name)) return { section: 'EXPENSE', group: 'Depreciation', order: 3 };
        if (/marketing|advertis|promotion|delivery|freight out/i.test(name))
          return { section: 'EXPENSE', group: 'Selling & distribution expenses', order: 3 };
        return { section: 'EXPENSE', group: 'Administrative expenses', order: 3 };
    }
  }

  /** Posted journal lines for a company, joined with their entry, optionally within [from, to]. */
  postedLines(companyId: number, from?: string, to?: string) {
    const entries = new Map<number, any>();
    for (const e of this.store.all<any>('journalEntry')) {
      if (e.companyId !== companyId || e.status === 'DRAFT') continue;
      // REVERSED originals stay in the ledger: their reversal entry offsets them.
      if (from && e.entryDate < from) continue;
      if (to && e.entryDate > to) continue;
      entries.set(e.id, e);
    }
    const out: { line: any; entry: any }[] = [];
    for (const l of this.store.all<any>('journalLine')) {
      const e = entries.get(l.entryId);
      if (e) out.push({ line: l, entry: e });
    }
    return out;
  }

  /** Net (debit - credit) base-currency movement per account. */
  movements(companyId: number, from?: string, to?: string): Map<number, number> {
    const m = new Map<number, number>();
    for (const { line } of this.postedLines(companyId, from, to)) {
      m.set(line.accountId, (m.get(line.accountId) || 0) + n(line.baseDebitMinor) - n(line.baseCreditMinor));
    }
    return m;
  }

  private dayBefore(d: string) {
    return iso(new Date(new Date(d + 'T00:00:00Z').getTime() - DAY));
  }

  // ===================================================================
  // Financial statements
  // ===================================================================

  /** Statement of profit or loss. Supports up to N comparison columns. */
  profitAndLoss(companyId: number, periods: { from: string; to: string; label?: string }[]): Statement {
    const company = this.company(companyId);
    const accts = this.accounts(companyId).filter((a) => a.accountType === 'INCOME' || a.accountType === 'EXPENSE');
    const mv = periods.map((p) => this.movements(companyId, p.from, p.to));
    // Income shown positive (credit), expenses positive (debit).
    const amt = (a: Row, i: number) => {
      const v = mv[i].get(a.id) || 0;
      return a.accountType === 'INCOME' ? -v : v;
    };
    const cols = periods.length;
    const zero = () => new Array(cols).fill(0);
    const lines: StatementLine[] = [];
    const groupTotals: Record<string, number[]> = {};

    const addGroup = (group: string, sign: 1 | -1, label = group) => {
      const members = accts.filter((a) => this.classify(a).group === group);
      const tot = zero();
      const rows: StatementLine[] = [];
      for (const a of members) {
        const vals = periods.map((_, i) => {
          // contra-revenue expense accounts reduce revenue
          const raw = amt(a, i);
          return group === 'Revenue' && a.accountType === 'EXPENSE' ? -raw : raw;
        });
        if (vals.every((v) => v === 0)) continue;
        vals.forEach((v, i) => (tot[i] += v));
        rows.push({ key: 'a' + a.id, label: a.name, code: a.code, accountId: a.id, level: 2, kind: 'account', amounts: vals });
      }
      groupTotals[group] = tot;
      if (rows.length === 0) return tot;
      lines.push({ key: 'h-' + group, label, level: 1, kind: 'heading', amounts: zero() });
      lines.push(...rows);
      lines.push({ key: 't-' + group, label: `Total ${label.toLowerCase()}`, level: 1, kind: 'subtotal', amounts: tot.map((v) => v * sign) });
      return tot;
    };

    const rev = addGroup('Revenue', 1);
    const cos = addGroup('Cost of sales', 1);
    const gp = rev.map((v, i) => v - cos[i]);
    lines.push({ key: 'gp', label: 'Gross profit', level: 0, kind: 'total', amounts: gp });
    lines.push({
      key: 'gpm',
      label: 'Gross margin %',
      level: 1,
      kind: 'percent', // basis points
      amounts: gp.map((v, i) => (rev[i] ? Math.round((v / rev[i]) * 10000) : 0)),
    });
    const oi = addGroup('Other income', 1);
    const sd = addGroup('Selling & distribution expenses', 1);
    const ad = addGroup('Administrative expenses', 1);
    const dep = addGroup('Depreciation', 1);
    const ox = addGroup('Other expenses', 1);
    const op = gp.map((v, i) => v + oi[i] - sd[i] - ad[i] - dep[i] - ox[i]);
    lines.push({ key: 'op', label: 'Operating profit / (loss)', level: 0, kind: 'total', amounts: op });
    const fc = addGroup('Finance costs', 1);
    const pbt = op.map((v, i) => v - fc[i]);
    lines.push({ key: 'pbt', label: 'Profit / (loss) before tax', level: 0, kind: 'total', amounts: pbt });
    const tax = addGroup('Income tax expense', 1);
    const pat = pbt.map((v, i) => v - tax[i]);
    lines.push({ key: 'pat', label: 'Profit / (loss) for the period', level: 0, kind: 'total', amounts: pat });

    return {
      title: 'Statement of Profit or Loss',
      company,
      columns: periods.map((p) => ({ label: p.label || `${p.from} to ${p.to}`, from: p.from, to: p.to })),
      lines,
      checks: { revenue: rev, grossProfit: gp, netProfit: pat },
    };
  }

  /** Statement of financial position as at one or more dates. */
  balanceSheet(companyId: number, asOfDates: string[]): Statement {
    const company = this.company(companyId);
    const accts = this.accounts(companyId);
    const cols = asOfDates.length;
    const zero = () => new Array(cols).fill(0);
    const bal = asOfDates.map((d) => this.movements(companyId, undefined, d));
    const plBal = asOfDates.map((d) => {
      // Profit for the current fiscal year to date + any earlier un-closed profits.
      const fy = fiscalYearStart(d);
      const cur = this.movements(companyId, fy, d);
      const prior = this.movements(companyId, undefined, this.dayBefore(fy));
      let cy = 0;
      let py = 0;
      for (const a of accts) {
        if (a.accountType !== 'INCOME' && a.accountType !== 'EXPENSE') continue;
        cy -= cur.get(a.id) || 0;
        py -= prior.get(a.id) || 0;
      }
      return { cy, py };
    });

    const lines: StatementLine[] = [];
    const section = (sectionKey: string, title: string, sign: 1 | -1, groups: string[]) => {
      lines.push({ key: 's-' + sectionKey, label: title, level: 0, kind: 'heading', amounts: zero() });
      const secTot = zero();
      for (const g of groups) {
        const rows: StatementLine[] = [];
        const tot = zero();
        for (const a of accts) {
          if (a.accountType !== sectionKey) continue;
          if (this.classify(a).group !== g) continue;
          const vals = bal.map((m) => (m.get(a.id) || 0) * sign);
          if (vals.every((v) => v === 0)) continue;
          vals.forEach((v, i) => (tot[i] += v));
          rows.push({ key: 'a' + a.id, label: a.name, code: a.code, accountId: a.id, level: 2, kind: 'account', amounts: vals });
        }
        if (sectionKey === 'EQUITY' && g === 'Equity') {
          const py = plBal.map((p) => p.py);
          const cy = plBal.map((p) => p.cy);
          if (py.some((v) => v !== 0)) {
            rows.push({ key: 'pyre', label: 'Retained earnings - prior periods (not yet closed)', level: 2, kind: 'account', amounts: py });
            py.forEach((v, i) => (tot[i] += v));
          }
          rows.push({ key: 'cyre', label: 'Profit / (loss) for the current year', level: 2, kind: 'account', amounts: cy });
          cy.forEach((v, i) => (tot[i] += v));
        }
        if (rows.length === 0) continue;
        if (g === title) {
          lines.push(...rows); // single-group section: the section total is enough
        } else {
          lines.push({ key: 'h-' + g, label: g, level: 1, kind: 'heading', amounts: zero() });
          lines.push(...rows);
          lines.push({ key: 't-' + g, label: `Total ${g.toLowerCase()}`, level: 1, kind: 'subtotal', amounts: tot });
        }
        tot.forEach((v, i) => (secTot[i] += v));
      }
      lines.push({ key: 'T-' + sectionKey, label: `Total ${title.toLowerCase()}`, level: 0, kind: 'total', amounts: secTot });
      return secTot;
    };

    const assets = section('ASSET', 'Assets', 1, ['Non-current assets', 'Current assets', 'Cash & cash equivalents']);
    const equity = section('EQUITY', 'Equity', -1, ['Equity']);
    const liab = section('LIABILITY', 'Liabilities', -1, ['Non-current liabilities', 'Current liabilities']);
    const le = equity.map((v, i) => v + liab[i]);
    lines.push({ key: 'TLE', label: 'Total equity and liabilities', level: 0, kind: 'total', amounts: le });
    return {
      title: 'Statement of Financial Position',
      company,
      columns: asOfDates.map((d) => ({ label: `As at ${d}`, asOf: d })),
      lines,
      checks: { assets, equityAndLiabilities: le, balanced: assets.map((v, i) => v === le[i]) },
    };
  }

  /** Statement of cash flows - indirect method, derived from balance-sheet movements. */
  cashFlow(companyId: number, from: string, to: string): Statement {
    const company = this.company(companyId);
    const accts = this.accounts(companyId);
    const mv = this.movements(companyId, from, to);
    const opening = this.movements(companyId, undefined, this.dayBefore(from));
    const closing = this.movements(companyId, undefined, to);
    const lines: StatementLine[] = [];
    const L = (key: string, label: string, v: number, kind: StatementLine['kind'] = 'account', level = 2) =>
      lines.push({ key, label, level, kind, amounts: [v] });

    let profit = 0;
    for (const a of accts) if (a.accountType === 'INCOME' || a.accountType === 'EXPENSE') profit -= mv.get(a.id) || 0;

    const isCash = (a: Row) => a.accountType === 'ASSET' && this.classify(a).group === 'Cash & cash equivalents';
    const isAccDep = (a: Row) => /accumulated depreciation|accum\.? dep/i.test(a.name);

    lines.push({ key: 'h-op', label: 'Cash flows from operating activities', level: 0, kind: 'heading', amounts: [0] });
    L('np', 'Profit / (loss) for the period', profit);
    let nonCash = 0;
    for (const a of accts) if (isAccDep(a)) nonCash -= mv.get(a.id) || 0;
    L('dep', 'Adjustment: depreciation', nonCash);
    let wc = 0;
    const wcRows: [string, string, number][] = [];
    for (const a of accts) {
      if (isCash(a) || isAccDep(a)) continue;
      const cls = this.classify(a);
      const v = mv.get(a.id) || 0;
      if (!v) continue;
      if (cls.group === 'Current assets' || cls.group === 'Current liabilities') {
        // An increase in an asset (debit) uses cash; an increase in a liability (credit) provides cash.
        wcRows.push(['wc' + a.id, `${v > 0 === (a.accountType === 'ASSET') ? 'Increase' : 'Decrease'} in ${a.name}`, -v]);
        wc -= v;
      }
    }
    for (const [k, l, v] of wcRows) L(k, l, v);
    const cfo = profit + nonCash + wc;
    L('cfo', 'Net cash from operating activities', cfo, 'subtotal', 1);

    lines.push({ key: 'h-inv', label: 'Cash flows from investing activities', level: 0, kind: 'heading', amounts: [0] });
    let cfi = 0;
    for (const a of accts) {
      if (isAccDep(a)) continue;
      if (this.classify(a).group !== 'Non-current assets') continue;
      const v = mv.get(a.id) || 0;
      if (!v) continue;
      L('inv' + a.id, v > 0 ? `Purchase of ${a.name.replace(/ - cost$/i, '')}` : `Disposal of ${a.name.replace(/ - cost$/i, '')}`, -v);
      cfi -= v;
    }
    L('cfi', 'Net cash used in investing activities', cfi, 'subtotal', 1);

    lines.push({ key: 'h-fin', label: 'Cash flows from financing activities', level: 0, kind: 'heading', amounts: [0] });
    let cff = 0;
    for (const a of accts) {
      const g = this.classify(a).group;
      if (g !== 'Equity' && g !== 'Non-current liabilities') continue;
      const v = mv.get(a.id) || 0;
      if (!v) continue;
      L('fin' + a.id, `${v < 0 ? 'Proceeds from' : 'Repayment of'} ${a.name}`, -v);
      cff -= v;
    }
    L('cff', 'Net cash from financing activities', cff, 'subtotal', 1);

    const net = cfo + cfi + cff;
    let open = 0;
    let close = 0;
    for (const a of accts) if (isCash(a)) {
      open += opening.get(a.id) || 0;
      close += closing.get(a.id) || 0;
    }
    L('net', 'Net increase / (decrease) in cash and cash equivalents', net, 'total', 0);
    L('open', `Cash and cash equivalents at ${from}`, open, 'account', 1);
    L('close', `Cash and cash equivalents at ${to}`, open + net, 'total', 0);
    return {
      title: 'Statement of Cash Flows (indirect method)',
      company,
      columns: [{ label: `${from} to ${to}`, from, to }],
      lines,
      checks: { closingPerLedger: close, closingPerStatement: open + net, reconciles: close === open + net },
    };
  }

  /** Statement of changes in equity for a period. */
  changesInEquity(companyId: number, from: string, to: string): Statement {
    const company = this.company(companyId);
    const accts = this.accounts(companyId);
    const eq = accts.filter((a) => a.accountType === 'EQUITY');
    const opening = this.movements(companyId, undefined, this.dayBefore(from));
    const mv = this.movements(companyId, from, to);
    let openPL = 0;
    let periodPL = 0;
    for (const a of accts) {
      if (a.accountType !== 'INCOME' && a.accountType !== 'EXPENSE') continue;
      openPL -= opening.get(a.id) || 0;
      periodPL -= mv.get(a.id) || 0;
    }
    // Columns: one per equity account + accumulated profits + total
    const colLabels = [...eq.map((a) => a.name), 'Accumulated profits (unclosed)', 'Total'];
    const row = (key: string, label: string, vals: number[], kind: StatementLine['kind'] = 'account'): StatementLine => ({
      key,
      label,
      level: kind === 'total' ? 0 : 2,
      kind,
      amounts: [...vals, vals.reduce((s, v) => s + v, 0)],
    });
    const openVals = [...eq.map((a) => -(opening.get(a.id) || 0)), openPL];
    const contrib = [...eq.map((a) => -(mv.get(a.id) || 0)), 0];
    const profitVals = [...eq.map(() => 0), periodPL];
    const closeVals = openVals.map((v, i) => v + contrib[i] + profitVals[i]);
    return {
      title: 'Statement of Changes in Equity',
      company,
      columns: colLabels.map((l) => ({ label: l, from, to })),
      lines: [
        row('open', `Balance at ${from}`, openVals, 'total'),
        row('pl', 'Profit / (loss) for the period', profitVals),
        row('contrib', 'Capital introduced / (withdrawn) and other equity movements', contrib),
        row('close', `Balance at ${to}`, closeVals, 'total'),
      ],
    };
  }

  /** Trial balance with opening, period movement and closing columns. */
  trialBalanceDetailed(companyId: number, from: string, to: string) {
    const opening = this.movements(companyId, undefined, this.dayBefore(from));
    const lines = this.postedLines(companyId, from, to);
    const dr = new Map<number, number>();
    const cr = new Map<number, number>();
    for (const { line } of lines) {
      dr.set(line.accountId, (dr.get(line.accountId) || 0) + n(line.baseDebitMinor));
      cr.set(line.accountId, (cr.get(line.accountId) || 0) + n(line.baseCreditMinor));
    }
    return this.accounts(companyId)
      .map((a) => {
        const o = opening.get(a.id) || 0;
        const d = dr.get(a.id) || 0;
        const c = cr.get(a.id) || 0;
        const cl = o + d - c;
        return {
          accountId: a.id,
          code: a.code,
          name: a.name,
          accountType: a.accountType,
          group: this.classify(a).group,
          openingDebit: o > 0 ? o : 0,
          openingCredit: o < 0 ? -o : 0,
          periodDebit: d,
          periodCredit: c,
          closingDebit: cl > 0 ? cl : 0,
          closingCredit: cl < 0 ? -cl : 0,
        };
      })
      .filter((r) => r.openingDebit || r.openingCredit || r.periodDebit || r.periodCredit);
  }

  // ===================================================================
  // VAT return (Sri Lanka - output / input schedules)
  // ===================================================================

  vatReturn(companyId: number, from: string, to: string) {
    const company = this.company(companyId);
    const taxRates = new Map(this.store.find<any>('taxRate', (t) => t.companyId === companyId).map((t) => [t.id, t]));
    const customers = new Map(this.store.find<any>('customer', (c) => c.companyId === companyId).map((c) => [c.id, c]));
    const suppliers = new Map(this.store.find<any>('supplier', (s) => s.companyId === companyId).map((s) => [s.id, s]));

    const outRows: Row[] = [];
    const byRate = new Map<string, { rate: string; net: number; vat: number; count: number }>();
    for (const inv of this.store.all<any>('invoice')) {
      if (inv.companyId !== companyId || inv.status === 'DRAFT' || inv.status === 'VOID') continue;
      if (inv.invoiceDate < from || inv.invoiceDate > to) continue;
      const fx = n(inv.exchangeRate) || 1;
      const lines = this.store.find<any>('invoiceLine', (l) => l.invoiceId === inv.id);
      let net = 0;
      let vat = 0;
      let zeroRated = 0;
      for (const l of lines) {
        const rate = taxRates.get(l.taxRateId);
        const lt = Math.round(n(l.lineTotalMinor) * fx);
        const isVat = rate?.isVat;
        const v = isVat ? Math.round((lt * rate.rateBasisPoints) / 10000) : 0;
        const key = isVat ? rate.name : rate ? rate.name : 'No tax / exempt';
        const agg = byRate.get(key) || { rate: key, net: 0, vat: 0, count: 0 };
        agg.net += lt;
        agg.vat += v;
        agg.count += 1;
        byRate.set(key, agg);
        if (isVat) {
          net += lt;
          vat += v;
        } else zeroRated += lt;
      }
      const c = customers.get(inv.customerId) || {};
      outRows.push({
        invoiceId: inv.id,
        invoiceNumber: inv.invoiceNumber,
        invoiceDate: inv.invoiceDate,
        customerName: c.name,
        customerTin: c.tin || c.vatRegistrationNo || '',
        taxableValue: net,
        zeroRatedOrExempt: zeroRated,
        vat,
        total: net + zeroRated + vat,
      });
    }

    const inRows: Row[] = [];
    for (const b of this.store.all<any>('bill')) {
      if (b.companyId !== companyId || b.status === 'DRAFT' || b.status === 'VOID') continue;
      if (b.billDate < from || b.billDate > to) continue;
      const fx = n(b.exchangeRate) || 1;
      const net = Math.round(n(b.subtotalMinor) * fx);
      const vat = Math.round(n(b.taxMinor) * fx);
      const s = suppliers.get(b.supplierId) || {};
      inRows.push({
        billNumber: b.billNumber,
        supplierInvoiceNo: b.supplierInvoiceNo || '',
        billDate: b.billDate,
        supplierName: s.name,
        supplierTin: s.tin || '',
        importOrLocal: s.defaultCurrencyCode && s.defaultCurrencyCode !== company.baseCurrency ? 'Import' : 'Local',
        value: net,
        vat,
        claimable: vat,
      });
    }

    // GL cross-check: movement on VAT accounts in the period.
    const vatAccounts = new Set<number>();
    const outAccounts = new Set<number>();
    const inAccounts = new Set<number>();
    for (const t of taxRates.values()) {
      if (!t.isVat) continue;
      if (t.outputTaxAccountId) {
        vatAccounts.add(t.outputTaxAccountId);
        outAccounts.add(t.outputTaxAccountId);
      }
      if (t.inputTaxAccountId) {
        vatAccounts.add(t.inputTaxAccountId);
        inAccounts.add(t.inputTaxAccountId);
      }
    }
    const glClosing = this.movements(companyId, undefined, to);
    let vatControlBalance = 0;
    for (const id of vatAccounts) vatControlBalance += glClosing.get(id) || 0;

    const outputVat = outRows.reduce((s, r) => s + r.vat, 0);
    const inputVat = inRows.reduce((s, r) => s + r.vat, 0);
    const taxable = outRows.reduce((s, r) => s + r.taxableValue, 0);
    const zero = outRows.reduce((s, r) => s + r.zeroRatedOrExempt, 0);
    return {
      company,
      period: { from, to },
      summary: {
        totalSupplies: taxable + zero,
        taxableSupplies: taxable,
        zeroRatedOrExempt: zero,
        outputVat,
        totalPurchases: inRows.reduce((s, r) => s + r.value, 0),
        importPurchases: inRows.filter((r) => r.importOrLocal === 'Import').reduce((s, r) => s + r.value, 0),
        localPurchases: inRows.filter((r) => r.importOrLocal === 'Local').reduce((s, r) => s + r.value, 0),
        inputVat,
        netVatPayable: outputVat - inputVat,
        invoiceCount: outRows.length,
        billCount: inRows.length,
        vatControlBalanceAtEnd: -vatControlBalance, // positive = payable to IRD
      },
      byRate: Array.from(byRate.values()),
      outputSchedule: outRows.sort((a, b) => (a.invoiceDate > b.invoiceDate ? 1 : -1)),
      inputSchedule: inRows.sort((a, b) => (a.billDate > b.billDate ? 1 : -1)),
    };
  }

  // ===================================================================
  // Invoice print data (VAT tax invoice)
  // ===================================================================

  invoicePrint(invoiceId: number) {
    const inv = this.store.findById<any>('invoice', invoiceId);
    if (!inv) throw new NotFoundException('Invoice not found');
    const company = this.company(inv.companyId);
    const customer = this.store.findById<any>('customer', inv.customerId) || {};
    const taxRates = new Map(this.store.all<any>('taxRate').map((t) => [t.id, t]));
    const items = new Map(this.store.all<any>('item').map((i) => [i.id, i]));
    const lines = this.store
      .find<any>('invoiceLine', (l) => l.invoiceId === inv.id)
      .map((l, idx) => {
        const rate = taxRates.get(l.taxRateId);
        const item = items.get(l.itemId);
        const net = n(l.lineTotalMinor);
        const vatRateBp = rate?.isVat ? rate.rateBasisPoints : 0;
        return {
          lineNo: idx + 1,
          itemCode: item?.sku || '',
          description: l.description,
          brand: item?.brand || null,
          warrantyMonths: item?.warrantyMonths ?? null,
          unitOfMeasure: item?.unitOfMeasure || 'EA',
          quantity: n(l.quantity),
          unitPriceMinor: n(l.unitPriceMinor),
          netMinor: net,
          vatRateBp,
          vatMinor: Math.round((net * vatRateBp) / 10000),
          otherTaxMinor: rate && !rate.isVat ? Math.round((net * rate.rateBasisPoints) / 10000) : 0,
        };
      });
    const receipts = this.store
      .find<any>('receiptAllocation', (a) => a.invoiceId === inv.id)
      .map((a) => {
        const r = this.store.findById<any>('receipt', a.receiptId);
        return { receiptNumber: r?.receiptNumber, receiptDate: r?.receiptDate, amountMinor: n(a.allocatedAmountMinor) };
      });
    return { invoice: inv, company, customer, lines, receipts };
  }

  // ===================================================================
  // Datasets for the JSON report engine
  // ===================================================================

  private ctx(companyId: number) {
    const items = new Map(this.store.find<any>('item', (i) => i.companyId === companyId).map((i) => [i.id, i]));
    const classes = new Map(this.store.find<any>('itemClass', (c) => c.companyId === companyId).map((c) => [c.id, c]));
    const customers = new Map(this.store.find<any>('customer', (c) => c.companyId === companyId).map((c) => [c.id, c]));
    const suppliers = new Map(this.store.find<any>('supplier', (s) => s.companyId === companyId).map((s) => [s.id, s]));
    const accounts = new Map(this.accounts(companyId).map((a) => [a.id, a]));
    return { items, classes, customers, suppliers, accounts };
  }

  /** Per-item cost of each invoice, from stock issues linked to the invoice (or its delivery note), else current WAC. */
  private invoiceCosts(companyId: number) {
    const byInvoiceItem = new Map<string, number>();
    const issueQtyByInvoiceItem = new Map<string, number>();
    const dnToInvoice = new Map<number, number>();
    for (const inv of this.store.all<any>('invoice')) if (inv.companyId === companyId && inv.dnId) dnToInvoice.set(inv.dnId, inv.id);
    const posSaleToInvoice = new Map<string, number>();
    for (const s of this.store.all<any>('posSale')) if (s.companyId === companyId && s.invoiceId) posSaleToInvoice.set(String(s.id), s.invoiceId);
    for (const m of this.store.all<any>('stockMovement')) {
      if (m.companyId !== companyId || m.movementType !== 'ISSUE') continue;
      let invId: number | undefined;
      if (m.sourceType === 'invoice') invId = Number(m.sourceId);
      else if (m.sourceType === 'delivery') invId = dnToInvoice.get(Number(m.sourceId));
      else if (m.sourceType === 'pos_sale') invId = posSaleToInvoice.get(String(m.sourceId));
      if (!invId) continue;
      const k = invId + ':' + m.itemId;
      byInvoiceItem.set(k, (byInvoiceItem.get(k) || 0) + n(m.totalCostMinor));
      issueQtyByInvoiceItem.set(k, (issueQtyByInvoiceItem.get(k) || 0) + n(m.quantity));
    }
    return { byInvoiceItem, issueQtyByInvoiceItem };
  }

  /** Current stock (qty, WAC) for every item, replaying movements up to `asOf`. */
  stockPositions(companyId: number, asOf?: string) {
    const moves = this.store
      .find<any>('stockMovement', (m) => m.companyId === companyId && (!asOf || m.movementDate <= asOf))
      .sort((a, b) => (a.movementDate < b.movementDate ? -1 : a.movementDate > b.movementDate ? 1 : a.id - b.id));
    const pos = new Map<number, { qty: number; wac: number; lastReceipt?: string; lastIssue?: string }>();
    for (const m of moves) {
      const p = pos.get(m.itemId) || { qty: 0, wac: 0 };
      const q = n(m.quantity);
      if (m.movementType === 'RECEIPT' || m.movementType === 'ADJUSTMENT_IN') {
        const nq = p.qty + q;
        p.wac = nq > 0 ? (p.qty * p.wac + q * n(m.unitCostMinor)) / nq : 0;
        p.qty = nq;
        if (m.movementType === 'RECEIPT') p.lastReceipt = m.movementDate;
      } else {
        p.qty -= q;
        if (m.movementType === 'ISSUE') p.lastIssue = m.movementDate;
      }
      pos.set(m.itemId, p);
    }
    return pos;
  }

  dataset(name: string, companyId: number, from?: string, to?: string): Row[] {
    const t = to || this.today();
    const f = from || fiscalYearStart(t);
    const inRange = (d: string) => !!d && d.slice(0, 10) >= f && d.slice(0, 10) <= t;
    const c = this.ctx(companyId);
    const today = this.today();
    const daysBetween = (a: string, b: string) =>
      Math.floor((new Date(b + 'T00:00:00Z').getTime() - new Date(a + 'T00:00:00Z').getTime()) / DAY);
    const bucket = (days: number) =>
      days <= 0 ? 'Current' : days <= 30 ? '1-30' : days <= 60 ? '31-60' : days <= 90 ? '61-90' : '90+';
    const catOf = (item: any) => (item ? c.classes.get(item.itemClassId)?.name || 'Uncategorised' : 'Non-stock / GL');

    switch (name) {
      case 'salesLines': {
        const costs = this.invoiceCosts(companyId);
        const pos = this.stockPositions(companyId);
        const rows: Row[] = [];
        for (const inv of this.store.all<any>('invoice')) {
          if (inv.companyId !== companyId || inv.status === 'DRAFT' || inv.status === 'VOID' || !inRange(inv.invoiceDate)) continue;
          const cust = c.customers.get(inv.customerId) || {};
          const fx = n(inv.exchangeRate) || 1;
          const invLines = this.store.find<any>('invoiceLine', (x) => x.invoiceId === inv.id);
          const isPcBuild = invLines.some((x) => /PC-BUILD/i.test(c.items.get(x.itemId)?.sku || ''));
          for (const l of invLines) {
            const item = c.items.get(l.itemId);
            const net = Math.round(n(l.lineTotalMinor) * fx);
            const qty = n(l.quantity);
            const k = inv.id + ':' + l.itemId;
            let cost = 0;
            if (item?.itemType === 'STOCK') {
              const issued = costs.byInvoiceItem.get(k);
              cost = issued != null ? issued : Math.round((pos.get(item.id)?.wac || 0) * qty);
            }
            const vat = Math.round((inv.taxMinor && n(inv.subtotalMinor) ? (n(l.lineTotalMinor) / n(inv.subtotalMinor)) * n(inv.taxMinor) : 0) * fx);
            rows.push({
              invoiceNumber: inv.invoiceNumber,
              invoiceDate: inv.invoiceDate,
              month: inv.invoiceDate.slice(0, 7),
              weekday: new Date(inv.invoiceDate + 'T00:00:00Z').toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' }),
              customerCode: cust.code,
              customerName: cust.name,
              customerType: cust.customerType || 'CUSTOMER',
              channel: inv.channel || (cust.code === 'WALKIN' ? 'WALK_IN' : 'B2B'),
              salesPerson: inv.salesPerson || 'Unassigned',
              paymentMode: inv.paymentMode || 'CREDIT',
              sku: item?.sku || '(GL line)',
              itemName: l.description,
              itemType: item?.itemType || 'GL',
              category: catOf(item),
              brand: item?.brand || '-',
              quantity: qty,
              unitPrice: Math.round(n(l.unitPriceMinor) * fx),
              listPrice: n(item?.salesPriceMinor) * qty,
              discount: item ? Math.max(0, n(item.salesPriceMinor) * qty - net) : 0,
              net,
              vat,
              gross: net + vat,
              cost,
              grossProfit: net - cost,
              marginPct: net ? Math.round(((net - cost) / net) * 10000) / 100 : 0,
              invoiceStatus: inv.status,
              invoiceId: inv.id,
              isPcBuild,
            });
          }
        }
        return rows;
      }

      case 'salesInvoices': {
        return this.store
          .find<any>('invoice', (i) => i.companyId === companyId && i.status !== 'DRAFT' && inRange(i.invoiceDate))
          .map((inv) => {
            const cust = c.customers.get(inv.customerId) || {};
            const fx = n(inv.exchangeRate) || 1;
            const bal = Math.round((n(inv.totalMinor) - n(inv.amountReceivedMinor)) * fx);
            const overdue = inv.status === 'PAID' || inv.status === 'VOID' ? 0 : Math.max(0, daysBetween(inv.dueDate, today));
            return {
              id: inv.id,
              invoiceNumber: inv.invoiceNumber,
              invoiceDate: inv.invoiceDate,
              dueDate: inv.dueDate,
              month: inv.invoiceDate.slice(0, 7),
              customerCode: cust.code,
              customerName: cust.name,
              customerTin: cust.tin || '',
              channel: inv.channel || (cust.code === 'WALKIN' ? 'WALK_IN' : 'B2B'),
              salesPerson: inv.salesPerson || 'Unassigned',
              paymentMode: inv.paymentMode || 'CREDIT',
              currencyCode: inv.currencyCode,
              net: Math.round(n(inv.subtotalMinor) * fx),
              vat: Math.round(n(inv.taxMinor) * fx),
              total: Math.round(n(inv.totalMinor) * fx),
              received: Math.round(n(inv.amountReceivedMinor) * fx),
              balance: bal,
              daysOverdue: overdue,
              agingBucket: bal > 0 ? bucket(overdue) : 'Settled',
              status: inv.status,
              lineCount: this.store.count('invoiceLine', (l: any) => l.invoiceId === inv.id),
            };
          });
      }

      case 'arOpen':
        return this.dataset('salesInvoices', companyId, '1900-01-01', t).filter(
          (r) => r.balance > 0 && r.status !== 'VOID',
        );

      case 'purchaseLines': {
        const rows: Row[] = [];
        for (const b of this.store.all<any>('bill')) {
          if (b.companyId !== companyId || b.status === 'DRAFT' || b.status === 'VOID' || !inRange(b.billDate)) continue;
          const sup = c.suppliers.get(b.supplierId) || {};
          const fx = n(b.exchangeRate) || 1;
          for (const l of this.store.find<any>('billLine', (x) => x.billId === b.id)) {
            const item = c.items.get(l.itemId);
            const net = Math.round(n(l.lineTotalMinor) * fx);
            const vat = n(b.subtotalMinor) ? Math.round((n(l.lineTotalMinor) / n(b.subtotalMinor)) * n(b.taxMinor) * fx) : 0;
            rows.push({
              billNumber: b.billNumber,
              billDate: b.billDate,
              month: b.billDate.slice(0, 7),
              supplierCode: sup.code,
              supplierName: sup.name,
              currencyCode: b.currencyCode,
              sku: item?.sku || '(expense)',
              itemName: l.description,
              category: item ? catOf(item) : c.accounts.get(l.expenseAccountId)?.name || 'Expense',
              brand: item?.brand || '-',
              quantity: n(l.quantity),
              unitCost: Math.round(n(l.unitPriceMinor) * fx),
              net,
              vat,
              gross: net + vat,
            });
          }
        }
        return rows;
      }

      case 'bills': {
        return this.store
          .find<any>('bill', (b) => b.companyId === companyId && b.status !== 'DRAFT' && inRange(b.billDate))
          .map((b) => {
            const sup = c.suppliers.get(b.supplierId) || {};
            const fx = n(b.exchangeRate) || 1;
            const bal = Math.round((n(b.totalMinor) - n(b.amountPaidMinor)) * fx);
            const overdue = b.status === 'PAID' ? 0 : Math.max(0, daysBetween(b.dueDate, today));
            const dueIn = daysBetween(today, b.dueDate);
            return {
              billNumber: b.billNumber,
              supplierInvoiceNo: b.supplierInvoiceNo || '',
              billDate: b.billDate,
              dueDate: b.dueDate,
              month: b.billDate.slice(0, 7),
              supplierCode: sup.code,
              supplierName: sup.name,
              currencyCode: b.currencyCode,
              net: Math.round(n(b.subtotalMinor) * fx),
              vat: Math.round(n(b.taxMinor) * fx),
              total: Math.round(n(b.totalMinor) * fx),
              paid: Math.round(n(b.amountPaidMinor) * fx),
              balance: bal,
              daysOverdue: overdue,
              dueInDays: dueIn,
              agingBucket: bal > 0 ? bucket(overdue) : 'Settled',
              status: b.status,
            };
          });
      }

      case 'apOpen':
        return this.dataset('bills', companyId, '1900-01-01', t).filter((r) => r.balance > 0 && r.status !== 'VOID');

      case 'stockStatus': {
        const pos = this.stockPositions(companyId, t);
        const sold30 = new Map<number, number>();
        const sold90 = new Map<number, number>();
        const soldRange = new Map<number, number>();
        const cogsRange = new Map<number, number>();
        const d30 = iso(new Date(new Date(t + 'T00:00:00Z').getTime() - 30 * DAY));
        const d90 = iso(new Date(new Date(t + 'T00:00:00Z').getTime() - 90 * DAY));
        for (const m of this.store.all<any>('stockMovement')) {
          if (m.companyId !== companyId || m.movementType !== 'ISSUE' || m.movementDate > t) continue;
          const q = n(m.quantity);
          if (m.movementDate > d30) sold30.set(m.itemId, (sold30.get(m.itemId) || 0) + q);
          if (m.movementDate > d90) sold90.set(m.itemId, (sold90.get(m.itemId) || 0) + q);
          if (m.movementDate >= f) {
            soldRange.set(m.itemId, (soldRange.get(m.itemId) || 0) + q);
            cogsRange.set(m.itemId, (cogsRange.get(m.itemId) || 0) + n(m.totalCostMinor));
          }
        }
        const rows: Row[] = [];
        for (const item of c.items.values()) {
          if (item.itemType !== 'STOCK') continue;
          const p = pos.get(item.id) || { qty: 0, wac: 0 };
          const qty = p.qty;
          const wac = Math.round(p.wac);
          const value = Math.round(qty * p.wac);
          const s30 = sold30.get(item.id) || 0;
          const dailyRate = (sold90.get(item.id) || 0) / 90;
          const daysCover = dailyRate > 0 ? Math.round(qty / dailyRate) : qty > 0 ? 999 : 0;
          const reorder = n(item.reorderLevel);
          let status = 'OK';
          if (qty <= 0) status = 'Out of stock';
          else if (qty <= reorder) status = 'Reorder';
          else if (!p.lastIssue || daysBetween(p.lastIssue, t) > 60) status = 'Slow / dead';
          else if (daysCover > 120) status = 'Overstock';
          const target = Math.max(reorder * 3, Math.ceil(dailyRate * 30));
          const sup = c.suppliers.get(item.preferredSupplierId);
          rows.push({
            itemId: item.id,
            sku: item.sku,
            itemName: item.name,
            category: catOf(item),
            brand: item.brand || '-',
            binLocation: item.binLocation || '',
            preferredSupplier: sup?.name || '',
            onHand: qty,
            reorderLevel: reorder,
            wac,
            stockValue: value,
            salesPrice: n(item.salesPriceMinor),
            priceInclVat: Math.round(n(item.salesPriceMinor) * 1.18),
            retailValue: Math.round(qty * n(item.salesPriceMinor)),
            potentialMarginPct: n(item.salesPriceMinor) ? Math.round(((n(item.salesPriceMinor) - wac) / n(item.salesPriceMinor)) * 10000) / 100 : 0,
            soldLast30: s30,
            soldInPeriod: soldRange.get(item.id) || 0,
            cogsInPeriod: cogsRange.get(item.id) || 0,
            turnover: value > 0 ? Math.round(((cogsRange.get(item.id) || 0) / value) * 100) / 100 : 0,
            daysOfCover: daysCover,
            lastReceiptDate: p.lastReceipt || '',
            lastSaleDate: p.lastIssue || '',
            daysSinceLastSale: p.lastIssue ? daysBetween(p.lastIssue, t) : null,
            status,
            suggestedOrderQty: status === 'Reorder' || status === 'Out of stock' ? Math.max(0, Math.ceil(target - qty)) : 0,
            suggestedOrderValue: status === 'Reorder' || status === 'Out of stock' ? Math.max(0, Math.ceil(target - qty)) * wac : 0,
            warrantyMonths: item.warrantyMonths ?? null,
          });
        }
        // ABC classification by period COGS (80/15/5)
        const total = rows.reduce((s, r) => s + r.cogsInPeriod, 0) || 1;
        let cum = 0;
        for (const r of [...rows].sort((a, b) => b.cogsInPeriod - a.cogsInPeriod)) {
          cum += r.cogsInPeriod;
          r.abcClass = r.cogsInPeriod === 0 ? 'C' : cum / total <= 0.8 ? 'A' : cum / total <= 0.95 ? 'B' : 'C';
          r.cumulativeSharePct = Math.round((cum / total) * 10000) / 100;
        }
        return rows;
      }

      case 'stockMovements':
        return this.store
          .find<any>('stockMovement', (m) => m.companyId === companyId && inRange(m.movementDate))
          .map((m) => {
            const item = c.items.get(m.itemId);
            const inbound = m.movementType === 'RECEIPT' || m.movementType === 'ADJUSTMENT_IN';
            return {
              movementDate: m.movementDate,
              month: m.movementDate.slice(0, 7),
              sku: item?.sku,
              itemName: item?.name,
              category: catOf(item),
              brand: item?.brand || '-',
              movementType: m.movementType,
              sourceType: m.sourceType,
              sourceId: m.sourceId,
              qtyIn: inbound ? n(m.quantity) : 0,
              qtyOut: inbound ? 0 : n(m.quantity),
              unitCost: n(m.unitCostMinor),
              valueIn: inbound ? n(m.totalCostMinor) : 0,
              valueOut: inbound ? 0 : n(m.totalCostMinor),
            };
          });

      case 'receipts':
        return this.store
          .find<any>('receipt', (r) => r.companyId === companyId && inRange(r.receiptDate))
          .map((r) => {
            const cust = c.customers.get(r.customerId) || {};
            const alloc = this.store.find<any>('receiptAllocation', (a) => a.receiptId === r.id);
            return {
              receiptNumber: r.receiptNumber,
              receiptDate: r.receiptDate,
              month: r.receiptDate.slice(0, 7),
              customerCode: cust.code,
              customerName: cust.name,
              currencyCode: r.currencyCode,
              amount: Math.round(n(r.amountMinor) * (n(r.exchangeRate) || 1)),
              appliedTo: alloc
                .map((a) => this.store.findById<any>('invoice', a.invoiceId)?.invoiceNumber)
                .filter(Boolean)
                .join(', '),
              depositAccount: c.accounts.get(r.bankAccountGlAccountId)?.name || '',
              status: r.status,
            };
          });

      case 'payments':
        return this.store
          .find<any>('payment', (p) => p.companyId === companyId && inRange(p.paymentDate))
          .map((p) => {
            const sup = c.suppliers.get(p.supplierId) || {};
            const alloc = this.store.find<any>('paymentAllocation', (a) => a.paymentId === p.id);
            return {
              paymentNumber: p.paymentNumber,
              paymentDate: p.paymentDate,
              month: p.paymentDate.slice(0, 7),
              supplierCode: sup.code,
              supplierName: sup.name,
              currencyCode: p.currencyCode,
              amount: Math.round(n(p.amountMinor) * (n(p.exchangeRate) || 1)),
              appliedTo: alloc
                .map((a) => this.store.findById<any>('bill', a.billId)?.billNumber)
                .filter(Boolean)
                .join(', '),
              paidFrom: c.accounts.get(p.bankAccountGlAccountId)?.name || '',
              status: p.status,
            };
          });

      case 'journalLines': {
        const rows: Row[] = [];
        for (const { line, entry } of this.postedLines(companyId, f, t)) {
          const a = c.accounts.get(line.accountId) || {};
          let party = '';
          if (line.partyType === 'customer') party = c.customers.get(line.partyId)?.name || '';
          if (line.partyType === 'supplier') party = c.suppliers.get(line.partyId)?.name || '';
          rows.push({
            entryDate: entry.entryDate,
            month: entry.entryDate.slice(0, 7),
            entryNumber: entry.entryNumber,
            sourceType: entry.sourceType,
            memo: entry.memo,
            accountCode: a.code,
            accountName: a.name,
            account: `${a.code} ${a.name}`,
            accountType: a.accountType,
            accountGroup: a.code ? this.classify(a).group : '',
            description: line.description,
            party,
            currencyCode: line.currencyCode,
            debit: n(line.baseDebitMinor),
            credit: n(line.baseCreditMinor),
            net: n(line.baseDebitMinor) - n(line.baseCreditMinor),
            status: entry.status,
          });
        }
        return rows.sort((a, b) => (a.entryDate > b.entryDate ? 1 : a.entryDate < b.entryDate ? -1 : 0));
      }

      case 'expenses':
        return this.dataset('journalLines', companyId, f, t)
          .filter((r) => r.accountType === 'EXPENSE' && !['Cost of sales', 'Revenue'].includes(r.accountGroup))
          .map((r) => ({ ...r, amount: r.net }));

      case 'trialBalance':
        return this.trialBalanceDetailed(companyId, f, t);

      case 'customers': {
        const inv = this.store.find<any>('invoice', (i) => i.companyId === companyId && i.status !== 'DRAFT' && i.status !== 'VOID');
        return Array.from(c.customers.values()).map((cu) => {
          const mine = inv.filter((i) => i.customerId === cu.id);
          const inPeriod = mine.filter((i) => inRange(i.invoiceDate));
          const bal = mine.reduce((s, i) => s + (n(i.totalMinor) - n(i.amountReceivedMinor)) * (n(i.exchangeRate) || 1), 0);
          const overdue = mine
            .filter((i) => i.dueDate < today)
            .reduce((s, i) => s + (n(i.totalMinor) - n(i.amountReceivedMinor)) * (n(i.exchangeRate) || 1), 0);
          const limit = n(cu.creditLimitMinor);
          const last = mine.map((i) => i.invoiceDate).sort().pop() || '';
          return {
            customerCode: cu.code,
            customerName: cu.name,
            customerType: cu.customerType || 'CUSTOMER',
            tin: cu.tin || '',
            phone: cu.phone || '',
            creditTermsDays: cu.creditTermsDays,
            creditLimit: limit,
            balance: Math.round(bal),
            overdue: Math.round(overdue),
            creditUtilisationPct: limit ? Math.round((bal / limit) * 10000) / 100 : null,
            invoicesInPeriod: inPeriod.length,
            salesInPeriod: inPeriod.reduce((s, i) => s + Math.round(n(i.subtotalMinor) * (n(i.exchangeRate) || 1)), 0),
            lastInvoiceDate: last,
            daysSinceLastPurchase: last ? daysBetween(last, today) : null,
          };
        });
      }

      case 'suppliers': {
        const bills = this.store.find<any>('bill', (b) => b.companyId === companyId && b.status !== 'DRAFT' && b.status !== 'VOID');
        return Array.from(c.suppliers.values()).map((s) => {
          const mine = bills.filter((b) => b.supplierId === s.id);
          const inPeriod = mine.filter((b) => inRange(b.billDate));
          const bal = mine.reduce((sum, b) => sum + (n(b.totalMinor) - n(b.amountPaidMinor)) * (n(b.exchangeRate) || 1), 0);
          return {
            supplierCode: s.code,
            supplierName: s.name,
            tin: s.tin || '',
            currencyCode: s.defaultCurrencyCode,
            paymentTermsDays: s.paymentTermsDays,
            billsInPeriod: inPeriod.length,
            purchasesInPeriod: inPeriod.reduce((sum, b) => sum + Math.round(n(b.subtotalMinor) * (n(b.exchangeRate) || 1)), 0),
            balance: Math.round(bal),
          };
        });
      }

      case 'fixedAssets': {
        const cats = new Map(this.store.find<any>('assetCategory', (x) => x.companyId === companyId).map((x) => [x.id, x]));
        return this.store
          .find<any>('fixedAsset', (a) => a.companyId === companyId)
          .map((a) => {
            const cost = n(a.costMinor);
            const acc = n(a.accumulatedDepreciationMinor);
            const life = n(a.usefulLifeMonths) || 1;
            return {
              assetCode: a.assetCode,
              name: a.name,
              category: cats.get(a.categoryId)?.name || '',
              location: a.branchOrLocation || '',
              serialNumber: a.serialNumber || '',
              acquisitionDate: a.acquisitionDate,
              cost,
              salvage: n(a.salvageValueMinor),
              usefulLifeMonths: life,
              method: a.depreciationMethod,
              monthlyDepreciation: a.depreciationMethod === 'STRAIGHT_LINE' ? Math.round((cost - n(a.salvageValueMinor)) / life) : null,
              accumulatedDepreciation: acc,
              netBookValue: cost - acc,
              depreciatedPct: cost ? Math.round((acc / cost) * 10000) / 100 : 0,
              lastDepreciatedPeriod: a.lastDepreciatedPeriod || '',
              status: a.status,
            };
          });
      }

      case 'depreciation': {
        const runs = new Map(this.store.find<any>('depreciationRun', (r) => r.companyId === companyId).map((r) => [r.id, r]));
        const assets = new Map(this.store.find<any>('fixedAsset', (a) => a.companyId === companyId).map((a) => [a.id, a]));
        return this.store
          .find<any>('depreciationLine', (l) => runs.has(l.runId))
          .map((l) => {
            const r = runs.get(l.runId);
            const a = assets.get(l.fixedAssetId) || {};
            return {
              period: r.periodCode,
              runDate: r.runDate,
              assetCode: a.assetCode,
              assetName: a.name,
              depreciation: n(l.depreciationAmountMinor),
              accumulatedAfter: n(l.accumulatedAfterMinor),
              netBookValueAfter: n(a.costMinor) - n(l.accumulatedAfterMinor),
            };
          })
          .filter((r) => inRange(r.runDate));
      }

      case 'bankTransactions': {
        const banks = new Map(this.store.find<any>('bankAccount', (b) => b.companyId === companyId).map((b) => [b.id, b]));
        return this.store
          .find<any>('bankStatementLine', (l) => banks.has(l.bankAccountId) && inRange(l.statementDate))
          .map((l) => {
            const b = banks.get(l.bankAccountId);
            return {
              statementDate: l.statementDate,
              month: l.statementDate.slice(0, 7),
              bankAccount: `${b.bankName} ${b.accountNumber}`,
              currencyCode: b.currencyCode,
              description: l.description,
              referenceNo: l.referenceNo,
              withdrawal: n(l.debitMinor),
              deposit: n(l.creditMinor),
              matched: l.isMatched ? 'Matched' : 'Unmatched',
            };
          });
      }

      case 'vatOutput':
        return this.vatReturn(companyId, f, t).outputSchedule.map((r) => ({ ...r, month: r.invoiceDate.slice(0, 7) }));
      case 'vatInput':
        return this.vatReturn(companyId, f, t).inputSchedule.map((r) => ({ ...r, month: r.billDate.slice(0, 7) }));

      case 'posSales':
        return this.store
          .find<any>('posSale', (s) => s.companyId === companyId && inRange(String(s.saleDate).slice(0, 10)))
          .map((s) => ({
            saleNumber: s.saleNumber,
            saleDate: String(s.saleDate).slice(0, 10),
            tenderType: s.tenderType,
            net: n(s.subtotalMinor),
            vat: n(s.taxMinor),
            total: n(s.totalMinor),
            status: s.status,
          }));

      default:
        throw new BadRequestException(`Unknown dataset '${name}'`);
    }
  }

  // ===================================================================
  // Dashboard (computer-hardware retail oriented)
  // ===================================================================

  dashboard(companyId: number, asOf?: string) {
    const company = this.company(companyId);
    const t = asOf || this.today();
    const tDate = new Date(t + 'T00:00:00Z');
    const addDays = (d: number) => iso(new Date(tDate.getTime() + d * DAY));
    const monthStart = t.slice(0, 8) + '01';
    const lmEnd = this.dayBefore(monthStart);
    const lmStart = lmEnd.slice(0, 8) + '01';
    const lmSameDay = (() => {
      const day = Math.min(Number(t.slice(8, 10)), Number(lmEnd.slice(8, 10)));
      return lmEnd.slice(0, 8) + String(day).padStart(2, '0');
    })();
    const fyStart = fiscalYearStart(t);
    const d90 = addDays(-89);

    const lines90 = this.dataset('salesLines', companyId, addDays(-179), t);
    const sumBy = (rows: Row[], from: string, to: string, field: string) =>
      rows.filter((r) => r.invoiceDate >= from && r.invoiceDate <= to).reduce((s, r) => s + (r[field] || 0), 0);

    // KPIs
    const mtdSales = sumBy(lines90, monthStart, t, 'net');
    const mtdGp = sumBy(lines90, monthStart, t, 'grossProfit');
    const lmtdSales = sumBy(lines90, lmStart, lmSameDay, 'net');
    const lmSales = sumBy(lines90, lmStart, lmEnd, 'net');
    const sales30 = sumBy(lines90, addDays(-29), t, 'net');
    const gp30 = sumBy(lines90, addDays(-29), t, 'grossProfit');
    const sales90 = sumBy(lines90, d90, t, 'net');
    const cogs90 = sumBy(lines90, d90, t, 'cost');
    const invoices = this.dataset('salesInvoices', companyId, '1900-01-01', t);
    const inv30 = invoices.filter((i) => i.invoiceDate >= addDays(-29));
    const units30 = lines90.filter((r) => r.invoiceDate >= addDays(-29) && r.itemType === 'STOCK').reduce((s, r) => s + r.quantity, 0);

    const tb = this.movements(companyId, undefined, t);
    const accts = this.accounts(companyId);
    let cash = 0;
    let currentAssets = 0;
    let currentLiab = 0;
    let inventoryGl = 0;
    let vatPayable = 0;
    const taxRates = this.store.find<any>('taxRate', (x) => x.companyId === companyId && x.isVat);
    const vatAccts = new Set<number>();
    taxRates.forEach((x) => {
      if (x.outputTaxAccountId) vatAccts.add(x.outputTaxAccountId);
      if (x.inputTaxAccountId) vatAccts.add(x.inputTaxAccountId);
    });
    for (const a of accts) {
      const v = tb.get(a.id) || 0;
      const g = this.classify(a).group;
      if (g === 'Cash & cash equivalents') cash += v;
      if (g === 'Cash & cash equivalents' || g === 'Current assets') currentAssets += v;
      if (g === 'Current liabilities') currentLiab -= v;
      if (/inventor|stock/i.test(a.name) && a.accountType === 'ASSET') inventoryGl += v;
      if (vatAccts.has(a.id)) vatPayable -= v;
    }
    const ar = invoices.reduce((s, i) => s + (i.status === 'VOID' ? 0 : Math.max(0, i.balance)), 0);
    const bills = this.dataset('bills', companyId, '1900-01-01', t);
    const ap = bills.reduce((s, b) => s + (b.status === 'VOID' ? 0 : Math.max(0, b.balance)), 0);
    const stock = this.dataset('stockStatus', companyId, d90, t);
    const stockValue = stock.reduce((s, r) => s + r.stockValue, 0);

    const pl = this.profitAndLoss(companyId, [
      { from: monthStart, to: t, label: 'MTD' },
      { from: fyStart, to: t, label: 'YTD' },
    ]);
    const plLine = (k: string) => pl.lines.find((l) => l.key === k)?.amounts || [0, 0];

    // Monthly trend (last 6 months) from the GL
    const months: Row[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(Date.UTC(tDate.getUTCFullYear(), tDate.getUTCMonth() - i, 1));
      const from = iso(d);
      const to = iso(new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)));
      const p = this.profitAndLoss(companyId, [{ from, to: to > t ? t : to }]);
      const get = (k: string) => p.lines.find((l) => l.key === k)?.amounts[0] || 0;
      const rev = (p.checks.revenue as number[])[0];
      months.push({
        month: from.slice(0, 7),
        revenue: rev,
        grossProfit: get('gp'),
        operatingExpenses: get('gp') - get('op'),
        netProfit: get('pat'),
        grossMarginPct: rev ? Math.round((get('gp') / rev) * 1000) / 10 : 0,
      });
    }

    // Daily sales, last 60 days
    const daily: Row[] = [];
    const dayMap = new Map<string, Row>();
    for (let i = 59; i >= 0; i--) {
      const d = addDays(-i);
      const r = { date: d, sales: 0, grossProfit: 0, invoices: 0 };
      daily.push(r);
      dayMap.set(d, r);
    }
    const seenInv = new Set<string>();
    for (const l of lines90) {
      const r = dayMap.get(l.invoiceDate);
      if (!r) continue;
      r.sales += l.net;
      r.grossProfit += l.grossProfit;
      if (!seenInv.has(l.invoiceNumber)) {
        seenInv.add(l.invoiceNumber);
        r.invoices += 1;
      }
    }

    const group = (rows: Row[], key: string, top = 0) => {
      const m = new Map<string, Row>();
      for (const r of rows) {
        const k = r[key] ?? '-';
        const g = m.get(k) || { name: k, net: 0, grossProfit: 0, quantity: 0, cost: 0, lines: 0 };
        g.net += r.net;
        g.grossProfit += r.grossProfit;
        g.cost += r.cost;
        g.quantity += r.itemType === 'STOCK' ? r.quantity : 0;
        g.lines += 1;
        m.set(k, g);
      }
      let out = Array.from(m.values())
        .map((g): Row => ({ ...g, marginPct: g.net ? Math.round((g.grossProfit / g.net) * 1000) / 10 : 0 }))
        .sort((a, b) => b.net - a.net);
      if (top) out = out.slice(0, top);
      return out;
    };
    const last90 = lines90.filter((r) => r.invoiceDate >= d90);
    const byCategory = group(last90.filter((r) => r.itemType === 'STOCK'), 'category');
    const byBrand = group(last90.filter((r) => r.itemType === 'STOCK'), 'brand', 12);
    const topSkus = group(last90.filter((r) => r.itemType === 'STOCK'), 'itemName', 10);
    const topCustomers = group(last90.filter((r) => r.customerCode !== 'WALKIN'), 'customerName', 8);
    const byChannel = group(last90, 'channel');
    const byPayment = (() => {
      const m = new Map<string, number>();
      invoices.filter((i) => i.invoiceDate >= d90).forEach((i) => m.set(i.paymentMode, (m.get(i.paymentMode) || 0) + i.total));
      return Array.from(m.entries()).map(([name, value]) => ({ name, value }));
    })();
    const bySalesPerson = group(last90, 'salesPerson');
    const weekdayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const byWeekday = weekdayOrder.map((w) => {
      const rows = last90.filter((r) => r.weekday === w);
      return { name: w, net: rows.reduce((s, r) => s + r.net, 0), invoices: new Set(rows.map((r) => r.invoiceNumber)).size };
    });

    const stockByCategory = (() => {
      const m = new Map<string, Row>();
      for (const s of stock) {
        const g = m.get(s.category) || { name: s.category, value: 0, units: 0, skus: 0, reorder: 0 };
        g.value += s.stockValue;
        g.units += s.onHand;
        g.skus += 1;
        if (s.status === 'Reorder' || s.status === 'Out of stock') g.reorder += 1;
        m.set(s.category, g);
      }
      return Array.from(m.values()).sort((a, b) => b.value - a.value);
    })();
    const statusCounts = ['OK', 'Reorder', 'Out of stock', 'Slow / dead', 'Overstock'].map((s) => ({
      name: s,
      count: stock.filter((r) => r.status === s).length,
      value: stock.filter((r) => r.status === s).reduce((sum, r) => sum + r.stockValue, 0),
    }));
    const reorderList = stock
      .filter((r) => r.status === 'Reorder' || r.status === 'Out of stock')
      .sort((a, b) => a.daysOfCover - b.daysOfCover)
      .slice(0, 12);
    const slowMovers = stock
      .filter((r) => r.status === 'Slow / dead' || r.status === 'Overstock')
      .sort((a, b) => b.stockValue - a.stockValue)
      .slice(0, 8);

    const agingOf = (rows: Row[]) =>
      ['Current', '1-30', '31-60', '61-90', '90+'].map((b) => ({
        bucket: b,
        value: rows.filter((r) => r.agingBucket === b).reduce((s, r) => s + r.balance, 0),
      }));
    const overdueInvoices = invoices
      .filter((i) => i.balance > 0 && i.daysOverdue > 0 && i.status !== 'VOID')
      .sort((a, b) => b.daysOverdue - a.daysOverdue)
      .slice(0, 8);
    const upcomingPayments = bills
      .filter((b) => b.balance > 0 && b.dueInDays <= 14 && b.status !== 'VOID')
      .sort((a, b) => a.dueInDays - b.dueInDays)
      .slice(0, 8);
    const expenses = (() => {
      const rows = this.dataset('expenses', companyId, addDays(-89), t);
      const m = new Map<string, number>();
      rows.forEach((r) => m.set(r.accountName, (m.get(r.accountName) || 0) + r.amount));
      return Array.from(m.entries())
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value);
    })();

    const pcBuilds = new Set(last90.filter((r) => /PC-BUILD/i.test(r.sku)).map((r) => r.invoiceNumber));
    const pcBuildLines = last90.filter((r) => pcBuilds.has(r.invoiceNumber));
    const recentInvoices = invoices.sort((a, b) => (a.invoiceDate < b.invoiceDate ? 1 : a.invoiceDate > b.invoiceDate ? -1 : b.id - a.id)).slice(0, 8);
    const vatMtd = this.vatReturn(companyId, monthStart, t).summary;
    const vatLm = this.vatReturn(companyId, lmStart, lmEnd).summary;

    const opex90 = expenses.reduce((s, e) => s + e.value, 0);
    return {
      company,
      asOf: t,
      periods: { monthStart, lastMonthStart: lmStart, lastMonthEnd: lmEnd, fyStart },
      kpis: {
        salesMtd: mtdSales,
        salesLastMonthToDate: lmtdSales,
        salesLastMonth: lmSales,
        salesGrowthPct: lmtdSales ? Math.round(((mtdSales - lmtdSales) / lmtdSales) * 1000) / 10 : null,
        grossProfitMtd: mtdGp,
        grossMarginMtdPct: mtdSales ? Math.round((mtdGp / mtdSales) * 1000) / 10 : 0,
        sales30,
        grossProfit30: gp30,
        grossMargin30Pct: sales30 ? Math.round((gp30 / sales30) * 1000) / 10 : 0,
        invoices30: inv30.length,
        avgInvoice30: inv30.length ? Math.round(inv30.reduce((s, i) => s + i.net, 0) / inv30.length) : 0,
        units30,
        netProfitMtd: plLine('pat')[0],
        netProfitYtd: plLine('pat')[1],
        revenueYtd: (pl.checks.revenue as number[])[1],
        cash,
        receivables: ar,
        payables: ap,
        inventoryValue: stockValue,
        inventoryGl,
        vatPayable,
        workingCapital: currentAssets - currentLiab,
        currentRatio: currentLiab ? Math.round((currentAssets / currentLiab) * 100) / 100 : null,
        quickRatio: currentLiab ? Math.round(((currentAssets - inventoryGl) / currentLiab) * 100) / 100 : null,
        dso: sales90 ? Math.round(ar / (sales90 / 90)) : null,
        dpo: cogs90 ? Math.round(ap / (cogs90 / 90)) : null,
        dio: cogs90 ? Math.round(stockValue / (cogs90 / 90)) : null,
        inventoryTurnsAnnualised: stockValue ? Math.round(((cogs90 * 365) / 90 / stockValue) * 10) / 10 : null,
        cashRunwayMonths: opex90 ? Math.round((cash / (opex90 / 3)) * 10) / 10 : null,
        skuCount: stock.length,
        skusToReorder: reorderList.length,
        pcBuilds90: pcBuilds.size,
        pcBuildRevenue90: pcBuildLines.reduce((s, r) => s + r.net, 0),
        activeCustomers90: new Set(last90.filter((r) => r.customerCode !== 'WALKIN').map((r) => r.customerCode)).size,
      },
      monthly: months,
      daily,
      byCategory,
      byBrand,
      topSkus,
      topCustomers,
      byChannel,
      byPayment,
      bySalesPerson,
      byWeekday,
      stockByCategory,
      stockStatus: statusCounts,
      reorderList,
      slowMovers,
      arAging: agingOf(invoices.filter((i) => i.balance > 0 && i.status !== 'VOID')),
      apAging: agingOf(bills.filter((b) => b.balance > 0 && b.status !== 'VOID')),
      overdueInvoices,
      upcomingPayments,
      expenses,
      recentInvoices,
      vat: { mtd: vatMtd, lastMonth: vatLm },
    };
  }
}
