import { Controller, Get, Param, ParseIntPipe, Query } from '@nestjs/common';
import { ReportsService, fiscalYearStart } from './reports.service';

@Controller('reports')
export class ReportsController {
  constructor(private svc: ReportsService) {}

  private range(from?: string, to?: string) {
    const t = to || this.svc.today();
    return { from: from || fiscalYearStart(t), to: t };
  }

  @Get('dashboard')
  dashboard(@Query('companyId', ParseIntPipe) companyId: number, @Query('asOf') asOf?: string) {
    return this.svc.dashboard(companyId, asOf);
  }

  /**
   * Profit & loss. Comparison columns: `compare=prior-period|prior-year|monthly` (monthly = one column per month in range).
   */
  @Get('profit-loss')
  profitLoss(
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('compare') compare?: string,
  ) {
    const r = this.range(from, to);
    const periods: { from: string; to: string; label?: string }[] = [];
    if (compare === 'monthly') {
      let d = new Date(r.from.slice(0, 8) + '01T00:00:00Z');
      while (true) {
        const s = d.toISOString().slice(0, 10);
        if (s > r.to) break;
        const e = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).toISOString().slice(0, 10);
        periods.push({ from: s < r.from ? r.from : s, to: e > r.to ? r.to : e, label: s.slice(0, 7) });
        d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1));
        if (periods.length > 24) break;
      }
      periods.push({ ...r, label: 'Total' });
    } else {
      periods.push({ ...r, label: 'Current period' });
      if (compare === 'prior-period' || compare === 'prior-year') {
        const f = new Date(r.from + 'T00:00:00Z');
        const t = new Date(r.to + 'T00:00:00Z');
        let pf: Date;
        let pt: Date;
        if (compare === 'prior-year') {
          pf = new Date(Date.UTC(f.getUTCFullYear() - 1, f.getUTCMonth(), f.getUTCDate()));
          pt = new Date(Date.UTC(t.getUTCFullYear() - 1, t.getUTCMonth(), t.getUTCDate()));
        } else {
          const len = t.getTime() - f.getTime();
          pt = new Date(f.getTime() - 86_400_000);
          pf = new Date(pt.getTime() - len);
        }
        periods.push({ from: pf.toISOString().slice(0, 10), to: pt.toISOString().slice(0, 10), label: compare === 'prior-year' ? 'Prior year' : 'Prior period' });
      }
    }
    return this.svc.profitAndLoss(companyId, periods);
  }

  @Get('balance-sheet')
  balanceSheet(
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('asOf') asOf?: string,
    @Query('compareAsOf') compareAsOf?: string,
  ) {
    const d = asOf || this.svc.today();
    return this.svc.balanceSheet(companyId, compareAsOf ? [d, compareAsOf] : [d]);
  }

  @Get('cash-flow')
  cashFlow(@Query('companyId', ParseIntPipe) companyId: number, @Query('from') from?: string, @Query('to') to?: string) {
    const r = this.range(from, to);
    return this.svc.cashFlow(companyId, r.from, r.to);
  }

  @Get('changes-in-equity')
  equity(@Query('companyId', ParseIntPipe) companyId: number, @Query('from') from?: string, @Query('to') to?: string) {
    const r = this.range(from, to);
    return this.svc.changesInEquity(companyId, r.from, r.to);
  }

  @Get('vat-return')
  vat(@Query('companyId', ParseIntPipe) companyId: number, @Query('from') from?: string, @Query('to') to?: string) {
    const t = to || this.svc.today();
    return this.svc.vatReturn(companyId, from || t.slice(0, 8) + '01', t);
  }

  @Get('invoice-print/:id')
  invoicePrint(@Param('id', ParseIntPipe) id: number) {
    return this.svc.invoicePrint(id);
  }

  @Get('datasets/:name')
  dataset(
    @Param('name') name: string,
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ) {
    return this.svc.dataset(name, companyId, from, to);
  }
}
