import { Body, Controller, Get, Param, ParseIntPipe, Patch, Post, Query } from '@nestjs/common';
import { ItemsService } from './items.service';
import { ItemClass } from './item-class.entity';
import { Item } from './item.entity';

@Controller('inventory')
export class ItemsController {
  constructor(private svc: ItemsService) {}

  @Get('item-classes')
  findAllItemClasses(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAllItemClasses(companyId);
  }

  @Post('item-classes')
  createItemClass(@Body() body: Partial<ItemClass>) {
    return this.svc.createItemClass(body);
  }

  @Patch('item-classes/:id')
  updateItemClass(@Param('id', ParseIntPipe) id: number, @Body() body: Partial<ItemClass>) {
    return this.svc.updateItemClass(id, body);
  }

  @Get('items')
  findAllItems(@Query('companyId', ParseIntPipe) companyId: number, @Query('search') search?: string) {
    return this.svc.findAllItems(companyId, search);
  }

  @Get('items/:id')
  findItem(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findItem(id);
  }

  @Post('items')
  createItem(@Body() body: Partial<Item>) {
    return this.svc.createItem(body);
  }

  @Patch('items/:id')
  updateItem(@Param('id', ParseIntPipe) id: number, @Body() body: Partial<Item>) {
    return this.svc.updateItem(id, body);
  }

  @Get('items/:id/stock')
  getStock(@Param('id', ParseIntPipe) id: number) {
    return this.svc.getCurrentStock(id);
  }

  @Get('items/:id/movements')
  getMovements(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findMovements(id);
  }

  @Get('stock-valuation')
  stockValuation(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.stockValuation(companyId);
  }

  @Post('adjustments')
  postAdjustment(
    @Body()
    body: {
      itemId: number;
      quantity: number;
      direction: 'IN' | 'OUT';
      unitCostMinor?: number;
      movementDate: string;
      companyId: number;
      reason: string;
    },
  ) {
    return this.svc.postAdjustment(body);
  }
}
