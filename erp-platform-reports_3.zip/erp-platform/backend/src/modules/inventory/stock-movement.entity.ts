import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

export enum StockMovementType {
  RECEIPT = 'RECEIPT',
  ISSUE = 'ISSUE',
  ADJUSTMENT_IN = 'ADJUSTMENT_IN',
  ADJUSTMENT_OUT = 'ADJUSTMENT_OUT',
  TRANSFER = 'TRANSFER',
}

@Entity('stock_movement')
@Index(['companyId', 'itemId'])
export class StockMovement {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  itemId: number;

  @Column({ type: 'date' })
  movementDate: string;

  @Column({ type: 'enum', enum: StockMovementType })
  movementType: StockMovementType;

  // Always positive; direction is implied by movementType.
  @Column({ type: 'decimal', precision: 18, scale: 4 })
  quantity: string;

  // Cost per unit, in minor units, in company base currency.
  @Column({ type: 'bigint' })
  unitCostMinor: string;

  @Column({ type: 'bigint' })
  totalCostMinor: string;

  @Column()
  sourceType: string; // e.g. 'goods_receipt' | 'delivery' | 'adjustment' | 'pos_sale'

  @Column({ nullable: true })
  sourceId: string;

  // The GL entry this movement triggered, if any.
  @Column({ type: 'bigint', nullable: true })
  journalEntryId: number;

  @CreateDateColumn()
  createdAt: Date;
}
