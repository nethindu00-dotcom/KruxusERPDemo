import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService } from '../accounting/accounting.service';
import { ItemClass } from './item-class.entity';
import { Item, ItemType } from './item.entity';
import { StockMovement, StockMovementType } from './stock-movement.entity';

export interface ResolvedGlAccounts {
  inventoryAccountId: number | null;
  cogsAccountId: number | null;
  salesAccountId: number | null;
  adjustmentAccountId: number | null;
  expenseAccountId: number | null;
  defaultTaxRateId: number | null;
}

export interface CurrentStock {
  quantityOnHand: number;
  weightedAverageCostMinor: number;
  stockValueMinor: number;
}

export interface PostReceiptInput {
  itemId: number;
  quantity: number;
  unitCostMinor: number;
  movementDate: string;
  sourceType: string;
  sourceId?: string;
  companyId: number;
  offsetAccountId: number;
}

export interface PostIssueInput {
  itemId: number;
  quantity: number;
  movementDate: string;
  sourceType: string;
  sourceId?: string;
  companyId: number;
  offsetAccountId?: number;
}

export interface PostAdjustmentInput {
  itemId: number;
  quantity: number;
  direction: 'IN' | 'OUT';
  unitCostMinor?: number;
  movementDate: string;
  companyId: number;
  reason: string;
}

@Injectable()
export class ItemsService {
  constructor(
    private store: DataStore,
    private accountingService: AccountingService,
  ) {}

  // ---------------------------------------------------------------------
  // Item classes
  // ---------------------------------------------------------------------

  findAllItemClasses(companyId: number) {
    return this.store
      .find<ItemClass>('itemClass', (c: any) => c.companyId === companyId)
      .sort((a: any, b: any) => (a.code > b.code ? 1 : a.code < b.code ? -1 : 0));
  }

  async findItemClass(id: number): Promise<ItemClass> {
    const itemClass = this.store.findById<ItemClass>('itemClass', id);
    if (!itemClass) throw new NotFoundException('Item class not found');
    return itemClass;
  }

  createItemClass(body: Partial<ItemClass>) {
    return this.store.insert('itemClass', { ...body });
  }

  async updateItemClass(id: number, body: Partial<ItemClass>) {
    await this.findItemClass(id);
    this.store.update('itemClass', id, body);
    return this.findItemClass(id);
  }

  // ---------------------------------------------------------------------
  // Items
  // ---------------------------------------------------------------------

  findAllItems(companyId: number, search?: string) {
    if (search) {
      const needle = search.toLowerCase();
      return this.store
        .find<Item>(
          'item',
          (i: any) =>
            i.companyId === companyId &&
            (String(i.sku).toLowerCase().includes(needle) || String(i.name).toLowerCase().includes(needle)),
        )
        .sort((a: any, b: any) => (a.sku > b.sku ? 1 : a.sku < b.sku ? -1 : 0));
    }
    return this.store
      .find<Item>('item', (i: any) => i.companyId === companyId)
      .sort((a: any, b: any) => (a.sku > b.sku ? 1 : a.sku < b.sku ? -1 : 0));
  }

  async findItem(id: number): Promise<Item> {
    const item = this.store.findById<Item>('item', id);
    if (!item) throw new NotFoundException('Item not found');
    return item;
  }

  createItem(body: Partial<Item>) {
    return this.store.insert('item', { ...body });
  }

  async updateItem(id: number, body: Partial<Item>) {
    await this.findItem(id);
    this.store.update('item', id, body);
    return this.findItem(id);
  }

  // ---------------------------------------------------------------------
  // GL account resolution — canonical fallback chain: item override, then
  // item class default, then null. Keep the field names exactly as here;
  // the frontend replicates this same shape.
  // ---------------------------------------------------------------------

  async resolveGlAccounts(item: Item, itemClass?: ItemClass | null): Promise<ResolvedGlAccounts> {
    let cls = itemClass;
    if (cls === undefined && item.itemClassId) {
      cls = this.store.findById<ItemClass>('itemClass', item.itemClassId) ?? null;
    }
    return {
      inventoryAccountId: item.inventoryAccountId ?? cls?.inventoryAccountId ?? null,
      cogsAccountId: item.cogsAccountId ?? cls?.cogsAccountId ?? null,
      salesAccountId: item.salesAccountId ?? cls?.salesAccountId ?? null,
      adjustmentAccountId: item.adjustmentAccountId ?? cls?.adjustmentAccountId ?? null,
      expenseAccountId: item.expenseAccountId ?? cls?.expenseAccountId ?? null,
      defaultTaxRateId: item.defaultTaxRateId ?? cls?.defaultTaxRateId ?? null,
    };
  }

  // ---------------------------------------------------------------------
  // Stock movements / costing
  // ---------------------------------------------------------------------

  findMovements(itemId: number) {
    return this.store
      .find<StockMovement>('stockMovement', (m: any) => m.itemId === itemId)
      .sort((a: any, b: any) => {
        if (a.movementDate > b.movementDate) return -1;
        if (a.movementDate < b.movementDate) return 1;
        return b.id - a.id;
      });
  }

  /**
   * Replays every StockMovement for an item, in date order, to compute the
   * current quantity on hand and weighted-average cost. Receipts and
   * adjustment-in recompute the WAC; issues, adjustment-out and transfers
   * only reduce quantity at the existing WAC.
   */
  async getCurrentStock(itemId: number): Promise<CurrentStock> {
    const movements = this.store
      .find<StockMovement>('stockMovement', (m: any) => m.itemId === itemId)
      .sort((a: any, b: any) => {
        if (a.movementDate < b.movementDate) return -1;
        if (a.movementDate > b.movementDate) return 1;
        return a.id - b.id;
      });

    let qty = 0;
    let wac = 0;

    for (const m of movements) {
      const moveQty = Number(m.quantity);
      switch (m.movementType) {
        case StockMovementType.RECEIPT:
        case StockMovementType.ADJUSTMENT_IN: {
          const moveUnitCost = Number(m.unitCostMinor);
          const newQty = qty + moveQty;
          wac = newQty > 0 ? (qty * wac + moveQty * moveUnitCost) / newQty : 0;
          qty = newQty;
          break;
        }
        case StockMovementType.ISSUE:
        case StockMovementType.ADJUSTMENT_OUT:
        case StockMovementType.TRANSFER: {
          qty -= moveQty;
          break;
        }
      }
    }

    return {
      quantityOnHand: qty,
      weightedAverageCostMinor: Math.round(wac),
      stockValueMinor: Math.round(qty * wac),
    };
  }

  async stockValuation(companyId: number) {
    const items = this.store
      .find<Item>(
        'item',
        (i: any) => i.companyId === companyId && i.itemType === ItemType.STOCK && i.isActive === true,
      )
      .sort((a: any, b: any) => (a.sku > b.sku ? 1 : a.sku < b.sku ? -1 : 0));
    const rows = [];
    for (const item of items) {
      const stock = await this.getCurrentStock(item.id);
      rows.push({
        itemId: item.id,
        sku: item.sku,
        name: item.name,
        unitOfMeasure: item.unitOfMeasure,
        quantityOnHand: stock.quantityOnHand,
        weightedAverageCostMinor: stock.weightedAverageCostMinor,
        stockValueMinor: stock.stockValueMinor,
      });
    }
    return rows;
  }

  // ---------------------------------------------------------------------
  // Postings — the only entry points that create StockMovements and push
  // the corresponding entry to the GL via AccountingService.post().
  // ---------------------------------------------------------------------

  async postReceipt(input: PostReceiptInput) {
    const item = await this.findItem(input.itemId);
    const gl = await this.resolveGlAccounts(item);
    if (!gl.inventoryAccountId) {
      throw new BadRequestException(`Item ${item.sku} has no resolved inventory account`);
    }

    const unitCostMinor = Math.round(input.unitCostMinor);
    const totalCostMinor = Math.round(input.quantity * input.unitCostMinor);

    const movement: any = {
      companyId: input.companyId,
      itemId: input.itemId,
      movementDate: input.movementDate,
      movementType: StockMovementType.RECEIPT,
      quantity: String(input.quantity),
      unitCostMinor: String(unitCostMinor),
      totalCostMinor: String(totalCostMinor),
      sourceType: input.sourceType,
      sourceId: input.sourceId,
    };

    const journalEntry = await this.accountingService.post({
      companyId: input.companyId,
      entryDate: input.movementDate,
      memo: `Stock receipt: ${item.sku} x ${input.quantity}`,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      lines: [
        { accountId: gl.inventoryAccountId, debitMinor: totalCostMinor, description: `Receipt ${item.sku}` },
        { accountId: input.offsetAccountId, creditMinor: totalCostMinor, description: `Receipt ${item.sku}` },
      ],
    });

    movement.journalEntryId = journalEntry.id;
    const saved = this.store.insert('stockMovement', movement);
    return { movement: saved, journalEntry };
  }

  async postIssue(input: PostIssueInput) {
    const item = await this.findItem(input.itemId);
    const gl = await this.resolveGlAccounts(item);
    if (!gl.inventoryAccountId) {
      throw new BadRequestException(`Item ${item.sku} has no resolved inventory account`);
    }

    const debitAccountId = input.offsetAccountId ?? gl.cogsAccountId;
    if (!debitAccountId) {
      throw new BadRequestException(`Item ${item.sku} has no resolved COGS/offset account for issue`);
    }

    const stock = await this.getCurrentStock(input.itemId);
    const unitCostMinor = stock.weightedAverageCostMinor;
    const totalCostMinor = Math.round(input.quantity * unitCostMinor);

    const movement: any = {
      companyId: input.companyId,
      itemId: input.itemId,
      movementDate: input.movementDate,
      movementType: StockMovementType.ISSUE,
      quantity: String(input.quantity),
      unitCostMinor: String(unitCostMinor),
      totalCostMinor: String(totalCostMinor),
      sourceType: input.sourceType,
      sourceId: input.sourceId,
    };

    const journalEntry = await this.accountingService.post({
      companyId: input.companyId,
      entryDate: input.movementDate,
      memo: `Stock issue: ${item.sku} x ${input.quantity}`,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      lines: [
        { accountId: debitAccountId, debitMinor: totalCostMinor, description: `Issue ${item.sku}` },
        { accountId: gl.inventoryAccountId, creditMinor: totalCostMinor, description: `Issue ${item.sku}` },
      ],
    });

    movement.journalEntryId = journalEntry.id;
    const saved = this.store.insert('stockMovement', movement);
    return { movement: saved, journalEntry };
  }

  async postAdjustment(input: PostAdjustmentInput) {
    const item = await this.findItem(input.itemId);
    const gl = await this.resolveGlAccounts(item);
    if (!gl.inventoryAccountId) {
      throw new BadRequestException(`Item ${item.sku} has no resolved inventory account`);
    }
    if (!gl.adjustmentAccountId) {
      throw new BadRequestException(`Item ${item.sku} has no resolved adjustment account`);
    }

    let unitCostMinor = input.unitCostMinor;
    if (input.direction === 'OUT' && unitCostMinor == null) {
      const stock = await this.getCurrentStock(input.itemId);
      unitCostMinor = stock.weightedAverageCostMinor;
    }
    if (unitCostMinor == null) {
      throw new BadRequestException('unitCostMinor is required for an IN adjustment');
    }
    unitCostMinor = Math.round(unitCostMinor);
    const totalCostMinor = Math.round(input.quantity * unitCostMinor);
    const movementType = input.direction === 'IN' ? StockMovementType.ADJUSTMENT_IN : StockMovementType.ADJUSTMENT_OUT;

    const movement: any = {
      companyId: input.companyId,
      itemId: input.itemId,
      movementDate: input.movementDate,
      movementType,
      quantity: String(input.quantity),
      unitCostMinor: String(unitCostMinor),
      totalCostMinor: String(totalCostMinor),
      sourceType: 'adjustment',
    };

    const lines =
      input.direction === 'IN'
        ? [
            { accountId: gl.inventoryAccountId, debitMinor: totalCostMinor, description: input.reason },
            { accountId: gl.adjustmentAccountId, creditMinor: totalCostMinor, description: input.reason },
          ]
        : [
            { accountId: gl.adjustmentAccountId, debitMinor: totalCostMinor, description: input.reason },
            { accountId: gl.inventoryAccountId, creditMinor: totalCostMinor, description: input.reason },
          ];

    const journalEntry = await this.accountingService.post({
      companyId: input.companyId,
      entryDate: input.movementDate,
      memo: `Stock adjustment (${input.direction}): ${item.sku} x ${input.quantity} - ${input.reason}`,
      sourceType: 'adjustment',
      lines,
    });

    movement.journalEntryId = journalEntry.id;
    const saved = this.store.insert('stockMovement', movement);
    return { movement: saved, journalEntry };
  }
}
