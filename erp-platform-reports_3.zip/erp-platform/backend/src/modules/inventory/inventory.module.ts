import { Module } from '@nestjs/common';
import { AccountingModule } from '../accounting/accounting.module';
import { ItemsService } from './items.service';
import { ItemsController } from './items.controller';

@Module({
  imports: [AccountingModule],
  providers: [ItemsService],
  controllers: [ItemsController],
  exports: [ItemsService],
})
export class InventoryModule {}
