import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('item_class')
@Index(['companyId', 'code'], { unique: true })
export class ItemClass {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  code: string;

  @Column()
  name: string;

  // GL defaults that items fall back to when they don't override.
  @Column({ nullable: true })
  inventoryAccountId: number; // asset

  @Column({ nullable: true })
  cogsAccountId: number; // expense

  @Column({ nullable: true })
  salesAccountId: number; // income

  @Column({ nullable: true })
  adjustmentAccountId: number; // expense — stock write-offs/losses

  @Column({ nullable: true })
  expenseAccountId: number; // non-stock/service item classes

  @Column({ nullable: true })
  defaultTaxRateId: number; // sales-side tax rate default

  @Column({ default: true })
  isActive: boolean;
}
