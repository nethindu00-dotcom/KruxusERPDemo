import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

export enum ItemType {
  STOCK = 'STOCK',
  SERVICE = 'SERVICE',
  NON_STOCK = 'NON_STOCK',
}

@Entity('item')
@Index(['companyId', 'sku'], { unique: true })
export class Item {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  sku: string;

  @Column()
  name: string;

  @Column({ nullable: true })
  description: string;

  @Column({ type: 'enum', enum: ItemType, default: ItemType.STOCK })
  itemType: ItemType;

  @Column({ nullable: true })
  itemClassId: number;

  @Column({ default: 'EA' })
  unitOfMeasure: string;

  @Column({ default: 'WEIGHTED_AVERAGE' })
  costingMethod: string;

  @Column({ type: 'bigint', default: 0 })
  salesPriceMinor: string;

  // The currency the sales price is quoted in.
  @Column({ default: 'LKR' })
  currencyCode: string;

  @Column({ type: 'int', nullable: true, default: 0 })
  reorderLevel: number;

  @Column({ default: true })
  isActive: boolean;

  // Item-level GL overrides. Null means "inherit from item class".
  @Column({ nullable: true })
  inventoryAccountId: number;

  @Column({ nullable: true })
  cogsAccountId: number;

  @Column({ nullable: true })
  salesAccountId: number;

  @Column({ nullable: true })
  adjustmentAccountId: number;

  @Column({ nullable: true })
  expenseAccountId: number;

  @Column({ nullable: true })
  defaultTaxRateId: number;
}
