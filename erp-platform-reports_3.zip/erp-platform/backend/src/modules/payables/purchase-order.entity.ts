import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { PurchaseOrderLine } from './purchase-order-line.entity';

export enum PurchaseOrderStatus {
  DRAFT = 'DRAFT',
  APPROVED = 'APPROVED',
  PARTIALLY_RECEIVED = 'PARTIALLY_RECEIVED',
  RECEIVED = 'RECEIVED',
  CLOSED = 'CLOSED',
  CANCELLED = 'CANCELLED',
}

@Entity('purchase_order')
@Index(['companyId', 'poNumber'], { unique: true })
export class PurchaseOrder {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  poNumber: string;

  @Column()
  supplierId: number;

  @Column({ type: 'date' })
  orderDate: string;

  @Column({ default: 'LKR' })
  currencyCode: string;

  // Rate to convert this PO's currency into the company's base currency.
  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  @Column({ type: 'enum', enum: PurchaseOrderStatus, default: PurchaseOrderStatus.DRAFT })
  status: PurchaseOrderStatus;

  @Column({ nullable: true })
  notes: string;

  @OneToMany(() => PurchaseOrderLine, (l) => l.po, { cascade: true })
  lines: PurchaseOrderLine[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
