import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Bill } from './bill.entity';

@Entity('bill_line')
export class BillLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => Bill, (b) => b.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'bill_id' })
  bill: Bill;

  @Column({ name: 'bill_id' })
  billId: number;

  // Null for a non-item line (a straight GL expense line).
  @Column({ nullable: true })
  itemId: number;

  @Column()
  description: string;

  @Column({ type: 'decimal', precision: 18, scale: 4, default: 1 })
  quantity: string;

  // In the bill's own currencyCode.
  @Column({ type: 'bigint' })
  unitPriceMinor: string;

  @Column({ nullable: true })
  taxRateId: number;

  // Net (tax-exclusive), in the bill's own currencyCode. quantity * unitPriceMinor.
  @Column({ type: 'bigint' })
  lineTotalMinor: string;

  // Used only when itemId is null, as the GL debit account for this line.
  // When itemId is set, the debit account is resolved at post-time via
  // ItemsService.resolveGlAccounts (not stored here).
  @Column({ nullable: true })
  expenseAccountId: number;
}
