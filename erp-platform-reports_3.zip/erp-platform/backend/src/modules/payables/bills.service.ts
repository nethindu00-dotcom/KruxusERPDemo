import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService, PostLineInput } from '../accounting/accounting.service';
import { ItemsService } from '../inventory/items.service';
import { ItemType } from '../inventory/item.entity';
import { TaxService } from '../tax/tax.service';
import { TaxRate } from '../tax/tax-rate.entity';
import { Bill, BillStatus } from './bill.entity';
import { BillLine } from './bill-line.entity';
import { Supplier } from './supplier.entity';

export interface CreateBillLineInput {
  itemId?: number;
  description: string;
  quantity?: number;
  unitPriceMinor: number;
  taxRateId?: number;
  // Only used when itemId is omitted (a direct GL expense line).
  expenseAccountId?: number;
}

export interface CreateBillInput {
  companyId: number;
  supplierId: number;
  billDate: string;
  dueDate: string;
  currencyCode?: string;
  exchangeRate?: number;
  poId?: number;
  grnId?: number;
  lines: CreateBillLineInput[];
}

export interface AgingBucket {
  supplierId: number;
  supplierName: string;
  current: number;
  d1to30: number;
  d31to60: number;
  d61to90: number;
  d90plus: number;
  totalOutstandingBaseMinor: number;
}

@Injectable()
export class BillsService {
  constructor(
    private store: DataStore,
    private itemsService: ItemsService,
    private taxService: TaxService,
    private accountingService: AccountingService,
  ) {}

  private withLines(bill: Bill): Bill {
    (bill as any).lines = this.store.find<BillLine>('billLine', (l: any) => l.billId === bill.id);
    return bill;
  }

  findAll(companyId: number) {
    return this.store
      .find<Bill>('bill', (b: any) => b.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((b) => this.withLines(b));
  }

  async findOne(id: number): Promise<Bill> {
    const bill = this.store.findById<Bill>('bill', id);
    if (!bill) throw new NotFoundException('Bill not found');
    return this.withLines(bill);
  }

  private nextBillNumber(companyId: number): string {
    return this.store.nextDocNumber('bill', 'billNumber', companyId, `BILL-${companyId}-`, 6);
  }

  async create(body: CreateBillInput) {
    if (!body.lines || body.lines.length === 0) {
      throw new BadRequestException('A bill needs at least one line');
    }

    let subtotalMinor = 0;
    let taxMinor = 0;
    const lineRows: Record<string, any>[] = [];

    for (const l of body.lines) {
      if (!l.itemId && !l.expenseAccountId) {
        throw new BadRequestException('A bill line must have either an itemId or an expenseAccountId');
      }
      const quantity = l.quantity ?? 1;
      const lineTotalMinor = Math.round(quantity * l.unitPriceMinor);
      subtotalMinor += lineTotalMinor;

      if (l.taxRateId) {
        const rate = this.store.findById<TaxRate>('taxRate', l.taxRateId);
        if (rate) taxMinor += this.taxService.computeTax(lineTotalMinor, rate);
      }

      lineRows.push({
        itemId: l.itemId ?? null,
        description: l.description,
        quantity: String(quantity),
        unitPriceMinor: String(Math.round(l.unitPriceMinor)),
        taxRateId: l.taxRateId ?? null,
        lineTotalMinor: String(lineTotalMinor),
        expenseAccountId: l.expenseAccountId ?? null,
      });
    }

    const bill = this.store.insert('bill', {
      companyId: body.companyId,
      billNumber: this.nextBillNumber(body.companyId),
      supplierId: body.supplierId,
      billDate: body.billDate,
      dueDate: body.dueDate,
      currencyCode: body.currencyCode ?? 'LKR',
      exchangeRate: String(body.exchangeRate ?? 1),
      status: BillStatus.DRAFT,
      subtotalMinor: String(subtotalMinor),
      taxMinor: String(taxMinor),
      totalMinor: String(subtotalMinor + taxMinor),
      amountPaidMinor: '0',
      poId: body.poId ?? null,
      grnId: body.grnId ?? null,
    });

    for (const row of lineRows) {
      this.store.insert('billLine', { ...row, billId: bill.id });
    }

    return this.findOne(bill.id);
  }

  /**
   * Resolves the GL, books the entry via AccountingService.post, and flips
   * the bill to POSTED. This is the only place a Bill produces journal lines.
   */
  async postBill(billId: number): Promise<Bill> {
    const bill = await this.findOne(billId);
    if (bill.status !== BillStatus.DRAFT) {
      throw new BadRequestException('Only a DRAFT bill can be posted');
    }
    const supplier = this.store.findById<Supplier>('supplier', bill.supplierId);
    if (!supplier) throw new NotFoundException('Supplier not found');

    const billRate = Number(bill.exchangeRate);
    const glLines: PostLineInput[] = [];

    for (const line of (bill as any).lines as BillLine[]) {
      let debitAccountId: number | null = null;

      if (line.itemId) {
        const item = await this.itemsService.findItem(line.itemId);
        const gl = await this.itemsService.resolveGlAccounts(item);
        debitAccountId = item.itemType === ItemType.STOCK ? gl.inventoryAccountId : (gl.expenseAccountId ?? gl.cogsAccountId);
        if (!debitAccountId) {
          throw new BadRequestException(`Item ${item.sku} has no resolved GL account to book this bill line against`);
        }
      } else {
        if (!line.expenseAccountId) {
          throw new BadRequestException('A bill line without an item must specify expenseAccountId');
        }
        debitAccountId = line.expenseAccountId;
      }

      const netMinor = Number(line.lineTotalMinor);
      let lineTaxMinor = 0;
      let taxRate: TaxRate | null = null;
      if (line.taxRateId) {
        taxRate = this.store.findById<TaxRate>('taxRate', line.taxRateId) ?? null;
        if (taxRate) lineTaxMinor = this.taxService.computeTax(netMinor, taxRate);
      }

      if (taxRate && lineTaxMinor > 0 && taxRate.inputTaxAccountId) {
        glLines.push({
          accountId: debitAccountId,
          debitMinor: netMinor,
          description: line.description,
          currencyCode: bill.currencyCode,
          exchangeRate: billRate,
        });
        glLines.push({
          accountId: taxRate.inputTaxAccountId,
          debitMinor: lineTaxMinor,
          description: `Input tax - ${line.description}`,
          currencyCode: bill.currencyCode,
          exchangeRate: billRate,
        });
      } else {
        // No creditable input-tax account (e.g. a non-creditable levy), or no
        // tax at all: fold the tax into the main line so the entry still
        // balances against the bill's totalMinor.
        glLines.push({
          accountId: debitAccountId,
          debitMinor: netMinor + lineTaxMinor,
          description: line.description,
          currencyCode: bill.currencyCode,
          exchangeRate: billRate,
        });
      }
    }

    glLines.push({
      accountId: supplier.apControlAccountId,
      creditMinor: Number(bill.totalMinor),
      description: `Supplier bill ${bill.billNumber}`,
      currencyCode: bill.currencyCode,
      exchangeRate: billRate,
      partyType: 'supplier',
      partyId: supplier.id,
    });

    const entry = await this.accountingService.post({
      companyId: bill.companyId,
      entryDate: bill.billDate,
      memo: `Supplier bill ${bill.billNumber} - ${supplier.name}`,
      sourceType: 'bill',
      sourceId: String(bill.id),
      lines: glLines,
    });

    this.store.update('bill', bill.id, {
      status: BillStatus.POSTED,
      journalEntryId: entry.id,
      amountPaidMinor: '0',
    });
    return this.findOne(billId);
  }

  /**
   * AP aging: for every supplier, the base-currency outstanding balance
   * (totalMinor - amountPaidMinor, converted via the bill's own
   * exchangeRate) of every POSTED/PARTIALLY_PAID bill, bucketed by days
   * overdue against dueDate.
   */
  async agingReport(companyId: number): Promise<AgingBucket[]> {
    const suppliers = this.store.find<Supplier>('supplier', (s: any) => s.companyId === companyId);
    // Ids are plain numbers everywhere now; Number(...) here is a harmless
    // no-op kept for parity with the pre-conversion lookup.
    const supplierNameById = new Map(suppliers.map((s) => [Number(s.id), s.name]));

    const bills = this.store.find<Bill>(
      'bill',
      (b: any) => b.companyId === companyId && (b.status === BillStatus.POSTED || b.status === BillStatus.PARTIALLY_PAID),
    );

    const buckets = new Map<number, AgingBucket>();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const bill of bills) {
      const outstandingMinor = Number(bill.totalMinor) - Number(bill.amountPaidMinor);
      if (outstandingMinor <= 0) continue;

      const outstandingBaseMinor = Math.round(outstandingMinor * Number(bill.exchangeRate));
      const dueDate = new Date(bill.dueDate);
      dueDate.setHours(0, 0, 0, 0);
      const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

      let bucket = buckets.get(bill.supplierId);
      if (!bucket) {
        bucket = {
          supplierId: bill.supplierId,
          supplierName: supplierNameById.get(bill.supplierId) ?? `Supplier ${bill.supplierId}`,
          current: 0,
          d1to30: 0,
          d31to60: 0,
          d61to90: 0,
          d90plus: 0,
          totalOutstandingBaseMinor: 0,
        };
        buckets.set(bill.supplierId, bucket);
      }

      if (daysOverdue <= 0) bucket.current += outstandingBaseMinor;
      else if (daysOverdue <= 30) bucket.d1to30 += outstandingBaseMinor;
      else if (daysOverdue <= 60) bucket.d31to60 += outstandingBaseMinor;
      else if (daysOverdue <= 90) bucket.d61to90 += outstandingBaseMinor;
      else bucket.d90plus += outstandingBaseMinor;

      bucket.totalOutstandingBaseMinor += outstandingBaseMinor;
    }

    return Array.from(buckets.values());
  }
}
