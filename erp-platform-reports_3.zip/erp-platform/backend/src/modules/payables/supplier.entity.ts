import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('supplier')
@Index(['companyId', 'code'], { unique: true })
export class Supplier {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  code: string;

  @Column()
  name: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true })
  address: string;

  @Column({ default: 'LKR' })
  defaultCurrencyCode: string;

  @Column({ type: 'int', default: 30 })
  paymentTermsDays: number;

  // Usually one shared "Trade creditors control" account, but stored per
  // supplier so it CAN be overridden for a supplier billed through a
  // different control account.
  @Column()
  apControlAccountId: number;

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
