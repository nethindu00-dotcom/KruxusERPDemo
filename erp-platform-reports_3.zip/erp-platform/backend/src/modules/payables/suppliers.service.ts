import { Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { Supplier } from './supplier.entity';

@Injectable()
export class SuppliersService {
  constructor(private store: DataStore) {}

  findAll(companyId: number) {
    return this.store
      .find<Supplier>('supplier', (s: any) => s.companyId === companyId)
      .sort((a: any, b: any) => (a.code > b.code ? 1 : a.code < b.code ? -1 : 0));
  }

  async findOne(id: number): Promise<Supplier> {
    const supplier = this.store.findById<Supplier>('supplier', id);
    if (!supplier) throw new NotFoundException('Supplier not found');
    return supplier;
  }

  create(body: Partial<Supplier>) {
    return this.store.insert('supplier', { ...body });
  }

  async update(id: number, body: Partial<Supplier>) {
    await this.findOne(id);
    this.store.update('supplier', id, body);
    return this.findOne(id);
  }
}
