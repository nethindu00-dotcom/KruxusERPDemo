import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { PurchaseOrder } from './purchase-order.entity';

@Entity('purchase_order_line')
export class PurchaseOrderLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => PurchaseOrder, (po) => po.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'po_id' })
  po: PurchaseOrder;

  @Column({ name: 'po_id' })
  poId: number;

  @Column()
  itemId: number;

  @Column({ nullable: true })
  description: string;

  @Column({ type: 'decimal', precision: 18, scale: 4 })
  quantity: string;

  // In the PO's own currencyCode.
  @Column({ type: 'bigint' })
  unitPriceMinor: string;

  // Deliberately a manual, buyer-chosen field: an item's defaultTaxRateId is
  // a sales-side concept (output tax), not applicable to what a supplier
  // charges us on a purchase, so purchase-side tax is never auto-filled from
  // the item here.
  @Column({ nullable: true })
  taxRateId: number;

  // Tracks fulfillment against this line as goods receipts are posted.
  @Column({ type: 'decimal', precision: 18, scale: 4, default: 0 })
  quantityReceived: string;
}
