import { Module } from '@nestjs/common';
import { AccountingModule } from '../accounting/accounting.module';
import { InventoryModule } from '../inventory/inventory.module';
import { TaxModule } from '../tax/tax.module';

import { SuppliersService } from './suppliers.service';
import { PurchaseOrdersService } from './purchase-orders.service';
import { GoodsReceiptsService } from './goods-receipts.service';
import { BillsService } from './bills.service';
import { PaymentsService } from './payments.service';

import { SuppliersController } from './suppliers.controller';
import { PurchaseOrdersController } from './purchase-orders.controller';
import { GoodsReceiptsController } from './goods-receipts.controller';
import { BillsController } from './bills.controller';
import { PaymentsController } from './payments.controller';
import { AgingController } from './aging.controller';

@Module({
  imports: [AccountingModule, InventoryModule, TaxModule],
  providers: [SuppliersService, PurchaseOrdersService, GoodsReceiptsService, BillsService, PaymentsService],
  controllers: [
    SuppliersController,
    PurchaseOrdersController,
    GoodsReceiptsController,
    BillsController,
    PaymentsController,
    AgingController,
  ],
  exports: [SuppliersService, PurchaseOrdersService, GoodsReceiptsService, BillsService, PaymentsService],
})
export class PayablesModule {}
