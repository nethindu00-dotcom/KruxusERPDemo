import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { PurchaseOrder, PurchaseOrderStatus } from './purchase-order.entity';
import { PurchaseOrderLine } from './purchase-order-line.entity';

export interface CreatePurchaseOrderLineInput {
  itemId: number;
  description?: string;
  quantity: number;
  unitPriceMinor: number;
  taxRateId?: number;
}

export interface CreatePurchaseOrderInput {
  companyId: number;
  supplierId: number;
  orderDate: string;
  currencyCode?: string;
  exchangeRate?: number;
  notes?: string;
  lines: CreatePurchaseOrderLineInput[];
}

@Injectable()
export class PurchaseOrdersService {
  constructor(private store: DataStore) {}

  private withLines(po: PurchaseOrder): PurchaseOrder {
    (po as any).lines = this.store.find<PurchaseOrderLine>('purchaseOrderLine', (l: any) => l.poId === po.id);
    return po;
  }

  findAll(companyId: number) {
    return this.store
      .find<PurchaseOrder>('purchaseOrder', (p: any) => p.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((p) => this.withLines(p));
  }

  async findOne(id: number): Promise<PurchaseOrder> {
    const po = this.store.findById<PurchaseOrder>('purchaseOrder', id);
    if (!po) throw new NotFoundException('Purchase order not found');
    return this.withLines(po);
  }

  private nextPoNumber(companyId: number): string {
    return this.store.nextDocNumber('purchaseOrder', 'poNumber', companyId, `PO-${companyId}-`, 6);
  }

  async create(body: CreatePurchaseOrderInput) {
    if (!body.lines || body.lines.length === 0) {
      throw new BadRequestException('A purchase order needs at least one line');
    }
    const po = this.store.insert('purchaseOrder', {
      companyId: body.companyId,
      poNumber: this.nextPoNumber(body.companyId),
      supplierId: body.supplierId,
      orderDate: body.orderDate,
      currencyCode: body.currencyCode ?? 'LKR',
      exchangeRate: String(body.exchangeRate ?? 1),
      status: PurchaseOrderStatus.DRAFT,
      notes: body.notes,
    });

    for (const l of body.lines) {
      this.store.insert('purchaseOrderLine', {
        poId: po.id,
        itemId: l.itemId,
        description: l.description,
        quantity: String(l.quantity),
        unitPriceMinor: String(Math.round(l.unitPriceMinor)),
        taxRateId: l.taxRateId,
        quantityReceived: '0',
      });
    }

    return this.findOne(po.id);
  }

  /** Header-level patch only; line changes are made through goods receipts (quantityReceived) or a new PO. */
  async update(id: number, body: Partial<PurchaseOrder>) {
    await this.findOne(id);
    const { lines, ...header } = body as any;
    this.store.update('purchaseOrder', id, header);
    return this.findOne(id);
  }

  async approve(id: number) {
    const po = await this.findOne(id);
    if (po.status !== PurchaseOrderStatus.DRAFT) {
      throw new BadRequestException('Only a DRAFT purchase order can be approved');
    }
    this.store.update('purchaseOrder', id, { status: PurchaseOrderStatus.APPROVED });
    return this.findOne(id);
  }
}
