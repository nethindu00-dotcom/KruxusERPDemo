import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { GoodsReceipt } from './goods-receipt.entity';

@Entity('goods_receipt_line')
export class GoodsReceiptLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => GoodsReceipt, (g) => g.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'grn_id' })
  grn: GoodsReceipt;

  @Column({ name: 'grn_id' })
  grnId: number;

  @Column({ nullable: true })
  poLineId: number;

  @Column()
  itemId: number;

  @Column({ type: 'decimal', precision: 18, scale: 4 })
  quantity: string;

  // In the company's base currency: converted from the PO's currency via the
  // PO's exchangeRate when this line is received against a PO line.
  @Column({ type: 'bigint' })
  unitCostMinor: string;
}
