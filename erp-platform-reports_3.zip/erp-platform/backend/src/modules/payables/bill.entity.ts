import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { BillLine } from './bill-line.entity';

export enum BillStatus {
  DRAFT = 'DRAFT',
  POSTED = 'POSTED',
  PARTIALLY_PAID = 'PARTIALLY_PAID',
  PAID = 'PAID',
  VOID = 'VOID',
}

@Entity('bill')
@Index(['companyId', 'billNumber'], { unique: true })
export class Bill {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  billNumber: string;

  @Column()
  supplierId: number;

  @Column({ type: 'date' })
  billDate: string;

  @Column({ type: 'date' })
  dueDate: string;

  @Column({ default: 'LKR' })
  currencyCode: string;

  // Rate to convert this bill's currency into the company's base currency.
  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  @Column({ type: 'enum', enum: BillStatus, default: BillStatus.DRAFT })
  status: BillStatus;

  // All money columns below are in the bill's own currencyCode.
  @Column({ type: 'bigint', default: 0 })
  subtotalMinor: string;

  @Column({ type: 'bigint', default: 0 })
  taxMinor: string;

  @Column({ type: 'bigint', default: 0 })
  totalMinor: string;

  @Column({ type: 'bigint', default: 0 })
  amountPaidMinor: string;

  @Column({ type: 'bigint', nullable: true })
  journalEntryId: number;

  @Column({ nullable: true })
  poId: number;

  @Column({ nullable: true })
  grnId: number;

  @OneToMany(() => BillLine, (l) => l.bill, { cascade: true })
  lines: BillLine[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
