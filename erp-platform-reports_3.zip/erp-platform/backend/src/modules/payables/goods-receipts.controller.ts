import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { GoodsReceiptsService, CreateGoodsReceiptInput } from './goods-receipts.service';

@Controller('payables/goods-receipts')
export class GoodsReceiptsController {
  constructor(private svc: GoodsReceiptsService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: CreateGoodsReceiptInput) {
    return this.svc.create(body);
  }
}
