import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { BillsService, CreateBillInput } from './bills.service';

@Controller('payables/bills')
export class BillsController {
  constructor(private svc: BillsService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: CreateBillInput) {
    return this.svc.create(body);
  }

  @Post(':id/post')
  post(@Param('id', ParseIntPipe) id: number) {
    return this.svc.postBill(id);
  }
}
