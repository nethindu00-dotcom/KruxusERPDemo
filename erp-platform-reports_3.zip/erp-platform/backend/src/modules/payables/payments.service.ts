import { Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService, PostLineInput } from '../accounting/accounting.service';
import { Bill, BillStatus } from './bill.entity';
import { Payment } from './payment.entity';
import { PaymentAllocation } from './payment-allocation.entity';
import { Supplier } from './supplier.entity';

export interface CreatePaymentAllocationInput {
  billId: number;
  // In the BILL's own currencyCode.
  allocatedAmountMinor: number;
}

export interface CreatePaymentInput {
  companyId: number;
  supplierId: number;
  paymentDate: string;
  bankAccountGlAccountId: number;
  currencyCode: string;
  exchangeRate?: number;
  // Total paid, in currencyCode.
  amountMinor: number;
  allocations: CreatePaymentAllocationInput[];
  // Optional: where to book a non-zero realized FX gain/loss. If the
  // relevant one is omitted, that gain/loss is simply not recognized
  // separately (see the comment inline below) rather than failing the
  // payment over a missing optional account.
  realizedGainAccountId?: number;
  realizedLossAccountId?: number;
  // The company's base currency, used to decide whether an allocation
  // crosses currencies and so can realize a gain/loss. Defaults to 'LKR' to
  // match this system's default base currency when the caller doesn't pass
  // it explicitly.
  companyBaseCurrency?: string;
}

@Injectable()
export class PaymentsService {
  constructor(
    private store: DataStore,
    private accountingService: AccountingService,
  ) {}

  private withAllocations(payment: Payment): Payment {
    (payment as any).allocations = this.store.find<PaymentAllocation>(
      'paymentAllocation',
      (a: any) => a.paymentId === payment.id,
    );
    return payment;
  }

  findAll(companyId: number) {
    return this.store
      .find<Payment>('payment', (p: any) => p.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((p) => this.withAllocations(p));
  }

  async findOne(id: number): Promise<Payment> {
    const payment = this.store.findById<Payment>('payment', id);
    if (!payment) throw new NotFoundException('Payment not found');
    return this.withAllocations(payment);
  }

  private nextPaymentNumber(companyId: number): string {
    return this.store.nextDocNumber('payment', 'paymentNumber', companyId, `PAY-${companyId}-`, 6);
  }

  /**
   * Allocates a payment against one or more bills and posts ONE combined GL
   * entry: one AP-control debit line per allocation (each converted at that
   * bill's own currency/exchangeRate, since allocations can span bills in
   * different currencies), a single bank credit line (in the payment's own
   * currency/exchangeRate), and, when applicable, a realized FX gain/loss
   * line.
   */
  async createPayment(input: CreatePaymentInput): Promise<Payment> {
    if (!input.allocations || input.allocations.length === 0) {
      throw new NotFoundException('A payment needs at least one allocation');
    }

    const supplier = this.store.findById<Supplier>('supplier', input.supplierId);
    if (!supplier) throw new NotFoundException('Supplier not found');

    const paymentExchangeRate = input.exchangeRate ?? 1;
    const companyBaseCurrency = input.companyBaseCurrency ?? 'LKR';
    const amountMinor = Math.round(input.amountMinor);

    // Save the header first so allocations and the GL entry's sourceId can
    // reference its id, mirroring how GoodsReceipt/StockMovement are wired.
    const payment = this.store.insert('payment', {
      companyId: input.companyId,
      paymentNumber: this.nextPaymentNumber(input.companyId),
      supplierId: input.supplierId,
      paymentDate: input.paymentDate,
      bankAccountGlAccountId: input.bankAccountGlAccountId,
      currencyCode: input.currencyCode,
      exchangeRate: String(paymentExchangeRate),
      amountMinor: String(amountMinor),
      status: 'POSTED',
    });

    const apDebitLines: PostLineInput[] = [];
    let gainTotal = 0;
    let lossTotal = 0;

    for (const alloc of input.allocations) {
      const bill = this.store.findById<Bill>('bill', alloc.billId);
      if (!bill) throw new NotFoundException(`Bill ${alloc.billId} not found`);

      const allocatedAmountMinor = Math.round(alloc.allocatedAmountMinor);
      const newAmountPaid = Number(bill.amountPaidMinor) + allocatedAmountMinor;
      const newStatus = newAmountPaid >= Number(bill.totalMinor) ? BillStatus.PAID : BillStatus.PARTIALLY_PAID;
      this.store.update('bill', bill.id, { amountPaidMinor: String(newAmountPaid), status: newStatus });

      const billRate = Number(bill.exchangeRate);
      let realizedGainLossMinor: number | null = null;
      // Defaults to the bill's own booking rate; only overridden below when
      // we need to silently absorb an unbooked gain/loss (see comment).
      let apLineRate = billRate;

      if (bill.currencyCode !== companyBaseCurrency && billRate !== paymentExchangeRate) {
        realizedGainLossMinor = Math.round(allocatedAmountMinor * (paymentExchangeRate - billRate));

        if (realizedGainLossMinor > 0) {
          if (input.realizedGainAccountId) {
            gainTotal += realizedGainLossMinor;
          } else {
            // No gain account supplied: rather than fail the whole payment
            // over a missing optional account, book this allocation's AP
            // line at the payment's own rate instead of the bill's booking
            // rate. That makes this AP debit line's base amount match the
            // bank credit's base contribution for the same money exactly,
            // so the entry still balances without a separate gain/loss
            // recognition — the gain is simply absorbed into the AP side.
            apLineRate = paymentExchangeRate;
          }
        } else if (realizedGainLossMinor < 0) {
          if (input.realizedLossAccountId) {
            lossTotal += -realizedGainLossMinor;
          } else {
            apLineRate = paymentExchangeRate;
          }
        }
      }

      this.store.insert('paymentAllocation', {
        paymentId: payment.id,
        billId: bill.id,
        allocatedAmountMinor: String(allocatedAmountMinor),
        realizedGainLossMinor: realizedGainLossMinor !== null ? String(realizedGainLossMinor) : null,
      });

      apDebitLines.push({
        accountId: supplier.apControlAccountId,
        debitMinor: allocatedAmountMinor,
        description: `Payment ${payment.paymentNumber} applied to bill ${bill.billNumber}`,
        currencyCode: bill.currencyCode,
        exchangeRate: apLineRate,
        partyType: 'supplier',
        partyId: supplier.id,
      });
    }

    const glLines: PostLineInput[] = [...apDebitLines];

    glLines.push({
      accountId: input.bankAccountGlAccountId,
      creditMinor: amountMinor,
      description: `Payment ${payment.paymentNumber} to ${supplier.name}`,
      currencyCode: input.currencyCode,
      exchangeRate: paymentExchangeRate,
    });

    if (gainTotal > 0) {
      glLines.push({
        accountId: input.realizedGainAccountId as number,
        creditMinor: gainTotal,
        description: 'Realized exchange gain',
        currencyCode: companyBaseCurrency,
        exchangeRate: 1,
      });
    }
    if (lossTotal > 0) {
      glLines.push({
        accountId: input.realizedLossAccountId as number,
        debitMinor: lossTotal,
        description: 'Realized exchange loss',
        currencyCode: companyBaseCurrency,
        exchangeRate: 1,
      });
    }

    // The lines above balance by construction (every AP debit line converts
    // at the same rate used for its matching bank/gain-loss credit
    // contribution). Integer rounding across different rates can still leave
    // a mismatch of a cent or two; rather than fail the payment over that,
    // plug the remainder onto the bank line.
    const baseOf = (minor: number, rate: number) => Math.round((minor * Math.round(rate * 1_000_000)) / 1_000_000);
    let debitBase = 0;
    let creditBase = 0;
    for (const l of glLines) {
      if (l.debitMinor) debitBase += baseOf(l.debitMinor, l.exchangeRate ?? 1);
      if (l.creditMinor) creditBase += baseOf(l.creditMinor, l.exchangeRate ?? 1);
    }
    const mismatch = debitBase - creditBase;
    if (mismatch !== 0) {
      const bankLine = glLines.find((l) => l.accountId === input.bankAccountGlAccountId);
      if (bankLine) {
        const rateScaled = Math.round(paymentExchangeRate * 1_000_000) || 1_000_000;
        const extraMinor = Math.round((mismatch * 1_000_000) / rateScaled);
        bankLine.creditMinor = (bankLine.creditMinor ?? 0) + extraMinor;
      }
    }

    const entry = await this.accountingService.post({
      companyId: input.companyId,
      entryDate: input.paymentDate,
      memo: `Payment ${payment.paymentNumber} to ${supplier.name}`,
      sourceType: 'payment',
      sourceId: String(payment.id),
      lines: glLines,
    });

    this.store.update('payment', payment.id, { journalEntryId: entry.id });
    return this.findOne(payment.id);
  }
}
