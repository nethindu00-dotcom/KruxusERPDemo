import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { GoodsReceiptLine } from './goods-receipt-line.entity';

@Entity('goods_receipt')
@Index(['companyId', 'grnNumber'], { unique: true })
export class GoodsReceipt {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  grnNumber: string;

  // A GRN can receive against a PO, or stand alone (no PO).
  @Column({ nullable: true })
  poId: number;

  @Column()
  supplierId: number;

  @Column({ type: 'date' })
  receiptDate: string;

  @Column({ nullable: true })
  notes: string;

  @OneToMany(() => GoodsReceiptLine, (l) => l.grn, { cascade: true })
  lines: GoodsReceiptLine[];

  @CreateDateColumn()
  createdAt: Date;
}
