import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Payment } from './payment.entity';

@Entity('payment_allocation')
export class PaymentAllocation {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => Payment, (p) => p.allocations, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'payment_id' })
  payment: Payment;

  @Column({ name: 'payment_id' })
  paymentId: number;

  @Column()
  billId: number;

  // In the BILL's own currencyCode.
  @Column({ type: 'bigint' })
  allocatedAmountMinor: string;

  // In the company's base currency. Filled only when the bill's currency
  // differs from the company base currency and the payment settled at a
  // different rate than the bill was booked at.
  @Column({ type: 'bigint', nullable: true })
  realizedGainLossMinor: string;
}
