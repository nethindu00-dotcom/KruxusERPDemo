import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { PaymentAllocation } from './payment-allocation.entity';

@Entity('payment')
@Index(['companyId', 'paymentNumber'], { unique: true })
export class Payment {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  paymentNumber: string;

  @Column()
  supplierId: number;

  @Column({ type: 'date' })
  paymentDate: string;

  // The cash/bank GL account paid FROM. Deliberately just an accountId, with
  // no dependency on any Banking module.
  @Column()
  bankAccountGlAccountId: number;

  @Column({ default: 'LKR' })
  currencyCode: string;

  // This payment's own rate to the company base currency.
  @Column({ type: 'decimal', precision: 18, scale: 6, default: 1 })
  exchangeRate: string;

  // Total paid, in the payment's own currencyCode.
  @Column({ type: 'bigint' })
  amountMinor: string;

  @Column({ type: 'bigint', nullable: true })
  journalEntryId: number;

  @Column({ default: 'POSTED' })
  status: string;

  @OneToMany(() => PaymentAllocation, (a) => a.payment, { cascade: true })
  allocations: PaymentAllocation[];

  @CreateDateColumn()
  createdAt: Date;
}
