import { Controller, Get, ParseIntPipe, Query } from '@nestjs/common';
import { BillsService } from './bills.service';

@Controller('payables')
export class AgingController {
  constructor(private billsService: BillsService) {}

  @Get('aging')
  aging(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.billsService.agingReport(companyId);
  }
}
