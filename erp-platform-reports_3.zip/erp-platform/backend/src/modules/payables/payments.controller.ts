import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { PaymentsService, CreatePaymentInput } from './payments.service';

@Controller('payables/payments')
export class PaymentsController {
  constructor(private svc: PaymentsService) {}

  @Get()
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Post()
  create(@Body() body: CreatePaymentInput) {
    return this.svc.createPayment(body);
  }
}
