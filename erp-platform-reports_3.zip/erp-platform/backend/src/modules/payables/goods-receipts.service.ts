import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { ItemsService } from '../inventory/items.service';
import { GoodsReceipt } from './goods-receipt.entity';
import { GoodsReceiptLine } from './goods-receipt-line.entity';
import { PurchaseOrder, PurchaseOrderStatus } from './purchase-order.entity';
import { PurchaseOrderLine } from './purchase-order-line.entity';

export interface CreateGoodsReceiptLineInput {
  poLineId?: number;
  itemId: number;
  quantity: number;
  // In the company's base currency. Required unless poLineId is set, in
  // which case it is derived from the PO line's unitPriceMinor converted at
  // the PO's exchangeRate.
  unitCostMinor?: number;
}

export interface CreateGoodsReceiptInput {
  companyId: number;
  poId?: number;
  supplierId: number;
  receiptDate: string;
  notes?: string;
  // The liability/clearing account credited for the stock receipt (e.g. a
  // GRN-clearing account, or the AP control account directly).
  grnClearingAccountId: number;
  lines: CreateGoodsReceiptLineInput[];
}

@Injectable()
export class GoodsReceiptsService {
  constructor(
    private store: DataStore,
    private itemsService: ItemsService,
  ) {}

  private withLines(grn: GoodsReceipt): GoodsReceipt {
    (grn as any).lines = this.store.find<GoodsReceiptLine>('goodsReceiptLine', (l: any) => l.grnId === grn.id);
    return grn;
  }

  findAll(companyId: number) {
    return this.store
      .find<GoodsReceipt>('goodsReceipt', (g: any) => g.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id)
      .map((g) => this.withLines(g));
  }

  async findOne(id: number): Promise<GoodsReceipt> {
    const grn = this.store.findById<GoodsReceipt>('goodsReceipt', id);
    if (!grn) throw new NotFoundException('Goods receipt not found');
    return this.withLines(grn);
  }

  private nextGrnNumber(companyId: number): string {
    return this.store.nextDocNumber('goodsReceipt', 'grnNumber', companyId, `GRN-${companyId}-`, 6);
  }

  async create(body: CreateGoodsReceiptInput) {
    if (!body.lines || body.lines.length === 0) {
      throw new BadRequestException('A goods receipt needs at least one line');
    }

    let po: PurchaseOrder | null = null;
    if (body.poId) {
      po = this.store.findById<PurchaseOrder>('purchaseOrder', body.poId) ?? null;
      if (!po) throw new NotFoundException('Purchase order not found');
    }

    // Resolve each line's base-currency unit cost up front.
    const resolvedLines: Array<{ poLineId: number | null; itemId: number; quantity: string; unitCostMinor: string }> = [];
    for (const l of body.lines) {
      let unitCostMinor = l.unitCostMinor;
      if (unitCostMinor == null) {
        if (!l.poLineId) {
          throw new BadRequestException('unitCostMinor is required for a receipt line not linked to a PO line');
        }
        const poLine = this.store.findById<PurchaseOrderLine>('purchaseOrderLine', l.poLineId);
        if (!poLine) throw new NotFoundException(`Purchase order line ${l.poLineId} not found`);
        const rate = po ? Number(po.exchangeRate) : 1;
        unitCostMinor = Number(poLine.unitPriceMinor) * rate;
      }
      resolvedLines.push({
        poLineId: l.poLineId ?? null,
        itemId: l.itemId,
        quantity: String(l.quantity),
        unitCostMinor: String(Math.round(unitCostMinor)),
      });
    }

    const grn = this.store.insert('goodsReceipt', {
      companyId: body.companyId,
      grnNumber: this.nextGrnNumber(body.companyId),
      poId: body.poId ?? null,
      supplierId: body.supplierId,
      receiptDate: body.receiptDate,
      notes: body.notes,
    });

    const insertedLines = resolvedLines.map((l) =>
      this.store.insert('goodsReceiptLine', { ...l, grnId: grn.id }),
    );

    // Post each line to stock + GL, and roll fulfillment up to the PO.
    for (const line of insertedLines) {
      await this.itemsService.postReceipt({
        itemId: line.itemId,
        quantity: Number(line.quantity),
        unitCostMinor: Number(line.unitCostMinor),
        movementDate: body.receiptDate,
        sourceType: 'goods_receipt',
        sourceId: String(grn.id),
        companyId: body.companyId,
        offsetAccountId: body.grnClearingAccountId,
      });

      if (line.poLineId) {
        const poLine = this.store.findById<PurchaseOrderLine>('purchaseOrderLine', line.poLineId);
        if (poLine) {
          this.store.update('purchaseOrderLine', poLine.id, {
            quantityReceived: String(Number(poLine.quantityReceived) + Number(line.quantity)),
          });
        }
      }
    }

    if (po) {
      this.refreshPoStatus(po.id);
    }

    return this.findOne(grn.id);
  }

  private refreshPoStatus(poId: number) {
    const po = this.store.findById<PurchaseOrder>('purchaseOrder', poId);
    if (!po) return;
    if (po.status === PurchaseOrderStatus.CLOSED || po.status === PurchaseOrderStatus.CANCELLED) return;

    const lines = this.store.find<PurchaseOrderLine>('purchaseOrderLine', (l: any) => l.poId === po.id);
    const allReceived = lines.every((l) => Number(l.quantityReceived) >= Number(l.quantity));
    const anyReceived = lines.some((l) => Number(l.quantityReceived) > 0);

    const status = allReceived
      ? PurchaseOrderStatus.RECEIVED
      : anyReceived
        ? PurchaseOrderStatus.PARTIALLY_RECEIVED
        : po.status;

    this.store.update('purchaseOrder', po.id, { status });
  }
}
