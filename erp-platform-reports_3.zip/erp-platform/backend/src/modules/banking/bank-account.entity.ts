import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('bank_account')
@Index(['companyId'])
export class BankAccount {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column({ name: 'account_id' })
  accountId: number;

  @Column()
  bankName: string;

  @Column()
  accountNumber: string;

  @Column({ nullable: true })
  branchName: string;

  @Column({ default: 'LKR' })
  currencyCode: string;

  @Column({ type: 'bigint', default: 0 })
  openingBalanceMinor: string;

  @Column({ type: 'date', nullable: true })
  openingBalanceDate: string;

  @Column({ default: true })
  isActive: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
