import { Body, Controller, Get, Param, ParseIntPipe, Patch, Post, Query } from '@nestjs/common';
import { BankingService } from './banking.service';

@Controller('banking')
export class BankingController {
  constructor(private svc: BankingService) {}

  @Get('accounts')
  findAll(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.findAll(companyId);
  }

  @Post('accounts')
  create(@Body() body: any) {
    return this.svc.create(body);
  }

  @Get('accounts/:id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Patch('accounts/:id')
  update(@Param('id', ParseIntPipe) id: number, @Body() body: any) {
    return this.svc.update(id, body);
  }

  @Post('accounts/:id/statement-lines/import')
  importStatementLines(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { companyId: number; lines: any[]; importBatchId?: string },
  ) {
    return this.svc.importStatementLines({
      bankAccountId: id,
      companyId: body.companyId,
      lines: body.lines,
      importBatchId: body.importBatchId,
    });
  }

  @Get('accounts/:id/statement-lines')
  listStatementLines(
    @Param('id', ParseIntPipe) id: number,
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('unmatchedOnly') unmatchedOnly?: string,
  ) {
    return this.svc.listStatementLines(id, companyId, {
      from,
      to,
      unmatchedOnly: unmatchedOnly === 'true',
    });
  }

  @Post('accounts/:id/auto-match')
  autoMatch(
    @Param('id', ParseIntPipe) id: number,
    @Query('companyId', ParseIntPipe) companyId: number,
    @Body() body?: { dateToleranceDays?: number },
  ) {
    return this.svc.autoMatch({
      bankAccountId: id,
      companyId,
      dateToleranceDays: body?.dateToleranceDays,
    });
  }

  @Post('statement-lines/:id/match')
  manualMatch(
    @Param('id', ParseIntPipe) id: number,
    @Body() body: { journalEntryId: number; journalLineId: number },
  ) {
    return this.svc.manualMatch({
      statementLineId: id,
      journalEntryId: body.journalEntryId,
      journalLineId: body.journalLineId,
    });
  }

  @Post('statement-lines/:id/unmatch')
  unmatch(@Param('id', ParseIntPipe) id: number) {
    return this.svc.unmatch(id);
  }

  @Get('accounts/:id/reconciliation')
  reconciliation(
    @Param('id', ParseIntPipe) id: number,
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('asOfDate') asOfDate: string,
  ) {
    return this.svc.reconciliationSummary({ bankAccountId: id, companyId, asOfDate });
  }

  @Post('accounts/:id/transactions')
  createTransaction(
    @Param('id', ParseIntPipe) id: number,
    @Query('companyId', ParseIntPipe) companyId: number,
    @Body()
    body: {
      transactionDate: string;
      description: string;
      amountMinor: number;
      direction: 'IN' | 'OUT';
      contraAccountId: number;
      sourceType?: string;
    },
  ) {
    return this.svc.createBankTransaction({
      bankAccountId: id,
      companyId,
      transactionDate: body.transactionDate,
      description: body.description,
      amountMinor: body.amountMinor,
      direction: body.direction,
      contraAccountId: body.contraAccountId,
      sourceType: body.sourceType,
    });
  }
}
