import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { BankAccount } from './bank-account.entity';
import { BankStatementLine } from './bank-statement-line.entity';
import { AccountingService } from '../accounting/accounting.service';

export interface ImportStatementLineInput {
  statementDate: string;
  description: string;
  referenceNo?: string;
  debitMinor?: number;
  creditMinor?: number;
  runningBalanceMinor?: number;
}

export interface ImportStatementLinesInput {
  bankAccountId: number;
  companyId: number;
  lines: ImportStatementLineInput[];
  importBatchId?: string;
}

export interface AutoMatchInput {
  bankAccountId: number;
  companyId: number;
  dateToleranceDays?: number;
}

export interface ManualMatchInput {
  statementLineId: number;
  journalEntryId: number;
  journalLineId: number;
}

export interface ReconciliationSummaryInput {
  bankAccountId: number;
  companyId: number;
  asOfDate: string;
}

export interface CreateBankTransactionInput {
  bankAccountId: number;
  companyId: number;
  transactionDate: string;
  description: string;
  amountMinor: number;
  direction: 'IN' | 'OUT';
  contraAccountId: number;
  sourceType?: string;
}

@Injectable()
export class BankingService {
  constructor(
    private store: DataStore,
    private accountingService: AccountingService,
  ) {}

  // ---------- Bank account CRUD ----------

  async findAll(companyId: number) {
    return this.store
      .find<BankAccount>('bankAccount', (a) => a.companyId === companyId)
      .sort((a, b) => a.id - b.id);
  }

  async findOne(id: number) {
    const bankAccount = this.store.findById<BankAccount>('bankAccount', id);
    if (!bankAccount) throw new NotFoundException('Bank account not found');
    return bankAccount;
  }

  async create(body: Partial<BankAccount>) {
    return this.store.insert('bankAccount', { ...body });
  }

  async update(id: number, body: Partial<BankAccount>) {
    this.store.update('bankAccount', id, body);
    return this.findOne(id);
  }

  // ---------- Statement import ----------

  private generateImportBatchId(): string {
    return `IMP-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  async importStatementLines(input: ImportStatementLinesInput) {
    if (!input.lines || input.lines.length === 0) {
      throw new BadRequestException('No statement lines supplied');
    }
    const importBatchId = input.importBatchId || this.generateImportBatchId();
    const saved = input.lines.map((l) =>
      this.store.insert('bankStatementLine', {
        companyId: input.companyId,
        bankAccountId: input.bankAccountId,
        statementDate: l.statementDate,
        description: l.description,
        referenceNo: l.referenceNo,
        debitMinor: String(Math.round(l.debitMinor || 0)),
        creditMinor: String(Math.round(l.creditMinor || 0)),
        runningBalanceMinor:
          l.runningBalanceMinor !== undefined && l.runningBalanceMinor !== null
            ? String(Math.round(l.runningBalanceMinor))
            : null,
        isMatched: false,
        matchedJournalEntryId: null,
        matchedJournalLineId: null,
        matchNote: null,
        importBatchId,
        createdAt: new Date(),
      }),
    );
    return { importBatchId, count: saved.length, lines: saved };
  }

  async listStatementLines(
    bankAccountId: number,
    companyId: number,
    opts: { from?: string; to?: string; unmatchedOnly?: boolean } = {},
  ) {
    let lines = this.store.find<BankStatementLine>(
      'bankStatementLine',
      (sl) => sl.bankAccountId === bankAccountId && sl.companyId === companyId,
    );
    if (opts.from) lines = lines.filter((sl) => sl.statementDate >= opts.from!);
    if (opts.to) lines = lines.filter((sl) => sl.statementDate <= opts.to!);
    if (opts.unmatchedOnly) lines = lines.filter((sl) => sl.isMatched === false);
    lines.sort((a, b) => (a.statementDate > b.statementDate ? 1 : a.statementDate < b.statementDate ? -1 : a.id - b.id));
    return lines;
  }

  // ---------- Matching ----------

  private addDays(dateStr: string, days: number): string {
    const d = new Date(`${dateStr}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().slice(0, 10);
  }

  async autoMatch(input: AutoMatchInput) {
    const bankAccount = await this.findOne(input.bankAccountId);
    const dateToleranceDays = input.dateToleranceDays ?? 3;

    const unmatchedLines = this.store
      .find<BankStatementLine>(
        'bankStatementLine',
        (sl) =>
          sl.bankAccountId === input.bankAccountId && sl.companyId === input.companyId && sl.isMatched === false,
      )
      .sort((a, b) => (a.statementDate > b.statementDate ? 1 : a.statementDate < b.statementDate ? -1 : a.id - b.id));

    // Journal lines already claimed by some statement line (from previous runs),
    // plus ones we claim during this run.
    const alreadyClaimed = this.store.find<BankStatementLine>(
      'bankStatementLine',
      (l) => l.bankAccountId === input.bankAccountId,
    );
    const claimed = new Set<number>(
      alreadyClaimed
        .filter((l) => l.matchedJournalLineId != null)
        .map((l) => Number(l.matchedJournalLineId)),
    );

    let matchedCount = 0;
    const totalChecked = unmatchedLines.length;

    for (const statementLine of unmatchedLines) {
      const debit = BigInt(statementLine.debitMinor || '0');
      const credit = BigInt(statementLine.creditMinor || '0');
      const fromDate = this.addDays(statementLine.statementDate, -dateToleranceDays);
      const toDate = this.addDays(statementLine.statementDate, dateToleranceDays);

      let amountKey: 'debitMinor' | 'creditMinor';
      let amount: bigint;
      if (credit > 0n) {
        // money in per the bank -> matches a journal line debiting the bank account
        amountKey = 'debitMinor';
        amount = credit;
      } else if (debit > 0n) {
        // money out per the bank -> matches a journal line crediting the bank account
        amountKey = 'creditMinor';
        amount = debit;
      } else {
        continue; // nothing to match on a zero-amount line
      }

      const entriesInRange = new Set(
        this.store
          .find<any>(
            'journalEntry',
            (e) => e.companyId === input.companyId && e.entryDate >= fromDate && e.entryDate <= toDate,
          )
          .map((e) => e.id),
      );

      const candidates = this.store
        .find<any>(
          'journalLine',
          (l) =>
            l.accountId === bankAccount.accountId &&
            entriesInRange.has(l.entryId) &&
            l[amountKey] === amount.toString(),
        )
        .filter((l) => !claimed.has(Number(l.id)));

      if (candidates.length === 1) {
        const match = candidates[0];
        claimed.add(Number(match.id));
        this.store.update('bankStatementLine', statementLine.id, {
          isMatched: true,
          matchedJournalEntryId: match.entryId,
          matchedJournalLineId: match.id,
          matchNote: 'auto-matched',
        });
        matchedCount++;
      }
      // zero or multiple candidates: ambiguous, leave unmatched for a human
    }

    return {
      matchedCount,
      unmatchedCount: totalChecked - matchedCount,
      totalChecked,
    };
  }

  async manualMatch(input: ManualMatchInput) {
    const statementLine = this.store.findById<BankStatementLine>('bankStatementLine', input.statementLineId);
    if (!statementLine) throw new NotFoundException('Statement line not found');
    return this.store.update('bankStatementLine', statementLine.id, {
      isMatched: true,
      matchedJournalEntryId: input.journalEntryId,
      matchedJournalLineId: input.journalLineId,
      matchNote: 'manually matched',
    });
  }

  async unmatch(statementLineId: number) {
    const statementLine = this.store.findById<BankStatementLine>('bankStatementLine', statementLineId);
    if (!statementLine) throw new NotFoundException('Statement line not found');
    return this.store.update('bankStatementLine', statementLine.id, {
      isMatched: false,
      matchedJournalEntryId: null,
      matchedJournalLineId: null,
      matchNote: null,
    });
  }

  // ---------- Reconciliation ----------

  async reconciliationSummary(input: ReconciliationSummaryInput) {
    const bankAccount = await this.findOne(input.bankAccountId);

    // (a) book balance
    const postedEntries = this.store.find<any>(
      'journalEntry',
      (e) =>
        e.companyId === input.companyId &&
        e.status === 'POSTED' &&
        e.entryDate <= input.asOfDate &&
        (!bankAccount.openingBalanceDate || e.entryDate >= bankAccount.openingBalanceDate),
    );
    const postedEntryIds = new Set(postedEntries.map((e) => e.id));
    const bookLines = this.store.find<any>(
      'journalLine',
      (l) => l.accountId === bankAccount.accountId && postedEntryIds.has(l.entryId),
    );
    let totalDebit = 0n;
    let totalCredit = 0n;
    for (const l of bookLines) {
      totalDebit += BigInt(l.debitMinor || '0');
      totalCredit += BigInt(l.creditMinor || '0');
    }
    const bookMovement = totalDebit - totalCredit;
    const bookBalanceMinor = BigInt(bankAccount.openingBalanceMinor || '0') + bookMovement;

    // (b) statement balance
    const statementLinesWithBalance = this.store
      .find<BankStatementLine>(
        'bankStatementLine',
        (sl) =>
          sl.bankAccountId === input.bankAccountId &&
          sl.statementDate <= input.asOfDate &&
          sl.runningBalanceMinor !== null &&
          sl.runningBalanceMinor !== undefined,
      )
      .sort((a, b) => (a.statementDate > b.statementDate ? -1 : a.statementDate < b.statementDate ? 1 : b.id - a.id));
    const latestWithRunningBalance = statementLinesWithBalance[0];

    let statementBalanceMinor: bigint;
    if (latestWithRunningBalance) {
      statementBalanceMinor = BigInt(latestWithRunningBalance.runningBalanceMinor);
    } else {
      const statementLinesUpToDate = this.store.find<BankStatementLine>(
        'bankStatementLine',
        (sl) => sl.bankAccountId === input.bankAccountId && sl.statementDate <= input.asOfDate,
      );
      let stmtTotalCredit = 0n;
      let stmtTotalDebit = 0n;
      for (const sl of statementLinesUpToDate) {
        stmtTotalCredit += BigInt(sl.creditMinor || '0');
        stmtTotalDebit += BigInt(sl.debitMinor || '0');
      }
      statementBalanceMinor = BigInt(bankAccount.openingBalanceMinor || '0') + (stmtTotalCredit - stmtTotalDebit);
    }

    // (c) unmatched statement lines up to asOfDate
    const unmatchedStatementLines = this.store
      .find<BankStatementLine>(
        'bankStatementLine',
        (sl) =>
          sl.bankAccountId === input.bankAccountId &&
          sl.companyId === input.companyId &&
          sl.isMatched === false &&
          sl.statementDate <= input.asOfDate,
      )
      .sort((a, b) => (a.statementDate > b.statementDate ? 1 : a.statementDate < b.statementDate ? -1 : 0));

    // (d) unreconciled journal lines up to asOfDate (not linked as matchedJournalLineId on any statement line)
    const matchedJournalLineIds = new Set(
      this.store
        .find<BankStatementLine>(
          'bankStatementLine',
          (sl) => sl.bankAccountId === input.bankAccountId && sl.matchedJournalLineId != null,
        )
        .map((sl) => Number(sl.matchedJournalLineId)),
    );

    const entriesUpToDate = this.store.find<any>(
      'journalEntry',
      (e) => e.companyId === input.companyId && e.entryDate <= input.asOfDate,
    );
    const entriesUpToDateById = new Map(entriesUpToDate.map((e) => [e.id, e]));
    const unreconciledJournalLines = this.store
      .find<any>(
        'journalLine',
        (l) => l.accountId === bankAccount.accountId && entriesUpToDateById.has(l.entryId) && !matchedJournalLineIds.has(Number(l.id)),
      )
      .sort((a, b) => {
        const ea = entriesUpToDateById.get(a.entryId)!.entryDate;
        const eb = entriesUpToDateById.get(b.entryId)!.entryDate;
        return ea > eb ? 1 : ea < eb ? -1 : 0;
      });

    const differenceMinor = bookBalanceMinor - statementBalanceMinor;

    return {
      bankAccountId: input.bankAccountId,
      asOfDate: input.asOfDate,
      bookBalanceMinor: bookBalanceMinor.toString(),
      statementBalanceMinor: statementBalanceMinor.toString(),
      differenceMinor: differenceMinor.toString(),
      unmatchedStatementLines,
      unreconciledJournalLines,
    };
  }

  // ---------- Convenience posting ----------

  async createBankTransaction(input: CreateBankTransactionInput) {
    const bankAccount = await this.findOne(input.bankAccountId);
    const amount = Math.round(input.amountMinor);
    if (amount <= 0) {
      throw new BadRequestException('amountMinor must be greater than zero');
    }
    const sourceType = input.sourceType || 'bank_transaction';

    const lines =
      input.direction === 'IN'
        ? [
            { accountId: bankAccount.accountId, debitMinor: amount, currencyCode: bankAccount.currencyCode },
            { accountId: input.contraAccountId, creditMinor: amount, currencyCode: bankAccount.currencyCode },
          ]
        : input.direction === 'OUT'
          ? [
              { accountId: bankAccount.accountId, creditMinor: amount, currencyCode: bankAccount.currencyCode },
              { accountId: input.contraAccountId, debitMinor: amount, currencyCode: bankAccount.currencyCode },
            ]
          : (() => {
              throw new BadRequestException("direction must be 'IN' or 'OUT'");
            })();

    return this.accountingService.post({
      companyId: input.companyId,
      entryDate: input.transactionDate,
      memo: input.description,
      sourceType,
      lines,
    });
  }
}
