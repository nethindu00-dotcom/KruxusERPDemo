import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('bank_statement_line')
@Index(['companyId', 'bankAccountId'])
export class BankStatementLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column({ name: 'bank_account_id' })
  bankAccountId: number;

  @Column({ type: 'date' })
  statementDate: string;

  @Column()
  description: string;

  @Column({ nullable: true })
  referenceNo: string;

  // money OUT per the bank (e.g. a withdrawal/payment)
  @Column({ type: 'bigint', default: 0 })
  debitMinor: string;

  // money IN per the bank (e.g. a deposit/receipt)
  @Column({ type: 'bigint', default: 0 })
  creditMinor: string;

  @Column({ type: 'bigint', nullable: true })
  runningBalanceMinor: string;

  @Column({ default: false })
  isMatched: boolean;

  @Column({ nullable: true })
  matchedJournalEntryId: number;

  @Column({ nullable: true })
  matchedJournalLineId: number;

  @Column({ nullable: true })
  matchNote: string;

  @Column({ nullable: true })
  importBatchId: string;

  @CreateDateColumn()
  createdAt: Date;
}
