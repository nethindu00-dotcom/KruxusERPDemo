import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { DataStore } from '../../database/data-store';

@Injectable()
export class AuthService {
  constructor(
    private store: DataStore,
    private jwt: JwtService,
  ) {}

  async login(email: string, password: string) {
    const user = this.store.findOne<any>('user', (u) => u.email === email);
    if (!user || !user.isActive) throw new UnauthorizedException('Invalid credentials');
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) throw new UnauthorizedException('Invalid credentials');
    const payload = { sub: user.id, email: user.email, role: user.role, fullName: user.fullName };
    return {
      accessToken: this.jwt.sign(payload, { expiresIn: '12h' }),
      user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role },
    };
  }

  async me(userId: number) {
    const user = this.store.findById<any>('user', userId);
    if (!user) throw new UnauthorizedException();
    return { id: user.id, email: user.email, fullName: user.fullName, role: user.role };
  }
}
