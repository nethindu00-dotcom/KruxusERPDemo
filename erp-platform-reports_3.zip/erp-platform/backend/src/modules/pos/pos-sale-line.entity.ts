import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { PosSale } from './pos-sale.entity';

@Entity('pos_sale_line')
@Index(['saleId'])
export class PosSaleLine {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @ManyToOne(() => PosSale, (s) => s.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'sale_id' })
  sale: PosSale;

  @Column({ name: 'sale_id' })
  saleId: number;

  @Column({ name: 'item_id' })
  itemId: number;

  @Column()
  description: string;

  @Column({ type: 'decimal', precision: 18, scale: 4, default: 1 })
  quantity: string;

  @Column({ type: 'bigint' })
  unitPriceMinor: string;

  @Column({ name: 'tax_rate_id', nullable: true })
  taxRateId: number;

  // Net of tax, mirroring InvoiceLine.lineTotalMinor (the invoice line this
  // was mirrored from) — quantity * unitPriceMinor, rounded.
  @Column({ type: 'bigint' })
  lineTotalMinor: string;
}
