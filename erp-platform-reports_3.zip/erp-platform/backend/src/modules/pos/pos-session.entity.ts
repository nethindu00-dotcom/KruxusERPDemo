import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

export enum PosSessionStatus {
  OPEN = 'OPEN',
  CLOSED = 'CLOSED',
}

@Entity('pos_session')
@Index(['companyId', 'cashierId', 'status'])
export class PosSession {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column({ name: 'branch_id', nullable: true })
  branchId: number;

  @Column({ name: 'cashier_id' })
  cashierId: number;

  @Column({ type: 'datetime' })
  openedAt: Date;

  @Column({ type: 'datetime', nullable: true })
  closedAt: Date;

  // Float of cash placed in the drawer at the start of the shift.
  @Column({ type: 'bigint', default: 0 })
  openingCashMinor: string;

  // Cash counted in the drawer at close; compared against expected cash
  // (opening + cash sales) by the FE/reporting layer, not by this entity.
  @Column({ type: 'bigint', nullable: true })
  closingCashMinor: string;

  @Column({ type: 'enum', enum: PosSessionStatus, default: PosSessionStatus.OPEN })
  status: PosSessionStatus;

  @Column({ nullable: true })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;
}
