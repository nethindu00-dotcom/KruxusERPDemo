import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { PosSaleLine } from './pos-sale-line.entity';

export enum PosTenderType {
  CASH = 'CASH',
  CARD = 'CARD',
  ON_ACCOUNT = 'ON_ACCOUNT',
}

export enum PosSaleStatus {
  COMPLETED = 'COMPLETED',
  VOIDED = 'VOIDED',
}

@Entity('pos_sale')
@Index(['companyId', 'saleNumber'], { unique: true })
export class PosSale {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column()
  saleNumber: string;

  @Column({ name: 'session_id' })
  sessionId: number;

  // Null only transiently — PosService always resolves a concrete customer
  // (a shared per-company "Walk-in Customer" when none is picked) before a
  // sale is saved, because every sale must post against a real Invoice/AR
  // customer. Left nullable here to match the column semantics asked for.
  @Column({ name: 'customer_id', nullable: true })
  customerId: number;

  @Column({ type: 'datetime' })
  saleDate: Date;

  @Column({ type: 'bigint', default: 0 })
  subtotalMinor: string;

  @Column({ type: 'bigint', default: 0 })
  taxMinor: string;

  @Column({ type: 'bigint', default: 0 })
  totalMinor: string;

  @Column({ type: 'enum', enum: PosTenderType, default: PosTenderType.CASH })
  tenderType: PosTenderType;

  // Amount physically handed over by the customer. For CARD/ON_ACCOUNT this
  // simply equals totalMinor (nothing "tendered" in the cash-drawer sense).
  @Column({ type: 'bigint', default: 0 })
  tenderedMinor: string;

  // CASH only: tenderedMinor - totalMinor. Zero for CARD/ON_ACCOUNT.
  @Column({ type: 'bigint', default: 0 })
  changeMinor: string;

  @Column({ name: 'invoice_id', type: 'bigint' })
  invoiceId: number;

  @Column({ type: 'enum', enum: PosSaleStatus, default: PosSaleStatus.COMPLETED })
  status: PosSaleStatus;

  @Column({ type: 'datetime', nullable: true })
  voidedAt: Date;

  @OneToMany(() => PosSaleLine, (l) => l.sale, { cascade: true })
  lines: PosSaleLine[];

  @CreateDateColumn()
  createdAt: Date;
}
