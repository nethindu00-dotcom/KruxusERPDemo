import { Body, Controller, Get, Param, ParseIntPipe, Post, Query } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import {
  CheckoutInput,
  CloseSessionInput,
  OpenSessionInput,
  PosService,
} from './pos.service';

@Controller('pos')
export class PosController {
  constructor(private svc: PosService) {}

  @Post('sessions/open')
  openSession(@Body() body: Partial<OpenSessionInput>, @CurrentUser() user: any) {
    return this.svc.openSession({ ...body, cashierId: body.cashierId ?? user?.id } as OpenSessionInput);
  }

  @Post('sessions/:id/close')
  closeSession(@Param('id', ParseIntPipe) id: number, @Body() body: Omit<CloseSessionInput, 'sessionId'>) {
    return this.svc.closeSession({ ...body, sessionId: id });
  }

  @Get('sessions')
  listSessions(@Query('companyId', ParseIntPipe) companyId: number) {
    return this.svc.listSessions(companyId);
  }

  @Get('items/lookup')
  lookupItem(@Query('companyId', ParseIntPipe) companyId: number, @Query('query') query: string) {
    return this.svc.lookupItem({ companyId, query });
  }

  @Post('checkout')
  checkout(@Body() body: Partial<CheckoutInput>, @CurrentUser() user: any) {
    return this.svc.checkout({ ...body, cashierId: body.cashierId ?? user?.id } as CheckoutInput);
  }

  @Post('sales/:id/void')
  voidSale(@Param('id', ParseIntPipe) id: number) {
    return this.svc.voidSale(id);
  }

  @Get('sales')
  listSales(
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('sessionId') sessionId?: string,
  ) {
    return this.svc.listSales(companyId, sessionId ? Number(sessionId) : undefined);
  }

  @Get('daily-summary')
  dailySummary(@Query('companyId', ParseIntPipe) companyId: number, @Query('date') date: string) {
    return this.svc.dailySummary(companyId, date);
  }
}
