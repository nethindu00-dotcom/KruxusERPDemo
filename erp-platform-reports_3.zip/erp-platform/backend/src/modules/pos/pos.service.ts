import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { Customer } from '../receivables/customer.entity';
import { CreateInvoiceLineInput, InvoicesService } from '../receivables/invoices.service';
import { ReceiptsService } from '../receivables/receipts.service';
import { ItemType } from '../inventory/item.entity';
import { ItemsService } from '../inventory/items.service';
import { TaxService } from '../tax/tax.service';
import { PosSession, PosSessionStatus } from './pos-session.entity';
import { PosSale, PosSaleStatus, PosTenderType } from './pos-sale.entity';
import { PosSaleLine } from './pos-sale-line.entity';

export interface OpenSessionInput {
  companyId: number;
  branchId?: number;
  cashierId: number;
  openingCashMinor?: number;
}

export interface CloseSessionInput {
  sessionId: number;
  closingCashMinor: number;
  notes?: string;
}

export interface LookupItemInput {
  companyId: number;
  query: string;
}

export interface LookupItemResult {
  id: number;
  sku: string;
  name: string;
  itemType: ItemType;
  salesPriceMinor: number;
  currencyCode: string;
  // Only populated for STOCK-type items (service/non-stock items have no
  // meaningful on-hand quantity).
  quantityOnHand?: number;
}

export interface CheckoutLineInput {
  itemId: number;
  quantity: number;
  // Defaults to the item's salesPriceMinor when omitted.
  unitPriceMinor?: number;
}

export interface CheckoutInput {
  companyId: number;
  sessionId: number;
  cashierId: number;
  // Omit for a walk-in sale: a single shared "Walk-in Customer" row per
  // company is found-or-created and used instead.
  customerId?: number;
  lines: CheckoutLineInput[];
  tenderType: PosTenderType;
  // CASH only: amount physically handed over. Defaults to the sale total
  // (i.e. exact change) when omitted, and is ignored for CARD/ON_ACCOUNT.
  tenderedMinor?: number;
  // The GL cash/bank account CASH or CARD tenders settle into — required
  // for those two tender types since Receivables' ReceiptsService needs a
  // concrete bankAccountGlAccountId. Not used for ON_ACCOUNT.
  cashOrCardAccountId?: number;
  // Used only the very first time a company's "Walk-in Customer" row is
  // created (see findOrCreateWalkInCustomer) — postInvoice() requires every
  // customer to have an arControlAccountId configured, and a brand-new
  // walk-in customer has none until one is supplied here. Once created,
  // later checkouts for the same company reuse that row and this is ignored.
  arControlAccountId?: number;
}

export interface CheckoutResult {
  sale: PosSale;
  invoiceNumber: string;
  changeMinor: number;
}

export interface DailySummary {
  companyId: number;
  date: string;
  salesCount: number;
  totalMinor: number;
  byTenderType: Record<string, { count: number; totalMinor: number }>;
}

const WALKIN_CUSTOMER_CODE = 'WALKIN';

@Injectable()
export class PosService {
  constructor(
    private store: DataStore,
    private itemsService: ItemsService,
    private taxService: TaxService,
    private invoicesService: InvoicesService,
    private receiptsService: ReceiptsService,
  ) {}

  // ---------------------------------------------------------------------
  // Sessions
  // ---------------------------------------------------------------------

  async findOpenSession(companyId: number, cashierId: number): Promise<PosSession | null> {
    return (
      this.store.findOne<PosSession>(
        'posSession',
        (s: any) => s.companyId === companyId && s.cashierId === cashierId && s.status === PosSessionStatus.OPEN,
      ) ?? null
    );
  }

  async openSession(input: OpenSessionInput): Promise<PosSession> {
    const existing = await this.findOpenSession(input.companyId, input.cashierId);
    if (existing) {
      throw new BadRequestException(`Cashier already has an open POS session (#${existing.id})`);
    }
    const session = {
      companyId: input.companyId,
      branchId: input.branchId,
      cashierId: input.cashierId,
      openedAt: new Date(),
      closedAt: null,
      openingCashMinor: String(Math.round(input.openingCashMinor ?? 0)),
      closingCashMinor: null,
      status: PosSessionStatus.OPEN,
      notes: null,
      createdAt: new Date(),
    };
    return this.store.insert('posSession', session);
  }

  async closeSession(input: CloseSessionInput): Promise<PosSession> {
    const session = this.store.findById<PosSession>('posSession', input.sessionId);
    if (!session) throw new NotFoundException('POS session not found');
    if (session.status !== PosSessionStatus.OPEN) {
      throw new BadRequestException(`POS session #${session.id} is not open`);
    }
    const patch: Record<string, any> = {
      status: PosSessionStatus.CLOSED,
      closedAt: new Date(),
      closingCashMinor: String(Math.round(input.closingCashMinor)),
    };
    if (input.notes) patch.notes = input.notes;
    return this.store.update('posSession', input.sessionId, patch);
  }

  listSessions(companyId: number) {
    return this.store
      .find<PosSession>('posSession', (s: any) => s.companyId === companyId)
      .sort((a: any, b: any) => b.id - a.id);
  }

  // ---------------------------------------------------------------------
  // Item lookup (barcode-scan / search box fast path)
  // ---------------------------------------------------------------------

  async lookupItem(input: LookupItemInput): Promise<LookupItemResult[]> {
    const { companyId, query } = input;
    if (!query) return [];

    // SKU exact match first (what a barcode scanner effectively does), then
    // fall back to a substring search across SKU and name.
    let items = this.store
      .find<any>('item', (i: any) => i.companyId === companyId && i.sku === query && i.isActive)
      .slice(0, 10);
    if (items.length === 0) {
      const needle = query.toLowerCase();
      items = this.store
        .find<any>(
          'item',
          (i: any) =>
            i.companyId === companyId &&
            i.isActive &&
            (String(i.sku).toLowerCase().includes(needle) || String(i.name).toLowerCase().includes(needle)),
        )
        .sort((a: any, b: any) => (a.sku > b.sku ? 1 : a.sku < b.sku ? -1 : 0))
        .slice(0, 20);
    }

    const results: LookupItemResult[] = [];
    for (const item of items) {
      const result: LookupItemResult = {
        id: item.id,
        sku: item.sku,
        name: item.name,
        itemType: item.itemType,
        salesPriceMinor: Number(item.salesPriceMinor),
        currencyCode: item.currencyCode,
      };
      if (item.itemType === ItemType.STOCK) {
        const stock = await this.itemsService.getCurrentStock(item.id);
        result.quantityOnHand = stock.quantityOnHand;
      }
      results.push(result);
    }
    return results;
  }

  // ---------------------------------------------------------------------
  // Walk-in customer — idempotent find-or-create, one row per company.
  // ---------------------------------------------------------------------

  private async findOrCreateWalkInCustomer(companyId: number, arControlAccountId?: number): Promise<Customer> {
    const existing = this.store.findOne<Customer>(
      'customer',
      (c: any) => c.companyId === companyId && c.code === WALKIN_CUSTOMER_CODE,
    );
    if (existing) return existing;

    const customer = {
      companyId,
      code: WALKIN_CUSTOMER_CODE,
      name: 'Walk-in Customer',
      email: null,
      phone: null,
      address: null,
      defaultCurrencyCode: 'LKR',
      creditTermsDays: 30,
      creditLimitMinor: null,
      arControlAccountId,
      isActive: true,
    };
    return this.store.insert('customer', customer);
  }

  private async nextSaleNumber(companyId: number): Promise<string> {
    return this.store.nextDocNumber('posSale', 'saleNumber', companyId, `POS-${companyId}-`, 0);
  }

  // ---------------------------------------------------------------------
  // Checkout — the core POS operation.
  //
  // NOTE on transactionality: AccountingService.post (called indirectly by
  // InvoicesService.postInvoice, ItemsService.postIssue and
  // ReceiptsService.createReceipt) already wraps ITS OWN posting logic.
  // Wrapping this whole method in one outer transaction as well would
  // require either passing shared state through three other modules'
  // services (a bigger refactor of code this task says not to touch) or
  // nesting transactions, which the in-memory store does not support. This
  // is therefore best-effort sequential: invoice create+post, then stock
  // issues, then settlement, then the PosSale row. If a later step throws,
  // earlier steps (e.g. the posted invoice) are NOT automatically rolled
  // back — acceptable for this demo-scope system, but a real deployment
  // would want a saga/compensation step here.
  // ---------------------------------------------------------------------

  async checkout(input: CheckoutInput): Promise<CheckoutResult> {
    if (!input.lines || input.lines.length === 0) {
      throw new BadRequestException('A POS sale needs at least one line');
    }

    const session = this.store.findById<PosSession>('posSession', input.sessionId);
    if (!session) throw new NotFoundException('POS session not found');
    if (session.status !== PosSessionStatus.OPEN) {
      throw new BadRequestException(`POS session #${session.id} is not open`);
    }

    if (
      (input.tenderType === PosTenderType.CASH || input.tenderType === PosTenderType.CARD) &&
      !input.cashOrCardAccountId
    ) {
      throw new BadRequestException('cashOrCardAccountId is required to settle a CASH or CARD sale');
    }

    // Resolve the customer to invoice against.
    let customerId = input.customerId;
    if (!customerId) {
      const walkIn = await this.findOrCreateWalkInCustomer(input.companyId, input.arControlAccountId);
      customerId = walkIn.id;
    }

    const today = new Date().toISOString().slice(0, 10);

    // Load each item up front: we need itemType (stock vs service) for the
    // issue step regardless of what InvoicesService does internally, and we
    // need salesPriceMinor to default a line's unit price.
    const items = await Promise.all(input.lines.map((l) => this.itemsService.findItem(l.itemId)));

    const invoiceLines: CreateInvoiceLineInput[] = input.lines.map((l, i) => ({
      itemId: items[i].id,
      description: items[i].name,
      quantity: l.quantity,
      unitPriceMinor: l.unitPriceMinor ?? Number(items[i].salesPriceMinor),
    }));

    // a-c: create a DRAFT invoice (InvoicesService.create resolves each
    // line's tax rate via ItemsService.resolveGlAccounts the same way a
    // normal sales invoice does) and immediately post it, exactly like a
    // regular sales invoice would be — nothing POS-specific about the GL.
    const draftInvoice = await this.invoicesService.create({
      companyId: input.companyId,
      customerId,
      invoiceDate: today,
      dueDate: today,
      lines: invoiceLines,
    });
    const invoice = await this.invoicesService.postInvoice(draftInvoice.id);

    // d: issue stock for STOCK-type lines only (SERVICE/NON_STOCK items have
    // nothing to decrement). ItemsService.postIssue posts its own COGS/
    // inventory GL entry at current weighted-average cost.
    for (let i = 0; i < input.lines.length; i++) {
      if (items[i].itemType === ItemType.STOCK) {
        await this.itemsService.postIssue({
          itemId: items[i].id,
          quantity: input.lines[i].quantity,
          movementDate: today,
          sourceType: 'pos_sale',
          sourceId: invoice.invoiceNumber,
          companyId: input.companyId,
        });
      }
    }

    const totalMinor = Number(invoice.totalMinor);

    // e: settle immediately for CASH/CARD; ON_ACCOUNT leaves the invoice
    // open on the customer's AR, like a normal credit sale.
    let tenderedMinor = totalMinor;
    let changeMinor = 0;

    if (input.tenderType === PosTenderType.CASH) {
      tenderedMinor = Math.round(input.tenderedMinor ?? totalMinor);
      if (tenderedMinor < totalMinor) {
        throw new BadRequestException('Tendered amount is less than the sale total');
      }
      changeMinor = tenderedMinor - totalMinor;
      await this.receiptsService.createReceipt({
        companyId: input.companyId,
        customerId,
        receiptDate: today,
        bankAccountGlAccountId: input.cashOrCardAccountId!,
        allocations: [{ invoiceId: invoice.id, allocatedAmountMinor: totalMinor }],
      });
    } else if (input.tenderType === PosTenderType.CARD) {
      tenderedMinor = totalMinor;
      await this.receiptsService.createReceipt({
        companyId: input.companyId,
        customerId,
        receiptDate: today,
        bankAccountGlAccountId: input.cashOrCardAccountId!,
        allocations: [{ invoiceId: invoice.id, allocatedAmountMinor: totalMinor }],
      });
    } else {
      // ON_ACCOUNT: nothing physically tendered, no receipt is posted.
      tenderedMinor = totalMinor;
    }

    // f: save the PosSale + PosSaleLine rows, mirroring the posted invoice's
    // own lines (same order InvoicesService.create built them in) so the
    // figures on the POS receipt always match the GL/AR exactly.
    const sale: any = {
      companyId: input.companyId,
      saleNumber: await this.nextSaleNumber(input.companyId),
      sessionId: input.sessionId,
      customerId,
      saleDate: new Date().toISOString(),
      subtotalMinor: invoice.subtotalMinor,
      taxMinor: invoice.taxMinor,
      totalMinor: invoice.totalMinor,
      tenderType: input.tenderType,
      tenderedMinor: String(tenderedMinor),
      changeMinor: String(changeMinor),
      invoiceId: invoice.id,
      status: PosSaleStatus.COMPLETED,
      voidedAt: null,
      createdAt: new Date(),
    };
    const saved = this.store.insert('posSale', sale);

    const saleLines = (invoice.lines as any[]).map((invLine: any) =>
      this.store.insert('posSaleLine', {
        saleId: saved.id,
        itemId: invLine.itemId,
        description: invLine.description,
        quantity: invLine.quantity,
        unitPriceMinor: invLine.unitPriceMinor,
        taxRateId: invLine.taxRateId,
        lineTotalMinor: invLine.lineTotalMinor,
      }),
    );
    saved.lines = saleLines;

    return { sale: saved, invoiceNumber: invoice.invoiceNumber, changeMinor };
  }

  // ---------------------------------------------------------------------
  // Void — demo-scope: flags the sale only.
  //
  // True reversal would need to: reverse the linked Invoice's journal entry
  // (AccountingService.reverse(invoice.journalEntryId)), reverse/credit-note
  // the settling Receipt if the sale was CASH/CARD (ReceiptsService has no
  // "unapply"/reversal method today), and reverse each StockMovement the
  // sale created (ItemsService has postReceipt/postIssue/postAdjustment but
  // no "reverse a specific movement" entry point). None of that is attempted
  // here — this only marks the sale VOIDED for reporting purposes.
  // ---------------------------------------------------------------------

  async voidSale(saleId: number): Promise<PosSale> {
    const sale = this.store.findById<any>('posSale', saleId);
    if (!sale) throw new NotFoundException('POS sale not found');
    if (sale.status === PosSaleStatus.VOIDED) {
      throw new BadRequestException(`Sale ${sale.saleNumber} is already voided`);
    }
    const updated = this.store.update('posSale', saleId, {
      status: PosSaleStatus.VOIDED,
      voidedAt: new Date(),
    });
    updated.lines = this.store.find<PosSaleLine>('posSaleLine', (l: any) => l.saleId === saleId);
    return updated;
  }

  listSales(companyId: number, sessionId?: number) {
    const sales = this.store
      .find<any>(
        'posSale',
        (s: any) => s.companyId === companyId && (sessionId ? s.sessionId === sessionId : true),
      )
      .sort((a: any, b: any) => b.id - a.id);
    for (const sale of sales) {
      sale.lines = this.store.find<PosSaleLine>('posSaleLine', (l: any) => l.saleId === sale.id);
    }
    return sales;
  }

  // ---------------------------------------------------------------------
  // End-of-day reporting
  // ---------------------------------------------------------------------

  async dailySummary(companyId: number, date: string): Promise<DailySummary> {
    const sales = this.store.find<any>(
      'posSale',
      (s: any) =>
        s.companyId === companyId && s.status === PosSaleStatus.COMPLETED && String(s.saleDate).slice(0, 10) === date,
    );

    const byTenderType: Record<string, { count: number; totalMinor: number }> = {};
    let totalMinor = 0;

    for (const sale of sales) {
      const amount = Number(sale.totalMinor);
      totalMinor += amount;
      const bucket = byTenderType[sale.tenderType] ?? { count: 0, totalMinor: 0 };
      bucket.count += 1;
      bucket.totalMinor += amount;
      byTenderType[sale.tenderType] = bucket;
    }

    return {
      companyId,
      date,
      salesCount: sales.length,
      totalMinor,
      byTenderType,
    };
  }
}
