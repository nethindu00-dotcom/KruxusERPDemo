import { Module } from '@nestjs/common';
import { AccountingModule } from '../accounting/accounting.module';
import { InventoryModule } from '../inventory/inventory.module';
import { ReceivablesModule } from '../receivables/receivables.module';
import { TaxModule } from '../tax/tax.module';
import { PosService } from './pos.service';
import { PosController } from './pos.controller';

@Module({
  imports: [AccountingModule, InventoryModule, ReceivablesModule, TaxModule],
  providers: [PosService],
  controllers: [PosController],
  exports: [PosService],
})
export class PosModule {}
