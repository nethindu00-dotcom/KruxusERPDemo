import { Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';
import { AccountingService } from '../accounting/accounting.service';

export interface AddRateInput {
  companyId: number;
  fromCurrency: string;
  toCurrency: string;
  rateDate: string;
  rate: number;
  source?: string;
}

export interface RevalueOpenBalancesInput {
  companyId: number;
  asOfDate: string;
  unrealizedGainAccountId: number;
  unrealizedLossAccountId: number;
}

const DEFAULT_CURRENCIES: Array<{ code: string; name: string; symbol: string; decimalPlaces?: number }> = [
  { code: 'LKR', name: 'Sri Lankan Rupee', symbol: 'Rs' },
  { code: 'USD', name: 'US Dollar', symbol: '$' },
  { code: 'GBP', name: 'British Pound', symbol: '£' },
  { code: 'EUR', name: 'Euro', symbol: '€' },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
];

@Injectable()
export class CurrencyService {
  constructor(
    private store: DataStore,
    private accountingService: AccountingService,
  ) {}

  async listCurrencies() {
    return this.store
      .find<any>('currency')
      .slice()
      .sort((a, b) => (a.code > b.code ? 1 : a.code < b.code ? -1 : 0));
  }

  /** Idempotent: only inserts currencies whose code isn't already present. */
  async seedDefaultCurrencies() {
    const existing = this.store.find<any>('currency');
    const existingCodes = new Set(existing.map((c) => c.code));
    const toInsert = DEFAULT_CURRENCIES.filter((c) => !existingCodes.has(c.code));
    if (toInsert.length > 0) {
      const now = new Date();
      for (const c of toInsert) {
        this.store.insert('currency', {
          code: c.code,
          name: c.name,
          symbol: c.symbol,
          decimalPlaces: c.decimalPlaces ?? 2,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        });
      }
    }
    return this.listCurrencies();
  }

  async addRate(input: AddRateInput) {
    const existing = this.store.findOne<any>(
      'exchangeRate',
      (r) =>
        r.companyId === input.companyId &&
        r.fromCurrency === input.fromCurrency &&
        r.toCurrency === input.toCurrency &&
        r.rateDate === input.rateDate,
    );
    const now = new Date();
    if (existing) {
      this.store.update('exchangeRate', existing.id, {
        rate: String(input.rate),
        source: input.source ?? 'manual',
        updatedAt: now,
      });
    } else {
      this.store.insert('exchangeRate', {
        companyId: input.companyId,
        fromCurrency: input.fromCurrency,
        toCurrency: input.toCurrency,
        rateDate: input.rateDate,
        rate: String(input.rate),
        source: input.source ?? 'manual',
        createdAt: now,
        updatedAt: now,
      });
    }
    return this.store.findOne<any>(
      'exchangeRate',
      (r) =>
        r.companyId === input.companyId &&
        r.fromCurrency === input.fromCurrency &&
        r.toCurrency === input.toCurrency &&
        r.rateDate === input.rateDate,
    );
  }

  async rateHistory(companyId: number, fromCurrency: string, toCurrency: string) {
    return this.store
      .find<any>(
        'exchangeRate',
        (r) => r.companyId === companyId && r.fromCurrency === fromCurrency && r.toCurrency === toCurrency,
      )
      .sort((a, b) => (a.rateDate < b.rateDate ? 1 : a.rateDate > b.rateDate ? -1 : 0));
  }

  /** Latest rate with rateDate <= asOfDate for the given pair. 1:1 for same currency, no DB hit. */
  async getRate(companyId: number, fromCurrency: string, toCurrency: string, asOfDate: string): Promise<number> {
    if (fromCurrency === toCurrency) return 1;
    const candidates = this.store
      .find<any>(
        'exchangeRate',
        (r) =>
          r.companyId === companyId &&
          r.fromCurrency === fromCurrency &&
          r.toCurrency === toCurrency &&
          r.rateDate <= asOfDate,
      )
      .sort((a, b) => (a.rateDate < b.rateDate ? 1 : a.rateDate > b.rateDate ? -1 : 0));
    const row = candidates[0];
    if (!row) {
      throw new NotFoundException(
        `No exchange rate found for ${fromCurrency} -> ${toCurrency} on or before ${asOfDate} (company ${companyId})`,
      );
    }
    return Number(row.rate);
  }

  async convert(
    companyId: number,
    amountMinor: number,
    fromCurrency: string,
    toCurrency: string,
    asOfDate: string,
  ): Promise<number> {
    const rate = await this.getRate(companyId, fromCurrency, toCurrency, asOfDate);
    return Math.round(amountMinor * rate);
  }

  /**
   * Pure helper for AP/AR settlement postings: the gain/loss realized when a
   * foreign-currency balance booked at `originalRate` is settled at `settlementRate`.
   * Positive = gain, negative = loss. Callers post the result themselves via
   * AccountingService.post — this module does not wire the AP/AR integration.
   */
  realizedGainLoss(params: {
    companyId: number;
    originalAmountMinor: number;
    originalRate: number;
    settlementRate: number;
    currencyCode: string;
  }): number {
    return Math.round(params.originalAmountMinor * (params.settlementRate - params.originalRate));
  }

  /**
   * Period-end FX revaluation. Finds every posted journal-line balance still
   * open in a foreign currency as of `asOfDate`, re-converts it at today's
   * rate, and posts ONE combined entry for the net unrealized gain/loss per
   * account/party/currency group.
   *
   * Simplifying assumption (documented, not a bug): rather than looking up
   * each account's type (asset/liability/...) to decide the correct debit/
   * credit direction, we always debit the revalued account and credit the
   * unrealized-gain account when the adjustment is positive, and credit the
   * revalued account and debit the unrealized-loss account when it is
   * negative. Because the foreign balance and its booked base value are both
   * computed the same way (debit - credit / baseDebit - baseCredit), this
   * happens to produce the correct accounting direction for both debit-normal
   * accounts (e.g. a USD receivable) and credit-normal accounts (e.g. a USD
   * payable) without a type lookup, and the entry always balances because
   * each group contributes exactly one debit leg and one credit leg of the
   * same magnitude. This module does not need to be perfectly correct for
   * every conceivable account type to be a convincing demo, but it does need
   * to actually balance and actually run — which this does.
   */
  async revalueOpenBalances(input: RevalueOpenBalancesInput) {
    const { companyId, asOfDate, unrealizedGainAccountId, unrealizedLossAccountId } = input;

    const company = this.store.findOne<any>('company', (c) => c.id === companyId);
    if (!company) {
      throw new NotFoundException(`Company ${companyId} not found`);
    }
    const baseCurrency = company.baseCurrency;

    const postedEntryIds = new Set(
      this.store
        .find<any>(
          'journalEntry',
          (e) => e.companyId === companyId && e.status === 'POSTED' && e.entryDate <= asOfDate,
        )
        .map((e) => e.id),
    );

    const matchingLines = this.store.find<any>(
      'journalLine',
      (l) => postedEntryIds.has(l.entryId) && l.currencyCode !== baseCurrency,
    );

    const groups = new Map<
      string,
      { accountId: number; partyId: number | null; currencyCode: string; foreignBalanceMinor: number; bookedBaseValueMinor: number }
    >();

    for (const l of matchingLines) {
      const partyId = l.partyId === null || l.partyId === undefined ? null : Number(l.partyId);
      const key = `${l.accountId}|${partyId}|${l.currencyCode}`;
      const existing = groups.get(key);
      const debitMinor = Number(l.debitMinor || 0);
      const creditMinor = Number(l.creditMinor || 0);
      const baseDebitMinor = Number(l.baseDebitMinor || 0);
      const baseCreditMinor = Number(l.baseCreditMinor || 0);
      if (existing) {
        existing.foreignBalanceMinor += debitMinor - creditMinor;
        existing.bookedBaseValueMinor += baseDebitMinor - baseCreditMinor;
      } else {
        groups.set(key, {
          accountId: l.accountId,
          partyId,
          currencyCode: l.currencyCode,
          foreignBalanceMinor: debitMinor - creditMinor,
          bookedBaseValueMinor: baseDebitMinor - baseCreditMinor,
        });
      }
    }

    const adjustments: Array<{
      accountId: number;
      currencyCode: string;
      partyId: number | null;
      foreignBalanceMinor: number;
      oldBaseValueMinor: number;
      newBaseValueMinor: number;
      adjustmentMinor: number;
    }> = [];

    const lines: Array<{
      accountId: number;
      description: string;
      debitMinor?: number;
      creditMinor?: number;
      currencyCode: string;
      exchangeRate: number;
      partyType?: string;
      partyId?: number;
    }> = [];

    for (const row of groups.values()) {
      const foreignBalanceMinor = row.foreignBalanceMinor;
      if (foreignBalanceMinor === 0) continue;

      const accountId = row.accountId;
      const currencyCode = row.currencyCode;
      const partyId = row.partyId;
      const bookedBaseValueMinor = row.bookedBaseValueMinor;

      const currentRate = await this.getRate(companyId, currencyCode, baseCurrency, asOfDate);
      const newBaseValueMinor = Math.round(foreignBalanceMinor * currentRate);
      const adjustmentMinor = newBaseValueMinor - bookedBaseValueMinor;

      if (adjustmentMinor === 0) continue;

      adjustments.push({
        accountId,
        currencyCode,
        partyId,
        foreignBalanceMinor,
        oldBaseValueMinor: bookedBaseValueMinor,
        newBaseValueMinor,
        adjustmentMinor,
      });

      const memo = `FX revaluation: ${currencyCode} balance on account ${accountId} as of ${asOfDate}`;
      if (adjustmentMinor > 0) {
        lines.push({
          accountId,
          description: memo,
          debitMinor: adjustmentMinor,
          currencyCode: baseCurrency,
          exchangeRate: 1,
          partyId: partyId ?? undefined,
        });
        lines.push({
          accountId: unrealizedGainAccountId,
          description: memo,
          creditMinor: adjustmentMinor,
          currencyCode: baseCurrency,
          exchangeRate: 1,
        });
      } else {
        const amount = -adjustmentMinor;
        lines.push({
          accountId,
          description: memo,
          creditMinor: amount,
          currencyCode: baseCurrency,
          exchangeRate: 1,
          partyId: partyId ?? undefined,
        });
        lines.push({
          accountId: unrealizedLossAccountId,
          description: memo,
          debitMinor: amount,
          currencyCode: baseCurrency,
          exchangeRate: 1,
        });
      }
    }

    if (adjustments.length === 0) {
      return { companyId, asOfDate, adjustments: [], journalEntryId: null };
    }

    const entry = await this.accountingService.post({
      companyId,
      entryDate: asOfDate,
      memo: `FX revaluation as of ${asOfDate}`,
      sourceType: 'fx_revaluation',
      lines,
    });

    return { companyId, asOfDate, adjustments, journalEntryId: entry.id };
  }
}
