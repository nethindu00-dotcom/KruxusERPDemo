import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('exchange_rate')
@Index(['companyId', 'fromCurrency', 'toCurrency', 'rateDate'], { unique: true })
export class ExchangeRate {
  @PrimaryGeneratedColumn('increment', { type: 'bigint' })
  id: number;

  @Column({ name: 'company_id' })
  companyId: number;

  @Column({ name: 'from_currency' })
  fromCurrency: string;

  @Column({ name: 'to_currency' })
  toCurrency: string;

  @Column({ name: 'rate_date', type: 'date' })
  rateDate: string;

  // 1 fromCurrency = `rate` toCurrency
  @Column({ type: 'decimal', precision: 18, scale: 6 })
  rate: string;

  @Column({ nullable: true })
  source: string; // 'manual' | 'CBSL' | ...

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
