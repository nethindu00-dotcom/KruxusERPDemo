import { Body, Controller, Get, ParseIntPipe, Post, Query } from '@nestjs/common';
import { CurrencyService } from './currency.service';

@Controller('currencies')
export class CurrencyController {
  constructor(private svc: CurrencyService) {}

  @Get()
  list() {
    return this.svc.listCurrencies();
  }

  @Post('seed-defaults')
  seedDefaults() {
    return this.svc.seedDefaultCurrencies();
  }

  @Get('rates')
  async getRate(
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('fromCurrency') fromCurrency: string,
    @Query('toCurrency') toCurrency: string,
    @Query('asOfDate') asOfDate: string,
  ) {
    const rate = await this.svc.getRate(companyId, fromCurrency, toCurrency, asOfDate);
    return { rate };
  }

  @Post('rates')
  addRate(@Body() body: any) {
    return this.svc.addRate(body);
  }

  @Get('rates/history')
  history(
    @Query('companyId', ParseIntPipe) companyId: number,
    @Query('fromCurrency') fromCurrency: string,
    @Query('toCurrency') toCurrency: string,
  ) {
    return this.svc.rateHistory(companyId, fromCurrency, toCurrency);
  }

  @Post('revalue')
  revalue(@Body() body: any) {
    return this.svc.revalueOpenBalances(body);
  }
}
