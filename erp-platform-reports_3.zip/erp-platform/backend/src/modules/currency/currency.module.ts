import { Module } from '@nestjs/common';
import { CurrencyService } from './currency.service';
import { CurrencyController } from './currency.controller';
import { AccountingModule } from '../accounting/accounting.module';
import { CompaniesModule } from '../companies/companies.module';

@Module({
  imports: [AccountingModule, CompaniesModule],
  providers: [CurrencyService],
  controllers: [CurrencyController],
  exports: [CurrencyService],
})
export class CurrencyModule {}
