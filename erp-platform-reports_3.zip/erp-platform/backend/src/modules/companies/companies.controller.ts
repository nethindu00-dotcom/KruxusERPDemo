import { Body, Controller, Get, Param, ParseIntPipe, Post } from '@nestjs/common';
import { CompaniesService } from './companies.service';

@Controller('companies')
export class CompaniesController {
  constructor(private svc: CompaniesService) {}

  @Get()
  findAll() {
    return this.svc.findAll();
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findOne(id);
  }

  @Get(':id/branches')
  branches(@Param('id', ParseIntPipe) id: number) {
    return this.svc.findBranches(id);
  }

  @Post()
  create(@Body() body: any) {
    return this.svc.create(body);
  }

  @Post(':id/branches')
  createBranch(@Param('id', ParseIntPipe) id: number, @Body() body: any) {
    return this.svc.createBranch(id, body);
  }
}
