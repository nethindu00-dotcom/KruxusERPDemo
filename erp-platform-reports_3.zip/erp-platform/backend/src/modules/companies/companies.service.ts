import { Injectable, NotFoundException } from '@nestjs/common';
import { DataStore } from '../../database/data-store';

@Injectable()
export class CompaniesService {
  constructor(private store: DataStore) {}

  findAll() {
    return this.store.find<any>('company').sort((a, b) => a.id - b.id);
  }

  async findOne(id: number) {
    const c = this.store.findById<any>('company', id);
    if (!c) throw new NotFoundException('Company not found');
    return c;
  }

  findBranches(companyId: number) {
    return this.store
      .find<any>('branch', (b) => b.companyId === companyId)
      .sort((a, b) => a.id - b.id);
  }

  async create(data: any) {
    return this.store.insert('company', { ...data });
  }

  async createBranch(companyId: number, data: any) {
    return this.store.insert('branch', { ...data, companyId });
  }
}
