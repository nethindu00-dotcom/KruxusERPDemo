import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

/**
 * The entire "database" for this build: every entity's rows, loaded once at
 * boot from the bundled JSON snapshots in ./seed-data (a real, verified
 * export of the previous MySQL-backed system - same companies, same figures,
 * same field names). Everything after boot lives only in process memory:
 * writes during a session (new invoices, POS sales, etc.) are visible for
 * the life of the process and are lost on restart. There is no database
 * connection anywhere in this app.
 *
 * Collection names match the dumped file names exactly, e.g. 'account',
 * 'journalEntry', 'journalLine', 'posSaleLine', etc. - the camelCased
 * entity class name.
 */
@Injectable()
export class DataStore implements OnModuleInit {
  private readonly logger = new Logger(DataStore.name);
  private collections = new Map<string, any[]>();
  private idCounters = new Map<string, number>();

  onModuleInit() {
    const dir = path.join(__dirname, 'seed-data');
    const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith('.json')) : [];
    for (const file of files) {
      const name = file.replace(/\.json$/, '');
      const rows = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
      this.collections.set(name, rows);
      let maxId = 0;
      for (const r of rows) {
        const idNum = Number(r?.id);
        if (!isNaN(idNum) && idNum > maxId) maxId = idNum;
      }
      this.idCounters.set(name, maxId);
    }
    this.logger.log(`Loaded ${files.length} in-memory collections from seed-data (no database used)`);
  }

  /** Raw mutable array for a collection (creates an empty one on first use). */
  all<T = any>(name: string): T[] {
    if (!this.collections.has(name)) this.collections.set(name, []);
    return this.collections.get(name) as T[];
  }

  find<T = any>(name: string, predicate?: (row: T) => boolean): T[] {
    const list = this.all<T>(name);
    return predicate ? list.filter(predicate) : list.slice();
  }

  findOne<T = any>(name: string, predicate: (row: T) => boolean): T | undefined {
    return this.all<T>(name).find(predicate);
  }

  findById<T extends { id?: any } = any>(name: string, id: number | string): T | undefined {
    return this.all<T>(name).find((r: any) => String(r.id) === String(id));
  }

  nextId(name: string): number {
    const next = (this.idCounters.get(name) || 0) + 1;
    this.idCounters.set(name, next);
    return next;
  }

  /** Inserts a row, assigning an id if one wasn't already set. Returns the stored row. */
  insert(name: string, row: Record<string, any>): any {
    const list = this.all<any>(name);
    if (row.id == null) {
      row.id = this.nextId(name);
    } else {
      const idNum = Number(row.id);
      if (!isNaN(idNum) && idNum > (this.idCounters.get(name) || 0)) {
        this.idCounters.set(name, idNum);
      }
    }
    list.push(row);
    return row;
  }

  /** Shallow-merges a patch into the row with the given id. Returns the updated row, or undefined if not found. */
  update(name: string, id: number | string, patch: Record<string, any>): any {
    const list = this.all<any>(name);
    const idx = list.findIndex((r) => String(r.id) === String(id));
    if (idx === -1) return undefined;
    list[idx] = { ...list[idx], ...patch };
    return list[idx];
  }

  remove(name: string, id: number | string): boolean {
    const list = this.all<any>(name);
    const idx = list.findIndex((r) => String(r.id) === String(id));
    if (idx === -1) return false;
    list.splice(idx, 1);
    return true;
  }

  /**
   * Next document number of the form `${prefix}${N}` for a company, where N
   * is one more than the highest numeric suffix already used (never the row
   * count, which would re-issue a number after a gap or deletion).
   */
  nextDocNumber(collection: string, field: string, companyId: number, prefix: string, pad = 0): string {
    let max = 0;
    for (const r of this.all<any>(collection)) {
      if (r.companyId !== companyId) continue;
      const v = String(r[field] ?? '');
      if (!v.startsWith(prefix)) continue;
      const n = Number(v.slice(prefix.length));
      if (!isNaN(n) && n > max) max = n;
    }
    const next = String(max + 1);
    return prefix + (pad ? next.padStart(pad, '0') : next);
  }

  count<T = any>(name: string, predicate?: (row: T) => boolean): number {
    return this.find(name, predicate).length;
  }
}
