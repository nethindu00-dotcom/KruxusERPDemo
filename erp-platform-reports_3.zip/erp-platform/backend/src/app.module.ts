import { Module } from '@nestjs/common';
import { APP_GUARD, APP_FILTER } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { AllExceptionsFilter } from './common/filters/all-exceptions.filter';
import { DataStoreModule } from './database/data-store.module';

import { AuthModule } from './modules/auth/auth.module';
import { CompaniesModule } from './modules/companies/companies.module';
import { AccountingModule } from './modules/accounting/accounting.module';
import { TaxModule } from './modules/tax/tax.module';
import { InventoryModule } from './modules/inventory/inventory.module';
import { FixedAssetsModule } from './modules/fixed-assets/fixed-assets.module';
import { CurrencyModule } from './modules/currency/currency.module';
import { PayablesModule } from './modules/payables/payables.module';
import { ReceivablesModule } from './modules/receivables/receivables.module';
import { BankingModule } from './modules/banking/banking.module';
import { PosModule } from './modules/pos/pos.module';
import { ReportsModule } from './modules/reports/reports.module';

// No database anywhere in this app: DataStoreModule loads the bundled JSON
// snapshots in src/database/seed-data into memory once at boot, and every
// module reads/writes that in-memory store instead of a real database.
@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    DataStoreModule,
    AuthModule,
    CompaniesModule,
    AccountingModule,
    TaxModule,
    InventoryModule,
    FixedAssetsModule,
    CurrencyModule,
    PayablesModule,
    ReceivablesModule,
    BankingModule,
    PosModule,
    ReportsModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
  ],
})
export class AppModule {}
