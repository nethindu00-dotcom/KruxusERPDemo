@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo   Kruxus ERP - launcher
echo   (no database required - everything runs
echo   from bundled demo data in memory)
echo ============================================
echo.

REM ---------- 1. Check Node.js ----------
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found.
  echo.
  echo Please install Node.js LTS first:
  echo   1. Go to https://nodejs.org
  echo   2. Download the "LTS" installer and run it ^(click Next, Next, Install, Finish^)
  echo   3. Close this window, then double-click start_kruxus.bat again
  echo.
  pause
  exit /b 1
)

echo Found Node.js. Continuing...
echo.

REM ---------- 2. Stop any copy that is already running ----------
REM (an old Backend/Frontend window left open keeps ports 3001/5173 busy,
REM  so the new version would silently fail to start and the old one
REM  would keep answering)
for %%P in (3001 5173) do (
  for /f "tokens=5" %%a in ('netstat -ano ^| findstr /c:":%%P " ^| findstr LISTENING') do (
    echo Stopping an older Kruxus process on port %%P ^(PID %%a^)...
    taskkill /F /PID %%a >nul 2>nul
  )
)

REM ---------- 3. Dependencies (re-installed whenever package.json changes) ----------
call :ensure_deps backend
if errorlevel 1 exit /b 1
call :ensure_deps frontend
if errorlevel 1 exit /b 1

REM ---------- 4. Start the backend ----------
echo.
echo Starting the backend server in its own window...
start "Kruxus ERP - Backend" cmd /k "cd /d "%~dp0backend" && npm run start:dev"

echo Waiting for the backend to come up...
set "READY=0"
for /l %%i in (1,1,60) do (
  if "!READY!"=="0" (
    curl -s -o nul http://localhost:3001/api/v1/accounting/accounts >nul 2>nul
    if not errorlevel 1 set "READY=1"
    if "!READY!"=="0" timeout /t 1 /nobreak >nul
  )
)
if "!READY!"=="0" (
  echo [ERROR] The backend did not come up within 60 seconds.
  echo Check the "Kruxus ERP - Backend" window for error messages.
  pause
  exit /b 1
)
echo Backend is up.

REM ---------- 5. Start the frontend ----------
echo.
echo Starting the frontend server in its own window...
start "Kruxus ERP - Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev"

echo Waiting for the frontend to come up...
timeout /t 6 /nobreak >nul

start http://localhost:5173

echo.
echo ============================================
echo   Kruxus ERP should now be open in your browser.
echo   Login:  admin@kruxus.local  /  Kruxus@2026
echo.
echo   Leave the two new black windows ^(Backend / Frontend^) open
echo   while you use the app. Close them when you're done.
echo.
echo   Note: this demo build keeps all data in memory -
echo   anything you add (new sales, invoices, etc.) is lost
echo   when you close the Backend window. The bundled demo
echo   data itself never changes.
echo ============================================
echo.
pause
exit /b 0

REM ------------------------------------------------------------------
REM Installs npm packages for a folder when node_modules is missing, or
REM when package.json changed since the last install (e.g. after
REM unzipping a newer version over an older one).
REM ------------------------------------------------------------------
:ensure_deps
set "NEED=0"
if not exist "%~1\node_modules" set "NEED=1"
if not exist "%~1\node_modules\.kruxus-stamp" set "NEED=1"
if "!NEED!"=="0" (
  fc /b "%~1\package.json" "%~1\node_modules\.kruxus-stamp" >nul 2>nul
  if errorlevel 1 set "NEED=1"
)
if "!NEED!"=="1" (
  echo Installing %~1 dependencies ^(first run or after an update - can take a few minutes^)...
  pushd "%~1"
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo [ERROR] npm install failed in %~1. See the messages above.
    popd
    pause
    exit /b 1
  )
  copy /y package.json node_modules\.kruxus-stamp >nul
  popd
)
exit /b 0
